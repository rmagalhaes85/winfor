--
-- PostgreSQL database dump
--

-- Dumped from database version 16.7
-- Dumped by pg_dump version 16.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alunoentity_seq; Type: SEQUENCE; Schema: public; Owner: winfor
--

CREATE SEQUENCE public.alunoentity_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alunoentity_seq OWNER TO winfor;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cursos; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.cursos (
    id integer NOT NULL,
    cod_curso character(4) NOT NULL,
    nome character varying NOT NULL,
    modalidade character varying NOT NULL,
    grau_academico character varying NOT NULL,
    turno character varying NOT NULL,
    grande_area character varying NOT NULL,
    area character varying NOT NULL
);


ALTER TABLE public.cursos OWNER TO winfor;

--
-- Name: cursos_id_seq; Type: SEQUENCE; Schema: public; Owner: winfor
--

CREATE SEQUENCE public.cursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cursos_id_seq OWNER TO winfor;

--
-- Name: cursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: winfor
--

ALTER SEQUENCE public.cursos_id_seq OWNED BY public.cursos.id;


--
-- Name: disciplinas; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.disciplinas (
    id integer NOT NULL,
    codigo character varying NOT NULL,
    descricao character varying,
    carga_horaria integer NOT NULL
);


ALTER TABLE public.disciplinas OWNER TO winfor;

--
-- Name: disciplinas_prequisitos; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.disciplinas_prequisitos (
    disciplina_id integer NOT NULL,
    prequisito_id integer NOT NULL
);


ALTER TABLE public.disciplinas_prequisitos OWNER TO winfor;

--
-- Name: matrizes_curriculares; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.matrizes_curriculares (
    id integer NOT NULL,
    curso_id integer NOT NULL,
    inicio_vigencia date NOT NULL,
    fim_vigencia date NOT NULL
);


ALTER TABLE public.matrizes_curriculares OWNER TO winfor;

--
-- Name: matrizes_curriculares_id_seq; Type: SEQUENCE; Schema: public; Owner: winfor
--

CREATE SEQUENCE public.matrizes_curriculares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.matrizes_curriculares_id_seq OWNER TO winfor;

--
-- Name: matrizes_curriculares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: winfor
--

ALTER SEQUENCE public.matrizes_curriculares_id_seq OWNED BY public.matrizes_curriculares.id;


--
-- Name: matrizes_disciplinas; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.matrizes_disciplinas (
    id integer NOT NULL,
    matriz_curricular_id integer NOT NULL,
    disciplina_id integer NOT NULL,
    semestre smallint,
    tipo character(3) NOT NULL
);


ALTER TABLE public.matrizes_disciplinas OWNER TO winfor;

--
-- Name: matrizes_disciplinas_id_seq; Type: SEQUENCE; Schema: public; Owner: winfor
--

CREATE SEQUENCE public.matrizes_disciplinas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.matrizes_disciplinas_id_seq OWNER TO winfor;

--
-- Name: matrizes_disciplinas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: winfor
--

ALTER SEQUENCE public.matrizes_disciplinas_id_seq OWNED BY public.matrizes_disciplinas.id;


--
-- Name: myentity; Type: TABLE; Schema: public; Owner: winfor
--

CREATE TABLE public.myentity (
    id bigint NOT NULL,
    field character varying(255)
);


ALTER TABLE public.myentity OWNER TO winfor;

--
-- Name: myentity_seq; Type: SEQUENCE; Schema: public; Owner: winfor
--

CREATE SEQUENCE public.myentity_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.myentity_seq OWNER TO winfor;

--
-- Name: cursos id; Type: DEFAULT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.cursos ALTER COLUMN id SET DEFAULT nextval('public.cursos_id_seq'::regclass);


--
-- Name: matrizes_curriculares id; Type: DEFAULT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_curriculares ALTER COLUMN id SET DEFAULT nextval('public.matrizes_curriculares_id_seq'::regclass);


--
-- Name: matrizes_disciplinas id; Type: DEFAULT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_disciplinas ALTER COLUMN id SET DEFAULT nextval('public.matrizes_disciplinas_id_seq'::regclass);


--
-- Data for Name: cursos; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.cursos (id, cod_curso, nome, modalidade, grau_academico, turno, grande_area, area) FROM stdin;
1	0413	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
2	0432	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
3	0439	História 	Presencial	Licenciatura	Noturno	Ciências Humanas	História
4	0443	Geografia 	Presencial	Licenciatura	Noturno	Ciências Humanas	Geografia
5	0446	Ciências Biológicas 	Presencial	Licenciatura	Noturno	Ciências Biológicas	Biologia Geral
6	0447	Matemática 	Presencial	Licenciatura	Vespertino	Ciências Exatas e da Terra	Matemática
7	0450	Administração 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
8	0457	Pedagogia 	Presencial	Licenciatura	Vespertino	Ciências Humanas	Educação
9	0465	Licenciatura Intercultural Indígena	Presencial	Licenciatura	Integral	Linguística, Letras e Artes	Letras
10	0466	Geografia	Presencial	Bacharelado	Noturno	Ciências Humanas	Geografia
11	0467	Pedagogia Intercultural Indígena	Presencial	Licenciatura	Integral	Ciências Humanas	Educação
12	0468	Presencial	Bacharelado	Integral	Ciências da Saúde	Enfermagem	Não encontrado
13	0513	Letras	Presencial	Licenciatura	Matutino	Linguística, Letras e Artes	Letras
14	0525	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
15	0541	Direito	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito
16	0547	Administração 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
17	0548	Ciências Contábeis	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
18	0549	Geografia	Presencial	Licenciatura	Noturno	Ciências Humanas	Geografia
19	0550	História 	Presencial	Licenciatura	Noturno	Ciências Humanas	História
20	0552	Ciências Biológicas 	Presencial	Licenciatura	Vespertino	Ciências Biológicas	Biologia Geral
21	0553	Matemática 	Presencial	Licenciatura	Integral (Vespertino e Noturno)	Ciências Exatas e da Terra	Matemática
22	0562	Psicologia 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Humanas	Psicologia
23	0568	Pedagogia 	Presencial	Licenciatura	Integral (Vespertino e Noturno)	Ciências Humanas	Educação
24	0569	Educação Física 	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Ciências da Saúde	Educação Física
25	0570	Sistemas de Informação 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Ciência da Computação
26	0571	Sistemas de Informação	Presencial	Bacharelado	Noturno	Ciências Exatas e da Terra	Ciência da Computação
27	0572	Pedagogia	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
28	0701	Geografia	Presencial	Bacharelado	Noturno	Ciências Humanas	Geografia
29	0702	Ciências Biológicas	Presencial	Bacharelado	Integral	Ciências Biológicas	Biologia Geral
30	0722	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
31	0728	Pedagogia	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
32	0739	Direito	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Direito
33	0740	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
34	0743	Sistemas de Informação	Presencial	Bacharelado	Noturno	Ciências Exatas e da Terra	Ciência da Computação
35	0744	Medicina 	Presencial	Bacharelado	Integral (Matutino, Vespertino e Noturno)	Ciências da Saúde	Medicina
36	0745	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
37	0781	Direito	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito
38	0783	História	Presencial	Licenciatura	Noturno	Ciências Humanas	História
39	0788	Ciências Biológicas	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Ciências Biológicas	Biologia Geral
40	0789	Matemática	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Matemática
41	0793	Administração	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
42	0795	Ciências Contábeis 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
43	0796	Geografia 	Presencial	Licenciatura	Noturno	Ciências Humanas	Geografia
44	0798	Enfermagem 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Enfermagem
45	0799	Engenharia de Produção 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Engenharias	Engenharia de Produção
46	0803	Sistemas de Informação 	Presencial	Bacharelado	Noturno	Ciências Exatas e da Terra	Ciência da Computação
47	0804	Enfermagem	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Enfermagem
48	0805	Letras	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
49	0806	Direito	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito
50	0901	Administração 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
51	0903	Psicologia  	Presencial	Bacharelado	Integral (Vespertino e Noturno)	Ciências Humanas	Psicologia
52	0904	Matemática 	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Matemática
53	0907	Medicina Veterinária	Presencial	Bacharelado	Integral	Ciências Agrárias	Medicina Veterinária
54	1002	Medicina 	Presencial	Bacharelado	Integral (Matutino, Vespertino e Noturno)	Ciências da Saúde	Medicina
55	1102	Odontologia 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Odontologia
56	1201	Medicina Veterinária 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Agrárias	Medicina Veterinária
57	1203	Zootecnia 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Agrárias	Zootecnia
58	1302	Engenharia Florestal 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Agrárias	Recursos Florestais e Engenharia Florestal
59	1303	Agronomia 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Agrárias	Agronomia
60	1304	Administração	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
61	1305	Engenharia Florestal	Presencial	Bacharelado	Matutino	Ciências Agrárias	Recursos Florestais e Engenharia Florestal
62	1306	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito	Não encontrado
63	1404	História 	Presencial	Licenciatura	Noturno	Ciências Humanas	História
64	1405	Administração 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
65	1407	Ciências Contábeis	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
66	1408	Engenharia de Produção	Presencial	Bacharelado	Integral	Engenharias	Engenharia de Produção
67	1409	Engenharia de Produção	Presencial	Bacharelado	Noturno	Engenharias	Engenharia de Produção
68	1701	Ciências Sociais 	Presencial	Licenciatura	Noturno	Ciências Humanas	Sociologia
69	1702	Pedagogia 	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
70	1703	Administração	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
71	1704	Arquitetura e Urbanismo	Presencial	Bacharelado	Integral	Ciências Sociais Aplicadas	Arquitetura e Urbanismo
72	1801	Matemática 	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Matemática
73	1802	Sistemas de Informação	Presencial	Bacharelado	Noturno	Ciências Exatas e da Terra	Ciência da Computação
74	1803	Pedagogia	Presencial	Licenciatura	Vespertino	Ciências Humanas	Educação
75	1829	Pedagogia	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
76	1830	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito	Não encontrado
77	1904	Ciência da Computação 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Ciência da Computação
78	1905	Engenharia de Computação	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Ciência da Computação
79	1906	Engenharia de Software	Presencial	Bacharelado	Integral (Vespertino e Noturno)	Ciências Exatas e da Terra	Ciência da Computação
80	1907	Sistemas de Informação	Presencial	Bacharelado	Noturno	Ciências Exatas e da Terra	Ciência da Computação
81	2001	Direito	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Direito
82	2002	Direito	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Direito
83	2101	Arquitetura e Urbanismo 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Arquitetura e Urbanismo
84	2102	Engenharia Civil 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Engenharias	Engenharia Civil
85	2103	Engenharia Elétrica 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Engenharias	Engenharia Elétrica
86	2104	Engenharia Ambiental 	Presencial	Bacharelado	Integral (Vespertino e Noturno)	Engenharias	Engenharia Sanitária
87	2106	Engenharia de Produção 	Presencial	Bacharelado	Integral (Vespertino e Noturno)	Engenharias	Engenharia de Produção
88	2109	Geografia 	Presencial	Bacharelado	Noturno	Ciências Humanas	Geografia
89	2111	Engenharia Civil 	Presencial	Bacharelado	Integral (Vespertino e Noturno)	Engenharias	Engenharia Civil
90	2201	Matemática 	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Matemática
91	2202	Matemática	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Matemática
92	2203	Matemática	Presencial	Bacharelado	Matutino	Ciências Exatas e da Terra	Matemática
93	2301	Química 	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Química
94	2302	Química 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Química
95	2304	Engenharia Química	Presencial	Bacharelado	Integral	Engenharias	Engenharia Química
96	2402	Física	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Exatas e da Terra	Física
97	2403	Física	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Física
98	2406	Engenharia Física	Presencial	Bacharelado	Integral	Ciências Exatas e da Terra	Física
99	2501	Administração 	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Administração
100	2502	Administração 	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
101	2503	Turismo 	Presencial	Bacharelado	Matutino	Ciências Sociais Aplicadas	Turismo
102	2504	Ciências Contábeis	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Administração
103	2505	Processos Gerenciais	Presencial	Tecnologia	Noturno	Ciências Sociais Aplicadas	Administração
104	2506	Ciências Econômicas	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Economia
105	2507	Presencial	Bacharelado	Noturno	Ciências Sociais Aplicadas	Economia	Não encontrado
106	2601	Farmácia	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Farmácia
107	2602	Nutrição	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Nutrição
108	2604	Engenharia de Alimentos	Presencial	Bacharelado	Integral	Ciências Agrárias	Ciência e Tecnologia de Alimentos
109	2701	Ciências Biológicas	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Biológicas	Biologia Geral
110	2703	Ciências Biológicas	Presencial	Licenciatura	Noturno	Ciências Biológicas	Biologia Geral
111	2801	Enfermagem	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Enfermagem
112	2802	Fisioterapia	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências da Saúde	Fisioterapia e Terapia Ocupacional
113	2901	Artes Visuais	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Linguística, Letras e Artes	Artes
114	2904	Artes Visuais	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Linguística, Letras e Artes	Artes
115	2906	Música	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Artes
116	2907	Jornalismo	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Sociais Aplicadas	Comunicação
117	2908	Letras Português e Espanhol	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Linguística, Letras e Artes	Letras
118	2909	Letras - Português e Inglês	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Linguística, Letras e Artes	Letras
119	2911	Audiovisual	Presencial	Bacharelado	Integral	Ciências Sociais Aplicadas	Comunicação
120	2912	Letras Português e Espanhol	Presencial	Licenciatura	Matutino	Linguística, Letras e Artes	Letras
121	2913	Letras - Português e Inglês	Presencial	Licenciatura	Matutino	Linguística, Letras e Artes	Letras
122	3002	História	Presencial	Licenciatura	Noturno	Ciências Humanas	História
123	3003	Psicologia	Presencial	Bacharelado	Integral (Matutino e Vespertino)	Ciências Humanas	Psicologia
124	3004	Filosofia	Presencial	Licenciatura	Noturno	Ciências Humanas	Filosofia
125	3005	Ciências Sociais	Presencial	Bacharelado	Matutino	Ciências Humanas	Sociologia
126	3008	História	Presencial	Bacharelado	Noturno	Ciências Humanas	História
127	3101	Pedagogia	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Ciências Humanas	Educação
128	3102	Educação Física	Presencial	Licenciatura	Integral (Matutino e Vespertino)	Ciências da Saúde	Educação Física
129	3103	Pedagogia	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
130	3107	Educação Física	Presencial	Bacharelado	Integral	Ciências da Saúde	Educação Física
131	3108	Educação do Campo	Presencial	Licenciatura	Integral	Multidisciplinar	Interdisciplinar
132	3109	Presencial	Licenciatura	Noturno	NÃO SE APLICA (NSA)	Educação	10/03/2025
133	3193	Educação e Processos de Trabalho: Alimentação Escolar	A Distância	Tecnologia	A Distância	Ciências Humanas	Educação
134	3201	Pedagogia	Presencial	Licenciatura	Noturno	Ciências Humanas	Educação
135	3202	Ciências Interdisciplinar	Presencial	Licenciatura	Noturno	Multidisciplinar	Interdisciplinar
136	3203	Matemática	Presencial	Licenciatura	Noturno	Ciências Exatas e da Terra	Matemática
137	3204	Letras Português	Presencial	Licenciatura	Noturno	Linguística, Letras e Artes	Letras
138	3205	A Distância	Tecnologia	A Distância	Ciências Humanas	Educação	01/01/2025
139	3206	A Distância	Tecnologia	A Distância	Ciências Humanas	Educação	15/03/2021
140	3290	Tecnologia de Ciência dos Dados	A Distância	Tecnologia	A Distância	Ciências Exatas e da Terra	Ciência da Computação
141	3291	Processos Gerenciais	A Distância	Tecnologia	A Distância	Ciências Sociais Aplicadas	Administração
142	3292	Tecnologia da Informação	A Distância	Tecnologia	A Distância	Ciências Exatas e da Terra	Ciência da Computação
143	3293	Gestão Comercial	A Distância	Tecnologia	A Distância	Ciências Sociais Aplicadas	Administração
144	3294	Gestão de Recursos Humanos	A Distância	Tecnologia	A Distância	Ciências Sociais Aplicadas	Administração
145	3295	Gestão de Mídias Sociais Digitais	A Distância	Tecnologia	A Distância	Ciências Sociais Aplicadas	Comunicação
146	3296	Gestão de Serviços Jurídicos e Notariais	A Distância	Tecnologia	A Distância	Ciências Sociais Aplicadas	Administração
147	3297	História - Licenciatura	A Distância	Licenciatura	A Distância	Ciências Humanas	História
148	3298	Pedagogia	A Distância	Licenciatura	A Distância	Ciências Humanas	Educação
149	3299	Letras Português e Espanhol	A Distância	Licenciatura	A Distância	Linguística, Letras e Artes	Letras
\.


--
-- Data for Name: disciplinas; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.disciplinas (id, codigo, descricao, carga_horaria) FROM stdin;
43279	0401.000.781-7	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
48275	0401.001.212-9	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
48281	0401.001.218-3	LÍNGUA ESPANHOLA I	68
43698	0401.000.927-7	METODOLOGIA CIENTÍFICA	34
48260	0401.001.197-2	PRÁTICA DE ENSINO I	34
48252	0401.001.189-2	TEORIA DA LITERATURA I	34
48273	0401.001.210-0	FUNDAMENTOS HISTÓRICOS E FILOSÓFICOS DA EDUCAÇÃO	51
48177	0401.001.147-1	LEITURA E PRODUÇÃO DE TEXTOS	68
48274	0401.001.211-0	LÍNGUA ESPANHOLA II	68
48282	0401.001.219-2	PRÁTICA DE ENSINO II	34
48251	0401.001.188-3	TEORIA DA LITERATURA II	34
43710	0401.000.939-3	TÓPICOS GRAMATICAIS EM LÍNGUA PORTUGUESA	34
43750	0401.000.979-6	ESTUDO DE LIBRAS	51
48245	0401.001.182-9	FONÉTICA E FONOLOGIA DA LÍNGUA PORTUGUESA	68
48249	0401.001.186-5	LÍNGUA ESPANHOLA III	68
48222	0401.001.159-8	LITERATURA BRASILEIRA I	34
48221	0401.001.158-9	PRÁTICA DE ENSINO III	34
48218	0401.001.155-1	TECNOLOGIAS APLICADAS AO ENSINO	34
48279	0401.001.216-5	TEORIA DA LITERATURA III	34
48213	0401.001.150-6	LÍNGUA ESPANHOLA IV	68
48256	0401.001.193-6	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
48266	0401.001.203-0	LITERATURA BRASILEIRA II	34
48250	0401.001.187-4	MORFOLOGIA DA LÍNGUA PORTUGUESA	68
48278	0401.001.215-6	PRÁTICA DE ENSINO IV	34
43278	0401.000.780-8	PSICOLOGIA E EDUCAÇÃO	51
48214	0401.001.151-5	TEORIA DA LITERATURA IV	34
48240	0401.001.177-6	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA I	51
48234	0401.001.171-1	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA I	51
34755	0401.000.072-3	FUNDAMENTOS DE DIDÁTICA	51
48231	0401.001.168-7	LÍNGUA ESPANHOLA V	68
48267	0401.001.204-9	LITERATURA BRASILEIRA III	34
48254	0401.001.191-8	LITERATURAS DE LÍNGUA ESPANHOLA I	34
48265	0401.001.202-0	PRÁTICA DE ENSINO DE LÍNGUA ESPANHOLA I	68
48233	0401.001.170-2	SINTAXE DA LÍNGUA PORTUGUESA	68
21921	0402.000.281-8	EDUCAÇÃO ESPECIAL	51
48241	0401.001.178-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA II	51
48216	0401.001.153-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA II	51
48225	0401.001.162-2	LÍNGUA ESPANHOLA VI	68
48289	0401.001.226-3	LITERATURA BRASILEIRA IV	34
48215	0401.001.152-4	LITERATURAS DE LÍNGUA ESPANHOLA II	34
48220	0401.001.157-0	PRÁTICA DE ENSINO DE LÍNGUA ESPANHOLA II	68
48229	0401.001.166-9	SOCIOLINGUÍSTICA	68
48244	0401.001.181-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA III	51
48224	0401.001.161-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA III	51
48276	0401.001.213-8	LÍNGUA ESPANHOLA VII	68
48219	0401.001.156-0	LITERATURA PORTUGUESA I	34
48228	0401.001.165-0	LITERATURAS DE LÍNGUA ESPANHOLA III	34
48283	0401.001.220-9	POLÍTICAS EDUCACIONAIS	51
48217	0401.001.154-2	PRÁTICA DE ENSINO DE LÍNGUA ESPANHOLA III	68
48243	0401.001.180-0	SEMÂNTICA DA LÍNGUA PORTUGUESA	51
48242	0401.001.179-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA IV	51
48232	0401.001.169-6	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA IV	51
48277	0401.001.214-7	LÍNGUA ESPANHOLA VIII	68
48227	0401.001.164-0	LITERATURA PORTUGUESA II	34
48230	0401.001.167-8	LITERATURAS DE LÍNGUA ESPANHOLA IV	34
48226	0401.001.163-1	PRÁTICA DE ENSINO DE LÍNGUA ESPANHOLA IV	68
43755	0401.000.984-9	CONVERSAÇÃO BÁSICA EM LÍNGUA BRASILEIRA DE SINAIS COM FOCO EDUCACIONAL	68
43691	0401.000.920-3	CRÍTICA LITERÁRIA	68
43692	0401.000.921-2	CULTURA BRASILEIRA	68
43723	0401.000.952-6	DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	68
43326	0401.000.828-9	EDUCAÇÃO AMBIENTAL	68
48270	0401.001.207-6	ESTUDOS DE LITERATURA INFANTO-JUVENIL E FORMAÇÃO DE LEITORES	34
37350	0401.000.386-2	ESTUDOS SEMÂNTICO-DISCURSIVOS DA LÍNGUA PORTUGUESA	68
48259	0401.001.196-3	FUNDAMENTOS DO ENSINO DE LITERATURA	34
43690	0401.000.919-7	GÊNEROS TEXTUAIS E DISCURSIVOS: NOÇÕES TEÓRICAS	68
48271	0401.001.208-5	GRAMÁTICA E ENSINO	34
43720	0401.000.949-1	HISTÓRIA DA ÁFRICA E CULTURA AFRO-BRASILEIRA	68
43754	0401.000.983-0	HISTÓRIA DA ARTE	68
48288	0401.001.225-4	HISTÓRIA DA MORTE NO OCIDENTE: PERSPECTIVAS LITERÁRIAS E DE OUTRAS ARTES	68
48262	0401.001.199-0	HISTÓRIA DAS IDEIAS LINGUÍSTICAS NO BRASIL	68
48235	0401.001.172-0	INGLÊS PARA FINS ACADÊMICOS I	68
48236	0401.001.173-0	INGLÊS PARA FINS ACADÊMICOS II	68
43743	0401.000.972-2	INTRODUÇÃO À HISTÓRIA DA LÍNGUA PORTUGUESA	68
43715	0401.000.944-6	INTRODUÇÃO À LÍNGUA LATINA	68
43704	0401.000.933-9	INTRODUÇÃO À LINGUÍSTICA DA LÍNGUA BRASILEIRA DE SINAIS	68
48253	0401.001.190-9	INTRODUÇÃO AOS ESTUDOS CULTURAIS	68
43738	0401.000.967-0	INTRODUÇÃO AOS ESTUDOS DOS POVOS INDÍGENAS	68
43748	0401.000.977-8	INTRODUÇÃO AOS ESTUDOS SOBRE LÍNGUAS E CULTURAS INDÍGENAS FALADAS NO BRASIL	34
43716	0401.000.945-5	INTRODUÇÃO ÀS LITERATURAS CLÁSSICAS	68
48257	0401.001.194-5	LETRAMENTOS EM JOGOS DIGITAIS NO ENSINO DE LÍNGUA INGLESA I	68
48258	0401.001.195-4	LETRAMENTOS EM JOGOS DIGITAIS NO ENSINO DE LÍNGUA INGLESA II	68
43717	0401.000.946-4	LETRAMENTOS TRANSNACIONAIS	68
48223	0401.001.160-4	LIBRAS I	34
48280	0401.001.217-4	LIBRAS II	34
48268	0401.001.205-8	LIBRAS III	34
43696	0401.000.925-9	LÍNGUA ESPANHOLA INSTRUMENTAL I	68
43718	0401.000.947-3	LÍNGUA ESPANHOLA INSTRUMENTAL II	68
48272	0401.001.209-4	LÍNGUA ESPANHOLA PARA FORMAÇÃO DE PROFESSORES I	34
48255	0401.001.192-7	LÍNGUA ESPANHOLA PARA FORMAÇÃO DE PROFESSORES II	34
48285	0401.001.222-7	LINGUAGEM, SIGNIFICAÇÃO E ENSINO	68
43721	0401.000.950-8	LÍNGUA INGLESA INSTRUMENTAL I	68
48286	0401.001.223-6	LÍNGUA INGLESA INSTRUMENTAL II	68
43724	0401.000.953-5	LINGUÍSTICA TEXTUAL	68
43725	0401.000.954-4	LITERATURA COMPARADA	68
43726	0401.000.955-3	LITERATURA E FILOSOFIA	68
43728	0401.000.957-1	LITERATURA EM MATO GROSSO DO SUL	68
43727	0401.000.956-2	LITERATURA E PSICANÁLISE	68
43729	0401.000.958-0	LITERATURA INFANTO-JUVENIL	68
48284	0401.001.221-8	LITERATURA LATINO-AMERICANA DE AUTORIA FEMININA	68
48211	0401.001.148-0	LITERATURA, RETÓRICA E POÉTICA	68
43733	0401.000.962-4	LITERATURAS DE LÍNGUA ESPANHOLA V	68
43730	0401.000.959-0	LITERATURAS DE LÍNGUA INGLESA V	68
48212	0401.001.149-0	MATEMÁTICA	34
48246	0401.001.183-8	METODOLOGIA DA PESQUISA CIENTÍFICA	68
48238	0401.001.175-8	OFICINA DE ANÁLISE LINGUÍSTICA	68
48269	0401.001.206-7	OFICINA DE ESCRITA CRIATIVA	68
43731	0401.000.960-6	OFICINA DE MATERIAL PEDAGÓGICO PARA EDUCAÇÃO DE SURDOS	68
43732	0401.000.961-5	OFICINA DE PRODUÇÃO TEXTUAL	68
48239	0401.001.176-7	OFICINA DE TRADUÇÃO PEDAGÓGICA	68
43714	0401.000.943-7	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
48264	0401.001.201-1	PESQUISA EM LINGUAGENS E PRÁTICA PEDAGÓGICA	34
48237	0401.001.174-9	PORTUGUÊS INSTRUMENTAL I	68
43734	0401.000.963-3	PORTUGUÊS INSTRUMENTAL II	68
43735	0401.000.964-2	PORTUGUÊS INSTRUMENTAL III	68
43751	0401.000.980-2	PRÁTICAS INTEGRADORAS PARA A FORMAÇÃO DOCENTE	68
43286	0401.000.788-0	PROFISSÃO DOCENTE E SAÚDE MENTAL DO PROFESSOR	68
43266	0401.000.768-4	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
48248	0401.001.185-6	REPRESENTAÇÕES DAS MULHERES NA LITERATURA BRASILEIRA E EM OUTRAS LINGUAGENS	68
48261	0401.001.198-1	SEMÂNTICA ARGUMENTATIVA	68
48247	0401.001.184-7	TEMAS DA LITERATURA E DA CULTURA BRASILEIRA CONTEMPORÂNEA	68
43739	0401.000.968-9	TÓPICOS CULTURAIS HISPÂNICOS	68
43736	0401.000.965-1	TÓPICOS DE ANÁLISE DO DISCURSO	68
43737	0401.000.966-0	TÓPICOS DE ARTE DRAMÁTICA	68
43742	0401.000.971-3	TÓPICOS DE SEMIÓTICA	68
48263	0401.001.200-2	TÓPICOS EM SOCIOLINGUÍSTICA	68
43741	0401.000.970-4	TÓPICOS GRAMATICAIS EM LÍNGUA ESPANHOLA	68
43740	0401.000.969-8	TÓPICOS SOBRE EDUCAÇÃO E SURDEZ	68
48287	0401.001.224-5	UNIVERSIDADE BRASILEIRA: HISTÓRIA, POLÍTICAS E DEBATES	68
48295	0401.001.232-5	LÍNGUA INGLESA I	68
48307	0401.001.244-1	LÍNGUA INGLESA II	68
48302	0401.001.239-9	LÍNGUA INGLESA III	68
48297	0401.001.234-3	LÍNGUA INGLESA IV	68
48300	0401.001.237-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA I	51
48306	0401.001.243-2	LÍNGUA INGLESA V	68
48296	0401.001.233-4	LITERATURAS DE LÍNGUA INGLESA I	34
48303	0401.001.240-5	PRÁTICA DE ENSINO DE LÍNGUA INGLESA I	68
48301	0401.001.238-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA II	51
48291	0401.001.228-1	LÍNGUA INGLESA VI	68
48299	0401.001.236-1	LITERATURAS DE LÍNGUA INGLESA II	34
48298	0401.001.235-2	PRÁTICA DE ENSINO DE LÍNGUA INGLESA II	68
48292	0401.001.229-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA III	51
48310	0401.001.247-9	LÍNGUA INGLESA VII	68
48305	0401.001.242-3	LITERATURAS DE LÍNGUA INGLESA III	34
48304	0401.001.241-4	PRÁTICA DE ENSINO DE LÍNGUA INGLESA III	68
48308	0401.001.245-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA IV	51
48311	0401.001.248-8	LÍNGUA INGLESA VIII	68
50109	0709.002.030-3	BIOESTATÍSTICA	34
48309	0401.001.246-0	LITERATURAS DE LÍNGUA INGLESA IV	34
48290	0401.001.227-2	PRÁTICA DE ENSINO DE LÍNGUA INGLESA IV	68
48293	0401.001.230-7	LÍNGUA INGLESA PARA FORMAÇÃO DE PROFESSORES I	34
48294	0401.001.231-6	LÍNGUA INGLESA PARA FORMAÇÃO DE PROFESSORES II	34
43756	0401.000.985-8	LITERATURA DE LÍNGUA ESPANHOLA V	68
48171	0401.001.141-7	ANTROPOLOGIA CULTURAL	68
48152	0401.001.122-0	HISTÓRIA ANTIGA I	68
34727	0401.000.044-8	INTRODUÇÃO AOS ESTUDOS HISTÓRICOS	68
43264	0401.000.766-6	POLÍTICAS EDUCACIONAIS	51
48148	0401.001.118-6	PRÁTICAS DE ENSINO EM HISTÓRIA I	68
48150	0401.001.120-1	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
48153	0401.001.123-9	HISTÓRIA ANTIGA II	68
48169	0401.001.139-1	HISTÓRIA INDÍGENA	68
48151	0401.001.121-0	PRÁTICAS DE ENSINO EM HISTÓRIA II	68
48154	0401.001.124-8	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
48149	0401.001.119-5	ENSINO DE HISTÓRIA E CULTURA AFRO-BRASILEIRA E AFRICANA	68
34737	0401.000.054-5	HISTÓRIA DAS AMÉRICAS INGLESA E ESPANHOLA	68
48155	0401.001.125-7	HISTÓRIA DO BRASIL COLONIAL	68
50135	0709.002.056-4	BIOLOGIA CELULAR	34
48158	0401.001.128-4	HISTÓRIA MEDIEVAL I	68
48161	0401.001.131-9	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
48170	0401.001.140-8	HISTÓRIA DAS AMÉRICAS INDEPENDENTES	68
48173	0401.001.143-5	HISTÓRIA DO BRASIL MONÁRQUICO	68
48160	0401.001.130-0	HISTÓRIA MEDIEVAL II	68
48164	0401.001.134-6	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	100
48174	0401.001.144-4	HISTÓRIA DO BRASIL REPUBLICANO I	68
48162	0401.001.132-8	HISTÓRIA MODERNA I	68
34746	0401.000.063-4	OFICINA DE PRÁTICA DE ENSINO I	68
48167	0401.001.137-3	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	100
34748	0401.000.065-0	HISTÓRIA DO BRASIL REPUBLICANO II	68
48163	0401.001.133-7	HISTÓRIA MODERNA II	68
34751	0401.000.068-5	OFICINA DE PRÁTICA DE ENSINO II	68
48165	0401.001.135-5	PESQUISA HISTÓRICA	68
48172	0401.001.142-6	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	100
48166	0401.001.136-4	HISTÓRIA CONTEMPORÂNEA I	68
48175	0401.001.145-3	LABORATÓRIO DE PRÁTICA DE ENSINO I	68
48176	0401.001.146-2	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	100
33873	0402.000.595-7	ESTUDO DE LIBRAS	51
48168	0401.001.138-2	HISTÓRIA CONTEMPORÂNEA II	68
34764	0401.000.081-2	LABORATÓRIO DE PRÁTICA DE ENSINO II	68
34768	0401.000.085-5	CORPO E SEXUALIDADE, EDUCAÇÃO E EQUIDADE DE GÊNERO	68
43280	0401.000.782-6	DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	68
43686	1991.000.004-3	EMPREENDEDORISMO E INOVAÇÃO	68
34769	0401.000.086-3	ESTUDOS ALTERNATIVOS EM HISTÓRIA DA AMÉRICA	68
34770	0401.000.087-1	ESTUDOS ALTERNATIVOS EM HISTÓRIA DO BRASIL	68
34725	0401.000.042-1	FUNDAMENTOS HISTÓRICOS E FILOSÓFICOS DA EDUCAÇÃO	51
34771	0401.000.088-0	GUERRA DO PARAGUAI: HISTÓRIA, MEMÓRIA E HISTORIOGRAFIA	68
43328	0401.000.830-4	HISTÓRIA AMBIENTAL	68
34772	0401.000.089-8	HISTÓRIA DE MATO GROSSO E MATO GROSSO DO SUL	68
34773	0401.000.090-1	HISTÓRIA DOS IMPRESSOS NO BRASIL	68
34774	0401.000.091-0	HISTÓRIA DOS MEIOS DE COMUNICAÇÃO NO BRASIL	68
34775	0401.000.092-8	HISTÓRIA DOS POVOS INDÍGENAS NA CONTEMPORANEIDADE	68
34776	0401.000.093-6	HISTÓRIA E FRONTEIRAS	68
43327	0401.000.829-8	HISTÓRIA & LINGUAGENS	68
34777	0401.000.094-4	HISTÓRIA SOCIAL DA CULTURA	68
34778	0401.000.095-2	HISTÓRIA SOCIAL DO FUTEBOL	68
34779	0401.000.096-0	HISTÓRIA SOCIAL DO MOVIMENTO OPERÁRIO BRASILEIRO	68
34739	0401.000.056-1	HISTORIOGRAFIA	68
34745	0401.000.062-6	HISTORIOGRAFIA BRASILEIRA	68
34780	0401.000.097-9	INTRODUÇÃO À ARQUEOLOGIA	68
48156	0401.001.126-6	INTRODUÇÃO AOS ESTUDOS CULTURAIS	68
34781	0401.000.098-7	LEITURA E PRODUÇÃO DE TEXTO	68
34782	0401.000.099-5	METODOLOGIA DO TRABALHO CIENTÍFICO	68
43265	0401.000.767-5	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
34783	0401.000.100-2	PATRIMÔNIO ARTÍSTICO CULTURAL E ESPAÇOS DA MEMÓRIA	68
43329	0401.000.831-3	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
43330	0401.000.832-2	TECNOLOGIA DA INFORMAÇÃO E DA COMUNICAÇÃO APLICADAS À EDUCAÇÃO	68
48159	0401.001.129-3	TÓPICOS EM HISTÓRIA DA ÁFRICA	68
48157	0401.001.127-5	TÓPICOS EM HISTÓRIA DA ÁSIA	68
34784	0401.000.101-0	TÓPICOS ESPECIAIS EM HISTÓRIA CONTEMPORÂNEA	68
34785	0401.000.102-9	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA LATINA	68
34786	0401.000.103-7	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL	68
34787	0401.000.104-5	TÓPICOS ESPECIAIS EM HISTÓRIA INDÍGENA	68
34788	0401.000.105-3	TÓPICOS ESPECIAIS EM HISTÓRIA MEDIEVAL	68
34789	0401.000.106-1	TÓPICOS ESPECIAIS EM HISTÓRIA MODERNA	68
34790	0401.000.107-0	TÓPICOS ESPECIAIS EM HISTÓRIA REGIONAL	68
34791	0401.000.108-8	TÓPICOS ESPECIAIS EM HISTORIOGRAFIA DIDÁTICA	68
34792	0401.000.109-6	TÓPICOS ESPECIAIS EM TEORIA DA HISTÓRIA	68
49291	0401.001.340-2	CLIMATOLOGIA	68
49318	0401.001.367-2	ECOLOGIA GERAL	34
49316	0401.001.365-4	ENSINO DE HISTÓRIA DA ÁFRICA E DA CULTURA AFRO-BRASILEIRA	68
49294	0401.001.343-0	FUNDAMENTOS HISTÓRICOS E FILOSÓFICOS DA EDUCAÇÃO	51
49315	0401.001.364-5	GEOGRAFIA DE MATO GROSSO DO SUL	34
49292	0401.001.341-1	GEOLOGIA	68
49297	0401.001.346-7	GEOMORFOLOGIA	68
49290	0401.001.339-6	HISTÓRIA DO PENSAMENTO GEOGRÁFICO	68
49317	0401.001.366-3	MATEMÁTICA	34
49313	0401.001.362-7	PRÁTICA DE ENSINO EM GEOGRAFIA I	68
49300	0401.001.349-4	CARTOGRAFIA	68
49296	0401.001.345-8	HIDROLOGIA	68
49314	0401.001.363-6	PRÁTICA DE ENSINO EM GEOGRAFIA II	68
43452	0401.000.856-5	CARTOGRAFIA TEMÁTICA	34
43457	0401.000.861-8	ESTATÍSTICA	34
49287	0401.001.336-9	GEOGRAFIA AGRÁRIA	68
49301	0401.001.350-0	GEOGRAFIA DA POPULAÇÃO	68
49311	0401.001.360-9	POLÍTICAS EDUCACIONAIS	51
49323	0401.001.372-5	PRÁTICA DE ENSINO EM GEOGRAFIA III	68
49293	0401.001.342-0	BIOGEOGRAFIA	68
49306	0401.001.355-6	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA I	100
49303	0401.001.352-9	PEDOLOGIA	68
49289	0401.001.338-7	PRÁTICA DE ENSINO EM GEOGRAFIA IV	68
49310	0401.001.359-2	TEORIA E MÉTODOS DE GEOGRAFIA	68
49307	0401.001.356-5	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA II	100
49305	0401.001.354-7	GEOGRAFIA ECONÔMICA	68
49320	0401.001.369-0	GEOGRAFIA URBANA	68
49312	0401.001.361-8	MÉTODOS E TÉCNICAS DE PESQUISA	68
49324	0401.001.373-4	PRÁTICA DE ENSINO EM GEOGRAFIA V	68
49302	0401.001.351-0	SENSORIAMENTO REMOTO	68
49295	0401.001.344-9	EDUCAÇÃO AMBIENTAL	34
49299	0401.001.348-5	EDUCAÇÃO DIFERENCIADA	51
49308	0401.001.357-4	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA III	100
43465	0401.000.869-0	GEOGRAFIA POLÍTICA	68
49319	0401.001.368-1	PRÁTICA DE ENSINO EM GEOGRAFIA VI	68
49309	0401.001.358-3	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA IV	100
49321	0401.001.370-7	GEOGRAFIA DO BRASIL	68
49304	0401.001.353-8	GEOGRAFIA REGIONAL	68
43450	0401.000.854-7	ORGANIZAÇÃO DO ESPAÇO GEOGRÁFICO	68
43440	0401.000.844-9	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	34
39358	0401.000.521-0	CLIMATOLOGIA URBANA	34
39359	0401.000.522-9	DEMOGRAFIA	34
49286	0401.001.335-0	DINÂMICA RECENTE DA GEOECONOMIA MUNDIAL	34
39360	0401.000.523-7	ELABORAÇÃO DE PLANO DIRETOR MUNICIPAL	34
43458	0401.000.862-7	ENSINO DE GEOLOGIA E GEOMORFOLOGIA	34
34863	0401.000.169-0	FISIOLOGIA DA PAISAGEM	34
43473	0401.000.877-0	FOTOINTERPRETAÇÃO	34
49322	0401.001.371-6	FUNDAMENTOS DE PRÁTICA DE ENSINO EM GEOGRAFIA	34
49288	0401.001.337-8	FUNDAMENTOS ECONÔMICOS, SOCIAIS E POLÍTICOS DA GEOGRAFIA	34
43451	0401.000.855-6	GEOGRAFIA CULTURAL	34
43441	0401.000.845-8	GEOGRAFIA DA AMÉRICA LATINA	34
39363	0401.000.526-1	GEOGRAFIA DA SAÚDE	34
39364	0401.000.527-0	GEOGRAFIA DAS INDÚSTRIAS	34
34819	0401.000.125-8	GEOGRAFIA DO ESPAÇO MUNDIAL	34
43442	0401.000.846-7	GEOGRAFIA DOS ESPAÇOS URBANOS E RURAIS	34
39366	0401.000.529-6	GEOGRAFIA DOS TRANSPORTES E DA ENERGIA	34
34845	0401.000.151-7	GEOGRAFIA DO TURISMO	34
39367	0401.000.530-0	GEOGRAFIA FÍSICA DO BRASIL	34
39368	0401.000.531-8	GEOGRAFIA HUMANA DO BRASIL	34
49298	0401.001.347-6	GEOGRAFIA INDÍGENA	34
39369	0401.000.532-6	GEOMORFOLOGIA FLUVIAL	34
43467	0401.000.871-6	GEOPROCESSAMENTO	34
39370	0401.000.533-4	GERENCIAMENTO DE RECURSOS HÍDRICOS	34
39371	0401.000.534-2	GERENCIAMENTO DE RESÍDUOS SÓLIDOS	34
34977	0401.000.223-8	HIDROLOGIA AMBIENTAL	34
39372	0401.000.535-0	HISTÓRIA ECONÔMICA DO BRASIL	34
39291	0401.000.474-5	HISTÓRIA GERAL E DO BRASIL	34
39373	0401.000.536-9	INDUSTRIALIZAÇÃO, URBANIZAÇÃO E MEIO AMBIENTE	34
39374	0401.000.537-7	INFORMÁTICA	34
34979	0401.000.225-4	LEGISLAÇÃO URBANA E AMBIENTAL	34
39375	0401.000.538-5	METEOROLOGIA	34
39376	0401.000.539-3	METODOLOGIA DO ENSINO DA GEOGRAFIA	34
39377	0401.000.540-7	MODELAGEM EM GEOGRAFIA	34
34877	0401.000.183-5	PERCEPÇÃO AMBIENTAL	34
34876	0401.000.182-7	PLANEJAMENTO E GESTÃO AMBIENTAL	34
39378	0401.000.541-5	PLANEJAMENTO E GESTÃO REGIONAL	34
43447	0401.000.851-0	PLANEJAMENTO E GESTÃO TERRITORIAL	34
43437	0401.000.841-1	PLANEJAMENTO E GESTÃO URBANA	34
39383	0401.000.542-3	POLÍTICA DE DESENVOLVIMENTO AGRÁRIO	34
39325	0401.000.508-3	PRÁTICAS INTERDISCIPLINARES DE CAMPO	34
39384	0401.000.543-1	REGIONALIZAÇÃO DO ESPAÇO BRASILEIRO	34
43461	0401.000.865-4	SANEAMENTO BÁSICO E AMBIENTAL	34
39387	0401.000.545-8	SOCIOLOGIA DA EDUCAÇÃO	34
39390	0401.000.547-4	TEORIAS DA GEOGRAFIA	34
47785	0401.001.117-7	TÓPICOS ESPECIAIS EM GEOCIÊNCIAS - DA GEOLOGIA À PEDOLOGIA	51
39473	0401.000.550-4	TÓPICOS ESPECIAIS EM GEOGRAFIA	34
43469	0401.000.873-4	TOPOGRAFIA	34
50983	0401.001.435-7	BASES DE ENSINO DE BIOLOGIA CELULAR	68
51012	0401.001.464-2	FILOSOFIA E HISTÓRIA DA EDUCAÇÃO EM CIÊNCIAS	51
50978	0401.001.430-1	FUNDAMENTOS DE GEOLOGIA PARA O ENSINO DE CIÊNCIAS	34
50988	0401.001.440-0	LEITURA E PRODUÇÃO DE TEXTO	34
51008	0401.001.460-6	MATEMÁTICA	34
50991	0401.001.443-7	PRÁTICA DE ENSINO E SABERES NECESSÁRIOS À DOCÊNCIA	68
50981	0401.001.433-9	BASES DE ENSINO EM ANATOMIA VEGETAL	68
51006	0401.001.458-0	BASES PARA ENSINO DE EMBRIOLOGIA	68
50987	0401.001.439-3	METODOLOGIA CIENTÍFICA	68
50998	0401.001.450-8	PRÁTICA DE ENSINO E EPISTEMOLOGIAS DAS CIÊNCIAS	68
50974	0401.001.426-8	FÍSICA	34
50980	0401.001.432-0	MÍDIAS E TECNOLOGIAS DIGITAIS NO ENSINO DE CIÊNCIAS BIOLÓGICAS	34
43516	0401.000.901-6	MORFOLOGIA VEGETAL	68
51000	0401.001.452-6	PRÁTICA DE ENSINO E O CURRÍCULO	68
50992	0401.001.444-6	ZOOLOGIA DE INVERTEBRADOS I	68
50982	0401.001.434-8	BASES DE ENSINO DE QUÍMICA	68
50996	0401.001.448-2	BIOESTATÍSTICA	34
51016	0401.001.468-9	HISTOLOGIA	68
51002	0401.001.454-4	PRÁTICA DE ENSINO EM AVALIAÇÃO E EDUCAÇÃO INCLUSIVA	68
50995	0401.001.447-3	ZOOLOGIA DE INVERTEBRADOS II	68
43512	0401.000.897-7	BIOLOGIA E TAXONOMIA DE CRIPTÓGAMAS	34
50986	0401.001.438-4	BIOQUÍMICA	68
50997	0401.001.449-1	DEUTEROSTOMIA I	51
38990	0709.000.660-4	GEOLOGIA	51
51027	0401.001.479-6	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS I	100
43502	0401.000.887-9	IMUNOLOGIA	34
43509	0401.000.894-0	PALEONTOLOGIA	34
51004	0401.001.456-2	PRÁTICA DE ENSINO INTERDISCIPLINAR	68
51001	0401.001.453-5	ANATOMIA E FISIOLOGIA ANIMAL COMPARADA I	68
50984	0401.001.436-6	BASES DE ENSINO DE GENÉTICA	68
50994	0401.001.446-4	DEUTEROSTOMIA II	51
50989	0401.001.441-9	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS II	100
51015	0401.001.467-0	MICROBIOLOGIA	68
51005	0401.001.457-1	PRÁTICA DE ENSINO EM CONTEÚDOS ESPECÍFICOS	68
51003	0401.001.455-3	ANATOMIA E FISIOLOGIA ANIMAL COMPARADA II	68
51013	0401.001.465-1	BIOLOGIA MOLECULAR	68
51007	0401.001.459-0	CIÊNCIAS DO AMBIENTE E SOCIEDADE	34
51014	0401.001.466-0	ECOLOGIA GERAL	68
51009	0401.001.461-5	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA I	100
50993	0401.001.445-5	FISIOLOGIA VEGETAL	68
50990	0401.001.442-8	BIOGEOGRAFIA	34
50999	0401.001.451-7	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA II	100
43517	0401.000.902-5	EVOLUÇÃO	68
43508	0401.000.893-0	PARASITOLOGIA	34
43515	0401.000.900-7	SISTEMÁTICA DE FANERÓGAMAS	68
34947	0401.000.193-2	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
50979	0401.001.431-0	BIOÉTICA E BIOSSEGURANÇA	34
43533	0401.000.918-8	BIOFÍSICA	68
51022	0401.001.474-0	BIOLOGIA APLICADA À SAÚDE	68
50976	0401.001.428-6	BIOLOGIA DA CONSERVAÇÃO	34
51018	0401.001.470-4	BIOMAS NO BRASIL E NO MUNDO	34
51026	0401.001.478-7	BIOTECNOLOGIA	68
45964	0401.001.084-0	BOTÂNICA DE CAMPO	68
43495	0401.000.880-5	BOTÂNICA ECONÔMICA	34
51021	0401.001.473-1	ECOLOGIA DAS INTERAÇÕES	68
45954	0401.001.074-1	ECOLOGIA DE CAMPO	68
45965	0401.001.085-9	ECOLOGIA DE POPULAÇÕES DE ÁGUA DOCE	68
45966	0401.001.086-8	ECOLOGIA DO CERRADO	68
45967	0401.001.087-7	ECOLOGIA DO PANTANAL	68
51023	0401.001.475-0	ECOLOGIA URBANA	34
50985	0401.001.437-5	EDUCAÇÃO AMBIENTAL	68
50973	0401.001.425-9	EDUCAÇÃO E SAÚDE	34
45958	0401.001.078-8	ENTOMOLOGIA GERAL	68
45951	0401.001.071-4	ETOLOGIA	68
51019	0401.001.471-3	FLORA E VEGETAÇÃO REGIONAL	34
51024	0401.001.476-9	FUNDAMENTOS DA CIÊNCIA E BIOLOGIA DO SOLO	68
51020	0401.001.472-2	FUNDAMENTOS EM ANATOMIA E FISIOLOGIA HUMANA	68
51017	0401.001.469-8	GERENCIAMENTO DE RECURSOS HÍDRICOS APLICADO À BIOLOGIA	68
45959	0401.001.079-7	LIMNOLOGIA	68
45960	0401.001.080-3	MÉTODOS E TÉCNICAS DE COLETA E PREPARAÇÃO DE ANIMAIS	68
50977	0401.001.429-5	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
51011	0401.001.463-3	PRATICAS PARASITOLÓGICAS E EPIDEMIOLÓGICAS	68
51028	0401.001.480-2	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
51010	0401.001.462-4	TÓPICOS EM MEIO AMBIENTE E BIODIVERSIDADE	68
51025	0401.001.477-8	TÓPICOS EM TECNOLOGIA, SAÚDE E SOCIEDADE	68
50975	0401.001.427-7	TÓPICOS ESPECIAIS EM BIOLOGIA E EDUCAÇÃO	68
43521	0401.000.906-1	TÓPICOS ESPECIAIS EM BIOLOGIA I	34
43499	0401.000.884-1	TÓPICOS ESPECIAIS EM BIOLOGIA II	34
45962	0401.001.082-1	TÓPICOS ESPECIAIS EM BIOLOGIA III	68
45956	0401.001.076-0	TÓPICOS ESPECIAIS EM BIOLOGIA IV	68
43527	0401.000.912-3	TÓPICOS ESPECIAIS EM BIOLOGIA V	68
43528	0401.000.913-2	TÓPICOS ESPECIAIS EM BIOLOGIA VI	68
50288	0401.001.393-0	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
50287	0401.001.392-1	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
50302	0401.001.407-0	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
50318	0401.001.423-0	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
50289	0401.001.394-0	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
50293	0401.001.398-6	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
50304	0401.001.409-9	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
50317	0401.001.422-1	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
50310	0401.001.415-0	PRÁTICA DE ENSINO I: DIDÁTICA DA MATEMÁTICA	68
50290	0401.001.395-9	CONSTRUÇÕES GEOMÉTRICAS	34
50316	0401.001.421-2	GEOMETRIA ESPACIAL	68
50286	0401.001.391-2	LEITURA E PRODUÇÃO DE TEXTO	68
50303	0401.001.408-0	LÓGICA MATEMÁTICA	68
50311	0401.001.416-0	PRÁTICA DE ENSINO II: MODELAGEM MATEMÁTICA E RESOLUÇÃO DE PROBLEMAS	68
50300	0401.001.405-2	TRIGONOMETRIA	51
50295	0401.001.400-7	CÁLCULO I	68
50319	0401.001.424-0	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
50309	0401.001.414-1	POLINÔMIOS E NÚMEROS COMPLEXOS	34
50312	0401.001.417-9	PRÁTICA DE ENSINO III: MATEMÁTICA NO ENSINO FUNDAMENTAL	68
50305	0401.001.410-5	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
36308	0401.000.307-2	VETORES E GEOMETRIA ANALÍTICA I	68
50306	0401.001.411-4	ÁLGEBRA LINEAR I	68
50296	0401.001.401-6	CÁLCULO II	68
50294	0401.001.399-5	ESTÁGIO OBRIGATÓRIO I	100
50313	0401.001.418-8	PRÁTICA DE ENSINO IV: TÓPICOS DE EDUCAÇÃO MATEMÁTICA	68
36313	0401.000.312-9	VETORES E GEOMETRIA ANALÍTICA II	68
36314	0401.000.313-7	ÁLGEBRA LINEAR II	68
36320	0401.000.319-6	CÁLCULO III	68
50297	0401.001.402-5	ESTÁGIO OBRIGATÓRIO II	100
36316	0401.000.315-3	ESTRUTURAS ALGÉBRICAS I	68
50292	0401.001.397-7	HISTÓRIA DA MATEMÁTICA	68
36324	0401.000.323-4	CÁLCULO IV	68
50298	0401.001.403-4	ESTÁGIO OBRIGATÓRIO III	100
36319	0401.000.318-8	ESTRUTURAS ALGÉBRICAS II	68
50291	0401.001.396-8	FUNDAMENTOS DE FÍSICA	68
50308	0401.001.413-2	MATEMÁTICA FINANCEIRA	51
50314	0401.001.419-7	PRÁTICA DE ENSINO V: MATEMÁTICA NO ENSINO MÉDIO	68
50307	0401.001.412-3	ANÁLISE COMBINATÓRIA	68
50301	0401.001.406-1	ESTÁGIO OBRIGATÓRIO IV	100
36326	0401.000.325-0	ESTRUTURAS ALGÉBRICAS III	68
50299	0401.001.404-3	INTRODUÇÃO À ANÁLISE REAL	68
50315	0401.001.420-3	PRÁTICA DE ENSINO VI: LABORATÓRIO DE ENSINO DE MATEMÁTICA	68
36332	0401.000.331-5	ANÁLISE REAL II	68
43277	0401.000.779-1	AVALIAÇÃO EM EDUCAÇÃO MATEMÁTICA	68
36279	0401.000.278-5	CÁLCULO V	68
34965	0401.000.211-4	EDUCAÇÃO AMBIENTAL	51
36280	0401.000.279-3	EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	68
36334	0401.000.333-1	ESPAÇOS MÉTRICOS	68
43267	0401.000.769-3	FUNDAMENTOS DE FÍSICA II	68
36283	0401.000.282-3	GRUPO FUNDAMENTAL	68
36285	0401.000.284-0	INFERÊNCIA ESTATÍSTICA	68
36286	0401.000.285-8	INTRODUÇÃO À ANÁLISE FUNCIONAL	68
36287	0401.000.286-6	INTRODUÇÃO À GEOMETRIA DIFERENCIAL	68
43269	0401.000.771-9	INTRODUÇÃO À PESQUISA EM EDUCAÇÃO MATEMÁTICA	68
36290	0401.000.289-0	INTRODUÇÃO A PROGRAMAÇÃO LINEAR	68
36291	0401.000.290-4	INTRODUÇÃO À TEORIA DOS NÚMEROS	68
36292	0401.000.291-2	INTRODUÇÃO À TOPOLOGIA GERAL	68
43270	0401.000.772-8	LABORATÓRIO DE MATEMÁTICA	68
36295	0401.000.294-7	LINGUAGENS DE PROGRAMAÇÃO	68
43271	0401.000.773-7	TÓPICOS DE ÁLGEBRA I	68
43272	0401.000.774-6	TÓPICOS DE ÁLGEBRA II	68
43273	0401.000.775-5	TÓPICOS DE EDUCAÇÃO ALGÉBRICA	68
43274	0401.000.776-4	TÓPICOS DE MATEMÁTICA ELEMENTAR I	68
43275	0401.000.777-3	TÓPICOS DE MATEMÁTICA ELEMENTAR II	68
43276	0401.000.778-2	TÓPICOS DE MATEMÁTICA ELEMENTAR III	68
46051	0401.001.089-5	TÓPICOS DE MATEMÁTICA ELEMENTAR IV	68
46053	0401.001.091-0	TÓPICOS DE MATEMÁTICA ELEMENTAR V	68
36299	0401.000.298-0	TÓPICOS DE TEORIA DE GRUPOS	68
36300	0401.000.299-8	VARIÁVEIS COMPLEXAS	68
48868	0401.001.269-3	ECONOMIA E NEGÓCIOS	68
48880	0401.001.281-7	FUNDAMENTOS DA ADMINISTRAÇÃO	68
48857	0401.001.258-6	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
40968	0401.000.744-2	INTRODUÇÃO À PSICOLOGIA	68
48871	0401.001.272-8	MATEMÁTICA	68
48869	0401.001.270-0	ECONOMIA, GESTÃO E SOCIEDADE	68
48848	0401.001.249-7	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
48872	0401.001.273-7	INTRODUÇÃO À CONTABILIDADE	68
48851	0401.001.252-1	MATEMÁTICA FINANCEIRA	68
48865	0401.001.266-6	TEORIA GERAL DA ADMINISTRAÇÃO	68
48870	0401.001.271-9	FUNDAMENTOS DA ESTATÍSTICA	68
48855	0401.001.256-8	GESTÃO DE CUSTOS	68
48862	0401.001.263-9	GESTÃO LOGÍSTICA	68
40964	0401.000.740-0	INTRODUÇÃO AO DIREITO	68
48854	0401.001.255-9	MÉTODOS E TÉCNICAS DE PESQUISA	68
48852	0401.001.253-0	DIREITO APLICADO À ADMINISTRAÇÃO	68
48860	0401.001.261-0	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
48882	0401.001.283-5	GESTÃO DA INOVAÇÃO	68
48866	0401.001.267-5	GESTÃO DE MARKETING	68
48856	0401.001.257-7	GESTÃO FINANCEIRA	68
48849	0401.001.250-3	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
48863	0401.001.264-8	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
48881	0401.001.282-6	GESTÃO DE AGRONEGÓCIOS	68
48861	0401.001.262-0	GESTÃO DE OPERAÇÕES	68
48867	0401.001.268-4	GESTÃO DO COMPOSTO DE MARKETING	68
48858	0401.001.259-5	ESTRATÉGIAS ORGANIZACIONAIS	68
48864	0401.001.265-7	GESTÃO DE PESSOAS	68
48884	0401.001.285-3	GESTÃO DE SERVIÇOS	68
48883	0401.001.284-4	GESTÃO SOCIOAMBIENTAL	68
48859	0401.001.260-1	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
47303	0401.001.105-0	ADMINISTRAÇÃO PÚBLICA	68
27904	0406.000.565-6	ELABORAÇÃO E ANÁLISE DE PROJETOS	68
40973	0401.000.749-3	EMPREENDEDORISMO	68
48853	0401.001.254-0	PRÁTICAS DE GESTÃO	68
47305	0401.001.107-9	PROCESSO DECISÓRIO	68
48875	0401.001.276-4	ATIVIDADE PRÁTICA SUPERVISIONADA	68
48850	0401.001.251-2	GESTÃO ESTRATÉGICA	68
48876	0401.001.277-3	EMPREENDEDORISMO E INOVAÇÃO	68
34763	0401.000.080-4	LÍNGUA BRASILEIRA DE SINAIS: NOÇÕES BÁSICAS	51
48877	0401.001.278-2	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA I	68
48878	0401.001.279-1	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA II	68
48879	0401.001.280-8	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA III	34
47309	0401.001.111-2	TÓPICOS ESPECIAIS I	68
47310	0401.001.112-1	TÓPICOS ESPECIAIS II	68
47311	0401.001.113-0	TÓPICOS ESPECIAIS III	68
47291	0401.001.093-9	TÓPICOS ESPECIAIS IV	68
47292	0401.001.094-8	TÓPICOS ESPECIAIS IX - EDUCAÇÃO AMBIENTAL	68
47293	0401.001.095-7	TÓPICOS ESPECIAIS VI - DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	68
47294	0401.001.096-6	TÓPICOS ESPECIAIS VII - EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
47295	0401.001.097-5	TÓPICOS ESPECIAIS VIII - HISTÓRIA DA ÁFRICA E CULTURA AFRO-BRASIALEIRA	68
47296	0401.001.098-4	TÓPICOS ESPECIAIS V - LEITURA E PRODUÇÃO DE TEXTOS	68
47297	0401.001.099-3	TÓPICOS ESPECIAIS X - DESENVOLVIMENTO REGIONAL	68
48873	0401.001.274-6	TÓPICOS ESPECIAIS XI - COMÉRCIO INTERNACIONAL	68
48874	0401.001.275-5	TÓPICOS ESPECIAIS XII - INTELIGÊNCIA DE MERCADO	68
49180	0401.001.308-2	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
49177	0401.001.305-5	ENSINO DE CIÊNCIAS: METODOLOGIAS E SUAS PRÁTICAS	68
49186	0401.001.314-4	HISTÓRIA DA EDUCAÇÃO I	68
49187	0401.001.315-3	PSICOLOGIA DA EDUCAÇÃO	68
49184	0401.001.312-6	TRABALHO ACADÊMICO	68
49164	0401.001.292-4	CURRÍCULO E EDUCAÇÃO	68
49175	0401.001.303-7	EDUCAÇÃO ESPECIAL	68
49158	0401.001.286-2	ENSINO DE MATEMÁTICA: METODOLOGIAS E SUAS PRÁTICAS	68
49179	0401.001.307-3	GESTÃO ESCOLAR	68
49173	0401.001.301-9	SOCIOLOGIA DA EDUCAÇÃO	68
49188	0401.001.316-2	DIDÁTICA I	68
49202	0401.001.330-4	ENSINO E PRÁTICA PARA A INFÂNCIA	68
49174	0401.001.302-8	FILOSOFIA DA EDUCAÇÃO	68
49165	0401.001.293-3	LEITURA E PRODUÇÃO DE TEXTOS EM EDUCAÇÃO	34
49166	0401.001.294-2	MATEMÁTICA APLICADA À EDUCAÇÃO	34
49178	0401.001.306-4	PSICOLOGIA DO DESENVOLVIMENTO	68
49176	0401.001.304-6	DIDÁTICA II	68
49197	0401.001.325-1	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
49189	0401.001.317-1	INFÂNCIA E SOCIEDADE	68
49206	0401.001.334-0	METODOLOGIA CIENTÍFICA	68
49171	0401.001.299-8	POLÍTICAS EDUCACIONAIS	68
49162	0401.001.290-6	EDUCAÇÃO DE JOVENS E ADULTOS	68
49181	0401.001.309-1	ENSINO DE GEOGRAFIA: METODOLOGIAS E SUAS PRÁTICAS	68
49195	0401.001.323-3	ESTÁGIO OBRIGATÓRIO I	100
49172	0401.001.300-0	HISTÓRIA DA EDUCAÇÃO II	68
49194	0401.001.322-4	LUDICIDADE E EDUCAÇÃO	68
49161	0401.001.289-0	PESQUISA EM EDUCAÇÃO	34
49191	0401.001.319-0	ALFABETIZAÇÃO E LETRAMENTO I	68
49183	0401.001.311-7	EDUCAÇÃO ESPECIAL: PESQUISA, CURRÍCULO E PRÁTICA DOCENTE	68
49167	0401.001.295-1	ENSINO DE HISTÓRIA: METODOLOGIAS E SUAS PRÁTICAS	68
49198	0401.001.326-0	ESTÁGIO OBRIGATÓRIO II	100
49163	0401.001.291-5	LITERATURA INFANTIL	68
49192	0401.001.320-6	ALFABETIZAÇÃO E LETRAMENTO II	68
49160	0401.001.288-0	DIFICULDADES DE APRENDIZAGEM E PSICOMOTRICIDADE	68
49193	0401.001.321-5	ENSINO DE LÍNGUA PORTUGUESA: METODOLOGIAS E SUAS PRÁTICAS	68
49199	0401.001.327-0	ESTÁGIO OBRIGATÓRIO III	100
49200	0401.001.328-9	ESTUDO DE LIBRAS	68
49185	0401.001.313-5	BASES NEUROLÓGICAS DA APRENDIZAGEM (NEUROAPRENDIZAGEM)	68
49168	0401.001.296-0	EDUCAÇÃO DIFERENCIADA E AS ESPECIFICIDADES REGIONAIS	68
49201	0401.001.329-8	ESTÁGIO OBRIGATÓRIO IV	100
49190	0401.001.318-0	LABORATÓRIO DE APLICAÇÃO DE ATIVIDADES DE LETRAMENTO E ALFABETIZAÇÃO	68
49170	0401.001.298-9	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
49159	0401.001.287-1	ESTUDOS DE GÊNERO	34
49169	0401.001.297-0	LINGUAGENS ARTÍSTICAS E SUAS EXPRESSÕES	68
43318	0401.000.820-6	ORIENTAÇÃO PROFISSIONAL	68
43320	0401.000.822-4	PESQUISA EM EDUCAÇÃO E SAÚDE	68
49182	0401.001.310-8	PESQUISA E PRÁTICA DOCENTE EM ESPAÇOS NÃO ESCOLARES	68
43285	0401.000.787-1	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
39880	0401.000.603-9	TEATRO E DANÇA NA EDUCAÇÃO	34
49203	0401.001.331-3	TÓPICOS ESPECIAIS EM FUNDAMENTOS DA EDUCAÇÃO II	68
49196	0401.001.324-2	TÓPICOS ESPECIAIS EM METODOLOGIAS DE ENSINO	68
49204	0401.001.332-2	TÓPICOS ESPECIAIS EM PRÁTICA DE ENSINO	68
49205	0401.001.333-1	TÓPIOS ESPECIAIS EM FUNDAMENTOS DA EDUCAÇÃO I	68
51881	0401.001.541-6	FUNDAMENTOS DA EDUCAÇÃO ESCOLAR INDÍGENA	102
44861	0401.001.035-8	INTRODUÇÃO À ANTROPOLOGIA CULTURAL	51
51857	0401.001.517-6	INTRODUÇÃO À PESQUISA	51
44840	0401.001.014-2	LEITURA E PRODUÇÃO DE TEXTOS	51
44844	0401.001.018-9	ORGANIZAÇÃO DA ESCOLA BÁSICA INDÍGENA	51
51858	0401.001.518-5	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA I	51
44857	0401.001.031-1	TERRITÓRIO E CULTURA	51
44875	0401.001.049-2	HISTÓRIA INDÍGENA	51
44842	0401.001.016-0	HISTÓRIA, SOCIEDADE, EDUCAÇÃO E COSMOVISÃO DOS POVOS INDÍGENAS	51
44848	0401.001.022-2	MEIO AMBIENTE, CULTURA E SOCIEDADE	51
44836	0401.001.010-6	PEDAGOGIA INDÍGENA	51
51868	0401.001.528-3	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA II	51
44878	0401.001.052-7	PSICOLOGIA E EDUCAÇÃO	51
51859	0401.001.519-4	EDUCAÇÃO INTERCULTURAL BILINGUE	68
51864	0401.001.524-7	ENSINO DE LÍNGUA INDÍGENA: CONTEÚDOS DE ENSINO PARA O ENSINO FUNDAMENTAL	68
51882	0401.001.542-5	ESTÁGIO OBRIGATÓRIO EM LINGUAGENS NO ENSINO FUNDAMENTAL I	100
51883	0401.001.543-4	FONÉTICA E FONOLOGIA DAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	102
51870	0401.001.530-9	INTRODUÇÃO À LINGUÍSTICA	51
51873	0401.001.533-6	LÍNGUA PORTUGUESA	51
51860	0401.001.520-0	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA III	51
51867	0401.001.527-4	ALFABETIZAÇÃO E LETRAMENTO EM LÍNGUAS INDÍGENAS	68
51852	0401.001.512-0	ENSINO DE ARTES NA ESCOLA INDÍGENA I	51
51861	0401.001.521-0	ENSINO DE LITERATURA NA ESCOLA INDÍGENA	51
51853	0401.001.513-0	ESTÁGIO OBRIGATÓRIO EM LINGUAGENS NO ENSINO FUNDAMENTAL II	100
51874	0401.001.534-5	MORFOLOGIA DAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	102
51869	0401.001.529-2	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA IV	51
51876	0401.001.536-3	PRODUÇÃO DE MATERIAL DIDÁTICO EM LÍNGUA INDÍGENA I	51
51856	0401.001.516-7	ENSINO DE ARTES NA ESCOLA INDÍGENA II	51
51865	0401.001.525-6	ENSINO DE LÍNGUA INDÍGENA: CONTEÚDOS DE ENSINO PARA O ENSINO MÉDIO	68
51863	0401.001.523-8	ESTÁGIO OBRIGATÓRIO EM LINGUAGENS NO ENSINO MÉDIO I	100
51855	0401.001.515-8	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA V	68
51877	0401.001.537-2	PRODUÇÃO DE MATERIAL DIDÁTICO EM LÍNGUA INDÍGENA II	68
51878	0401.001.538-1	SINTAXE DAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	102
51862	0401.001.522-9	DIDÁTICA DO ENSINO DE LÍNGUAS NA ESCOLA INDÍGENA	68
51884	0401.001.544-3	ENSINO DE LÍNGUA PORTUGUESA NA ESCOLA INDÍGENA: CONTEÚDOS DE ENSINO PARA O ENSINO FUNDAMENTAL	68
51854	0401.001.514-9	ESTÁGIO OBRIGATÓRIO EM LINGUAGENS NO ENSINO MÉDIO II	100
51871	0401.001.531-8	LEITURA E PRODUÇÃO DE TEXTOS NAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	68
51872	0401.001.532-7	LEXICOGRAFIA E LEXICOLOGIA DAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	68
51885	0401.001.545-2	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA VI	68
51866	0401.001.526-5	ENSINO DE LÍNGUA PORTUGUESA NA ESCOLA INDÍGENA: CONTEÚDOS DE ENSINO PARA O ENSINO MÉDIO	68
51875	0401.001.535-4	POLÍTICAS LINGUÍSTICAS, MANUTENÇÃO E REVITALIZAÇÃO DE LÍNGUAS INDÍGENAS	68
51851	0401.001.511-1	PRÁTICA DE ENSINO NA ESCOLA INDÍGENA VII	68
51879	0401.001.539-0	SOCIOLINGUÍSTICA E AS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	68
51880	0401.001.540-7	TEORIA E PRÁTICA DE TRADUÇÃO	68
44866	0401.001.040-0	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
44855	0401.001.029-6	PRÁTICA EM ANÁLISE DE DADOS I	51
44860	0401.001.034-9	PRÁTICA EM ANÁLISE DE DADOS II	51
44833	0401.001.007-1	PRÁTICA EM ANÁLISE DE DADOS III	51
44864	0401.001.038-5	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
44873	0401.001.047-4	TÓPICOS EM CONHECIMENTOS TRADICIONAIS NAS ESCOLAS INDÍGENAS	51
44829	0401.001.003-5	TÓPICOS EM EMPREENDEDORISMO	51
44849	0401.001.023-1	TÓPICOS EM ETNOLINGUÍSTICA	51
44839	0401.001.013-3	TÓPICOS EM LINGUAS EM CONTATO	51
45940	0401.001.060-7	GEOGRAFIA DA SAÚDE	34
33882	0406.000.651-2	GEOGRAFIA DE MATO GROSSO DO SUL	34
49401	0401.001.375-2	HISTÓRIA GERAL E ECONÔMICA DO BRASIL	68
49416	0401.001.390-3	INFORMÁTICA	34
49404	0401.001.378-0	LEITURA E PRODUÇÃO DE TEXTOS	68
34873	0401.000.179-7	MATEMÁTICA	34
49400	0401.001.374-3	LEGISLAÇÃO URBANA E AMBIENTAL	34
49408	0401.001.382-3	PLANEJAMENTO TERRITORIAL E URBANO	68
33895	0405.000.523-8	TOPOGRAFIA	51
45933	0401.001.053-6	GERENCIAMENTO DE RECURSOS HÍDRICOS	51
49413	0401.001.387-9	SANEAMENTO BÁSICO E AMBIENTAL	51
49409	0401.001.383-2	FUNDAMENTOS DE GEODÉSIA	34
49411	0401.001.385-0	PLANEJAMENTO E GESTÃO AMBIENTAL	34
49405	0401.001.379-9	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
43463	0401.000.867-2	GEOGRAFIA ECONÔMICA	68
49403	0401.001.377-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
49410	0401.001.384-1	ELABORAÇÃO DE PROJETOS E RELATÓRIOS TÉCNICOS	34
49406	0401.001.380-5	ESTÁGIO OBRIGATÓRIO I	124
49414	0401.001.388-8	GEOPROCESSAMENTO	68
49402	0401.001.376-1	HIDROLOGIA AMBIENTAL	34
49407	0401.001.381-4	ESTÁGIO OBRIGATÓRIO II	124
45935	0401.001.055-4	AEROFOTOGRAMETRIA	34
45944	0401.001.064-3	ANTROPOLOGIA CULTURAL	34
45945	0401.001.065-2	ARQUEOLOGIA	34
49415	0401.001.389-7	CADASTRO MULTIFINALITÁRIO	34
45946	0401.001.066-1	CARTOGRAFIA GEOMORFOLÓGICA	34
33877	0406.000.646-6	CULTURA BRASILEIRA	34
29968	0405.000.467-3	DEMOGRAFIA	34
45950	0401.001.070-5	DESENHO TÉCNICO	34
33880	0406.000.649-0	ECONOMIA POLÍTICA	34
45934	0401.001.054-5	FUNDAMENTOS ECONÔMICOS, SOCIAIS E POLÍTICOS DA GEOGRAFIA	34
30408	0407.000.163-7	GEOMETRIA PRÁTICA	34
49412	0401.001.386-0	GEOMORFOLOGIA FLUVIAL	34
30409	0405.000.483-5	GEOTURISMO	34
26277	0405.000.401-0	GERENCIAMENTO DE RESÍDUOS SÓLIDOS	34
43333	0401.000.835-0	HISTÓRIA DA ÁFRICA E CULTURA AFRO-BRASILEIRA	68
30653	0405.000.501-7	INTERPRETAÇÃO DE IMAGENS ORBITAIS	34
45942	0401.001.062-5	INTERPRETAÇÃO E ANÁLISE DE IMAGEM	34
30148	0406.000.615-6	INTRODUÇÃO À ADMINISTRAÇÃO	34
30149	0406.000.616-4	INTRODUÇÃO À ECONOMIA	34
30412	0406.000.624-5	INTRODUÇÃO À FILOSOFIA	34
45941	0401.001.061-6	INTRODUÇÃO AO AUTOCAD	34
30655	0405.000.503-3	METODOLOGIA DO ENSINO DE GEOGRAFIA	34
45949	0401.001.069-9	POSICIONAMENTO POR SATÉLITES ARTIFICIAIS	34
33904	0405.000.532-7	PRÁTICAS INTERDISCIPLINARES DE CAMPO	34
27559	0405.000.420-7	SISTEMA DE INFORMAÇÃO GEOGRÁFICA	34
47784	0401.001.116-8	TÓPICOS ESPECIAIS EM GEOCIÊNCIAS - DA GEOLOGIA À PEDOLOGIA	51
45939	0401.001.059-0	TÓPICOS ESPECIAIS EM GEOGRAFIA I	34
45943	0401.001.063-4	TÓPICOS ESPECIAIS EM GEOGRAFIA II	34
45947	0401.001.067-0	TÓPICOS ESPECIAIS EM GEOGRAFIA III	34
45948	0401.001.068-0	TÓPICOS ESPECIAIS EM GEOGRAFIA IV	34
44852	0401.001.026-9	FUNDAMENTOS DA EDUCAÇÃO ESCOLAR INDÍGENA	102
44862	0401.001.036-7	INTRODUÇÃO À PESQUISA	51
51830	0401.001.490-0	PRÁTICA DE ENSINO DE GEOGRAFIA: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51850	0401.001.510-2	LÍNGUA PORTUGUESA	68
51831	0401.001.491-0	PRÁTICA DE ENSINO DE HISTÓRIA: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51842	0401.001.502-2	ALFABETIZAÇÃO E LETRAMENTO EM LÍNGUA INDÍGENA I: FUNDAMENTOS TEÓRICOS	68
51843	0401.001.503-1	ASPECTOS GRAMATICAIS DAS LÍNGUAS INDÍGENAS DOS POVOS DO PANTANAL	68
51821	0401.001.481-1	DIDÁTICA NA EDUCAÇÃO INFANTIL NA ESCOLA INDÍGENA	68
51841	0401.001.501-3	EDUCAÇÃO ESPECIAL NA COSMOVISÃO DOS POVOS INDÍGENAS DO PANTANAL	68
51835	0401.001.495-6	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO INFANTIL I	100
51836	0401.001.496-5	LÍNGUAS INDÍGENAS DE SINAIS PARA SURDOS NO PROCESSO DE ESCOLARIZAÇÃO	68
51837	0401.001.497-4	PRÁTICA DE ENSINO DE MATEMÁTICA: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51824	0401.001.484-9	ALFABETIZAÇÃO E LETRAMENTO EM LÍNGUA INDÍGENA II: ANÁLISE DE MATERIAIS DIDÁTICOS	68
51847	0401.001.507-8	ALFABETIZAÇÃO E LETRAMENTO EM LÍNGUA PORTUGUESA I: FUNDAMENTOS TEÓRICOS	68
51822	0401.001.482-0	EDUCAÇÃO DE JOVENS E ADULTOS NA ESCOLA INDÍGENA	68
51823	0401.001.483-0	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO INFANTIL II	100
51825	0401.001.485-8	LITERATURA INFANTIL	68
51838	0401.001.498-3	PRÁTICA DE ENSINO DE CIÊNCIAS: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51826	0401.001.486-7	ALFABETIZAÇÃO E LETRAMENTO EM LÍNGUA PORTUGUESA II: ANÁLISE DE MATERIAIS DIDÁTICOS	68
51839	0401.001.499-2	DIDÁTICA NAS SÉRIES INICIAIS NA ESCOLA INDÍGENA	68
51828	0401.001.488-5	EDUCAÇÃO INFANTIL NA COSMOVISÃO DOS POVOS INDÍGENAS DO PANTANAL	68
51848	0401.001.508-7	ESTÁGIO OBRIGATÓRIO NAS SÉRIES INICIAIS DO ENSINO FUNDAMENTAL I	100
51845	0401.001.505-0	MÍDIAS E TECNOLOGIAS DA EDUCAÇÃO ESCOLAR INDÍGENA	34
51834	0401.001.494-7	PRÁTICA DE ENSINO DE LÍNGUA INDÍGENA: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51846	0401.001.506-9	ESTÁGIO OBRIGATÓRIO NAS SÉRIES INICIAIS DO ENSINO FUNDAMENTAL II	100
51840	0401.001.500-4	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
51833	0401.001.493-8	LUDICIDADE ENTRE OS POVOS INDÍGENAS DO PANTANAL	68
51829	0401.001.489-4	PRÁTICA DE ENSINO DE LÍNGUA PORTUGUESA: CONTEÚDOS E PRÁTICAS PEDAGÓGICAS	68
51849	0401.001.509-6	ETNOMATEMÁTICA	68
51827	0401.001.487-6	NARRATIVAS ORAIS E ENSINO NA ESCOLA INDÍGENA	68
51844	0401.001.504-0	PROBLEMAS DE APRENDIZAGEM NA INFÂNCIA	68
51832	0401.001.492-9	PROCESSOS DE GESTÃO NA ESCOLA INDÍGENA	68
44193	0510.001.090-2	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
50646	0510.001.824-0	HISTÓRIA E FORMAÇÃO DA LÍNGUA PORTUGUESA	34
50644	0510.001.822-1	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
50708	0510.001.886-7	LÍNGUA ESPANHOLA I	68
50687	0510.001.865-1	LITERATURA BRASILEIRA I	34
50670	0510.001.848-2	LITERATURA PORTUGUESA I	34
43554	0510.000.996-6	PSICOLOGIA E EDUCAÇÃO	51
50641	0510.001.819-7	TEORIA DA LITERATURA I	34
35335	0510.000.046-1	EDUCAÇÃO ESPECIAL	51
50651	0510.001.829-5	FONÉTICA E FONOLOGIA DA LÍNGUA PORTUGUESA	68
50707	0510.001.885-8	LÍNGUA ESPANHOLA II	68
50639	0510.001.817-9	LITERATURA BRASILEIRA II	34
50673	0510.001.851-7	LITERATURA PORTUGUESA II	34
50677	0510.001.855-3	ORALIDADE E LETRAMENTO	34
43556	0510.000.998-4	POLÍTICAS EDUCACIONAIS	51
50675	0510.001.853-5	TEORIA DA LITERATURA II	34
35329	0510.000.040-2	FUNDAMENTOS DE DIDÁTICA	51
50700	0510.001.878-7	FUNDAMENTOS DO ENSINO DE LÍNGUA ESPANHOLA	34
50701	0510.001.879-6	LÍNGUA ESPANHOLA III	68
44156	0510.001.053-7	LITERATURA BRASILEIRA III	34
50674	0510.001.852-6	LITERATURA PORTUGUESA III	34
50658	0510.001.836-6	MORFOLOGIA DA LÍNGUA PORTUGUESA	68
50678	0510.001.856-2	TEORIA DA LITERATURA III	34
50682	0510.001.860-6	TEXTO E ENSINO	68
50627	0510.001.805-2	GRAMÁTICA E ENSINO	68
50706	0510.001.884-9	LÍNGUA ESPANHOLA IV	68
50660	0510.001.838-4	LITERATURA BRASILEIRA IV	34
50642	0510.001.820-3	LITERATURA PORTUGUESA IV	34
50696	0510.001.874-0	PRÁTICA DE ENSINO DE LÍNGUA ESPANHOLA	68
50652	0510.001.830-1	SINTAXE DA LÍNGUA PORTUGUESA	68
50680	0510.001.858-0	TEORIA DA LITERATURA IV	34
50704	0510.001.882-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA I	51
50643	0510.001.821-2	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA I	51
50699	0510.001.877-8	FUNDAMENTOS DO ENSINO DE LITERATURA	34
50698	0510.001.876-9	LÍNGUA ESPANHOLA V	68
44188	0510.001.085-0	LITERATURA BRASILEIRA V	34
50640	0510.001.818-8	LITERATURA INFANTOJUVENIL	34
50655	0510.001.833-9	METODOLOGIA DO TRABALHO CIENTÍFICO I	34
50647	0510.001.825-9	PRÁTICA DE ENSINO DE LÍNGUA PORTUGUESA I	34
50659	0510.001.837-5	SEMÂNTICA DA LÍNGUA PORTUGUESA	51
50702	0510.001.880-2	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA II	51
50650	0510.001.828-6	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA II	51
50672	0510.001.850-8	ESTILÍSTICA DA LÍNGUA PORTUGUESA	51
50705	0510.001.883-0	LÍNGUA ESPANHOLA VI	68
44164	0510.001.061-7	LITERATURA BRASILEIRA VI	34
50664	0510.001.842-8	METODOLOGIA DO TRABALHO CIENTÍFICO II	34
50649	0510.001.827-7	PRÁTICA DE ENSINO DE LÍNGUA PORTUGUESA II	34
50695	0510.001.873-1	PRÁTICA DE ENSINO DE LITERATURA	68
50703	0510.001.881-1	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA III	51
50653	0510.001.831-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA III	51
43573	0510.001.015-2	ESTUDO DE LIBRAS	51
50710	0510.001.888-5	LÍNGUA ESPANHOLA VII	68
44181	0510.001.078-9	LITERATURA BRASILEIRA VII	34
50676	0510.001.854-4	LITERATURAS AFRICANAS DE LÍNGUA PORTUGUESA I	34
50709	0510.001.887-6	LITERATURAS DE LÍNGUA ESPANHOLA I	68
50656	0510.001.834-8	PRÁTICA DE ENSINO DE LÍNGUA PORTUGUESA III	34
50666	0510.001.844-6	SOCIOLINGUÍSTICA I	34
50697	0510.001.875-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA IV	51
50662	0510.001.840-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA IV	51
50711	0510.001.889-4	LÍNGUA ESPANHOLA VIII	68
50713	0510.001.891-0	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
44182	0510.001.079-8	LITERATURA BRASILEIRA VIII	34
50661	0510.001.839-3	LITERATURA REGIONAL	34
50712	0510.001.890-0	LITERATURAS DE LÍNGUA ESPANHOLA II	68
50669	0510.001.847-3	LITERATURAS INDÍGENAS	34
50667	0510.001.845-5	PRÁTICA DE ENSINO DE LÍNGUA PORTUGUESA IV	34
50689	0510.001.867-0	SOCIOLINGUÍSTICA II	34
35797	0510.000.266-9	CULTURA BRASILEIRA	34
35798	0510.000.267-7	CULTURA HISPÂNICA	34
35305	0510.000.016-0	EDUCAÇÃO DE JOVENS E ADULTOS	51
50648	0510.001.826-8	ESTATÍSTICA EDUCACIONAL	34
44145	0510.001.042-0	ESTÉTICA E HISTÓRIA DA ARTE I	34
44186	0510.001.083-1	ESTÉTICA E HISTÓRIA DA ARTE II	34
44173	0510.001.070-6	ESTUDOS DE LÍNGUAS INDÍGENAS BRASILEIRAS	34
35313	0510.000.024-0	FUNDAMENTOS SOCIOLÓGICOS DA EDUCAÇÃO	51
50637	0510.001.815-0	GESTÃO ESCOLAR	34
50693	0510.001.871-3	INTRODUÇÃO À DIALETOLOGIA	34
44192	0510.001.089-6	INTRODUÇÃO À LITERATURA E PSICANÁLISE	51
35800	0510.000.269-3	INTRODUÇÃO À SEMIÓTICA	34
50671	0510.001.849-1	LEITURA DE TEXTOS DRAMÁTICOS	34
50645	0510.001.823-0	LEITURA DE TEXTOS NARRATIVOS	34
50681	0510.001.859-0	LEITURA DE TEXTOS POÉTICOS	34
39609	0510.000.928-0	LÍNGUA ESPANHOLA INSTRUMENTAL	68
50654	0510.001.832-0	LINGUAGENS, CÓDIGOS E TECNOLOGIAS	34
44183	0510.001.080-4	LINGUÍSTICA TEXTUAL	34
16948	0507.000.549-5	LITERATURA COMPARADA	51
35805	0510.000.274-0	LITERATURA DO NOVO MUNDO	34
39567	0510.000.887-0	LITERATURA PORTUGUESA CONTEMPORÂNEA	68
50663	0510.001.841-9	LITERATURAS AFRICANAS DE LÍNGUA PORTUGUESA II	34
43823	0510.001.027-9	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
50668	0510.001.846-4	POÉTICA DO RAP	34
50692	0510.001.870-4	POLÍTICAS LINGUÍSTICAS EM REGIÕES DE FRONTEIRA	68
43824	0510.001.028-8	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
39568	0510.000.888-8	SOCIOLINGUÍSTICA	68
50694	0510.001.872-2	TÓPICO DE LEITURA E PRODUÇÃO TEXTUAL	68
39611	0510.000.930-2	TÓPICOS DE ENSINO E APRENDIZAGEM DE PORTUGUÊS COMO LÍNGUA NÃO MATERNA	51
39337	0510.000.820-9	TÓPICOS DE FONÉTICA E FONOLOGIA DA LÍNGUA ESPANHOLA	34
50690	0510.001.868-9	TÓPICOS DE GRAMÁTICA NORMATIVA I	68
50691	0510.001.869-8	TÓPICOS DE GRAMÁTICA NORMATIVA II	68
35818	0510.000.287-1	TÓPICOS DE LITERATURA BRASILEIRA	34
44170	0510.001.067-1	TÓPICOS DE LITERATURA UNIVERSAL	68
39612	0510.000.931-0	TÓPICOS DE TRADUÇÃO EM LÍNGUA ESPANHOLA	68
44191	0510.001.088-7	TÓPICOS EM LITERATURA E PSICANÁLISE	34
50686	0510.001.864-2	LÍNGUA INGLESA I	68
50629	0510.001.807-0	LÍNGUA INGLESA II	68
50635	0510.001.813-2	FUNDAMENTOS DO ENSINO DE LÍNGUA INGLESA	34
50684	0510.001.862-4	LÍNGUA INGLESA III	68
50630	0510.001.808-0	LÍNGUA INGLESA IV	68
50636	0510.001.814-1	PRÁTICA DO ENSINO DE LÍNGUA INGLESA	68
50632	0510.001.810-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA I	51
50628	0510.001.806-1	FUNDAMENTOS DO ENSINO DE LITERATURA	34
50631	0510.001.809-9	LÍNGUA INGLESA V	68
50683	0510.001.861-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA II	51
50638	0510.001.816-0	LÍNGUA INGLESA VI	68
50665	0510.001.843-7	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA III	51
50688	0510.001.866-0	LÍNGUA INGLESA VII	68
50657	0510.001.835-7	LITERATURAS DE LÍNGUA INGLESA I	68
50634	0510.001.812-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA IV	51
50685	0510.001.863-3	LÍNGUA INGLESA VIII	68
50679	0510.001.857-1	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
50633	0510.001.811-4	LITERATURAS DE LÍNGUA INGLESA II	68
51754	0510.002.054-2	ESCRITA ACADÊMICA EM LÍNGUA INGLESA	68
52013	0510.002.056-0	INTRODUÇÃO ÀS HISTÓRIAS EM QUADRINHOS	68
39565	0510.000.885-3	LÍNGUA INGLESA INSTRUMENTAL	68
35808	0510.000.277-4	LITERATURA E ENSINO	34
45038	0510.001.130-0	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
52220	0510.002.066-9	REDAÇÃO OFICIAL	68
35811	0510.000.280-4	TÓPICOS DE FONÉTICA E FONOLOGIA DA LÍNGUA INGLESA	34
39570	0510.000.890-0	TÓPICOS DE TRADUÇÃO EM LÍNGUA INGLESA	68
48340	0510.001.463-4	CIÊNCIA POLÍTICA E TEORIA GERAL DO ESTADO	68
48342	0510.001.465-2	DIREITO CIVIL: PARTE GERAL	68
48378	0510.001.501-4	FILOSOFIA GERAL E JURÍDICA	68
36646	0510.000.554-4	HISTÓRIA DO DIREITO	34
48386	0510.001.509-7	SOCIOLOGIA E DIREITO	34
48373	0510.001.496-6	TEORIA DO DIREITO	68
48393	0510.001.516-8	DIREITO CONSTITUCIONAL I	68
48379	0510.001.502-3	DIREITO DAS OBRIGAÇÕES	68
48357	0510.001.480-3	ECONOMIA POLÍTICA	34
48349	0510.001.472-3	FORMAS CONSENSUAIS DE SOLUÇÃO DE CONFLITOS	34
46577	0510.001.350-1	HERMENÊUTICA E ARGUMENTAÇÃO JURÍDICA	68
48374	0510.001.497-5	INTRODUÇÃO À METODOLOGIA DA PESQUISA	34
48377	0510.001.500-5	PSICOLOGIA APLICADA AO DIREITO	34
48387	0510.001.510-3	DIREITO CONSTITUCIONAL II	68
48372	0510.001.495-7	DIREITO CONTRATUAL	68
36663	0510.000.571-4	DIREITO EMPRESARIAL I	68
48365	0510.001.488-6	DIREITO PENAL - PARTE GERAL I	68
48344	0510.001.467-0	TEORIA GERAL DO PROCESSO	68
48388	0510.001.511-2	ANTROPOLOGIA E DIREITO	34
36675	0510.000.583-8	DIREITO CONSTITUCIONAL III	68
46580	0510.001.353-9	DIREITO EMPRESARIAL II	34
48366	0510.001.489-5	DIREITO PENAL - PARTE GERAL II	68
48375	0510.001.498-4	TUTELA DE CONHECIMENTO	68
48368	0510.001.491-0	DIREITO ADMINISTRATIVO I	68
48376	0510.001.499-3	DIREITO DO TRABALHO I	68
48358	0510.001.481-2	DIREITO PENAL - PARTE ESPECIAL I	68
48371	0510.001.494-8	DIREITO PROCESSUAL CONSTITUCIONAL	34
48343	0510.001.466-1	RESPONSABILIDADE CIVIL	34
48347	0510.001.470-5	TUTELA PROVISÓRIA E TUTELA COLETIVA	68
48363	0510.001.486-8	DIREITO ADMINISTRATIVO II	68
48394	0510.001.517-7	DIREITO DAS COISAS	68
48364	0510.001.487-7	DIREITO DO TRABALHO II	68
48350	0510.001.473-2	DIREITO PENAL - PARTE ESPECIAL II	68
48359	0510.001.482-1	TUTELA RECURSAL	68
48389	0510.001.512-1	DIREITO DO CONSUMIDOR	34
48390	0510.001.513-0	DIREITO FINANCEIRO	34
48360	0510.001.483-0	DIREITO PROCESSUAL DO TRABALHO	68
48381	0510.001.504-1	DIREITO PROCESSUAL PENAL I	68
48395	0510.001.518-6	DIREITO TRIBUTÁRIO I	34
48351	0510.001.474-1	METODOLOGIA APLICADA AO TRABALHO DE CONCLUSÃO DE CURSO	34
48361	0510.001.484-0	TUTELA EXECUTIVA	68
48362	0510.001.485-9	DIREITO DE FAMÍLIA	68
48380	0510.001.503-2	DIREITO PREVIDENCIÁRIO E SEGURIDADE SOCIAL	68
48352	0510.001.475-0	DIREITO PROCESSUAL PENAL II	68
48369	0510.001.492-0	DIREITO TRIBUTÁRIO II	68
48353	0510.001.476-0	PROCESSO COLETIVO DO TRABALHO E PROCEDIMENTOS ESPECIAIS	68
48370	0510.001.493-9	DIREITO AMBIENTAL	68
48392	0510.001.515-9	DIREITO DIGITAL E TECNOLÓGICO	34
48354	0510.001.477-9	DIREITO PROCESSUAL PENAL III	68
48382	0510.001.505-0	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA I	136
48367	0510.001.490-1	SUCESSÕES	68
46605	0510.001.378-0	DIREITO INTERNACIONAL PÚBLICO E PRIVADO	68
46594	0510.001.367-3	DIREITOS HUMANOS	34
48383	0510.001.506-0	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA II	136
48391	0510.001.514-0	ÉTICA PROFISSIONAL	34
48355	0510.001.478-8	ARBITRAGEM	34
46578	0510.001.351-0	BIOÉTICA E BIODIREITO	34
48341	0510.001.464-3	CONTRATOS E ATOS UNILATERAIS CÍVEIS	34
36617	0510.000.525-0	CONTRATOS INTERNACIONAIS	34
46606	0510.001.379-0	CRIMINOLOGIA	34
46596	0510.001.369-1	DIREITO AGRÁRIO	34
46609	0510.001.382-4	DIREITO ANIMAL	34
48384	0510.001.507-9	DIREITO AO DESENVOLVIMENTO	68
46568	0510.001.341-2	DIREITO, CIDADANIA E RELAÇÕES ÉTNICO-RACIAIS	34
36619	0510.000.527-7	DIREITO COMUNITÁRIO	34
36620	0510.000.528-5	DIREITO CONSTITUCIONAL COMPARADO	34
36686	0510.000.594-3	DIREITO DA CRIANÇA E DO ADOLESCENTE	34
46570	0510.001.343-0	DIREITO DAS MINORIAS	34
48385	0510.001.508-8	DIREITO, DESENVOLVIMENTISMO E DESENVOLVIMENTO	34
46585	0510.001.358-4	DIREITO E CINEMA	34
46600	0510.001.373-5	DIREITO ECONÔMICO	34
36623	0510.000.531-5	DIREITO EDUCACIONAL	34
46574	0510.001.347-7	DIREITO ELEITORAL	34
36624	0510.000.532-3	DIREITO ELETRÔNICO	34
36626	0510.000.534-0	DIREITO INTERNACIONAL DO TRABALHO	34
36627	0510.000.535-8	DIREITO MUNICIPAL	34
46575	0510.001.348-6	DIREITO PROCESSUAL TRIBUTÁRIO	34
46573	0510.001.346-8	DIREITOS HUMANOS, FRONTEIRAS E MIGRAÇÃO	34
48346	0510.001.469-9	DIREITOS REAIS SOBRE COISAS ALHEIAS	34
36628	0510.000.536-6	DIREITO URBANÍSTICO	34
48348	0510.001.471-4	ECONOMIA BRASILEIRA	34
46601	0510.001.374-4	ECONOMIA DO MEIO AMBIENTE	34
46582	0510.001.355-7	INVISIBILIDADE PÚBLICA, ESTIGMA SOCIAL E DIREITOS FUNDAMENTAIS	34
46592	0510.001.365-5	JUIZADO ESPECIAL	34
46563	0510.001.336-0	JUSTIÇA RESTAURATIVA	34
46593	0510.001.366-4	LEGISLAÇÃO PENAL EXTRAVAGANTE	34
35352	0510.000.063-1	LIBRAS	51
46590	0510.001.363-7	LINGUAGEM JURÍDICA	34
46591	0510.001.364-6	MEDICINA LEGAL	34
46602	0510.001.375-3	MEIO AMBIENTE DO TRABALHO	34
36633	0510.000.541-2	NOÇÕES DE ADMINISTRAÇÃO	34
36634	0510.000.542-0	NOÇÕES DE CONTABILIDADE	34
46583	0510.001.356-6	PENSAMENTO JURÍDICO CRÍTICO	34
48356	0510.001.479-7	PROCEDIMENTOS ESPECIAIS	34
46610	0510.001.383-3	TEORIA DA DEMOCRACIA	34
46603	0510.001.376-2	TEORIA DA JUSTIÇA	34
46611	0510.001.384-2	TEORIA DO DIREITO I	34
46597	0510.001.370-8	TEORIA DO DIREITO II	34
46562	0510.001.335-0	TÓPICOS ESPECIAIS DE DIREITO I	34
46587	0510.001.360-0	TÓPICOS ESPECIAIS DE DIREITO II	34
46576	0510.001.349-5	TÓPICOS ESPECIAIS DE DIREITO III	34
46564	0510.001.337-9	TÓPICOS ESPECIAIS DE DIREITO IV	34
48345	0510.001.468-0	TÓPICOS ESPECIAIS DE ECONOMIA: COOPERAÇÃO SUL-SUL E OS NOVOS DESAFIOS DO DESENVOLVIMENTO REGIONAL	34
50879	0510.001.952-3	ECONOMIA E NEGÓCIOS	68
50877	0510.001.950-5	FUNDAMENTOS DA ADMINISTRAÇÃO	68
50878	0510.001.951-4	INTRODUÇÃO À CONTABILIDADE	68
50883	0510.001.956-0	MATEMÁTICA	68
46561	0510.001.334-1	MÉTODOS E TÉCNICAS DE PESQUISA	68
50889	0510.001.962-1	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
50876	0510.001.949-9	COMUNICAÇÃO NAS ORGANIZAÇÕES	68
50888	0510.001.961-2	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
50907	0510.001.980-0	GESTÃO DE CUSTOS	68
50887	0510.001.960-3	TEORIA GERAL DA ADMINISTRAÇÃO	68
50892	0510.001.965-9	ESTRATÉGIAS ORGANIZACIONAIS	68
50898	0510.001.971-0	FUNDAMENTOS DA ESTATÍSTICA	68
50881	0510.001.954-1	GESTÃO DA INOVAÇÃO	68
50890	0510.001.963-0	GESTÃO DE MARKETING	68
46560	0510.001.333-2	MATEMÁTICA FINANCEIRA	68
50893	0510.001.966-8	ECONOMIA, GESTÃO E SOCIEDADE	68
50908	0510.001.981-9	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
50868	0510.001.941-6	GESTÃO DE PESSOAS	68
50906	0510.001.979-3	GESTÃO DO COMPOSTO DE MARKETING	68
50874	0510.001.947-0	ORGANIZAÇÃO DO TRABALHO, SISTEMAS E MÉTODOS	68
50891	0510.001.964-0	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
50895	0510.001.968-6	GESTÃO DE OPERAÇÕES	68
50897	0510.001.970-1	GESTÃO ESTRATÉGICA	68
50896	0510.001.969-5	GESTÃO FINANCEIRA	68
50894	0510.001.967-7	GESTÃO PÚBLICA	68
50900	0510.001.973-9	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
50899	0510.001.972-0	DIREITO APLICADO À ADMINISTRAÇÃO	68
46547	0510.001.320-7	EMPREENDEDORISMO	68
50872	0510.001.945-2	GESTÃO COMUNITÁRIA E INOVAÇÃO SOCIAL	68
50901	0510.001.974-8	GESTÃO LOGÍSTICA	68
50884	0510.001.957-9	ESTÁGIO SUPERVISIONADO OBRIGATÓRIO I	68
50866	0510.001.939-0	GESTÃO DE EMPREENDIMENTOS TURÍSTICOS	68
37043	0510.000.736-9	GESTÃO DE PROJETOS	68
50886	0510.001.959-7	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
50905	0510.001.978-4	ESTÁGIO SUPERVISIONADO OBRIGATÓRIO II	68
50902	0510.001.975-7	GESTÃO SOCIOAMBIENTAL	68
50863	0510.001.936-3	NEGÓCIOS DIGITAIS	68
50864	0510.001.937-2	ECONOMIA BRASILEIRA CONTEMPORÂNEA	68
46548	0510.001.321-6	ECONOMIA DO MEIO AMBIENTE	34
46550	0510.001.323-4	EDUCAÇÃO AMBIENTAL	34
35794	0510.000.263-4	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
37006	0510.000.701-6	ESTUDOS DE LIBRAS	68
46541	0510.001.314-5	FELICIDADE NO TRABALHO	34
50880	0510.001.953-2	FINANÇAS PESSOAIS	68
50875	0510.001.948-0	GESTÃO DE AGRONEGÓCIOS	68
46537	0510.001.310-9	GESTÃO DE NOVOS NEGÓCIOS	68
50885	0510.001.958-8	GESTÃO DE PESSOAS II	68
46557	0510.001.330-5	GESTÃO DO AGRONEGÓCIO	34
46542	0510.001.315-4	GESTÃO PÚBLICA	34
46554	0510.001.327-0	GOVERNANÇA CORPORATIVA	34
50909	0510.001.982-8	GOVERNANÇA CORPORATIVA	68
46539	0510.001.312-7	HISTÓRIA DE ORGANIZAÇÕES	34
50873	0510.001.946-1	HISTÓRIA DE ORGANIZAÇÕES	68
50882	0510.001.955-0	INFERÊNCIA ESTATÍSTICA	68
46543	0510.001.316-3	INTELIGÊNCIA EMOCIONAL NAS ORGANIZAÇÕES	34
46558	0510.001.331-4	INTERNACIONALIZAÇÃO DE EMPRESAS	34
50869	0510.001.942-5	INTRODUÇÃO À CIÊNCIA POLÍTICA	68
46544	0510.001.317-2	LINGUAGEM DAS TECNOLOGIAS	34
50867	0510.001.940-7	PESQUISA DE MARKETING E COMPORTAMENTO DO CONSUMIDOR	68
36178	0510.000.476-9	PESQUISA OPERACIONAL	68
46538	0510.001.311-8	REGIONALIDADE, INOVAÇÃO SOCIAL E DESENVOLVIMENTO TERRITORIAL SUSTENTÁVEL	68
35886	0510.000.355-0	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO I	68
35887	0510.000.356-8	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO II	68
35888	0510.000.357-6	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO III	68
37007	0510.000.702-4	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO IV	68
37008	0510.000.703-2	TÓPICOS ESPECIAIS EM COMÉRCIO INTERNACIONAL	68
37009	0510.000.704-0	TÓPICOS ESPECIAIS EM CONTABILIDADE ESTRATÉGICA	68
37010	0510.000.705-9	TÓPICOS ESPECIAIS EM CONTABILIDADE I	68
37011	0510.000.706-7	TÓPICOS ESPECIAIS EM CONTABILIDADE II	68
37012	0510.000.707-5	TÓPICOS ESPECIAIS EM CONTABILIDADE III	68
35896	0510.000.365-7	TÓPICOS ESPECIAIS EM DIREITO I	68
35895	0510.000.364-9	TÓPICOS ESPECIAIS EM DIREITO II	68
37013	0510.000.708-3	TÓPICOS ESPECIAIS EM DIREITO III	68
35899	0510.000.368-1	TÓPICOS ESPECIAIS EM ECONOMIA I	68
35900	0510.000.369-0	TÓPICOS ESPECIAIS EM ECONOMIA II	68
35901	0510.000.370-3	TÓPICOS ESPECIAIS EM ECONOMIA III	68
37016	0510.000.709-1	TÓPICOS ESPECIAIS EM EMPREENDEDORISMO	68
37017	0510.000.710-5	TÓPICOS ESPECIAIS EM ERGONOMIA E SEGURANÇA DO TRABALHO	68
50862	0510.001.935-4	TÓPICOS ESPECIAIS EM ESTUDOS FRONTEIRIÇOS	34
37018	0510.000.711-3	TÓPICOS ESPECIAIS EM FINANÇAS CORPORATIVAS	68
50904	0510.001.977-5	TÓPICOS ESPECIAIS EM FORMULAÇÃO E GERENCIAMENTO DE PROJETOS SOCIOAMBIENTAIS	34
37019	0510.000.712-1	TÓPICOS ESPECIAIS EM GEOGRAFIA ECONÔMICA E NEGÓCIOS	68
37020	0510.000.713-0	TÓPICOS ESPECIAIS EM GESTÃO AGROINDUSTRIAL	68
37021	0510.000.714-8	TÓPICOS ESPECIAIS EM GESTÃO DA PRODUÇÃO	68
37023	0510.000.716-4	TÓPICOS ESPECIAIS EM GESTÃO DE CARREIRAS	68
37024	0510.000.717-2	TÓPICOS ESPECIAIS EM GESTÃO DE EMPRESAS SEM FINS LUCRATIVOS	68
37025	0510.000.718-0	TÓPICOS ESPECIAIS EM GESTÃO DE ESTOQUES	68
37026	0510.000.719-9	TÓPICOS ESPECIAIS EM GESTÃO DE EVENTOS	68
37031	0510.000.724-5	TÓPICOS ESPECIAIS EM GESTÃO DE INOVAÇÃO	68
37027	0510.000.720-2	TÓPICOS ESPECIAIS EM GESTÃO DE MICROEMPREENDIMENTOS	68
37039	0510.000.732-6	TÓPICOS ESPECIAIS EM GESTÃO DE PESSOAS	68
50870	0510.001.943-4	TÓPICOS ESPECIAIS EM GESTÃO DE PESSOAS	68
37022	0510.000.715-6	TÓPICOS ESPECIAIS EM GESTÃO DE QUALIDADE	68
46545	0510.001.318-1	TÓPICOS ESPECIAIS EM GESTÃO, DESENVOLVIMENTO COMUNITÁRIO E PODER LOCAL	68
37028	0510.000.721-0	TÓPICOS ESPECIAIS EM GESTÃO DE SERVIÇOS E VAREJO	68
37029	0510.000.722-9	TÓPICOS ESPECIAIS EM GESTÃO DE TRANSPORTES	68
37030	0510.000.723-7	TÓPICOS ESPECIAIS EM GESTÃO ESTRATÉGICA	68
50903	0510.001.976-6	TÓPICOS ESPECIAIS EM GESTÃO MUNICIPAL	68
37040	0510.000.733-4	TÓPICOS ESPECIAIS EM JOGOS EMPRESARIAIS	68
37032	0510.000.725-3	TÓPICOS ESPECIAIS EM LÍNGUA ESPANHOLA	68
37033	0510.000.726-1	TÓPICOS ESPECIAIS EM LÍNGUA INGLESA	68
37034	0510.000.727-0	TÓPICOS ESPECIAIS EM LÍNGUA PORTUGUESA	68
37035	0510.000.728-8	TÓPICOS ESPECIAIS EM LOGÍSTICA EMPRESARIAL	68
37036	0510.000.729-6	TÓPICOS ESPECIAIS EM MARKETING	68
37037	0510.000.730-0	TÓPICOS ESPECIAIS EM PESQUISA ORGANIZACIONAIS	68
37038	0510.000.731-8	TÓPICOS ESPECIAIS EM PROJETOS SOCIOAMBIENTAIS	68
37041	0510.000.734-2	TÓPICOS ESPECIAIS EM SOCIOLOGIA	68
35885	0510.000.354-1	TÓPICOS ESPECIAIS EM TECNOLOGIA DA INFORMAÇÃO	68
50865	0510.001.938-1	TÓPICOS ESPECIAIS EM TEORIAS ORGANIZACIONAIS AVANÇADOS	34
50871	0510.001.944-3	TÓPICOS ESPECIAIS EM TEORIAS ORGANIZACIONAIS AVANÇADOS	68
46555	0510.001.328-0	TÓPICOS ESPECIAIS EM TEORIAS ORGANIZACIONAIS AVANÇADOS I	34
46549	0510.001.322-5	TÓPICOS ESPECIAIS EM TEORIAS ORGANIZACIONAIS AVANÇADOS II	34
37042	0510.000.735-0	TÓPICOS ESPECIAIS EM TURISMO	68
47533	0510.001.449-2	CONTABILIDADE INTRODUTÓRIA	136
48680	0510.001.519-5	INTRODUÇÃO À ADMINISTRAÇÃO	68
48703	0510.001.542-6	MATEMÁTICA	68
48697	0510.001.536-4	MÉTODOS E TÉCNICAS DE PESQUISA	68
47525	0510.001.441-0	CONTABILIDADE INTERMEDIÁRIA	68
48693	0510.001.532-8	CONTABILIDADE SOCIETÁRIA I	68
47540	0510.001.456-3	DIREITO CONSTITUCIONAL E EMPRESARIAL	68
48705	0510.001.544-4	INTRODUÇÃO À ECONOMIA	68
48696	0510.001.535-5	MATEMÁTICA FINANCEIRA	68
48695	0510.001.534-6	CONTABILIDADE DE CUSTOS	68
48683	0510.001.522-0	CONTABILIDADE SOCIETÁRIA II	68
46556	0510.001.329-9	ESTATÍSTICA	68
48685	0510.001.524-8	FILOSOFIA, ÉTICA E LEGISLAÇÃO PROFISSIONAL CONTÁBIL	68
47500	0510.001.416-0	ORÇAMENTO GOVERNAMENTAL	68
48706	0510.001.545-3	ANÁLISE DE CUSTOS	68
48694	0510.001.533-7	CONTABILIDADE APLICADA AO SETOR PÚBLICO	68
48692	0510.001.531-9	DIREITO TRIBUTÁRIO	68
48700	0510.001.539-1	INFERÊNCIA ESTATÍSTICA	68
48699	0510.001.538-2	TEORIA DA CONTABILIDADE	68
48707	0510.001.546-2	CONTABILIDADE APLICADA AO AGRONEGÓCIO	68
48687	0510.001.526-6	CONTABILIDADE AVANÇADA	68
48701	0510.001.540-8	CONTABILIDADE E LEGISLAÇÃO TRABALHISTA	68
48684	0510.001.523-9	CONTABILIDADE TRIBUTÁRIA	68
48686	0510.001.525-7	ADMINISTRAÇÃO FINANCEIRA	68
48689	0510.001.528-4	ANÁLISE DAS DEMONSTRAÇÕES CONTÁBEIS	68
47534	0510.001.450-9	CONTABILIDADE PARA O TERCEIRO SETOR	68
47503	0510.001.419-8	PLANEJAMENTO ESTRATÉGICO E ORÇAMENTÁRIO	68
47504	0510.001.420-4	SISTEMA DE INFORMAÇÃO CONTÁBIL	68
48704	0510.001.543-5	AUDITORIA CONTÁBIL	68
48681	0510.001.520-1	CONTROLADORIA	68
48688	0510.001.527-5	LABORATÓRIO CONTÁBIL I	68
48702	0510.001.541-7	MERCADO FINANCEIRO E DE CAPITAIS	68
47532	0510.001.448-3	CONTABILIDADE ATUARIAL	68
48708	0510.001.547-1	LABORATÓRIO CONTÁBIL II	68
48698	0510.001.537-3	PERÍCIA E ARBITRAGEM	68
47528	0510.001.444-7	AUDITORIA GOVERNAMENTAL E CONTROLE EXTERNO	34
47529	0510.001.445-6	COMPORTAMENTO ORGANIZACIONAL	68
36971	0510.000.677-0	COMUNICAÇÃO NAS ORGANIZAÇÕES	68
47530	0510.001.446-5	CONTABILIDADE APLICADA À INSTITUIÇÃO FINANCEIRA	68
47516	0510.001.432-0	CONTABILIDADE E ANÁLISE FINANCEIRA DE SOCIEDADES COOPERATIVAS	68
47518	0510.001.434-9	CONTABILIDADE GERENCIAL	34
47520	0510.001.436-7	CONTABILIDADE IMOBILIÁRIA	68
47535	0510.001.451-8	CONTABILIDADE SOCIAL	68
45088	0510.001.180-1	EDUCAÇÃO ÉTNICO-RACIAL, GÊNERO E DIVERSIDADE	51
47544	0510.001.460-7	FINANÇAS PESSOAIS	34
47545	0510.001.461-6	GESTÃO HOSPITALAR	68
47546	0510.001.462-5	GESTÃO SOCIOAMBIENTAL	68
47490	0510.001.406-2	GOVERNANÇA CORPORATIVA	68
44169	0510.001.066-2	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
47499	0510.001.415-1	MÉTODOS QUANTITATIVOS APLICADOS À CONTABILIDADE	68
48682	0510.001.521-0	PESQUISA EM CONTABILIDADE	68
47506	0510.001.422-2	TÓPICOS EM TEMAS EMERGENTES NA CONTABILIDADE I	34
47507	0510.001.423-1	TÓPICOS EM TEMAS EMERGENTES NA CONTABILIDADE II	68
47508	0510.001.424-0	TÓPICOS EM TEMAS EMERGENTES NA CONTROLADORIA I	34
47509	0510.001.425-0	TÓPICOS EM TEMAS EMERGENTES NA CONTROLADORIA II	68
47510	0510.001.426-9	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO	68
47511	0510.001.427-8	TÓPICOS ESPECIAIS EM DIREITO	68
47512	0510.001.428-7	TÓPICOS ESPECIAIS EM ECONOMIA	68
48711	0510.001.550-6	TÓPICOS ESPECIAIS EM EDUCAÇÃO	34
48691	0510.001.530-0	TÓPICOS ESPECIAIS EM ESTATÍSTICA	34
48709	0510.001.548-0	TÓPICOS ESPECIAIS EM HISTÓRIA	34
47513	0510.001.429-6	TÓPICOS ESPECIAIS EM LÍNGUA INGLESA	68
47522	0510.001.438-5	TÓPICOS ESPECIAIS EM LÍNGUA PORTUGUESA	68
47523	0510.001.439-4	TÓPICOS ESPECIAIS EM MARKETING	68
48710	0510.001.549-0	TÓPICOS ESPECIAIS EM MATEMÁTICA	34
48712	0510.001.551-5	TÓPICOS ESPECIAIS EM PROGRAMAÇÃO	68
48690	0510.001.529-3	TÓPICOS ESPECIAIS EM PSICOLOGIA	34
47524	0510.001.440-0	TÓPICOS ESPECIAIS EM TECNOLOGIA DA INFORMAÇÃO	68
49764	0510.001.656-8	CARTOGRAFIA	68
49748	0510.001.640-5	GEOGRAFIA DO BRASIL	68
49788	0510.001.680-8	GEOLOGIA	68
49786	0510.001.678-2	HISTÓRIA DO PENSAMENTO GEOGRÁFICO	68
49779	0510.001.671-9	INTRODUÇÃO À METODOLOGIA CIENTÍFICA	68
49781	0510.001.673-7	CARTOGRAFIA TEMÁTICA	68
49782	0510.001.674-6	CLIMATOLOGIA	68
49787	0510.001.679-1	GEOGRAFIA ECONÔMICA	68
49755	0510.001.647-9	SOCIOLOGIA DA EDUCAÇÃO	51
43570	0510.001.012-5	EDUCAÇÃO ESPECIAL	51
43569	0510.001.011-6	FUNDAMENTOS DE DIDÁTICA	51
49780	0510.001.672-8	GEOGRAFIA DA POPULAÇÃO	68
49746	0510.001.638-0	GEOMORFOLOGIA	68
49753	0510.001.645-0	TEORIA E MÉTODOS DA GEOGRAFIA	68
35333	0510.000.044-5	CARTOGRAFIA APLICADA	68
49760	0510.001.652-1	ENSINO E PRÁTICAS DE GEOGRAFIA: ENSINO FUNDAMENTAL E VIVÊNCIA ESCOLAR	68
49769	0510.001.661-0	GEOGRAFIA POLÍTICA	68
49763	0510.001.655-9	HIDROLOGIA	68
49745	0510.001.637-0	PROJETO DE ATIVIDADES DE PESQUISA E DE EXTENSÃO	34
49762	0510.001.654-0	ENSINO E PRÁTICAS DE GEOGRAFIA: ENSINO MÉDIO E VIVÊNCIA ESCOLAR	68
49765	0510.001.657-7	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA I	100
49747	0510.001.639-9	GEOGRAFIA DO MATO GROSSO DO SUL	68
49766	0510.001.658-6	GEOGRAFIA URBANA	68
49761	0510.001.653-0	SENSORIAMENTO REMOTO	68
49767	0510.001.659-5	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA II	100
49768	0510.001.660-1	GEOGRAFIA AGRÁRIA	68
49777	0510.001.669-3	GEOGRAFIA DOS ESPAÇOS GLOBAIS	68
38633	0510.000.815-2	PRÁTICA DE ENSINO DE GEOGRAFIA E AS TECNOLOGIAS DA INFORMAÇÃO	68
49744	0510.001.636-1	ENSINO E PRÁTICAS DE GEOGRAFIA: TEMAS TRANSVERSAIS	68
49751	0510.001.643-2	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA III	100
49790	0510.001.682-6	GEOGRAFIA DA FRONTEIRA	68
49784	0510.001.676-4	GEOGRAFIA E MEIO AMBIENTE	68
49752	0510.001.644-1	PEDOLOGIA	68
49750	0510.001.642-3	BIOGEOGRAFIA	68
49797	0510.001.689-0	ENSINO E PRÁTICAS DE GEOGRAFIA: USO DE DIFERENTES LINGUAGENS	68
49789	0510.001.681-7	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA IV	100
49743	0510.001.635-2	GEOGRAFIA CULTURAL E SOCIAL	68
49774	0510.001.666-6	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
51911	0510.002.055-1	CONCEITOS PARA ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
49775	0510.001.667-5	DESENVOLVIMENTO LOCAL	68
49749	0510.001.641-4	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
49794	0510.001.686-2	GEOGRAFIA DA CIRCULAÇÃO E DO COMÉRCIO	68
49795	0510.001.687-1	GEOGRAFIA DA SAÚDE	68
49770	0510.001.662-0	GEOGRAFIA DO TURISMO	68
49783	0510.001.675-5	GEOGRAFIA REGIONAL	68
49791	0510.001.683-5	GEOLOGIA AMBIENTAL	68
49772	0510.001.664-8	GEOLOGIA DO QUATERNÁRIO: MUDANÇAS CLIMÁTICAS GLOBAIS	68
49771	0510.001.663-9	GEOMORFOLOGIA FLUVIAL	68
49792	0510.001.684-4	GESTÃO DE BACIAS HIDROGRÁFICAS	68
49798	0510.001.690-6	INTRODUÇÃO AO GEOPROCESSAMENTO	68
49773	0510.001.665-7	MEIO AMBIENTE E SAÚDE HUMANA	68
35733	0510.000.202-2	ORGANIZAÇÃO E FUNCIONAMENTO DA EDUCAÇÃO BÁSICA	51
49793	0510.001.685-3	PLANEJAMENTO URBANO E REGIONAL	68
38631	0510.000.813-6	PRÁTICA DE ENSINO DE GEOGRAFIA: EDUCAÇÃO NO CAMPO	68
49776	0510.001.668-4	PRÁTICA E HISTÓRIA DO ENSINO DA GEOGRAFIA	68
43550	0510.000.992-0	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
49759	0510.001.651-2	PRINCÍPIOS E PRÁTICAS DE AGROECOLOGIA	68
49796	0510.001.688-0	TÓPICOS DE EXTENSÃO	68
49785	0510.001.677-3	TÓPICOS EM GEOGRAFIA	68
49756	0510.001.648-8	TÓPICOS ESPECIAIS EM SISTEMA DE POSICIONAMENTO GLOBAL	68
49778	0510.001.670-0	TRABALHO DE CAMPO INTEGRADO DE GEOGRAFIA	68
49757	0510.001.649-7	URBANIZAÇÃO E MEIO AMBIENTE	68
49758	0510.001.650-3	URBANIZAÇÃO E POLÍTICAS PÚBLICAS	68
51157	0510.001.998-0	INTRODUÇÃO AO ENSINO DE HISTÓRIA	68
51164	0510.002.005-0	PRÁTICAS DE ENSINO EM HISTÓRIA I	68
43549	0510.000.991-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
51156	0510.001.997-1	EDUCAÇÃO EM FRONTEIRA	68
51158	0510.001.999-0	PRÁTICAS DE ENSINO EM HISTÓRIA II	68
35928	0510.000.397-5	SOCIOLOGIA GERAL	51
51175	0510.002.016-8	ANTROPOLOGIA, CULTURA E EDUCAÇÃO	68
36724	0510.000.632-0	ARQUEOLOGIA	68
51154	0510.001.995-3	ENSINO DE HISTÓRIA E CULTURA AFRO-BRASILEIRA E AFRICANA	68
51160	0510.002.001-4	HISTÓRIA ANTIGA I	68
43820	0510.001.024-1	LEITURA E PRODUÇÃO DE TEXTOS HISTÓRICOS	68
51152	0510.001.993-5	PRATICAS DE ENSINO EM HISTÓRIA III	68
51161	0510.002.002-3	HISTÓRIA ANTIGA II	68
36730	0510.000.638-9	HISTÓRIA DA AMÉRICA I	68
36738	0510.000.646-0	HISTÓRIA DA AMÉRICA II	68
51142	0510.001.983-7	HISTÓRIA REGIONAL	68
51159	0510.002.000-5	PESQUISA HISTÓRICA	68
51146	0510.001.987-3	PRÁTICAS DE ENSINO EM HISTÓRIA IV	68
51168	0510.002.009-7	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	100
36752	0510.000.660-5	HISTÓRIA DA AMÉRICA III	68
51179	0510.002.020-1	HISTÓRIA DO BRASIL I	68
51171	0510.002.012-1	HISTÓRIA MEDIEVAL I	68
51143	0510.001.984-6	HISTÓRIA MODERNA I	68
51153	0510.001.994-4	PRÁTICAS DE ENSINO EM HISTÓRIA V	68
51170	0510.002.011-2	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	100
51177	0510.002.018-6	HISTÓRIA DO BRASIL II	68
51155	0510.001.996-2	HISTÓRIA MEDIEVAL II	68
51162	0510.002.003-2	HISTÓRIA MODERNA II	68
51163	0510.002.004-1	INTRODUÇÃO MATEMÁTICA À HISTÓRIA ECONÔMICA	68
51173	0510.002.014-0	PRÁTICAS DE ENSINO EM HISTÓRIA VI	68
51151	0510.001.992-6	EDUCAÇÃO PATRIMONIAL	68
51166	0510.002.007-9	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	100
51144	0510.001.985-5	HISTÓRIA CONTEMPORÂNEA I	68
51178	0510.002.019-5	HISTÓRIA DO BRASIL III	68
35716	0510.000.185-9	INTRODUÇÃO À FILOSOFIA	68
51172	0510.002.013-0	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
51174	0510.002.015-9	EDUCAÇÃO E GÊNERO	68
51167	0510.002.008-8	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	100
51145	0510.001.986-4	HISTÓRIA CONTEMPORÂNEA II	68
51176	0510.002.017-7	HISTÓRIA DO BRASIL IV	68
51150	0510.001.991-7	HISTORIOGRAFIA	68
51165	0510.002.006-0	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
43564	0510.001.006-3	EDUCAÇÃO AMBIENTAL	34
45899	0510.001.306-5	HISTÓRIA DO PENSAMENTO ECONÔMICO	68
45892	0510.001.299-9	HISTÓRIA DOS ESTADOS UNIDOS	68
51149	0510.001.990-8	HISTÓRIA E MIGRAÇÕES INTERNACIONAIS	68
45889	0510.001.296-1	HISTÓRIA ORAL	68
45894	0510.001.301-0	HISTÓRIA REGIONAL I	68
45891	0510.001.298-0	HISTÓRIA REGIONAL II	68
43565	0510.001.007-2	LIBRAS: NOÇÕES BÁSICAS I	34
43568	0510.001.010-7	LIBRAS: NOÇÕES BÁSICAS II	34
51169	0510.002.010-3	PRÁTICA DA PESQUISA EM HISTÓRIA	68
51148	0510.001.989-1	PRÁTICA DE ENSINO EM HISTÓRIA REGIONAL I	68
51147	0510.001.988-2	PRÁTICA DE ENSINO EM HISTÓRIA REGIONAL II	68
43816	0510.001.020-5	PRÁTICA DE LABORATÓRIO EM ARQUEOLOGIA	68
43831	0510.001.035-9	TÓPICOS ESPECIAIS EM AMÉRICA PRÉ-COLONIAL	68
45897	0510.001.304-7	TÓPICOS ESPECIAIS EM HISTÓRIA ANTIGA I	68
45898	0510.001.305-6	TÓPICOS ESPECIAIS EM HISTÓRIA ANTIGA II	68
45900	0510.001.307-4	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA I	68
45901	0510.001.308-3	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA II	68
43837	0510.001.041-0	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL COLÔNIA	68
43828	0510.001.032-1	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL IMPÉRIO	68
45895	0510.001.302-9	TÓPICOS ESPECIAIS EM HISTÓRIA I	68
45893	0510.001.300-0	TÓPICOS ESPECIAIS EM HISTÓRIA II	68
45890	0510.001.297-0	TÓPICOS ESPECIAIS EM HISTÓRIA III	68
45888	0510.001.295-2	TÓPICOS ESPECIAIS EM HISTÓRIA IV	68
45896	0510.001.303-8	TÓPICOS ESPECIAIS EM HISTÓRIA V	68
43832	0510.001.036-8	TÓPICOS ESPECIAL DE PRÁTICA DE ENSINO EM HISTÓRIA AMBIENTAL	68
50719	0510.001.897-4	BASES DE ENSINO DE BIOLOGIA CELULAR	68
50717	0510.001.895-6	BASES DE ENSINO DE QUÍMICA	68
50716	0510.001.894-7	BASES DE FÍSICA PARA O ENSINO DE CIÊNCIAS	68
50741	0510.001.919-4	ENSINO POR PROJETOS I	51
50715	0510.001.893-8	MÍDIAS E TECNOLOGIA DIGITAIS NO ENSINO DE CIÊNCIAS BIOLÓGICAS	34
50720	0510.001.898-3	BASES DE ENSINO DE GENÉTICA	68
50721	0510.001.899-2	BASES PARA ENSINO DE EMBRIOLOGIA	68
50722	0510.001.900-4	BIOSSISTEMÁTICA PARA O ENSINO	34
50736	0510.001.914-9	ENSINO POR PROJETOS II	51
50714	0510.001.892-9	FILOSOFIA E HISTÓRIA DA EDUCAÇÃO EM CIÊNCIAS	51
50748	0510.001.926-5	PRÁTICA DE ENSINO E SABERES NECESSÁRIOS À DOCÊNCIA	68
50726	0510.001.904-0	HISTOLOGIA	51
35549	0510.000.095-0	INVERTEBRADOS I	51
50723	0510.001.901-3	LEITURA E PRODUÇÃO DE TEXTO	34
50724	0510.001.902-2	MATEMÁTICA	34
50742	0510.001.920-0	MORFOLOGIA VEGETAL	68
50749	0510.001.927-4	PRÁTICA DE ENSINO E EPISTEMOLOGIAS DAS CIÊNCIAS	68
50735	0510.001.913-0	ANATOMIA VEGETAL	68
50737	0510.001.915-8	BIOESTATÍSTICA	34
35555	0510.000.101-8	INVERTEBRADOS II	51
50750	0510.001.928-3	PRÁTICA DE ENSINO E O CURRÍCULO	68
50740	0510.001.918-5	QUIMICA ORGÂNICA	51
50738	0510.001.916-7	TÓPICOS EM BIOLOGIA CELULAR E MOLECULAR	51
50753	0510.001.931-8	BIOLOGIA E TAXONOMIA DE CRIPTÓGAMAS	68
35559	0510.000.105-0	BIOQUÍMICA I	51
50728	0510.001.906-9	DEUTEROSTOMIA I	51
35567	0510.000.113-1	ECOLOGIA I	51
50746	0510.001.924-7	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS I	100
50754	0510.001.932-7	PRÁTICA DE ENSINO INTERDISCIPLINAR	68
50725	0510.001.903-1	TÓPICOS EM GENÉTICA	51
35564	0510.000.110-7	BIOQUÍMICA II	51
50729	0510.001.907-8	DEUTEROSTOMIA II	51
35570	0510.000.116-6	ECOLOGIA II	51
50747	0510.001.925-6	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS II	100
50718	0510.001.896-5	MICROBIOLOGIA	51
50751	0510.001.929-2	PRÁTICA DE ENSINO EM AVALIAÇÃO E EDUCAÇÃO INCLUSIVA	68
50727	0510.001.905-0	SISTEMÁTICA DE FANERÓGAMAS	68
50734	0510.001.912-0	AMBIENTE E SAÚDE HUMANA	51
50739	0510.001.917-6	BIOGEOGRAFIA	34
50730	0510.001.908-7	BIOTECNOLOGIA	34
50743	0510.001.921-0	EDUCAÇÃO AMBIENTAL	51
50744	0510.001.922-9	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA I	100
50731	0510.001.909-6	FISIOLOGIA ANIMAL COMPARADA	51
43575	0510.001.017-0	FISIOLOGIA VEGETAL	68
50732	0510.001.910-2	ANATOMIA COMPARADA DOS VERTEBRADOS	51
50733	0510.001.911-1	BIOLOGIA DE CAMPO	51
50745	0510.001.923-8	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA II	100
35583	0510.000.129-8	EVOLUÇÃO	51
35554	0510.000.100-0	INTRODUÇÃO À GEOLOGIA E PALEONTOLOGIA	51
50752	0510.001.930-9	PRÁTICA DE ENSINO EM CONTEÚDOS ESPECÍFICOS	68
35521	0510.000.067-4	AGROECOLOGIA	34
35522	0510.000.068-2	BIOFÍSICA	34
35523	0510.000.069-0	BIOINDICADORES AMBIENTAIS	34
35524	0510.000.070-4	BIOLOGIA DE PEIXES DE ÁGUA DOCE	34
35526	0510.000.072-0	BIOLOGIA DOS INSETOS SOCIAIS	34
35525	0510.000.071-2	BIOLOGIA DO SOLO	34
35527	0510.000.073-9	BOTÂNICA DE CAMPO	34
35528	0510.000.074-7	BOTÂNICA ECONÔMICA	34
43572	0510.001.014-3	CIÊNCIAS AMBIENTAIS	34
35529	0510.000.075-5	CONSERVAÇÃO E MANEJO DE RECURSOS NATURAIS	34
35530	0510.000.076-3	ECOLOGIA DA POLINIZAÇÃO	34
35531	0510.000.077-1	ECOLOGIA E TAXONOMIA DO ZOOPLÂNCTON	34
35533	0510.000.079-8	ENTOMOLOGIA GERAL	34
35534	0510.000.080-1	GENÉTICA DE POPULAÇÕES	34
43566	0510.001.008-1	GENÉTICA FORENSE	34
35535	0510.000.081-0	GERENCIAMENTO DE RESÍDUOS SÓLIDOS	34
43562	0510.001.004-5	INGLÊS INSTRUMENTAL I	34
43567	0510.001.009-0	INGLÊS INSTRUMENTAL II	34
35536	0510.000.082-8	INTRODUÇÃO À ETOLOGIA	34
35537	0510.000.083-6	INTRODUÇÃO AO ESTUDO DAS AVES	34
35538	0510.000.084-4	INTRODUÇÃO AO ESTUDO DE RÉPTEIS	34
35539	0510.000.085-2	INTRODUÇÃO AO ESTUDO DOS MAMÍFEROS	34
35540	0510.000.086-0	LIMNOLOGIA	34
50755	0510.001.933-6	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
35541	0510.000.087-9	PARASITOLOGIA	34
35542	0510.000.088-7	POLUIÇÃO AMBIENTAL	34
50756	0510.001.934-5	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
35544	0510.000.090-9	QUÍMICA AMBIENTAL	34
35545	0510.000.091-7	RECUPERAÇÃO DE ÁREAS DEGRADADAS	34
43571	0510.001.013-4	TÉCNICAS DE COLETA E PREPARAÇÃO DE PLANTAS E ANIMAIS	34
47481	0510.001.399-6	TÓPICOS EM CIÊNCIAS BIOLÓGICAS I	34
47480	0510.001.398-7	TÓPICOS EM CIÊNCIAS BIOLÓGICAS II	34
47479	0510.001.397-8	TÓPICOS EM CIÊNCIAS BIOLÓGICAS III	34
47478	0510.001.396-9	TÓPICOS EM CIÊNCIAS BIOLÓGICAS IV	34
35546	0510.000.092-5	VIROLOGIA	34
49980	0510.001.717-1	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
49972	0510.001.709-1	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
49978	0510.001.715-3	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
36195	0510.000.493-9	MATEMÁTICA NA EDUCAÇÃO BÁSICA I	68
49966	0510.001.703-7	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
49979	0510.001.716-2	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
49973	0510.001.710-8	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
49967	0510.001.704-6	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
36199	0510.000.497-1	MATEMÁTICA NA EDUCAÇÃO BÁSICA II	68
49970	0510.001.707-3	CÁLCULO I	68
49975	0510.001.712-6	LEITURA E PRODUÇÃO DE TEXTOS	68
49958	0510.001.695-1	LÓGICA MATEMÁTICA	68
49955	0510.001.692-4	MATEMÁTICA DISCRETA	68
49954	0510.001.691-5	PRÁTICA DE ENSINO I	34
49959	0510.001.696-0	TRIGONOMETRIA E NÚMEROS COMPLEXOS	68
36207	0510.000.505-6	CÁLCULO II	68
49961	0510.001.698-9	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
45878	0510.001.285-4	GEOMETRIA PLANA	102
49956	0510.001.693-3	VETORES E GEOMETRIA ANALÍTICA	68
49957	0510.001.694-2	ÁLGEBRA I	85
36209	0510.000.507-2	ÁLGEBRA LINEAR I	68
36210	0510.000.508-0	CÁLCULO III	68
49963	0510.001.700-0	ESTÁGIO OBRIGATÓRIO I	100
49960	0510.001.697-0	GEOMETRIA ESPACIAL	68
45869	0510.001.276-5	METODOLOGIAS PARA O ENSINO DE MATEMÁTICA	68
49976	0510.001.713-5	ÁLGEBRA II	102
45868	0510.001.275-6	ÁLGEBRA LINEAR II	68
49964	0510.001.701-9	ESTÁGIO OBRIGATÓRIO II	100
36216	0510.000.513-7	INFERÊNCIA ESTATÍSTICA	68
45880	0510.001.287-2	INTRODUÇÃO À METODOLOGIA CIENTÍFICA	68
49971	0510.001.708-2	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
49962	0510.001.699-8	ESTÁGIO OBRIGATÓRIO III	100
36220	0510.000.517-0	FÍSICA I	68
49977	0510.001.714-4	HISTÓRIA DA MATEMÁTICA	68
49968	0510.001.705-5	INTRODUÇÃO À ANÁLISE REAL	68
45875	0510.001.282-7	INTRODUÇÃO AO SOFTWARE MATEMÁTICO	68
45877	0510.001.284-5	CÁLCULO IV	102
45881	0510.001.288-1	ENSINO E APRENDIZAGEM EM MATEMÁTICA	68
49974	0510.001.711-7	ESTÁGIO OBRIGATÓRIO IV	100
36225	0510.000.521-8	FÍSICA II	68
49969	0510.001.706-4	PRÁTICA DE ENSINO II	34
49965	0510.001.702-8	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
36157	0510.000.455-6	ÁLGEBRA III	68
36158	0510.000.456-4	ALGORITMOS E PROGRAMAÇÃO I	102
36159	0510.000.457-2	ALGORITMOS E PROGRAMAÇÃO II	102
36160	0510.000.458-0	ANÁLISE DE SOFTWARES EDUCATIVOS DE MATEMÁTICA	51
35671	0510.000.140-9	BRINQUEDOTECA	51
44505	0510.001.110-4	CÁLCULO AVANÇADO	68
36162	0510.000.460-2	CÁLCULO NA EDUCAÇÃO BÁSICA	68
38550	0510.000.811-0	CÁLCULO NUMÉRICO	51
36163	0510.000.461-0	CURIOSIDADES, JOGOS E RECREAÇÕES MATEMÁTICAS	51
36164	0510.000.462-9	DESENHO GEOMÉTRICO	51
36165	0510.000.463-7	DIDÁTICA FRANCESA	51
44498	0510.001.103-3	DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	51
36166	0510.000.464-5	EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	68
44508	0510.001.113-1	EQUAÇÕES DIFERENCIAIS PARCIAIS	68
36167	0510.000.465-3	ESPAÇOS MÉTRICOS	68
36168	0510.000.466-1	ESTRUTURA DE DADOS E PROGRAMAÇÃO	102
36169	0510.000.467-0	EXPERIMENTOS EM FÍSICA	51
35745	0510.000.214-6	FUNDAMENTOS E METODOLOGIA DO ENSINO DE MATEMÁTICA	68
36170	0510.000.468-8	GEOMETRIA NA EDUCAÇÃO BÁSICA	68
36171	0510.000.469-6	INTRODUÇÃO À COMPUTAÇÃO	68
36172	0510.000.470-0	INTRODUÇÃO À FILOSOFIA	51
36173	0510.000.471-8	INTRODUÇÃO AO ELETROMAGNETISMO	51
43077	0510.000.965-2	INTRODUÇÃO A SISTEMAS DIGITAIS	68
44494	0510.001.099-4	JOGOS NA PERSPECTIVA DO LETRAMENTO MATEMÁTICO	51
36174	0510.000.472-6	LABORATÓRIO DE MATEMÁTICA	68
44509	0510.001.114-0	LETRAMENTO ESTATÍSTICO	51
35769	0510.000.238-3	MATEMÁTICA FINANCEIRA	68
35695	0510.000.164-6	MATEMÁTICA NA EDUCAÇÃO INFANTIL	51
44499	0510.001.104-2	MATERIAIS E RECURSOS PEDAGÓGICOS NA ESCOLA	51
44496	0510.001.101-5	MODELAGEM EM EDUCAÇÃO MATEMÁTICA	68
36176	0510.000.474-2	MODELAGEM ESTATÍSTICA	68
44493	0510.001.098-5	MODELAGEM MATEMÁTICA	51
45867	0510.001.274-7	NÚMEROS IRRACIONAIS E TRANSCENDENTES	51
44489	0510.001.094-9	O LÚDICO NO ENSINO DA MATEMÁTICA NA EDUCAÇÃO INFANTIL	51
36179	0510.000.477-7	PRÁTICA DE ENSINO EM FÍSICA	68
35551	0510.000.097-6	QUÍMICA I	51
35557	0510.000.103-4	QUÍMICA II	51
36180	0510.000.478-5	TEORIA DOS CONJUNTOS	51
36181	0510.000.479-3	TÓPICOS DE EDUCAÇÃO MATEMÁTICA I	34
36182	0510.000.480-7	TÓPICOS DE EDUCAÇÃO MATEMÁTICA II	51
36183	0510.000.481-5	TÓPICOS DE EDUCAÇÃO MATEMÁTICA III	68
44504	0510.001.109-8	TÓPICOS DE EDUCAÇÃO MATEMÁTICA IV	68
45884	0510.001.291-6	TÓPICOS DE EDUCAÇÃO MATEMÁTICA IX	136
44495	0510.001.100-6	TÓPICOS DE EDUCAÇÃO MATEMÁTICA V	68
44490	0510.001.095-8	TÓPICOS DE EDUCAÇÃO MATEMÁTICA VI	68
44497	0510.001.102-4	TÓPICOS DE EDUCAÇÃO MATEMÁTICA VII	68
44507	0510.001.112-2	TÓPICOS DE EDUCAÇÃO MATEMÁTICA VIII	68
45887	0510.001.294-3	TÓPICOS DE EDUCAÇÃO MATEMÁTICA X	136
36184	0510.000.482-3	TÓPICOS DE FÍSICA	51
36185	0510.000.483-1	TÓPICOS DE HISTÓRIA DA MATEMÁTICA	51
36186	0510.000.484-0	TÓPICOS DE MATEMÁTICA I	34
36187	0510.000.485-8	TÓPICOS DE MATEMÁTICA II	51
36188	0510.000.486-6	TÓPICOS DE MATEMÁTICA III	68
44501	0510.001.106-0	TÓPICOS DE MATEMÁTICA IV	68
45874	0510.001.281-8	TÓPICOS DE MATEMÁTICA IX	136
44500	0510.001.105-1	TÓPICOS DE MATEMÁTICA V	68
44502	0510.001.107-0	TÓPICOS DE MATEMÁTICA VI	68
44503	0510.001.108-9	TÓPICOS DE MATEMÁTICA VII	68
44510	0510.001.115-0	TÓPICOS DE MATEMÁTICA VIII	68
45871	0510.001.278-3	TÓPICOS DE MATEMÁTICA X	136
43079	0510.000.967-0	TÓPICOS EM ROBÓTICA	68
36189	0510.000.487-4	TOPOLOGIA GERAL	68
36192	0510.000.490-4	VARIÁVEIS COMPLEXAS	68
50223	0510.001.765-4	ANTROPOLOGIA	51
50213	0510.001.755-6	BASES BIOLÓGICAS DO COMPORTAMENTO	68
50210	0510.001.752-9	FILOSOFIA GERAL	68
50214	0510.001.756-5	INTRODUÇÃO À PSICOLOGIA	68
50219	0510.001.761-8	PSICOLOGIA E ÉTICA PROFISSIONAL	68
50211	0510.001.753-8	SOCIOLOGIA GERAL	68
50212	0510.001.754-7	ESTATÍSTICA APLICADA À PSICOLOGIA	68
50200	0510.001.742-0	FISIOLOGIA E COMPORTAMENTO	68
50218	0510.001.760-9	MÉTODOS DE PESQUISA EM PSICOLOGIA I	68
50197	0510.001.739-6	PSICOLOGIA DO DESENVOLVIMENTO I	68
50204	0510.001.746-7	PSICOLOGIA E DIVERSIDADE HUMANA I	68
50222	0510.001.764-5	PSICOLOGIA SOCIAL	68
50216	0510.001.758-3	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
50178	0510.001.720-6	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE HISTÓRICO-CULTURAL	68
50177	0510.001.719-0	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE PSICANALÍTICO	68
50215	0510.001.757-4	MÉTODOS DE PESQUISA EM PSICOLOGIA II	68
50196	0510.001.738-7	PSICOLOGIA DO DESENVOLVIMENTO II	68
50207	0510.001.749-4	PSICOLOGIA E DIVERSIDADE HUMANA II	68
35947	0510.000.416-5	PSICOLOGIA E POLÍTICAS PÚBLICAS	68
50221	0510.001.763-6	ANÁLISE INSTITUCIONAL	51
50217	0510.001.759-2	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL I	68
50181	0510.001.723-3	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL I	68
50176	0510.001.718-0	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO I	68
50220	0510.001.762-7	GENÉTICA HUMANA APLICADA À PSICOLOGIA	68
50189	0510.001.731-3	PSICOLOGIA E SAÚDE I	68
35953	0510.000.422-0	ESTÁGIO OBRIGATÓRIO BÁSICO I	85
50229	0510.001.771-6	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL II	68
50179	0510.001.721-5	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL II	68
50230	0510.001.772-5	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO II	68
50186	0510.001.728-9	PSICOLOGIA E SAÚDE II	68
50227	0510.001.769-0	PSICOLOGIA ESCOLAR E EDUCACIONAL I	68
50194	0510.001.736-9	ANÁLISE DO COMPORTAMENTO APLICADA	34
50183	0510.001.725-1	AVALIAÇÃO PSICOLÓGICA I	68
35959	0510.000.428-9	ESTÁGIO OBRIGATÓRIO BÁSICO II	85
50228	0510.001.770-7	ORIENTAÇÃO PROFISSIONAL	68
50201	0510.001.743-0	PSICOLOGIA E NEUROCIÊNCIA	51
50226	0510.001.768-1	PSICOLOGIA ESCOLAR E EDUCACIONAL IL	68
50184	0510.001.726-0	PSICOPATOLOGIA GERAL I	68
50224	0510.001.766-3	AVALIAÇÃO PSICOLÓGICA II	68
35966	0510.000.435-1	ESTÁGIO OBRIGATÓRIO BÁSICO III	85
50180	0510.001.722-4	PSICOLOGIA DO TRABALHO	68
50182	0510.001.724-2	PSICOPATOLOGIA GERAL II	68
50187	0510.001.729-8	TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
50188	0510.001.730-4	TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE PSICANALÍTICO	68
35973	0510.000.442-4	ESTÁGIO OBRIGATÓRIO BÁSICO IV	85
50225	0510.001.767-2	PSICOLOGIA E PROCESSOS GRUPAIS	51
50195	0510.001.737-8	PSICOPATOLOGIA INFANTIL	51
35972	0510.000.441-6	SAÚDE MENTAL E TRABALHO	68
50199	0510.001.741-1	TÓPICOS AVANÇADOS EM PSICANÁLISE	34
50198	0510.001.740-2	TÓPICOS AVANÇADOS EM PSICOTERAPIA: ENFOQUE ANALÍTICO COMPORTAMENTAL	51
50185	0510.001.727-0	TÓPICOS AVANÇADOS EM PSICOTERAPIA: ENFOQUE PSICANALÍTICO	51
50202	0510.001.744-9	ESTÁGIO OBRIGATÓRIO EM PSICOLOGIA CLÍNICA E PROMOÇÃO DE SAÚDE I	170
50205	0510.001.747-6	ESTÁGIO OBRIGATÓRIO EM PSICOLOGIA ORGANIZACIONAL E DO TRABALHO I	170
50203	0510.001.745-8	ESTÁGIO OBRIGATÓRIO EM PSICOLOGIA CLÍNICA E PROMOÇÃO DE SAÚDE II	170
50206	0510.001.748-5	ESTÁGIO OBRIGATÓRIO EM PSICOLOGIA ORGANIZACIONAL E DO TRABALHO II	170
50192	0510.001.734-0	GESTÃO DE PESSOAS	68
50193	0510.001.735-0	PSICOFARMACOLOGIA	68
35923	0510.000.392-4	PSICOLOGIA AMBIENTAL	51
35921	0510.000.390-8	PSICOLOGIA DO ESPORTE	51
35922	0510.000.391-6	PSICOLOGIA DO TRÂNSITO	51
50208	0510.001.750-0	PSICOLOGIA E O SISTEMA ÚNICO DE ASSISTÊNCIA SOCIAL	51
35919	0510.000.388-6	PSICOLOGIA HOSPITALAR	51
35917	0510.000.386-0	PSICOLOGIA JURÍDICA	51
50190	0510.001.732-2	PSICOSSOMÁTICA	51
50209	0510.001.751-0	TEORIAS DE PERSONALIDADE	51
46864	0510.001.389-8	TÓPICOS AVANÇADOS EM PSICOLOGIA I	51
46861	0510.001.386-0	TÓPICOS AVANÇADOS EM PSICOLOGIA II	51
46870	0510.001.395-0	TÓPICOS AVANÇADOS EM PSICOLOGIA III	51
46860	0510.001.385-1	TÓPICOS AVANÇADOS EM PSICOLOGIA IV	51
46862	0510.001.387-0	TÓPICOS AVANÇADOS EM PSICOLOGIA V	51
46863	0510.001.388-9	TÓPICOS AVANÇADOS EM PSICOLOGIA VI	51
46865	0510.001.390-4	TÓPICOS AVANÇADOS EM PSICOLOGIA VII	51
50191	0510.001.733-1	TÓPICOS AVANÇADOS EM PSICOLOGIA VIII	68
49093	0510.001.570-2	EDUCAÇÃO ESPECIAL	68
49094	0510.001.571-1	FILOSOFIA DA EDUCAÇÃO	68
49089	0510.001.566-9	HISTÓRIA DA EDUCAÇÃO I	68
49111	0510.001.588-3	INFÂNCIA E SOCIEDADE	68
49079	0510.001.556-0	PSICOLOGIA DA EDUCAÇÃO	68
49105	0510.001.582-9	TRABALHO ACADÊMICO	68
49090	0510.001.567-8	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
49122	0510.001.599-0	ESTUDOS APROFUNDADOS EM EDUCAÇÃO ESPECIAL	68
49100	0510.001.577-6	HISTÓRIA DA EDUCAÇÃO II	68
49101	0510.001.578-5	POLÍTICAS EDUCACIONAIS	68
49075	0510.001.552-4	PSICOLOGIA DO DESENVOLVIMENTO E DA APRENDIZAGEM	68
49103	0510.001.580-0	SOCIOLOGIA DA EDUCAÇÃO	68
49087	0510.001.564-0	DIDÁTICA I	68
49109	0510.001.586-5	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
49110	0510.001.587-4	ESTUDO DE LIBRAS	68
49151	0510.001.628-1	FUNDAMENTOS DA EDUCAÇÃO INFANTIL	51
49095	0510.001.572-0	LITERATURA E EDUCAÇÃO	51
49088	0510.001.565-0	PESQUISA EM EDUCAÇÃO I	51
49086	0510.001.563-1	CURRÍCULO E EDUCAÇÃO	68
49108	0510.001.585-6	DIDÁTICA II	68
49098	0510.001.575-8	GESTÃO ESCOLAR	68
49113	0510.001.590-9	LUDICIDADE E EDUCAÇÃO	68
49128	0510.001.605-8	ORGANIZAÇÃO DO TRABALHO PEDAGÓGICO NA EDUCAÇÃO INFANTIL	51
49104	0510.001.581-0	PRÁTICA EM EDUCAÇÃO ESPECIAL	68
49076	0510.001.553-3	ARTE E EDUCAÇÃO	68
49102	0510.001.579-4	ESTÁGIO OBRIGATÓRIO III	100
49124	0510.001.601-1	FUNDAMENTOS E METODOLOGIA DO ENSINO DE CIÊNCIAS	68
49125	0510.001.602-0	FUNDAMENTOS E METODOLOGIA DO ENSINO DE GEOGRAFIA	68
49080	0510.001.557-0	FUNDAMENTOS E METODOLOGIA DO ENSINO DE LÍNGUA PORTUGUESA	68
49127	0510.001.604-9	PRÁTICA EM GESTÃO, CURRÍCULO E TRABALHO PEDAGÓGICO	68
49078	0510.001.555-1	ESTÁGIO OBRIGATÓRIO IV	100
49123	0510.001.600-2	FUNDAMENTOS E METODOLOGIA DA ALFABETIZAÇÃO	68
49126	0510.001.603-0	FUNDAMENTOS E METODOLOGIA DO ENSINO DE HISTÓRIA	68
49129	0510.001.606-7	FUNDAMENTOS E METODOLOGIA DO ENSINO DE MATEMÁTICA	68
49096	0510.001.573-0	PESQUISA EM EDUCAÇÃO II	51
49106	0510.001.583-8	PRÁTICA EM EDUCAÇÃO NA PRIMEIRA INFÂNCIA	68
49118	0510.001.595-4	EDUCAÇÃO DE JOVENS E ADULTOS	68
49119	0510.001.596-3	EDUCAÇÃO SOCIAL E EM CONTEXTOS NÃO ESCOLARES	68
49091	0510.001.568-7	ESTÁGIO OBRIGATÓRIO I	100
49150	0510.001.627-2	FUNDAMENTOS E METODOLOGIA DO ENSINO DE ARTES	68
49107	0510.001.584-7	PRÁTICA EM ALFABETIZAÇÃO	68
49116	0510.001.593-6	AVALIAÇÃO DA EDUCAÇÃO	51
49099	0510.001.576-7	ESTÁGIO OBRIGATÓRIO II	100
49130	0510.001.607-6	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
49147	0510.001.624-5	PRÁTICA EM EDUCAÇÃO DE JOVENS E ADULTOS, EDUCAÇÃO SOCIAL E CONTEXTOS NÃO ESCOLARES	68
49155	0510.001.632-5	SEMINÁRIO DE PESQUISA	34
49143	0510.001.620-9	ALFABETIZAÇÃO E LETRAMENTO DIGITAL	34
49081	0510.001.558-9	ALTAS HABILIDADES/SUPERDOTAÇÃO EM SALA DE AULA: ESTRATÉGIAS DE IDENTIFICAÇÃO	34
49082	0510.001.559-8	BOURDIEU E A EDUCAÇÃO	34
49145	0510.001.622-7	BRINQUEDOTECA	34
49097	0510.001.574-9	CONFECÇÃO DE MATERIAIS ADAPTADOS	34
49152	0510.001.629-0	CULTURA ESCOLAR	34
49115	0510.001.592-7	EDUCAÇÃO AMBIENTAL	34
49154	0510.001.631-6	EDUCAÇÃO ANTIRRACISTA E PREVENÇÃO DE VIOLÊNCIA	34
49144	0510.001.621-8	EDUCAÇÃO EM DIREITOS HUMANOS	34
49142	0510.001.619-2	EDUCAÇÃO INTEGRAL/EM TEMPO INTEGRAL	34
49117	0510.001.594-5	ESTUDOS DE PAULO FREIRE	34
49157	0510.001.634-3	ÉTICA NA FORMAÇÃO E NO TRABALHO DOCENTE	34
49153	0510.001.630-7	EXPRESSÕES VISUAIS NA EDUCAÇÃO	34
49136	0510.001.613-8	FEMINISMO DIALÓGICO E PREVENÇÃO DE VIOLÊNCIA	34
49131	0510.001.608-5	JOGOS NA ALFABETIZAÇÃO E LETRAMENTO	34
49139	0510.001.616-5	JOGOS TEATRAIS E EDUCAÇÃO	34
49112	0510.001.589-2	LEITURA E PRODUÇÃO DE TEXTOS EM EDUCAÇÃO	34
49114	0510.001.591-8	MATEMÁTICA APLICADA À EDUCAÇÃO	34
49084	0510.001.561-3	MATERIAIS E RECURSOS PEDAGÓGICOS NA ESCOLA	34
49146	0510.001.623-6	METODOLOGIAS ATIVAS	34
49140	0510.001.617-4	MOVIMENTO E MÚSICA NA EDUCAÇÃO	34
49083	0510.001.560-4	NÚCLEO DE APROFUNDAMENTO EM EDUCAÇÃO DO CAMPO	68
49120	0510.001.597-2	NÚCLEO DE APROFUNDAMENTO EM EDUCAÇÃO E FRONTEIRA	68
49121	0510.001.598-1	NÚCLEO DE APROFUNDAMENTO EM EDUCAÇÃO E GÊNERO	68
49138	0510.001.615-6	PRÁTICA EM EDUCAÇÃO DO CAMPO	34
49133	0510.001.610-0	PRÁTICA EM EDUCAÇÃO INTEGRAL	34
49148	0510.001.625-4	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE I	68
49149	0510.001.626-3	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE II	68
49132	0510.001.609-4	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE III	68
49137	0510.001.614-7	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE IV	68
49156	0510.001.633-4	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE V	68
49077	0510.001.554-2	PRÁTICAS INTEGRADORAS DE EXTENSÃO PARA A FORMAÇÃO DOCENTE VI	68
49134	0510.001.611-0	PRÁTICAS PEDAGÓGICAS E AS TECNOLOGIAS DIGITAIS NA ALFABETIZAÇÃO	34
49092	0510.001.569-6	PROCESSOS CRIATIVOS E ESTÉTICOS NA FORMAÇÃO PEDAGÓGICA	34
49141	0510.001.618-3	PROFISSÃO DOCENTE: IDENTIDADE E DESENVOLVIMENTO PROFISSIONAL	34
49085	0510.001.562-2	TÓPICOS ESPECIAIS EM EDUCAÇÃO PARA A DIVERSIDADE	34
49135	0510.001.612-9	TRANSTORNOS DE APRENDIZAGEM	34
51406	0510.002.045-3	FUNDAMENTOS HISTÓRICOS E EDUCAÇÃO FÍSICA	51
51411	0510.002.050-6	METODOLOGIA DO ENSINO DO BASQUETEBOL	68
51394	0510.002.033-7	METODOLOGIAS DE ENSINO DAS GINÁSTICAS	68
51395	0510.002.034-6	METODOLOGIAS DE ENSINO DAS LUTAS	68
51409	0510.002.048-0	METODOLOGIAS DE ENSINO DO VOLEIBOL	68
45162	0510.001.254-0	FUNDAMENTOS FILOSÓFICOS E EDUCAÇÃO FÍSICA	51
45136	0510.001.228-2	JOGO, BRINQUEDO E BRINCADEIRA	68
51396	0510.002.035-5	METODOLOGIAS DE ENSINO DO ATLETISMO	68
51408	0510.002.047-1	METODOLOGIAS DE ENSINO DO FUTEBOL E FUTSAL	68
51399	0510.002.038-2	ANATOMIA HUMANA	51
51384	0510.002.023-9	APRENDIZAGEM MOTORA	51
51392	0510.002.031-9	CRESCIMENTO E DESENVOLVIMENTO HUMANO	51
45167	0510.001.259-6	FUNDAMENTOS SOCIOANTROPOLÓGICOS E EDUCAÇÃO FISICA	68
51398	0510.002.037-3	INTRODUÇÃO AO TRABALHO ACADÊMICO	51
51391	0510.002.030-0	METODOLOGIAS DE ENSINO DAS DANÇAS	68
51404	0510.002.043-5	ORGANIZAÇÃO DE EVENTOS NA EDUCAÇÃO FÍSICA	68
51400	0510.002.039-1	ANATOMIA APLICADA À EDUCAÇÃO FÍSICA ESCOLAR	51
51414	0510.002.053-3	EDUCAÇÃO FÍSICA ADAPTADA	68
51385	0510.002.024-8	EDUCAÇÃO FÍSICA NA EDUCAÇÃO INFANTIL	68
45159	0510.001.251-3	PESQUISAS EM EDUCAÇÃO FÍSICA	51
51397	0510.002.036-4	PRÁTICAS CORPORAIS DE AVENTURA	68
51410	0510.002.049-0	PREVENÇÃO DE ACIDENTES E SOCORROS DE URGÊNCIA EM EDUCAÇÃO FÍSICA	34
51405	0510.002.044-4	TEORIAS PEDAGÓGICAS NA EDUCAÇÃO FÍSICA	51
45129	0510.001.221-9	DIDÁTICA E AVALIAÇÃO EM EDUCAÇÃO FÍSICA	68
51401	0510.002.040-8	EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS INICIAIS	51
51386	0510.002.025-7	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NA EDUCAÇÃO INFANTIL	100
51403	0510.002.042-6	ESTATÍSTICA APLICADA À EDUCAÇÃO FÍSICA	51
24634	0505.000.781-6	FISIOLOGIA HUMANA E DO EXERCÍCIO I	68
30453	0505.000.993-2	NUTRIÇÃO E ATIVIDADE FÍSICA	34
51390	0510.002.029-3	EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS FINAIS	51
51389	0510.002.028-4	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS INICIAIS	100
51393	0510.002.032-8	ESTUDOS DO LAZER	68
24641	0505.000.788-3	FISIOLOGIA HUMANA E DO EXERCÍCIO II	68
45138	0510.001.230-8	MEDIDAS E AVALIAÇÃO EM EDUCAÇÃO FÍSICA	51
34187	0505.001.037-0	METODOLOGIAS DE PESQUISA CIENTÍFICA	51
51412	0510.002.051-5	METODOLOGIAS DO ENSINO DO HANDEBOL	68
34178	0505.001.028-0	BIOMECÂNICA DO MOVIMENTO HUMANO	51
51402	0510.002.041-7	EDUCAÇÃO FÍSICA NO ENSINO MÉDIO	68
51388	0510.002.027-5	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS FINAIS	100
51413	0510.002.052-4	PRÁTICA CIENTÍFICA I	51
51407	0510.002.046-2	EDUCAÇÃO FÍSICA E PROMOÇÃO DA SAÚDE	51
51387	0510.002.026-6	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO MÉDIO	100
34194	0505.001.044-2	METODOLOGIAS DE ENSINO DAS ATIVIDADES AQUÁTICAS	68
51382	0510.002.021-0	PRÁTICA CIENTÍFICA II	51
45168	0510.001.260-2	TREINAMENTO FÍSICO NA ESCOLA	51
45163	0510.001.255-0	ATIVIDADES FÍSICAS PARA GRUPOS ESPECÍFICOS	51
45150	0510.001.242-4	CAPOEIRA	51
45132	0510.001.224-6	EDUCAÇÃO DE JOVENS E ADULTOS	51
45155	0510.001.247-0	EDUCAÇÃO FÍSICA E CIRCO	51
45153	0510.001.245-1	EDUCAÇÃO FÍSICA, EDUCAÇÃO E FRONTEIRA	51
45145	0510.001.237-1	GÊNERO, CORPO E SEXUALIDADE NA EDUCAÇÃO FÍSICA ESCOLAR	51
51383	0510.002.022-0	GESTÃO E POLÍTICA PARA O ESPORTE	51
45135	0510.001.227-3	GINÁSTICA DE ACADEMIA	51
45165	0510.001.257-8	MUSCULAÇÃO	51
45141	0510.001.233-5	PSICOLOGIA DO ESPORTE	51
45131	0510.001.223-7	RECREAÇÃO	51
45161	0510.001.253-1	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO FÍSICA I	51
45142	0510.001.234-4	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO FÍSICA II	51
45143	0510.001.235-3	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO FÍSICA III	51
45157	0510.001.249-8	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO FÍSICA IV	51
45128	0510.001.220-0	TREINAMENTO PERSONALIZADO	51
50325	0510.001.778-0	COMPUTAÇÃO E SOCIEDADE	34
50329	0510.001.782-3	FUNDAMENTOS DA ADMINISTRAÇÃO	68
50338	0510.001.791-2	FUNDAMENTOS DE SISTEMAS DE INFORMAÇÃO	68
50336	0510.001.789-7	MATEMÁTICA ELEMENTAR	68
50322	0510.001.775-2	ALGORITMOS E PROGRAMAÇÃO II	102
43069	0510.000.957-2	FUNDAMENTOS DE TEORIA DA COMPUTAÇÃO	68
50337	0510.001.790-3	INTRODUÇÃO A SISTEMAS DIGITAIS	68
50335	0510.001.788-8	MÉTODOS E TÉCNICAS DE PESQUISA	68
50340	0510.001.793-0	MINDSET E CRIATIVIDADE	34
43084	0510.000.972-3	ARQUITETURA DE COMPUTADORES	68
50323	0510.001.776-1	BANCO DE DADOS	68
50326	0510.001.779-9	ENGENHARIA DE SOFTWARE	68
50320	0510.001.773-4	ESTRUTURAS DE DADOS	68
50327	0510.001.780-5	GERÊNCIA DE PROJETOS	68
50344	0510.001.797-7	GESTÃO ESTRATÉGICA	68
50330	0510.001.783-2	INTRODUÇÃO A SISTEMAS OPERACIONAIS	68
50347	0510.001.800-7	LABORATÓRIO DE BANCO DE DADOS	68
50350	0510.001.803-4	LINGUAGEM DE PROGRAMAÇÃO ORIENTADA A OBJETOS	68
37085	0510.000.746-6	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS	68
50331	0510.001.784-1	ESTATÍSTICA	68
50332	0510.001.785-0	PROGRAMAÇÃO PARA WEB	68
50351	0510.001.804-3	QUALIDADE DE SOFTWARE	68
50321	0510.001.774-3	REDES DE COMPUTADORES	68
50349	0510.001.802-5	INTELIGÊNCIA ARTIFICIAL	68
50343	0510.001.796-8	PROGRAMAÇÃO PARA WEB AVANÇADA	68
37093	0510.000.754-7	SEGURANÇA E AUDITORIA DE SISTEMAS	68
50348	0510.001.801-6	STARTUPS E ECOSSISTEMA INOVADOR	68
50341	0510.001.794-0	VERIFICAÇÃO, VALIDAÇÃO E TESTE DE SOFTWARE	68
50345	0510.001.798-6	CIÊNCIA DE DADOS	68
50346	0510.001.799-5	COMPORTAMENTO ORGANIZACIONAL	34
50334	0510.001.787-9	ESTÁGIO OBRIGATÓRIO	225
50328	0510.001.781-4	INTERAÇÃO HUMANO-COMPUTADOR	68
50342	0510.001.795-9	PROGRAMAÇÃO PARA DISPOSITIVOS MÓVEIS	68
50324	0510.001.777-0	COMPUTAÇÃO DISTRIBUÍDA	68
50339	0510.001.792-1	GOVERNANÇA DE TI	68
50333	0510.001.786-0	SISTEMAS DE APOIO À DECISÃO	68
37105	0510.000.765-2	ADMINISTRAÇÃO DE SISTEMAS	68
37107	0510.000.767-9	ALGORITMOS PARALELOS	68
37111	0510.000.771-7	COMPILADORES I	68
37113	0510.000.773-3	COMPUTAÇÃO GRÁFICA	68
43092	0510.000.980-3	DIREITO DIGITAL	68
43080	0510.000.968-0	DIREITOS HUMANOS	34
43082	0510.000.970-5	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
37118	0510.000.778-4	GEOMETRIA COMPUTACIONAL	68
37120	0510.000.780-6	GERÊNCIA DE REDES	68
37122	0510.000.782-2	IMPLEMENTAÇÃO E EXPERIMENTAÇÃO ALGORÍTIMICA	68
43065	0510.000.953-6	INFORMÁTICA NA EDUCAÇÃO	68
37125	0510.000.785-7	INTRODUÇÃO À COMPLEXIDADE COMPUTACIONAL	68
37126	0510.000.786-5	INTRODUÇÃO À CRIPTOGRAFIA COMPUTACIONAL	68
43095	0510.000.983-0	INTRODUÇÃO À ECONOMIA	68
37128	0510.000.788-1	JOGOS DIGITAIS I	68
37130	0510.000.790-3	LABORATÓRIO DE DESENVOLVIMENTO DE SISTEMAS ORIENTADO E OBJETOS	68
37133	0510.000.793-8	LINGUAGENS FORMAIS E AUTÔMATOS	68
43096	0510.000.984-0	OTIMIZAÇÃO COMBINATÓRIA	68
43089	0510.000.977-9	PROCESSAMENTO DE IMAGENS DIGITAIS	68
37140	0510.000.800-4	SIMULAÇÃO DE SISTEMAS	68
37141	0510.000.801-2	SISTEMAS DISTRIBUÍDOS	68
37144	0510.000.804-7	TEORIA DOS GRAFOS E SEUS ALGORITMOS	68
43097	0510.000.985-9	TÓPICOS EM ADMINISTRAÇÃO	68
43093	0510.000.981-2	TÓPICOS EM ARQUITETURA DE COMPUTADORES	68
43101	0510.000.989-5	TÓPICOS EM BANCO DE DADOS	68
43102	0510.000.990-1	TÓPICOS EM ENGENHARIA DE SOFTWARE	68
43066	0510.000.954-5	TÓPICOS EM ENGENHARIA DE SOFTWARE EXPERIMENTAL	68
43074	0510.000.962-5	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL	68
43072	0510.000.960-7	TÓPICOS EM INTERAÇÃO HUMANO COMPUTADOR	68
43098	0510.000.986-8	TÓPICOS EM LINGUAGENS DE PROGRAMAÇÃO	68
43100	0510.000.988-6	TÓPICOS EM PARADIGMAS DE PROGRAMAÇÃO	34
43068	0510.000.956-3	TÓPICOS EM PROGRAMAÇÃO PARA DISPOSITIVOS MÓVEIS	68
43067	0510.000.955-4	TÓPICOS EM REDES DE COMPUTADORES	68
40950	0510.000.950-7	TÓPICOS EM SISTEMAS DE COMPUTAÇÃO	68
40951	0510.000.951-5	TÓPICOS EM SISTEMAS DE INFORMAÇÃO	68
43078	0510.000.966-1	TÓPICOS EM SISTEMAS DE INFORMAÇÃO II	68
43099	0510.000.987-7	TÓPICOS EM SISTEMAS DISTRIBUÍDOS	68
43094	0510.000.982-1	TÓPICOS EM SISTEMAS OPERACIONAIS	68
40949	0510.000.949-3	TÓPICOS EM TEORIA DA COMPUTAÇAO	68
43064	0510.000.952-7	TÓPICOS ESPECIAIS EM COMPUTAÇÃO I	34
43075	0510.000.963-4	TÓPICOS ESPECIAIS EM COMPUTAÇÃO II	34
37146	0510.000.805-5	TÓPICOS ESPECIAIS EM: GESTÃO OPERACIONAL E CADEIA DE SUPRIMENTOS	68
43071	0510.000.959-0	TÓPICOS ESPECIAIS EM SISTEMAS DE INFORMAÇÃO I	34
43070	0510.000.958-1	TÓPICOS ESPECIAIS EM SISTEMAS DE INFORMAÇÃO II	34
44976	0709.001.222-1	TRABALHO DE CAMPO INTEGRADO	68
50518	0709.002.079-8	CARTOGRAFIA	68
50607	0709.002.168-8	GEOLOGIA	68
50521	0709.002.082-2	HISTÓRIA DO PENSAMENTO GEOGRÁFICO	68
50606	0709.002.167-9	CLIMATOLOGIA	68
50622	0709.002.183-9	GEOGRAFIA ECONÔMICA	68
50509	0709.002.070-6	CULTURA E RELAÇÕES ÉTNICO-RACIAIS	68
50516	0709.002.077-0	GEOGRAFIA DA POPULAÇÃO	68
50614	0709.002.175-9	GEOGRAFIA URBANA	68
50608	0709.002.169-7	GEOMORFOLOGIA	68
44958	0709.001.204-3	CARTOGRAFIA TEMÁTICA	68
50523	0709.002.084-0	GEOGRAFIA AGRÁRIA	68
50626	0709.002.187-5	MÉTODOS E TÉCNICAS DE PESQUISA	68
50514	0709.002.075-1	PLANEJAMENTO URBANO E REGIONAL	68
50613	0709.002.174-0	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
47388	0709.001.708-6	ELABORAÇÃO DE PROJETOS E RELATÓRIOS TÉCNICOS	68
47397	0709.001.717-5	GEOGRAFIA E MOVIMENTOS SOCIAIS	68
50508	0709.002.069-0	GEOGRAFIA REGIONAL	68
50617	0709.002.178-6	SENSORIAMENTO REMOTO	68
50619	0709.002.180-1	GEOPROCESSAMENTO	68
50611	0709.002.172-1	HIDROLOGIA	68
50615	0709.002.176-8	PEDOLOGIA	68
50623	0709.002.184-8	TEORIA E MÉTODOS DA GEOGRAFIA	68
50618	0709.002.179-5	ESTÁGIO OBRIGATÓRIO I	124
47391	0709.001.711-0	GEOGRAFIA DOS ESPAÇOS GLOBAIS	68
50625	0709.002.186-6	INTRODUÇÃO AO PROJETO DE PESQUISA CIENTÍFICA	68
44968	0709.001.214-1	SISTEMA DE INFORMAÇÃO GEOGRÁFICA	68
50616	0709.002.177-7	BIOGEOGRAFIA	68
50620	0709.002.181-0	ESTÁGIO OBRIGATÓRIO II	124
50601	0709.002.162-3	PLANEJAMENTO AMBIENTAL	68
47386	0709.001.706-8	CLIMATOLOGIA E APLICAÇÕES	68
47196	0709.001.645-4	CLIMATOLOGIA URBANA	68
47381	0709.001.701-2	DINÂMICA REGIONAL E PRODUÇÃO AGRÁRIA NO MATO GROSSO DO SUL	68
34565	0709.000.080-0	ESTUDO DE LIBRAS	51
47389	0709.001.709-5	FISIOLOGIA DA PAISAGEM	68
44950	0709.001.196-8	FOTOINTERPRETAÇÃO E AEROFOTOGRAMETRIA	68
47197	0709.001.646-3	GÊNERO E PODER NA ANÁLISE GEOGRÁFICA	68
47392	0709.001.712-0	GEOGRAFIA CULTURAL	68
44992	0709.001.238-4	GEOGRAFIA DA ENERGIA E DA INDÚSTRIA	68
47393	0709.001.713-9	GEOGRAFIA DA SAÚDE	68
47384	0709.001.704-0	GEOGRAFIA DAS REDES E DOS TERRITÓRIOS	68
44964	0709.001.210-5	GEOGRAFIA DE MATO GROSSO DO SUL	68
44970	0709.001.216-0	GEOGRAFIA DO BRASIL	68
44951	0709.001.197-7	GEOGRAFIA POLÍTICA	68
47400	0709.001.720-0	GEOMORFOLOGIA AMBIENTAL	68
47399	0709.001.719-3	GEOMORFOLOGIA FLUVIAL	68
44974	0709.001.220-3	LEGISLAÇÃO AMBIENTAL	68
50605	0709.002.166-0	MATEMÁTICA E ESTATÍSTICA APLICADA À GEOGRAFIA	68
50603	0709.002.164-1	MORFOLOGIA DO SOLO	68
44986	0709.001.232-0	PLANEJAMENTO DO TURISMO	68
44990	0709.001.236-6	REDAÇÃO E PRODUÇÃO DE TEXTO	68
50604	0709.002.165-0	SEMINÁRIOS DE GRADUAÇÃO	68
44939	0709.001.185-0	TEORIA DA REGIÃO E DA REGIONALIZAÇÃO	68
44975	0709.001.221-2	TOPOGRAFIA E GEODÉSIA	68
45370	0709.001.312-0	VEÍCULOS AÉREOS NÃO TRIPULADOS	68
47141	0709.001.590-2	BIOLOGIA CELULAR I	51
38984	0709.000.657-4	BIOLOGIA DE PROTOSTOMIA I	51
47160	0709.001.609-8	BIOLOGIA E SISTEMÁTICA DE CRIPTÓGAMAS I	51
38986	0709.000.658-2	EMBRIOLOGIA	34
47170	0709.001.619-6	FILOSOFIA E HISTÓRIA DA CIÊNCIA	34
47190	0709.001.639-2	GEOLOGIA	51
47165	0709.001.614-0	MATEMÁTICA	34
44451	0709.001.144-9	MORFOLOGIA VEGETAL	51
38992	0709.000.662-0	QUÍMICA GERAL E ORGÂNICA	68
47193	0709.001.642-7	ANATOMIA VEGETAL	34
38994	0709.000.664-7	BIOESTATÍSTICA	34
38995	0709.000.665-5	BIOLOGIA CELULAR II	51
38996	0709.000.666-3	BIOLOGIA DE PROTOSTOMIA II	51
47191	0709.001.640-9	BIOLOGIA E SISTEMÁTICA DE CRIPTÓGAMAS II	51
44475	0709.001.168-1	HISTOLOGIA	51
47156	0709.001.605-1	INFORMÁTICA	51
47180	0709.001.629-4	PARASITOLOGIA	51
39055	0709.000.672-8	ANATOMIA ANIMAL E HUMANA	51
47169	0709.001.618-7	BIOLOGIA DE DEUTEROSTOMIA I	51
47162	0709.001.611-3	BIOLOGIA E SISTEMÁTICA DE FANERÓGAMAS I	51
44469	0709.001.162-7	BIOQUÍMICA I	51
47166	0709.001.615-0	CONSERVAÇÃO E EDUCAÇÃO AMBIENTAL	34
39051	0709.000.668-0	FÍSICA	34
39058	0709.000.675-2	GENÉTICA BÁSICA	51
39059	0709.000.676-0	PALEONTOLOGIA	51
39056	0709.000.673-6	BIOFÍSICA	34
47134	0709.001.583-1	BIOLOGIA DE DEUTEROSTOMIA II	51
47161	0709.001.610-4	BIOLOGIA E SISTEMÁTICA DE FANERÓGAMAS II	51
44470	0709.001.163-6	BIOQUÍMICA II	34
47171	0709.001.620-2	EVOLUÇÃO	51
47118	0709.001.567-1	FISIOLOGIA ANIMAL E HUMANA	51
39065	0709.000.682-5	GENÉTICA APLICADA	51
47147	0709.001.596-7	METODOLOGIA E COMUNICAÇÃO CIENTÍFICA	34
47133	0709.001.582-2	BIOGEOGRAFIA	51
39068	0709.000.685-0	BIOLOGIA MOLECULAR I	51
47148	0709.001.597-6	DELINEAMENTO EXPERIMENTAL	34
39081	0709.000.698-1	ECOLOGIA I	51
47183	0709.001.632-9	ESTATÍSTICA EXPERIMENTAL (MODELOS/NPAR/MULTIDIM)	68
47144	0709.001.593-0	EXPERIMENTAÇÃO CIENTÍFICA	34
47146	0709.001.595-8	FISIOLOGIA DO METABOLISMO VEGETAL	51
47121	0709.001.570-6	IMUNOLOGIA	51
47135	0709.001.584-0	MICROBIOLOGIA	51
47194	0709.001.643-6	BIOLOGIA MOLECULAR II	51
47167	0709.001.616-9	ECOLOGIA II	51
47181	0709.001.630-0	EMPREENDEDORISMO	34
47120	0709.001.569-0	FISIOLOGIA DO DESENVOLVIMENTO VEGETAL	51
47158	0709.001.607-0	GENÔMICA	51
47184	0709.001.633-8	GESTÃO AMBIENTAL	51
47189	0709.001.638-3	LEGISLAÇÃO DO PROFISSIONAL BIÓLOGO	34
47138	0709.001.587-8	TRANSFORMAÇÃO GENÉTICA (DNA RECOMBINANTE)	51
47130	0709.001.579-8	BIOÉTICA E BIOSSEGURANÇA	51
47177	0709.001.626-7	BIOLOGIA DA CONSERVAÇÃO	51
47124	0709.001.573-3	BIOTECNOLOGIA	51
47188	0709.001.637-4	ENZIMOLOGIA	51
47192	0709.001.641-8	ESTÁGIO OBRIGATÓRIO	408
47126	0709.001.575-1	ANÁLISE GENÉTICA	51
47143	0709.001.592-0	ANIMAIS PEÇONHENTOS E VENENOSOS	68
47178	0709.001.627-6	ASPECTOS MOLECULARES DA INTERAÇÃO PLANTA-MICRORGANISMO	51
47163	0709.001.612-2	AVALIAÇÃO DO IMPACTO AMBIENTAL	51
47159	0709.001.608-9	AVALIAÇÃO NUMÉRICA DA BIODIVERSIDADE	51
47119	0709.001.568-0	BIOLOGIA DE INSETOS SOCIAIS	51
44468	0709.001.161-8	BIOLOGIA DE PEIXES DE ÁGUA DOCE	68
47103	0709.001.552-8	BIOLOGIA MOLECULAR DE PLANTAS	51
47104	0709.001.553-7	BIOLOGIA MOLECULAR E HEREDIETARIEDADE	51
47105	0709.001.554-6	BIOLOGIA REPRODUTIVA DE ANGIOSPERMAS	51
47157	0709.001.606-0	BIOQUÍMICA EXPERIMENTAL	51
47152	0709.001.601-5	BIOTECNOLOGIA ANIMAL	51
47139	0709.001.588-7	BIOTECNOLOGIA VEGETAL	51
47140	0709.001.589-6	CITOGENÉTICA	51
47185	0709.001.634-7	CITOGENÉTICA E MANIPULAÇÃO CROMOSSÔMICA	51
47110	0709.001.559-1	CLADÍSTICA, EVOLUÇÃO E A NOVA NOMENCLATURA DOS DEUTEROSTÔMIA	51
47128	0709.001.577-0	CLIMATOLOGIA	51
47179	0709.001.628-5	CONSERVAÇÃO DE RECURSOS GENÉTICOS E BIODIVERSIDADE	51
47123	0709.001.572-4	CONTROLE DA EXPRESSÃO GÊNICA	51
47127	0709.001.576-0	CULTURA DE TECIDOS VEGETAIS	51
47168	0709.001.617-8	DIVERSIDADE EM AMBIENTES AQUÁTICOS	51
39105	0709.000.718-0	ECOFISIOLOGIA VEGETAL	68
44455	0709.001.148-5	ECOLOGIA DE RIOS E RIACHOS	68
47116	0709.001.565-3	EMBRIOLOGIA EXPERIMENTAL	51
47125	0709.001.574-2	ESTRUTURA DE MACROMOLÉCULAS	51
47137	0709.001.586-9	FARMACOLOGIA	51
44464	0709.001.157-4	FAUNA SELVAGEM: BIOLOGIA DA CONSERVAÇÃO	68
44463	0709.001.156-5	FISIOLOGIA DE SEMENTES	68
47132	0709.001.581-3	FLORA E VEGETAÇÃO REGIONAL	51
47151	0709.001.600-6	FLORÍSTICA	51
47195	0709.001.644-5	FUNDAMENTOS DE BIOLOGIA E FISIOLOGIA CELULAR	51
47115	0709.001.564-4	FUNDAMENTOS DE BIOTECNOLOGIA	51
47182	0709.001.631-0	GENÉTICA DE MICRORGANISMOS	51
47108	0709.001.557-3	GENÉTICA MOLECULAR	51
47107	0709.001.556-4	GEOMORFOLOGIA GERAL E ESCULTURAL	51
47129	0709.001.578-9	GEOPROCESSAMENTO	51
47109	0709.001.558-2	HERPETOLOGIA	51
47106	0709.001.555-5	HIDROGEOLOGIA	51
47136	0709.001.585-0	IMUNOLOGIA CELULAR	51
44476	0709.001.169-0	INTERAÇÕES BIOLÓGICAS	68
47172	0709.001.621-1	INTRODUÇÃO À BIOTECNOLOGIA	51
47174	0709.001.623-0	INTRODUÇÃO À FITOSSOCIOLOGIA	51
39112	0709.000.725-2	INTRODUÇÃO À ORNITOLOGIA DE CAMPO	68
37810	0709.000.545-4	CONVERSAÇÃO EM LÍNGUA INGLESA	34
47175	0709.001.624-9	INTRODUÇÃO ÀS ADAPTAÇÕES EVOLUTIVAS DOS INVERTEBRADOS	68
47176	0709.001.625-8	LABORATÓRIO DE BIOQUÍMICA E BIOLOGIA MOLECULAR	51
39114	0709.000.727-9	LEVANTAMENTOS GEOAMBIENTAIS	68
47101	0709.001.550-0	LIMNOLOGIA	51
47145	0709.001.594-9	MANEJO DE BACIAS HIDROGRÁFICAS	51
47154	0709.001.603-3	MANEJO DE COLEÇÕES BIOLÓGICAS	51
47186	0709.001.635-6	MARCADORES MOLECULARES	51
47102	0709.001.551-9	MASTOZOOLOGIA	34
47122	0709.001.571-5	MECANISMOS DE SINALIZAÇÃO CELULAR	51
39115	0709.000.728-7	MÉTODOS E MELHORAMENTO GENÉTICO	68
39116	0709.000.729-5	MUTAGÊNESE AMBIENTAL	51
47187	0709.001.636-5	MUTAGÊNESE E REPARO DE DNA	51
47173	0709.001.622-0	PLANEJAMENTO E GESTÃO DE RECURSOS HÍDRICOS	51
47117	0709.001.566-2	PLANTAS MEDICINAIS E AROMÁTICAS	51
47114	0709.001.563-5	PROCESSOS BIOTECNOLÓGICOS	51
47111	0709.001.560-8	PROTEÍNAS	51
47112	0709.001.561-7	QUALIDADE DAS ÁGUAS SUPERFICIAIS DOCE EM BACIAS HIDROGRÁFICAS	51
47164	0709.001.613-1	RESTAURAÇÃO DE ÁREAS DEGRADADAS	51
44995	0709.001.241-9	SENSORIAMENTO REMOTO	68
47094	0709.001.543-9	SISTEMÁTICA BOTÂNICA AVANÇADA	68
47150	0709.001.599-4	SISTEMÁTICA E DIVERSIDADE DOS CHORDATA	51
47153	0709.001.602-4	SISTEMÁTICA FILOGENÉTICA E CLADÍSTICA	51
47113	0709.001.562-6	TÉCNICAS ANALÍTICAS	51
47142	0709.001.591-1	TÉCNICAS DE ANÁLISES NUMÉRICAS	51
44456	0709.001.149-4	TÓPICOS ESPECIAIS EM BIOLOGIA I	68
44453	0709.001.146-7	TÓPICOS ESPECIAIS EM BIOLOGIA II	51
44459	0709.001.152-9	TÓPICOS ESPECIAIS EM BIOLOGIA III	34
47131	0709.001.580-4	TÓPICOS ESPECIAIS EM BIOLOGIA IV	68
47155	0709.001.604-2	TRATAMENTO DE RESÍDUOS INDUSTRIAIS	51
47149	0709.001.598-5	VIROLOGIA	51
50014	0709.001.978-8	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
50004	0709.001.968-0	LÍNGUA ESPANHOLA I	68
49988	0709.001.952-7	METODOLOGIA DO ENSINO DE LITERATURA INFANTO-JUVENIL	34
39194	0709.000.748-1	POLÍTICAS EDUCACIONAIS	51
50024	0709.001.988-6	PRÁTICA DE LEITURA E DE PRODUÇÃO DE TEXTOS I	85
49986	0709.001.950-9	PRÁTICA DE NORMAS GRAMATICAIS DA LÍNGUA PORTUGUESA	51
50019	0709.001.983-0	TEORIA DA LITERATURA I	34
35182	0709.000.243-9	EDUCAÇÃO ESPECIAL	51
50030	0709.001.994-8	FUNDAMENTOS DE LINGUÍSTICA	34
49989	0709.001.953-6	LÍNGUA ESPANHOLA II	68
43788	0709.001.100-0	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
50008	0709.001.972-3	PRÁTICA DE LEITURA E DE FORMAÇÃO DO LEITOR LITERÁRIO	85
50006	0709.001.970-5	PRÁTICA DE LEITURA E DE PRODUÇÃO DE TEXTOS II	51
50022	0709.001.986-8	TEORIA DA LITERATURA II	34
50020	0709.001.984-0	FONÉTICA E FONOLOGIA DA LÍNGUA PORTUGUESA	68
50007	0709.001.971-4	FUNDAMENTOS DE LINGUÍSTICA PARA A FORMAÇÃO DE PROFESSORES I	34
49999	0709.001.963-4	LÍNGUA ESPANHOLA III	68
49987	0709.001.951-8	LITERATURA, SOCIEDADE E FORMAÇÃO DE PROFESSORES	68
50021	0709.001.985-9	PRÁTICA DE LEITURA E DE PRODUÇÃO DE TEXTOS ACADÊMICOS	51
43783	0709.001.095-1	PSICOLOGIA E EDUCAÇÃO	51
50023	0709.001.987-7	TEORIA DA LITERATURA III	34
50032	0709.001.996-6	FUNDAMENTOS DE LINGUÍSTICA PARA A FORMAÇÃO DE PROFESSORES II	34
49990	0709.001.954-5	LÍNGUA ESPANHOLA IV	68
49981	0709.001.945-6	LITERATURA PORTUGUESA I	68
50025	0709.001.989-5	MORFOLOGIA DA LÍNGUA PORTUGUESA	68
50027	0709.001.991-0	PRÁTICA E METODOLOGIAS DO ENSINO DE LÍNGUA PORTUGUESA	51
50028	0709.001.992-0	TEORIA DA LITERATURA IV	34
50031	0709.001.995-7	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA I	51
49984	0709.001.948-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA I	51
35198	0709.000.259-5	FUNDAMENTOS DE DIDÁTICA	51
50009	0709.001.973-2	LÍNGUA ESPANHOLA V	68
49997	0709.001.961-6	LITERATURA PORTUGUESA II	68
50005	0709.001.969-9	PRÁTICA DE CRÍTICA LITERÁRIA	51
49983	0709.001.947-4	SINTAXE DA LÍNGUA PORTUGUESA	68
50000	0709.001.964-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA II	51
50012	0709.001.976-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA II	51
50010	0709.001.974-1	FUNDAMENTOS DO TEXTO E DO DISCURSO	68
50011	0709.001.975-0	LETRAMENTOS E FORMAÇÃO DE PROFESSORES DE LÍNGUAS	68
49991	0709.001.955-4	LÍNGUA ESPANHOLA VI	68
50017	0709.001.981-2	LITERATURA BRASILEIRA I	68
50002	0709.001.966-1	SEMÂNTICA DA LÍNGUA PORTUGUESA	51
43775	0709.001.087-1	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
50033	0709.001.997-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA III	51
49982	0709.001.946-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA III	51
50026	0709.001.990-1	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LÍNGUA ESPANHOLA I	68
50001	0709.001.965-2	LITERATURA BRASILEIRA II	68
49985	0709.001.949-2	LITERATURAS DE LÍNGUA ESPANHOLA I	68
50016	0709.001.980-3	SOCIOLINGUÍSTICA	68
50003	0709.001.967-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA IV	51
50013	0709.001.977-9	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA IV	51
50029	0709.001.993-9	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LÍNGUA ESPANHOLA II	68
49998	0709.001.962-5	HISTÓRIA DA LÍNGUA PORTUGUESA	68
50018	0709.001.982-1	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
49992	0709.001.956-3	LITERATURA BRASILEIRA III	68
50015	0709.001.979-7	LITERATURAS DE LÍNGUA ESPANHOLA II	68
37807	0709.000.542-0	ANÁLISE DO DISCURSO	34
37808	0709.000.543-8	BILINGUISMO	34
37809	0709.000.544-6	CONVERSAÇÃO EM LÍNGUA ESPANHOLA	34
37811	0709.000.546-2	CULTURA BRASILEIRA	34
37812	0709.000.547-0	CULTURAS DE LÍNGUA INGLESA	34
37813	0709.000.548-9	ESTUDOS DE TRADUÇÃO DE ESPANHOL	34
37814	0709.000.549-7	ESTUDOS DE TRADUÇÃO DE INGLÊS	34
37815	0709.000.550-0	ESTUDOS ESPECÍFICOS DE LITERATURA EM LÍNGUA ESPANHOLA	34
37816	0709.000.551-9	ESTUDOS ESPECÍFICOS DE LITERATURA EM LÍNGUA INGLESA	34
37817	0709.000.552-7	ESTUDOS ESPECÍFICOS DO TEXTO POÉTICO	34
49993	0709.001.957-2	ESTUDOS ESPECÍFICOS EM LITERATURA	34
37818	0709.000.553-5	FICÇÃO E HISTÓRIA	34
37819	0709.000.554-3	FONÉTICA E FONOLOGIA DA LÍNGUA INGLESA	34
37820	0709.000.555-1	FONOLOGIA E VARIAÇÃO	34
43789	0709.001.101-9	FUNDAMENTOS DE FILOLOGIA PORTUGUESA	34
37821	0709.000.556-0	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE LÍNGUAS	34
37822	0709.000.557-8	HISTÓRIA DA ARTE	34
37823	0709.000.558-6	INTRODUÇÃO À ENUNCIAÇÃO	34
37824	0709.000.559-4	INTRODUÇÃO À FILOSOFIA	34
37825	0709.000.560-8	INTRODUÇÃO À GRAMÁTICA FUNCIONAL	34
37826	0709.000.561-6	INTRODUÇÃO À GRAMATICALIZAÇÃO	34
43778	0709.001.090-6	INTRODUÇÃO À LEXICOGRAFIA PEDAGÓGICA	34
37888	0709.000.623-0	INTRODUÇÃO A LEXICOLOGIA E LEXICOGRAFIA	34
37827	0709.000.562-4	INTRODUÇÃO À SEMIÓTICA	34
37828	0709.000.563-2	INTRODUÇÃO ÀS LÍNGUAS INDÍGENAS	34
37829	0709.000.564-0	LABORATÓRIO DE ENSINO DE GRAMÁTICA	34
37830	0709.000.565-9	LÍNGUA E CULTURA HISPÂNICA	34
37831	0709.000.566-7	LÍNGUA INGLESA INSTRUMENTAL	34
37833	0709.000.568-3	LINGUÍSTICA ROMÂNICA	34
37834	0709.000.569-1	LITERATURA COMPARADA	34
37835	0709.000.570-5	LITERATURA E CINEMA	34
37836	0709.000.571-3	LITERATURA HISPANO-AMERICANA	34
49994	0709.001.958-1	LITERATURA INFANTO-JUVENIL	34
37838	0709.000.573-0	LITERATURA PORTUGUESA CONTEMPORÂNEA	34
37839	0709.000.574-8	MÉTODOS E TÉCNICAS DE ALFABETIZAÇÃO	34
37840	0709.000.575-6	PRÁTICA DE ANÁLISE LITERÁRIA	34
43777	0709.001.089-0	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
37842	0709.000.577-2	PSICOLINGUÍSTICA	34
37843	0709.000.578-0	SOCIOLOGIA GERAL	34
43779	0709.001.091-5	TECNOLOGIAS DIGITAIS E ENSINO DE LÍNGUA ESTRANGEIRA	34
43787	0709.001.099-8	TECNOLOGIAS DIGITAIS E ENSINO DE LÍNGUAS	34
37844	0709.000.579-9	TENDÊNCIAS DE FICÇÃO MODERNA E POÉTICAS DE VANGUARDA	34
37845	0709.000.580-2	TEXTO TEATRAL	34
49995	0709.001.959-0	TÓPICOS DE ANÁLISE LINGUÍSTICA	34
37846	0709.000.581-0	TÓPICOS DE LITERATURA UNIVERSAL	34
49996	0709.001.960-7	TÓPICOS ESPECIAIS DE LÍNGUA PORTUGUESA	34
49352	0709.001.837-9	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
49348	0709.001.833-2	FILOSOFIA DA EDUCAÇÃO	68
49349	0709.001.834-1	HISTÓRIA DA EDUCAÇÃO I	68
49350	0709.001.835-0	SOCIOLOGIA DA EDUCAÇÃO	68
49354	0709.001.839-7	TRABALHO ACADÊMICO	68
49353	0709.001.838-8	HISTÓRIA DA EDUCAÇÃO II	68
49355	0709.001.840-3	POLÍTICAS EDUCACIONAIS	68
49395	0709.001.880-6	PRÁTICA EM INSTITUIÇÕES NÃO-ESCOLARES	34
49378	0709.001.863-7	PSICOLOGIA DA EDUCAÇÃO	68
49396	0709.001.881-5	TÓPICOS FILOSÓFICOS APLICADOS À EDUCAÇÃO	68
49399	0709.001.884-2	TÓPICOS SOCIOLÓGICOS APLICADOS À EDUCAÇÃO	68
49366	0709.001.851-0	ABORDAGEM PSICOLÓGICA DO DESENVOLVIMENTO E DA APRENDIZAGEM	68
49351	0709.001.836-0	DIDÁTICA I	68
49356	0709.001.841-2	EDUCAÇÃO ESPECIAL	68
49360	0709.001.845-9	INFÂNCIA E SOCIEDADE	68
49391	0709.001.876-2	PRÁTICA EM EDUCAÇÃO DE JOVENS E ADULTOS	34
49358	0709.001.843-0	TRABALHO DOCENTE EM ESPAÇOS NÃO ESCOLARES	51
49365	0709.001.850-1	CURRÍCULO E EDUCAÇÃO	68
49388	0709.001.873-5	DIDÁTICA II	68
49328	0709.001.813-6	EDUCAÇÃO DE JOVENS E ADULTOS	68
49389	0709.001.874-4	ESTÁGIO OBRIGATÓRIO I	100
49364	0709.001.849-5	GESTÃO ESCOLAR	68
49392	0709.001.877-1	PRESSUPOSTOS TEÓRICOS E PRÁTICOS EM INFÂNCIA E LETRAMENTO	68
49325	0709.001.810-9	ESTÁGIO OBRIGATÓRIO II	100
49367	0709.001.852-0	PESQUISA EM EDUCAÇÃO I	51
49326	0709.001.811-8	PRÁTICA DE ALFABETIZAÇÃO	51
49374	0709.001.859-3	PRESSUPOSTOS TEÓRICOS E PRÁTICOS DO ENSINO DE CIÊNCIAS PARA A EDUCAÇÃO DA INFÂNCIA	68
49357	0709.001.842-1	PRESSUPOSTOS TEÓRICOS E PRÁTICOS DO ENSINO DE MATEMÁTICA PARA A EDUCAÇÃO DA INFÂNCIA	68
49368	0709.001.853-9	PRESSUPOSTOS TEÓRICOS E PRÁTICOS EM ALFABETIZAÇÃO	68
49363	0709.001.848-6	ESTÁGIO OBRIGATÓRIO III	100
49393	0709.001.878-0	FUNDAMENTOS E PRÁTICAS DE EDUCAÇÃO DA PRIMEIRA INFÂNCIA	68
49397	0709.001.882-4	PESQUISA EM EDUCAÇÃO II	68
49370	0709.001.855-7	PRÁTICA DE MATEMÁTICA PARA A EDUCAÇÃO DA INFÂNCIA	68
49361	0709.001.846-8	PRÁTICA EM EDUCAÇÃO INCLUSIVA	51
49362	0709.001.847-7	PRESSUPOSTOS TEÓRICOS E PRÁTICOS DE LÍNGUA PORTUGUESA PARA A EDUCAÇÃO DA INFÂNCIA	68
49359	0709.001.844-0	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
49390	0709.001.875-3	ESTÁGIO OBRIGATÓRIO IV	100
49372	0709.001.857-5	LUDICIDADE E EDUCAÇÃO	68
47241	0709.001.647-2	PRÁTICA CIENTÍFICA I	34
49327	0709.001.812-7	PRÁTICA NA EDUCAÇÃO DA PRIMEIRA INFÂNCIA	51
49373	0709.001.858-4	PRESSUPOSTOS TEÓRICOS E PRÁTICOS DO ENSINO DE GEOGRAFIA PARA A EDUCAÇÃO DA INFÂNCIA	68
49375	0709.001.860-0	PRESSUPOSTOS TEÓRICOS E PRÁTICOS DO ENSINO DE HISTÓRIA PARA A EDUCAÇÃO DA INFÂNCIA	68
49329	0709.001.814-5	ESTÁGIO OBRIGATÓRIO V	34
49376	0709.001.861-9	ESTUDO DE LIBRAS	68
49398	0709.001.883-3	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
49379	0709.001.864-6	LITERATURA INFANTOJUVENIL	68
47242	0709.001.648-1	PRÁTICA CIENTÍFICA II	34
49371	0709.001.856-6	PRÁTICA DE LÍNGUA PORTUGUESA PARA A EDUCAÇÃO DA INFÂNCIA	51
49330	0709.001.815-4	AFETIVIDADE E APRENDIZAGEM	34
49394	0709.001.879-0	ARTE E EDUCAÇÃO	34
49339	0709.001.824-3	CONHECIMENTOS E SABERES SOBRE PRÁTICAS EDUCATIVAS COM BEBÊS	34
49332	0709.001.817-2	DESENVOLVIMENTO DO PENSAMENTO NA INFÂNCIA	34
44999	0709.001.245-5	DIDÁTICA E AVALIAÇÃO DA APRENDIZAGEM	34
49340	0709.001.825-2	DIFERENTES ABORDAGENS PARA EDUCAÇÃO DE BEBÊS	34
45009	0709.001.255-3	DIFICULDADE ACENTUADA DE APRENDIZAGEM E MEDICALIZAÇÃO	34
49380	0709.001.865-5	DIREITOS HUMANOS E DIVERSIDADE	34
45010	0709.001.256-2	EDUCAÇÃO, DIVERSIDADE E PRÁTICAS PEDAGÓGICAS	34
49369	0709.001.854-8	EDUCAÇÃO EMPREENDEDORA	34
49346	0709.001.831-4	EDUCAÇÃO MATEMÁTICA PARA A APRENDIZAGEM E DESENVOLVIMENTO INFANTIL	34
49331	0709.001.816-3	FORMAÇÃO, IDENTIDADE, PROFISSIONALIZAÇÃO E ATUAÇÃO DOCENTE	34
45000	0709.001.246-4	GESTÃO DA AVALIAÇÃO EDUCACIONAL NA ESCOLA	34
45002	0709.001.248-2	GESTÃO DAS POLÍTICAS EDUCACIONAIS NA ESCOLA	34
49334	0709.001.819-0	GESTÃO DE POLÍTICAS EDUCACIONAIS E CONSELHOS DE EDUCAÇÃO	34
49337	0709.001.822-5	GESTÃO PEDAGÓGICA E PLANEJAMENTO	34
49344	0709.001.829-9	HISTÓRIA DA ESCOLA PRIMÁRIA NO BRASIL	34
49347	0709.001.832-3	INFÂNCIA E DIREITOS	34
49341	0709.001.826-1	INTELECTUAIS BRASILEIROS E ESCOLA PÚBLICA NO BRASIL REPUBLICANO	34
49345	0709.001.830-5	LEITURA E PRODUÇÃO DE TEXTOS EM EDUCAÇÃO	34
49377	0709.001.862-8	MATEMÁTICA APLICADA À EDUCAÇÃO	34
49342	0709.001.827-0	MEMÓRIAS ESCOLARES, FORMAÇÃO E CONSTRUÇÃO DE IDENTIDADES DOCENTES	34
45020	0709.001.266-0	ORGANIZAÇÃO DO TRABALHO PEDAGÓGICO NA EDUCAÇÃO INFANTIL	34
45015	0709.001.261-5	PAULO FREIRE: A REALIDADE EDUCACIONAL, O DISCURSO PEDAGÓGICO E A EDUCAÇÃO LIBERTADORA/HUMANIZADORA	34
49381	0709.001.866-4	PEDAGOGIA UNIVERSITÁRIA, DIDÁTICA E FORMAÇÃO DE PROFESSORES	34
49336	0709.001.821-6	POLÍTICAS E AVALIAÇÃO EDUCACIONAL: PROCESSOS E PRINCÍPIOS	34
49384	0709.001.869-1	REPRESENTAÇÕES, REGISTROS INFANTIS E SEUS CONHECIMENTOS	34
49333	0709.001.818-1	SISTEMAS DE ENSINO NO BRASIL E AS REFORMAS EDUCACIONAIS	34
49338	0709.001.823-4	TENDÊNCIAS DE ENSINO EM EDUCAÇÃO MATEMÁTICA	34
45001	0709.001.247-3	TÓPICOS EM EDUCAÇÃO DA INFÂNCIA E CONCEPÇÕES PEDAGÓGICAS	34
51817	0709.002.309-2	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA I	68
51818	0709.002.310-9	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA II	68
51819	0709.002.311-8	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA III	68
49387	0709.001.872-6	TÓPICOS ESPECIAIS EM DIDÁTICA	34
49386	0709.001.871-7	TÓPICOS ESPECIAIS EM EDUCAÇÃO ESCOLAR I	34
49385	0709.001.870-8	TÓPICOS ESPECIAIS EM EDUCAÇÃO ESCOLAR II	34
49382	0709.001.867-3	TÓPICOS ESPECIAIS EM EDUCAÇÃO NÃO ESCOLAR	34
49383	0709.001.868-2	TÓPICOS ESPECIAIS EM HISTÓRIA DO ENSINO DE LEITURA E ESCRITA NO BRASIL	34
49343	0709.001.828-0	TÓPICOS ESPECIAIS EM LEITURA E FORMAÇÃO DO LEITOR	34
49335	0709.001.820-7	TÓPICOS ESPECIAIS EM SOCIOLOGIA DA INFÂNCIA	34
45024	0709.001.270-4	TRABALHO E EDUCAÇÃO	34
51427	0709.002.226-4	CIÊNCIA POLÍTICA E TEORIA GERAL DO ESTADO	68
51436	0709.002.235-3	FILOSOFIA GERAL E JURÍDICA	68
51429	0709.002.228-2	HISTÓRIA DO DIREITO	68
51445	0709.002.244-2	INTRODUÇÃO À METODOLOGIA DA PESQUISA	34
47042	0709.001.491-4	LINGUAGEM JURÍDICA	34
51426	0709.002.225-5	TEORIA DO DIREITO	68
51420	0709.002.219-3	ATIVIDADES INTEGRATIVAS DE EXTENSÃO I	34
51428	0709.002.227-3	DIREITO CONSTITUCIONAL I	68
51418	0709.002.217-5	DIREITO PENAL - PARTE GERAL I	68
51452	0709.002.251-3	ECONOMIA POLÍTICA	34
51454	0709.002.253-1	PSICOLOGIA APLICADA AO DIREITO	34
34491	0709.000.006-1	SOCIOLOGIA JURÍDICA	68
47051	0709.001.500-9	TEORIA DO DIREITO PRIVADO I	68
47036	0709.001.485-2	ANTROPOLOGIA JURÍDICA	68
51467	0709.002.266-7	ATIVIDADES INTEGRATIVAS DE EXTENSÃO II	34
51424	0709.002.223-7	DIREITO CONSTITUCIONAL II - DIREITOS FUNDAMENTAIS, SOCIAIS E POLÍTICOS	68
34545	0709.000.060-6	DIREITO INTERNACIONAL PÚBLICO	68
51466	0709.002.265-8	DIREITO PENAL - PARTE GERAL II	68
47075	0709.001.524-1	TEORIA DO DIREITO PRIVADO II	68
52155	0709.002.325-2	DIREITO CONSTITUCIONAL III - DO ESTADO	68
51463	0709.002.262-0	DIREITO DAS OBRIGAÇÕES	68
51457	0709.002.256-9	DIREITO DO TRABALHO I	68
52157	0709.002.327-0	DIREITO PENAL - PARTE ESPECIAL I	68
51450	0709.002.249-8	TUTELA DE CONHECIMENTO - TEORIA GERAL DO DIREITO PROCESSUAL CIVIL	68
51458	0709.002.257-8	DIREITO CONSTITUCIONAL IV - DOS PODERES	68
51455	0709.002.254-0	DIREITO CONTRATUAL	68
51444	0709.002.243-3	DIREITO DO TRABALHO II	68
47072	0709.001.521-4	DIREITO PENAL - PARTE ESPECIAL II	68
51421	0709.002.220-0	TUTELA DE CONHECIMENTO	68
51433	0709.002.232-6	DIREITO PROCESSUAL DO TRABALHO	68
51437	0709.002.236-2	DIREITO PROCESSUAL PENAL I	68
52156	0709.002.326-1	DIREITOS HUMANOS	68
46996	0709.001.445-0	RESPONSABILIDADE CIVIL	68
51422	0709.002.221-9	TUTELA RECURSAL	68
51464	0709.002.263-0	DIREITO DAS COISAS	68
46993	0709.001.442-2	DIREITO EMPRESARIAL I	34
51417	0709.002.216-6	DIREITO PROCESSUAL CONSTITUCIONAL	34
51423	0709.002.222-8	DIREITO PROCESSUAL PENAL II	68
52150	0709.002.320-7	ESTÁGIO OBRIGATÓRIO - PRÁTICA REAL I	34
46990	0709.001.439-8	ESTÁGIO OBRIGATÓRIO - PRÁTICA SIMULADA I	34
47078	0709.001.527-9	FORMAS CONSENSUAIS DE SOLUÇÃO DE CONFLITOS	34
51443	0709.002.242-4	TUTELA EXECUTIVA	68
51438	0709.002.237-1	DIREITO ADMINISTRATIVO I	68
51461	0709.002.260-2	DIREITO DE FAMÍLIA	68
34540	0709.000.055-0	DIREITO EMPRESARIAL II	68
51419	0709.002.218-4	DIREITO PROCESSUAL PENAL III	34
52149	0709.002.319-0	ESTÁGIO OBRIGATÓRIO - PRÁTICA REAL II	34
52148	0709.002.318-1	ESTÁGIO OBRIGATÓRIO - PRÁTICA SIMULADA II	34
51449	0709.002.248-9	TUTELA DE CONHECIMENTO - TUTELAS PROVISÓRIAS E PROCEDIMENTOS ESPECIAIS	68
51442	0709.002.241-5	ATIVIDADES INTEGRATIVAS DE EXTENSÃO III	34
51440	0709.002.239-0	DIREITO ADMINISTRATIVO II	68
51462	0709.002.261-1	DIREITO DIGITAL E TECNOLÓGICO	34
51425	0709.002.224-6	DIREITO DO CONSUMIDOR	34
34544	0709.000.059-2	DIREITO EMPRESARIAL III	68
34548	0709.000.063-0	DIREITO INTERNACIONAL PRIVADO	68
51416	0709.002.215-7	DIREITO TRIBUTÁRIO I	68
52151	0709.002.321-6	ESTÁGIO OBRIGATÓRIO - PRÁTICA REAL III	34
52147	0709.002.317-2	ATIVIDADES INTEGRATIVA DE EXTENSÃO IV	34
51439	0709.002.238-0	DIREITO AMBIENTAL	68
51459	0709.002.258-7	DIREITO DAS SUCESSÕES	68
51451	0709.002.250-4	DIREITO FINANCEIRO	34
51446	0709.002.245-1	DIREITO PREVIDENCIÁRIO E SEGURIDADE SOCIAL	68
51453	0709.002.252-2	DIREITO TRIBUTÁRIO II	68
52152	0709.002.322-5	ESTÁGIO OBRIGATÓRIO - PRÁTICA REAL IV	34
51441	0709.002.240-6	ÉTICA PROFISSIONAL	34
47003	0709.001.452-0	ACESSO À JUSTIÇA	34
47000	0709.001.449-6	ADMINISTRAÇÃO APLICADA AO DIREITO	34
51435	0709.002.234-4	ANÁLISE DE CENÁRIOS ECONÔMICOS E EDUCAÇÃO FINANCEIRA	34
47065	0709.001.514-3	ANÁLISE ECONÔMICA DO DIREITO	34
47004	0709.001.453-0	ARBITRAGEM	34
34553	0709.000.068-1	BIODIREITO E BIOÉTICA	34
47082	0709.001.531-2	CONFLITOS SOCIOAMBIENTAIS	68
47079	0709.001.528-8	CONTROLE JUDICIAL DA ADMINISTRAÇÃO PÚBLICA	68
46995	0709.001.444-0	CRIMINOLOGIA	34
47086	0709.001.535-9	DEFICIÊNCIA, DIREITO E INCLUSÃO	34
34555	0709.000.070-3	DIREITO AGRÁRIO	34
47026	0709.001.475-4	DIREITO CIVIL E LITERATURA	34
34556	0709.000.071-1	DIREITO COMUNITÁRIO	34
47057	0709.001.506-3	DIREITO CONDOMINIAL	34
51415	0709.002.214-8	DIREITO CONSTITUCIONAL COMPARADO	68
47009	0709.001.458-5	DIREITO CONSTITUCIONAL E LITERATURA	34
47022	0709.001.471-8	DIREITO CONSTITUCIONAL SUBNACIONAL	34
34557	0709.000.072-0	DIREITO DA CRIANÇA E DO ADOLESCENTE	34
47088	0709.001.537-7	DIREITO DA PESSOA IDOSA	34
47017	0709.001.466-5	DIREITO DA PROPRIEDADE INTELECTUAL	34
47012	0709.001.461-0	DIREITO DAS ÁGUAS	34
34558	0709.000.073-8	DIREITO DAS ORGANIZAÇÕES INTERNACIONAIS	34
47005	0709.001.454-9	DIREITO DESPORTIVO	34
47019	0709.001.468-3	DIREITO DE TRÂNSITO	34
47016	0709.001.465-6	DIREITO DE VIZINHANÇA	34
34559	0709.000.074-6	DIREITO DIGITAL E PROCESSO JUDICIAL ELETRÔNICO	34
47063	0709.001.512-5	DIREITO DOS ANIMAIS	34
47030	0709.001.479-0	DIREITO DOS POVOS	34
47032	0709.001.481-6	DIREITO E CIDADE	34
47033	0709.001.482-5	DIREITO ECONOMICO E CONCORRENCIAL	34
52153	0709.002.323-4	DIREITO E DESENVOLVIMENTO	34
47038	0709.001.487-0	DIREITO E EDUCAÇÃO	34
47041	0709.001.490-5	DIREITO E ESTADO	68
51460	0709.002.259-6	DIREITO E HANNAH ARENDT: O CASO EICHMANN	68
47044	0709.001.493-2	DIREITO ELEITORAL	68
52154	0709.002.324-3	DIREITO E LITERATURA	68
47084	0709.001.533-0	DIREITO E PODER	68
47001	0709.001.450-2	DIREITO E SAÚDE	34
47011	0709.001.460-0	DIREITO IMOBILIÁRIO	34
34563	0709.000.078-9	DIREITO INTERNACIONAL HUMANITÁRIO	34
47013	0709.001.462-9	DIREITO PORTUÁRIO	34
47018	0709.001.467-4	DIREITO PROCESSUAL TRIBUTÁRIO	34
47081	0709.001.530-3	DIRETO CIVIL E LITERATURA	34
47073	0709.001.522-3	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
47040	0709.001.489-9	EDUCAÇÃO EM DIREITOS HUMANOS	34
47052	0709.001.501-8	EDUCAÇÃO ESPECIAL	51
47045	0709.001.494-1	ESTATÍSTICA APLICADA AO DIREITO - JURIMETRIA	34
25678	0704.001.438-7	ESTUDO DE LIBRAS	51
47014	0709.001.463-8	EXECUÇÃO PENAL	34
47089	0709.001.538-6	GÊNERO, DIREITOS HUMANOS E SOCIEDADE	34
47020	0709.001.469-2	HERMENÊUTICA CONSTITUCIONAL	68
47083	0709.001.532-1	HERMENÊUTICA JURÍDICA	68
51456	0709.002.255-0	HISTÓRIA CONSTITUCIONAL	34
47031	0709.001.480-7	JUIZADOS ESPECIAIS	34
47029	0709.001.478-1	LEGISLAÇÃO ESPECIAL PENAL	68
46989	0709.001.438-9	MEDICINA FORENSE	34
46975	0709.001.424-4	PROCESSO ADMINISTRATIVO	34
51448	0709.002.247-0	RESPONSABILIDADE CIVIL E SAÚDE	34
34569	0709.000.084-3	TÓPICOS DE JURISPRUDÊNCIA DO STF	68
34570	0709.000.085-1	TÓPICOS DE JURISPRUDÊNCIA DO STJ	68
46980	0709.001.429-0	TÓPICOS ESPECIAIS DE ANTROPOLOGIA JURÍDICA	34
47066	0709.001.515-2	TÓPICOS ESPECIAIS DE DIREITO ADMINISTRATIVO	34
46992	0709.001.441-3	TÓPICOS ESPECIAIS DE DIREITO AMBIENTAL	34
47061	0709.001.510-7	TÓPICOS ESPECIAIS DE DIREITO CONSTITUCIONAL	34
46976	0709.001.425-3	TÓPICOS ESPECIAIS DE DIREITO CONTRATUAL	34
47067	0709.001.516-1	TÓPICOS ESPECIAIS DE DIREITO DAS OBRIGAÇÕES	34
46977	0709.001.426-2	TÓPICOS ESPECIAIS DE DIREITO DAS SUCESSÕES	34
34572	0709.000.087-8	TÓPICOS ESPECIAIS DE DIREITO DE FAMILIA	34
47076	0709.001.525-0	TÓPICOS ESPECIAIS DE DIREITO DIGITAL E TECNOLÓGICO	34
47090	0709.001.539-5	TÓPICOS ESPECIAIS DE DIREITO DO TRABALHO	34
34573	0709.000.088-6	TÓPICOS ESPECIAIS DE DIREITO EMPRESARIAL	34
47054	0709.001.503-6	TÓPICOS ESPECIAIS DE DIREITO E POLÍTICA	34
46983	0709.001.432-4	TÓPICOS ESPECIAIS DE DIREITO INTERNACIONAL PRIVADO	34
46991	0709.001.440-4	TÓPICOS ESPECIAIS DE DIREITO INTERNACIONAL PÚBLICO	34
34574	0709.000.089-4	TÓPICOS ESPECIAIS DE DIREITO PENAL	34
47046	0709.001.495-0	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL CIVIL	68
46985	0709.001.434-2	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL CIVIL COMPARADO	34
46984	0709.001.433-3	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL DO TRABALHO	34
46978	0709.001.427-1	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL EMPRESARIAL	34
46987	0709.001.436-0	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL PENAL	34
46986	0709.001.435-1	TÓPICOS ESPECIAIS DE DIREITOS HUMANOS	34
34576	0709.000.091-6	TÓPICOS ESPECIAIS DE DIREITOS REAIS	34
47043	0709.001.492-3	TÓPICOS ESPECIAIS DE DIREITOS SOCIAIS	34
47021	0709.001.470-9	TÓPICOS ESPECIAIS DE DIREITO TRIBUTÁRIO	34
47025	0709.001.474-5	TÓPICOS ESPECIAIS DE FILOSOFIA DO DIREITO	34
46998	0709.001.447-8	TÓPICOS ESPECIAIS DE HISTÓRIA DO DIREITO	34
47068	0709.001.517-0	TÓPICOS ESPECIAIS DE JURISDIÇÃO CONSTITUCIONAL	34
47074	0709.001.523-2	TÓPICOS ESPECIAIS DE METODOLOGIA DA PESQUISA EM DIREITO	34
47071	0709.001.520-5	TÓPICOS ESPECIAIS DE PROCESSO COLETIVO	34
47087	0709.001.536-8	TOPICOS ESPECIAIS DE PROCESSO E DEMOCRACIA	34
46981	0709.001.430-6	TÓPICOS ESPECIAIS DE PSICOLOGIA APLICADA AO DIREITO	34
47023	0709.001.472-7	TÓPICOS ESPECIAIS DE RESPONSABILIDADE CIVIL	34
47024	0709.001.473-6	TÓPICOS ESPECIAIS DE SOCIOLOGIA JURÍDICA	34
46979	0709.001.428-0	TÓPICOS ESPECIAIS DE TEORIA DO DIREITO	34
47069	0709.001.518-0	TÓPICOS ESPECIAIS EM FORMAS CONSENSUAIS DE SOLUÇÃO DE CONFLITOS	34
47070	0709.001.519-9	TÓPICOS ESPECIAIS EM NOVAS RELAÇÕES PRIVADAS	34
51434	0709.002.233-5	TUTELA DOS DIREITOS HUMANOS NO SISTEMA INTERAMERICANO	68
50077	0709.001.998-4	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LITERATURA	68
50078	0709.001.999-3	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LITERATURA INFANTO-JUVENIL	68
50079	0709.002.000-9	ESTUDOS DO GÊNERO POÉTICO	68
50080	0709.002.001-8	TEORIAS DA NARRATIVA	68
50088	0709.002.009-0	ESTÁGIO OBRIGATÓRIO DE LITERATURAS DE LÍNGUA PORTUGUESA I	102
50081	0709.002.002-7	ESTUDOS DO GÊNERO DRAMÁTICO	68
50083	0709.002.004-5	ESTÁGIO OBRIGATÓRIO DE LITERATURAS DE LÍNGUA PORTUGUESA II	102
50082	0709.002.003-6	TÓPICOS ESPECIAIS DE LITERATURA	68
50084	0709.002.005-4	LITERATURA PORTUGUESA CONTEMPORÂNEA	68
50087	0709.002.008-1	TÓPICOS DE LITERATURA BRASILEIRA I	68
50085	0709.002.006-3	LITERATURA BRASILEIRA CONTEMPORÂNEA	68
50086	0709.002.007-2	TÓPICOS DE LITERATURA BRASILEIRA II	68
39904	0709.000.785-6	FONÉTICA E FONOLOGIA DE LÍNGUA INGLESA	34
39905	0709.000.786-4	PRÁTICA E ANÁLISE LITERÁRIA	34
43043	0709.000.975-1	TECNOLOGIAS DIGITAIS E ENSINO DE LÍNGUAS	34
49517	0709.001.917-0	ALGORITMOS E PROGRAMAÇÃO I	102
35278	0709.000.335-4	FUNDAMENTOS DE TECNOLOGIA DA INFORMAÇÃO	68
49513	0709.001.913-3	LABORATÓRIO DE ALGORITMOS E PROGRAMAÇÃO I	34
50585	0709.002.146-3	MATEMÁTICA ELEMENTAR	68
49491	0709.001.891-3	MODELAGEM DE PROCESSOS DE NEGÓCIO	68
35275	0709.000.332-0	ALGORITMOS E PROGRAMAÇÃO II	102
49504	0709.001.904-4	ENGENHARIA DE SOFTWARE	68
50914	0709.002.192-8	FUNDAMENTOS DA ADMINISTRAÇÃO	68
35274	0709.000.331-1	FUNDAMENTOS DA TEORIA DA COMPUTAÇÃO	68
49514	0709.001.914-2	LABORATÓRIO DE ALGORITMOS E PROGRAMAÇÃO II	34
49486	0709.001.886-0	BANCO DE DADOS	68
35284	0709.000.341-9	ESTRUTURAS DE DADOS E PROGRAMAÇÃO I	68
49500	0709.001.900-8	GERÊNCIA DE PROJETOS	68
35273	0709.000.330-3	INTRODUÇÃO A SISTEMAS DIGITAIS	68
49503	0709.001.903-5	LINGUAGEM DE PROGRAMAÇÃO ORIENTADA A OBJETOS	68
49501	0709.001.901-7	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS	68
35276	0709.000.333-8	ARQUITETURA DE COMPUTADORES I	68
49497	0709.001.897-8	ESTATÍSTICA	68
49519	0709.001.919-8	LABORATÓRIO DE BANCO DE DADOS	68
49518	0709.001.918-9	PROGRAMAÇÃO PARA WEB	68
49496	0709.001.896-9	INTELIGÊNCIA ARTIFICIAL	68
49505	0709.001.905-3	INTRODUÇÃO A SISTEMAS OPERACIONAIS	68
49494	0709.001.894-0	LABORATÓRIO DE PROGRAMAÇÃO PARA WEB	68
35282	0709.000.339-7	REDES DE COMPUTADORES I	68
49485	0709.001.885-1	COMPUTAÇÃO DISTRIBUÍDA	68
35289	0709.000.346-0	REDES DE COMPUTADORES II	68
49490	0709.001.890-4	SISTEMAS DE APOIO À DECISÃO	68
49499	0709.001.899-6	TÉCNICAS AVANÇADAS DE DESENVOLVIMENTO DE SOFTWARE	68
50929	0709.002.207-7	GESTÃO ESTRATÉGICA	68
49492	0709.001.892-2	GOVERNANÇA DE TECNOLOGIA DA INFORMAÇÃO	68
49507	0709.001.907-1	INTERAÇÃO HUMANO-COMPUTADOR	68
49502	0709.001.902-6	QUALIDADE DE SOFTWARE	68
35363	0709.000.356-7	COMPUTAÇÃO E SOCIEDADE	68
49488	0709.001.888-9	GERENCIAMENTO DE SERVIÇOS DE TECNOLOGIA DA INFORMAÇÃO	68
49495	0709.001.895-0	SEGURANÇA E AUDITORIA DE SISTEMAS	68
35367	0709.000.360-5	ALGORITMOS PARALELOS	68
35368	0709.000.361-3	ANÁLISE DE ALGORITMOS	68
35369	0709.000.362-1	ANÁLISE E PROJETO DE APLICAÇÕES WEB	68
35371	0709.000.364-8	ANÁLISE FORENSE COMPUTACIONAL	68
35372	0709.000.365-6	ARQUITETURA DE COMPUTADORES II	68
49489	0709.001.889-8	BANCO DE DADOS II	68
35374	0709.000.367-2	CABEAMENTO ESTRUTURADO	34
50581	0709.002.142-7	CÁLCULO I	68
35375	0709.000.368-0	COMPILADORES I	68
35376	0709.000.369-9	COMPILADORES II	68
47281	0709.001.687-5	COMPORTAMENTO ORGANIZACIONAL	68
35377	0709.000.370-2	COMPUTAÇÃO GRÁFICA	68
50916	0709.002.194-6	DIREITO APLICADO À ADMINISTRAÇÃO	68
35261	0709.000.318-4	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS NO BRASIL	34
35378	0709.000.371-0	ESTRUTURAS DE DADOS E PROGRAMAÇÃO II	68
35110	0709.000.171-8	ESTUDO DE LIBRAS	68
34522	0709.000.037-1	FILOSOFIA	68
49487	0709.001.887-0	FUNDAMENTOS DE MULTIMÍDIA	68
35392	0709.000.385-0	GEOMETRIA ANALÍTICA E ÁLGEBRA LINEAR	68
35393	0709.000.386-9	IMPLEMENTAÇÃO E EXPERIMENTAÇÃO ALGORÍTMICA	68
35395	0709.000.388-5	INTRODUÇÃO À CONTABILIDADE	68
49639	0709.001.928-7	INTRODUÇÃO À ECONOMIA	68
35399	0709.000.392-3	LABORATÓRIO DE DESENVOLVIMENTO DE SISTEMAS ORIENTADO A OBJETOS	68
35400	0709.000.393-1	LABORATÓRIO DE DESENVOLVIMENTO DE SISTEMAS PARA WEB	68
35401	0709.000.394-0	LABORATÓRIO DE REDES DE COMPUTADORES	68
52162	0709.002.332-3	LINGUAGENS FORMAIS E AUTÔMATOS	68
49640	0709.001.929-6	MATEMÁTICA FINANCEIRA	68
35404	0709.000.397-4	METODOLOGIA DE PESQUISA CIENTÍFICA	68
47269	0709.001.675-9	PORTUGUÊS INSTRUMENTAL	34
35407	0709.000.400-8	PROJETO DE REDES DE COMPUTADORES	68
35111	0709.000.172-6	PSICOLOGIA ORGANIZACIONAL	68
35409	0709.000.402-4	SEGURANÇA DE REDES DE COMPUTADORES	68
35412	0709.000.405-9	TÓPICOS EM BANCO DE DADOS	68
35413	0709.000.406-7	TÓPICOS EM COMPUTAÇÃO	68
35414	0709.000.407-5	TÓPICOS EM ENGENHARIA DE SOFTWARE	68
35415	0709.000.408-3	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL	68
35416	0709.000.409-1	TÓPICOS EM REDES DE COMPUTADORES	68
35417	0709.000.410-5	TÓPICOS EM SISTEMAS DE INFORMAÇÃO I	68
35418	0709.000.411-3	TÓPICOS EM SISTEMAS DE INFORMAÇÃO II	68
35419	0709.000.412-1	TÓPICOS EM SISTEMAS DE INFORMAÇÃO III	68
49508	0709.001.908-0	TÓPICOS EM SISTEMAS DE INFORMAÇÃO IV	68
49509	0709.001.909-0	TÓPICOS EM SISTEMAS DE INFORMAÇÃO V	34
49510	0709.001.910-6	TÓPICOS EM SISTEMAS DE INFORMAÇÃO VI	34
49511	0709.001.911-5	TÓPICOS EM SISTEMAS DE INFORMAÇÃO VII	34
49512	0709.001.912-4	TÓPICOS EM SISTEMAS DE INFORMAÇÃO VIII	34
35420	0709.000.413-0	TÓPICOS EM SISTEMAS DISTRIBUÍDOS	68
52158	0709.002.328-0	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA III	34
52159	0709.002.329-9	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA IV	34
52160	0709.002.330-5	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA V	34
52161	0709.002.331-4	TÓPICOS ESPECIAIS DE EXTENSÃO CURRICULARIZADA VI	34
51562	0709.002.286-3	BASES BIOLOGICAS DA PRÁTICA MÉDICA I	272
43675	0709.001.073-7	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA I	119
43614	0709.001.012-9	FUNDAMENTOS DA PRÁTICA MÉDICA I	34
43630	0709.001.028-1	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE I	68
51563	0709.002.287-2	BASES BIOLOGICAS DA PRÁTICA MÉDICA II	272
43628	0709.001.026-3	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA II	119
43582	0709.000.980-7	FUNDAMENTOS DA PRÁTICA MÉDICA II	51
43631	0709.001.029-0	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE II	68
43649	0709.001.047-9	BASES BIOLÓGICAS DA PRÁTICA MÉDICA III	272
43625	0709.001.023-6	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA III	136
43583	0709.000.981-6	FUNDAMENTOS DA PRÁTICA MÉDICA III	51
43632	0709.001.030-7	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE III	68
51561	0709.002.285-4	URGÊNCIA E EMERGÊNCIA I	34
43674	0709.001.072-8	BASES BIOLÓGICAS DA PRÁTICA MÉDICA IV	272
43676	0709.001.074-6	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA IV	136
43584	0709.000.982-5	FUNDAMENTOS DA PRÁTICA MÉDICA IV	68
43636	0709.001.034-3	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE IV	68
43602	0709.001.000-2	BASES BIOLÓGICAS DA PRÁTICA MÉDICA V	204
43677	0709.001.075-5	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA V	68
43586	0709.000.984-3	FUNDAMENTOS DA PRÁTICA MÉDICA V	136
43633	0709.001.031-6	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE V	68
51567	0709.002.291-6	URGÊNCIA E EMERGÊNCIA II	51
43650	0709.001.048-8	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VI	204
43678	0709.001.076-4	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA VI	68
51559	0709.002.283-6	CIRURGIA I	51
43587	0709.000.985-2	FUNDAMENTOS DA PRÁTICA MÉDICA VI	136
43634	0709.001.032-5	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE VI	68
43651	0709.001.049-7	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VII	34
43621	0709.001.019-2	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA VII	68
51570	0709.002.294-3	CIRURGIA II	68
43616	0709.001.014-7	FUNDAMENTOS DA PRÁTICA MÉDICA VII	170
43646	0709.001.044-1	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE VII	136
51564	0709.002.288-1	URGÊNCIA E EMERGÊNCIA III	51
51566	0709.002.290-7	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VIII	34
43679	0709.001.077-3	BASES PSICOSSOCIAIS DA PRÁTICA MÉDICA VIII	34
51560	0709.002.284-5	CIRURGIA III	68
43661	0709.001.059-5	FUNDAMENTOS DA PRÁTICA MÉDICA VIII	170
43637	0709.001.035-2	PRÁTICA DE INTEGRAÇÃO: ENSINO, SERVIÇO E COMUNIDADE VIII	136
51558	0709.002.282-7	URGÊNCIA E EMERGÊNCIA IV	68
51555	0709.002.279-2	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA I	160
51556	0709.002.280-9	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA II	160
51553	0709.002.277-4	ESTÁGIO OBRIGATÓRIO EM CLÍNICA MÉDICA I	160
51552	0709.002.276-5	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS CLÍNICAS	160
51568	0709.002.292-5	ESTÁGIO OBRIGATÓRIO EM CIRURGIA I	160
51548	0709.002.272-9	ESTÁGIO OBRIGATÓRIO EM PEDIATRIA I	160
51557	0709.002.281-8	ESTÁGIO OBRIGATÓRIO EM SAÚDE DA MULHER I	320
51569	0709.002.293-4	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS CIRÚRGICAS	160
51543	0709.002.267-6	ESTÁGIO OBRIGATÓRIO EM CIRURGIA II	320
51549	0709.002.273-8	ESTÁGIO OBRIGATÓRIO EM PEDIATRIA II	320
51550	0709.002.274-7	ESTÁGIO OBRIGATÓRIO EM SAÚDE DA MULHER II	160
51565	0709.002.289-0	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA III	160
51551	0709.002.275-6	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA E COMUNIDADE E SAÚDE COLETIVA IV	160
51554	0709.002.278-3	ESTÁGIO OBRIGATÓRIO EM CLÍNICA MÉDICA II	320
43673	0709.001.071-9	AÇÕES EDUCATIVAS DE SAÚDE - SAÚDE E EDUCAÇÃO POPULAR - EDUCAÇÃO POPULAR E SAÚDE - PRÁTICAS EDUCATIVAS DE SAÚDE	34
39062	0709.000.679-5	AMBIENTE, SAÚDE E SOCIEDADE	34
43595	0709.000.993-2	ANÁLISE E INTERPRETAÇÃO DE EXAMES LABORATORIAIS	68
46087	0709.001.346-1	ANEMIAS HEREDITÁRIAS E ADQUIRIDAS: FISIOPATOLOGIA E DIAGNÓSTICO DIFERENCIAL	34
46073	0709.001.332-7	APRENDIZADO ANATÔMICO PELA DISSECAÇÃO	51
46095	0709.001.354-1	ASPECTOS BIOQUÍMICOS, IMUNOPATOLÓGICOS E TERAPÊUTICOS DE DOENÇAS INFECCIOSAS E NÃO INFECCIOSAS	68
46083	0709.001.342-5	BIOESTATÍSTICA BÁSICA	51
43609	0709.001.007-6	CIRURGIA VASCULAR E ENDOVASCULAR	51
43611	0709.001.009-4	CUIDADOS PALIATIVOS EM SAÚDE	51
43592	0709.000.990-5	DIREITO E SAÚDE NO BRASIL	68
46085	0709.001.344-3	DOENÇAS EMERGENTES, RE-EMERGENTES E NEGLIGENCIADAS	68
43680	0709.001.078-2	EDUCAÇÃO, CIDADANIA E DIREITOS HUMANOS	34
43593	0709.000.991-4	EDUCAÇÃO E SAÚDE NO CONTEXTO ESCOLAR	51
43597	0709.000.995-0	ÉTICA E BIOÉTICA EM SAÚDE	51
43660	0709.001.058-6	FARMACOLOGIA APLICADA ÀS PRINCIPAIS DOENÇAS METABÓLICAS	68
43594	0709.000.992-3	FISIOPATOLOGIA E TERAPÊUTICA DE DOENÇAS CRÔNICAS	68
43596	0709.000.994-1	FUNDAMENTOS DA MEDICINA DE FAMÍLIA E COMUNIDADE	68
46092	0709.001.351-4	FUNDAMENTOS DE FARMACOEPIDEMIOLOGIA CLÍNICA	68
43598	0709.000.996-0	FUNDAMENTOS DO USO RACIONAL DE FÁRMACOS	51
43664	0709.001.062-0	GERENCIAMENTO DE DOENÇAS CRÔNICAS	68
43662	0709.001.060-1	GESTÃO EM SAÚDE PÚBLICA	68
43652	0709.001.050-3	GRUPOS, RODAS E ESPAÇOS DE CONVERSA: ESTRATÉGIAS DE ATENÇÃO À SAÚDE	68
46094	0709.001.353-2	HUMANIZAÇÃO DO PARTO E DO NASCIMENTO	34
46097	0709.001.356-0	IMUNOLOGIA CLÍNICA	68
43588	0709.000.986-1	IMUNOPATOLOGIA E FARMACOLOGIA CLÍNICA DOS PROCESSOS INFECCIOSOS	68
40105	0709.000.839-9	INFECTOLOGIA E SUAS INTERFACES	51
43608	0709.001.006-7	INFORMÁTICA APLICADA À MEDICINA	34
46093	0709.001.352-3	INICIAÇÃO À DOCÊNCIA MÉDICA	68
51545	0709.002.269-4	INTELIGÊNCIA ARTIFICIAL APLICADA A SAÚDE	68
46078	0709.001.337-2	INTRODUÇÃO À MEDICINA GENÔMICA	34
43613	0709.001.011-0	INTRODUÇÃO ÀS PRÁTICAS INTEGRATIVAS E COMPLEMENTARES EM SAÚDE	34
43603	0709.001.001-1	INTRODUÇÃO ÀS PRÁTICAS LABORATORIAIS	68
43667	0709.001.065-7	MEDICINA LEGAL	34
43615	0709.001.013-8	NEUROIMAGEM	51
46086	0709.001.345-2	NEUROIMUNOMODULAÇÃO: O PAPEL DA DISAUTONOMIA NA FISIOPATOLOGIA DE DOENÇAS CRÔNICAS INFLAMATÓRIAS	68
43668	0709.001.066-6	NEUROPSICOFARMACOLOGIA	68
43682	0709.001.080-8	ORTOPEDIA E CIRURGIA DE URGÊNCIA	34
43601	0709.000.999-7	PLANTAS MEDICINAIS, FITOTERAPIA E FITOQUÍMICA	51
40113	0709.000.847-0	PROMOÇÃO DE SAÚDE E QUALIDADE DE VIDA NO ENVELHECIMENTO	51
43617	0709.001.015-6	REGULAÇÃO, CONTROLE, AVALIAÇÃO E AUDITORIA EM SAÚDE	51
43618	0709.001.016-5	SAÚDE E ESPIRITUALIDADE	68
46067	0709.001.326-5	TÓPICOS ATUAIS EM ANESTESIOLOGIA	34
46072	0709.001.331-8	TÓPICOS ATUAIS EM BIOLOGIA CELULAR - CONTEXTOS BÁSICOS E CLÍNICOS	34
46068	0709.001.327-4	TÓPICOS ATUAIS EM CARDIOLOGIA	34
43669	0709.001.067-5	TÓPICOS ATUAIS EM CIRURGIA	34
46166	0709.001.358-8	TÓPICOS ATUAIS EM DIABETOLOGIA	34
46186	0709.001.378-4	TÓPICOS ATUAIS EM MASTOLOGIA	34
46069	0709.001.328-3	TÓPICOS ATUAIS EM NEFROLOGIA E UROLOGIA	34
43619	0709.001.017-4	TÓPICOS ATUAIS EM NEUROLOGIA, SAÚDE MENTAL E PSIQUIATRIA	34
46066	0709.001.325-6	TÓPICOS ATUAIS EM PEDIATRIA	34
46070	0709.001.329-2	TÓPICOS ATUAIS EM REUMATOLOGIA	34
46063	0709.001.322-9	TÓPICOS ATUAIS EM TOXICOLOGIA	34
46178	0709.001.370-1	TÓPICOS ATUAIS NO POTENCIAL TERAPÊUTICO DE CANABINOIDES	34
43624	0709.001.022-7	TÓPICOS AVANÇADOS DA ANATOMIA APLICADA À PALPAÇÃO E IMAGENOLOGIA	51
46065	0709.001.324-7	TÓPICOS AVANÇADOS EM DOR	34
46088	0709.001.347-0	TÓPICOS AVANÇADOS EM EMBRIOLOGIA CLÍNICA	51
46172	0709.001.364-0	TÓPICOS AVANÇADOS EM GINECOLOGIA E OBSTETRÍCIA	34
46177	0709.001.369-5	TÓPICOS AVANÇADOS EM NEONATOLOGIA	34
43670	0709.001.068-4	TÓPICOS AVANÇADOS EM NEUROCIÊNCIAS	51
46169	0709.001.361-2	TÓPICOS AVANÇADOS EM RADIOLOGIA	34
46064	0709.001.323-8	TÓPICOS AVANÇADOS NO DIAGNÓSTICO DAS DOENÇAS INFECCIOSAS	51
46082	0709.001.341-6	TÓPICOS AVANÇADOS NO DIAGNÓSTICO IMUNOLÓGICO	51
51546	0709.002.270-0	TÓPICOS EM ACOLHIMENTO ACADÊMICO I	34
51544	0709.002.268-5	TÓPICOS EM ACOLHIMENTO ACADÊMICO II	34
46089	0709.001.348-0	TÓPICOS EM COMUNICAÇÃO CIENTÍFICA APLICADA A ÁREAS BIOMÉDICAS	34
46061	0709.001.320-0	TÓPICOS EM ENDOCRINOLOGIA E NUTROLOGIA	34
46084	0709.001.343-4	TÓPICOS EM FARMACOLOGIA BASEADA EM EVIDÊNCIAS	34
46090	0709.001.349-9	TÓPICOS EM FILOSOFIA APLICADA AO PENSAMENTO CIENTÍFICO	34
46170	0709.001.362-1	TÓPICOS EM PSIQUIATRIA INFANTIL	34
51547	0709.002.271-0	TÓPICOS ESPECIAIS DOS SISTEMAS BIOLÓGICOS	68
46174	0709.001.366-8	TÓPICOS ESPECIAIS EM ALERGOLOGIA	34
46179	0709.001.371-0	TÓPICOS ESPECIAIS EM COLOPROCTOLOGIA	34
46182	0709.001.374-8	TÓPICOS ESPECIAIS EM OFTALMOLOGIA	34
46176	0709.001.368-6	TÓPICOS ESPECIAIS EM SAÚDE DO TRABALHADOR	34
46062	0709.001.321-0	TÓPICOS ESSENCIAIS PARA O ALEITAMENTO MATERNO	34
43620	0709.001.018-3	VIROLOGIA CLÍNICA	51
43672	0709.001.070-0	ZOONOSES	51
50092	0709.002.013-4	LÍNGUA INGLESA I	68
50093	0709.002.014-3	LÍNGUA INGLESA II	68
50094	0709.002.015-2	LÍNGUA INGLESA III	68
50102	0709.002.023-2	LÍNGUA INGLESA IV	68
50095	0709.002.016-1	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA I	51
50096	0709.002.017-0	LÍNGUA INGLESA V	68
50100	0709.002.021-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA II	51
50089	0709.002.010-7	LÍNGUA INGLESA VI	68
50099	0709.002.020-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA III	51
50090	0709.002.011-6	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LÍNGUA INGLESA I	68
50097	0709.002.018-0	LITERATURAS DE LÍNGUA INGLESA I	68
50101	0709.002.022-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA IV	51
50091	0709.002.012-5	FUNDAMENTOS PARA A FORMAÇÃO DE PROFESSORES DE LÍNGUA INGLESA II	68
50098	0709.002.019-9	LITERATURAS DE LÍNGUA INGLESA II	68
37841	0709.000.576-4	PRÁTICA DE LEITURA E DE FORMAÇÃO DO LEITOR LITERÁRIO	34
49250	0709.001.774-7	HISTÓRIA ANTIGA I	68
36213	0709.000.454-7	HISTÓRIA DA AMÉRICA COLONIAL	68
36226	0709.000.456-3	HISTÓRIA DA AMÉRICA PORTUGUESA I	68
36229	0709.000.457-1	INTRODUÇÃO A PRÁTICA DE ENSINO E DE PESQUISA EM HISTÓRIA	68
49257	0709.001.781-8	PRÁTICAS DE ENSINO EM HISTÓRIA I	68
36235	0709.000.462-8	FUNDAMENTOS DE HISTÓRIA	68
49264	0709.001.788-1	HISTÓRIA ANTIGA II	68
36233	0709.000.460-1	HISTÓRIA DA AMÉRICA INDEPENDENTE	68
36234	0709.000.461-0	HISTÓRIA DA AMÉRICA PORTUGUESA II	68
49265	0709.001.789-0	HISTÓRIA MEDIEVAL I	68
49251	0709.001.775-6	PRÁTICAS DE ENSINO EM HISTÓRIA II	68
49262	0709.001.786-3	ENSINO DE HISTÓRIA E CULTURA AFRO-BRASILEIRA E AFRICANA	68
49255	0709.001.779-2	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	100
36240	0709.000.467-9	HISTÓRIA DO BRASIL IMPÉRIO	68
49281	0709.001.805-6	HISTÓRIA MEDIEVAL II	68
49253	0709.001.777-4	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	100
49285	0709.001.809-2	HISTÓRIA MODERNA I	68
49282	0709.001.806-5	METODOLOGIA DA HISTÓRIA	68
49284	0709.001.808-3	PRÁTICAS DE ENSINO EM HISTÓRIA III	68
49256	0709.001.780-9	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	100
49283	0709.001.807-4	HISTÓRIA MODERNA II	68
36247	0709.000.474-1	INTRODUÇÃO À ANTROPOLOGIA	68
49273	0709.001.797-0	PRÁTICAS DE ENSINO EM HISTÓRIA IV	68
49249	0709.001.773-8	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
49258	0709.001.782-7	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	100
49266	0709.001.790-7	HISTÓRIA CONTEMPORÂNEA I	68
36252	0709.000.479-2	HISTÓRIA DO BRASIL CONTEMPORÂNEO I	68
49272	0709.001.796-1	PESQUISA HISTÓRICA	68
49267	0709.001.791-6	HISTÓRIA CONTEMPORÂNEA II	68
36254	0709.000.481-4	HISTÓRIA DO BRASIL CONTEMPORÂNEO II	68
49275	0709.001.799-9	PRÁTICAS DE ENSINO EM HISTÓRIA V	68
49278	0709.001.802-9	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
49252	0709.001.776-5	ANÁLISE DO DISCURSO E HISTÓRIA	68
39496	0709.000.750-3	CULTURA BRASILEIRA	68
34520	0709.000.035-5	ECONOMIA POLÍTICA	68
49279	0709.001.803-8	ECONOMIA SOCIAL E SOLIDÁRIA I	68
49270	0709.001.794-3	ECONOMIA SOCIAL E SOLIDÁRIA II	68
43960	0709.001.104-6	ENSINO DE HISTÓRIA E EDUCAÇÃO DO CAMPO	68
49254	0709.001.778-3	ENSINO DE HISTÓRIA REGIONAL: TERRITORIALIDADE, FRONTEIRAS E RELAÇÕES DE PODER	68
49260	0709.001.784-5	ESTUDOS SOCIOCULTURAIS E PRÁTICA TEATRAL	68
49280	0709.001.804-7	FASCISMOS: HISTÓRIA E HISTORIOGRAFIA	68
39497	0709.000.751-1	FORMAÇÃO DA CULTURA CRISTÃ	68
43966	0709.001.110-8	FUNDAMENTOS DA TEORIA DE GÊNERO	68
49261	0709.001.785-4	FUNDAMENTOS TEÓRICOS DA DIDÁTICA DA HISTÓRIA	68
36130	0709.000.429-6	GEOGRAFIA AGRÁRIA	68
39498	0709.000.752-0	GEO-HISTÓRIA	68
39499	0709.000.753-8	GESTÃO E PRESERVAÇÃO DE PATRIMÔNIO HISTÓRICO	68
43968	0709.001.112-6	HISTÓRIA AMBIENTAL: TÉCNICAS, TECNOLOGIAS E A NATUREZA DO ESPAÇO	68
49269	0709.001.793-4	HISTÓRIA CULTURAL	68
39500	0709.000.754-6	HISTÓRIA DA ARTE	68
39507	0709.000.755-4	HISTÓRIA DA CIVILIZAÇÃO IBÉRICA	68
43961	0709.001.105-5	HISTÓRIA DA IMPRENSA ALTERNATIVA NO BRASIL	68
39508	0709.000.756-2	HISTÓRIA DO COTIDIANO	68
39509	0709.000.757-0	HISTÓRIA DO PENSAMENTO ECONÔMICO	68
43974	0709.001.118-0	HISTÓRIA DOS DIREITOS HUMANOS	68
43964	0709.001.108-2	HISTÓRIA DOS MOVIMENTOS FEMINISTAS NO BRASIL	68
39510	0709.000.758-9	HISTÓRIA E CINEMA	68
43969	0709.001.113-5	HISTÓRIA E CULTURA DA ALIMENTAÇÃO	68
43965	0709.001.109-1	HISTÓRIA E CULTURAS AFRICANAS	68
49276	0709.001.800-0	HISTÓRIA, EDUCAÇÃO E MOVIMENTOS SOCIAIS	68
49263	0709.001.787-2	HISTÓRIA E EDUCAÇÃO AMBIENTAL	68
39511	0709.000.759-7	HISTÓRIA E FONTES	68
43971	0709.001.115-3	HISTÓRIA E GÊNERO	68
49268	0709.001.792-5	HISTÓRIA E IMPRENSA	68
43963	0709.001.107-3	HISTÓRIA E LITERATURA MEDIEVAL	68
43970	0709.001.114-4	HISTÓRIA E MARXISMO	68
39512	0709.000.760-0	HISTÓRIA E MEMÓRIA	68
39513	0709.000.761-9	HISTÓRIA E MOVIMENTOS SOCIAIS	68
39514	0709.000.762-7	HISTÓRIA E MOVIMENTOS SOCIAIS NO CAMPO	68
43967	0709.001.111-7	HISTÓRIA E MÚSICA	68
39515	0709.000.763-5	HISTÓRIA INDÍGENA	68
39516	0709.000.764-3	HISTÓRIA ORAL	68
49274	0709.001.798-0	HISTÓRIA PÚBLICA E DIVULGAÇÃO CIENTÍFICA	68
39517	0709.000.765-1	HISTÓRIA REGIONAL	68
39519	0709.000.767-8	HISTÓRIA, RELIGIÕES E RELIGIOSIDADES	68
43975	0709.001.119-0	HISTÓRIA RURAL	68
39518	0709.000.766-0	HISTÓRIA SOCIAL DA GUERRA	68
49277	0709.001.801-0	HISTÓRIA SOCIAL DAS ELITES E DAS PROFISSÕES NO BRASIL	68
43973	0709.001.117-1	HISTÓRIA SOCIAL DO TRABALHO	68
39520	0709.000.768-6	HISTORIOGRAFIA	68
39521	0709.000.769-4	HISTORIOGRAFIA BRASILEIRA	68
43972	0709.001.116-2	HISTORIOGRAFIA GREGA	68
39522	0709.000.770-8	INTRODUÇÃO À CIÊNCIA POLÍTICA	68
39523	0709.000.771-6	INTRODUÇÃO A FILOSOFIA	68
39524	0709.000.772-4	INTRODUÇÃO A SOCIOLOGIA	68
39525	0709.000.773-2	MICROHISTÓRIA	68
39526	0709.000.774-0	NOÇÕES DE ARQUEOLOGIA	68
49271	0709.001.795-2	PRÉ-HISTÓRIA	68
49259	0709.001.783-6	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
50105	0709.002.026-0	BASES DE ENSINO DE BIOLOGIA CELULAR	68
50106	0709.002.027-9	BASES DE ENSINO DE QUÍMICA	68
50126	0709.002.047-5	BASES PARA ENSINO DE EMBRIOLOGIA	68
50127	0709.002.048-4	FILOSOFIA E HISTÓRIA DA EDUCAÇÃO EM CIÊNCIAS	51
50108	0709.002.029-7	MATEMÁTICA	34
50104	0709.002.025-0	MORFOLOGIA VEGETAL	51
50122	0709.002.043-9	PROTOSTOMIA I	51
47251	0709.001.657-0	ANATOMIA VEGETAL	51
50110	0709.002.031-2	LEITURA E PRODUÇÃO DE TEXTO	34
50121	0709.002.042-0	PRÁTICA DE ENSINO EM SABERES NECESSÁRIOS À DOCÊNCIA	68
50124	0709.002.045-7	PROTOSTOMIA II	51
50111	0709.002.032-1	BASES DE ENSINO DE GENÉTICA	68
50130	0709.002.051-9	ESTUDO DE LIBRAS	51
50103	0709.002.024-1	METODOLOGIA E COMUNICAÇÃO CIENTÍFICA	34
50107	0709.002.028-8	MÍDIAS E TECNOLOGIA DIGITAIS NO ENSINO DE CIÊNCIAS BIOLÓGICAS	34
44481	0709.001.174-3	AMBIENTE, SAÚDE E SOCIEDADE	34
50123	0709.002.044-8	GENÉTICA MOLECULAR	34
50129	0709.002.050-0	PRÁTICA DE ENSINO EM EPISTEMOLOGIAS DAS CIÊNCIAS	68
50132	0709.002.053-7	CONSERVAÇÃO E EDUCAÇÃO AMBIENTAL	51
50125	0709.002.046-6	DEUTEROSTOMIA I	51
50119	0709.002.040-1	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS I	100
39071	0709.000.688-4	FISIOLOGIA DO METABOLISMO VEGETAL	51
50115	0709.002.036-8	PRÁTICA DE ENSINO E O CURRÍCULO	68
50112	0709.002.033-0	DEUTEROSTOMIA II	51
50120	0709.002.041-0	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS II	100
39077	0709.000.694-9	FISIOLOGIA DO DESENVOLVIMENTO VEGETAL	51
50131	0709.002.052-8	POLÍTICAS EDUCACIONAIS	51
50128	0709.002.049-3	PRÁTICA DE ENSINO EM AVALIAÇÃO E EDUCAÇÃO INCLUSIVA	68
50114	0709.002.035-9	PRÁTICA DE ENSINO INTERDISCIPLINAR	68
50116	0709.002.037-7	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA I	100
50117	0709.002.038-6	PRÁTICA DE ENSINO EM CONTEÚDOS ESPECÍFICOS	68
50113	0709.002.034-0	BIOGEOGRAFIA	34
39089	0709.000.706-6	ECOLOGIA II	51
50118	0709.002.039-5	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA II	100
44478	0709.001.171-6	PARASITOLOGIA	51
47250	0709.001.656-1	ANÁLISE GENÉTICA	51
47244	0709.001.650-7	BIOLOGIA DE PEIXES DE ÁGUA DOCE	68
47091	0709.001.540-1	BIOTECNOLOGIA DA REPRODUÇÃO ANIMAL	68
39104	0709.000.717-1	CLADÍSTICA, EVOLUÇÃO E A NOVA NOMENCLATURA DOS DEUTEROSTOMIA	51
50136	0709.002.057-3	CURADORIA DE COLEÇÕES BIOLÓGICAS	68
44484	0709.001.177-0	CURRÍCULO E GESTÃO PEDAGÓGICA	51
44485	0709.001.178-0	DIDÁTICA E TECNOLOGIAS EDUCACIONAIS	68
47252	0709.001.658-0	ECOLOGIA URBANA	68
36551	0709.000.533-0	EDUCAÇÃO, CIDADANIA E DIREITOS HUMANOS	68
47096	0709.001.545-7	ELABORAÇÃO DE PROJETOS DE PESQUISA	85
47095	0709.001.544-8	ELABORAÇÃO DE TRABALHOS CIENTÍFICOS	85
44472	0709.001.165-4	EMBRIOLOGIA: DESENVOLVIMENTO HUMANO E CORRELAÇÕES CLÍNICAS	34
47245	0709.001.651-6	EMBRIOLOGIA EXPERIMENTAL	51
47783	0709.001.730-8	EMPREENDEDORISMO, INOVAÇÃO E SUSTENTABILIDADE	68
47247	0709.001.653-4	ESTUDOS DE CAMPO DE ECOSSISTEMAS BRASILEIROS	68
39107	0709.000.720-1	ETNOBOTÂNICA	34
51757	0709.002.295-2	FAUNA SELVAGEM: BIOLOGIA DA CONSERVAÇÃO	68
44462	0709.001.155-6	FISIOPATOLOGIA E TERAPÊUTICA DE DOENÇAS CRÔNICAS	51
50134	0709.002.055-5	GERENCIAMENTO E SEGURANÇA DE DADOS	34
44486	0709.001.179-9	GESTÃO EDUCACIONAL	51
39111	0709.000.724-4	INTRODUÇÃO À ENTOMOLOGIA	68
36238	0709.000.465-2	INTRODUÇÃO A HISTÓRIA DA ÁFRICA	68
44473	0709.001.166-3	INTRODUÇÃO À NEUROCIÊNCIA COM ENFOQUE NA APRENDIZADEM	68
39113	0709.000.726-0	INTRODUÇÃO ÀS ADAPTAÇÕES DOS INVERTEBRADOS	68
47248	0709.001.654-3	LIMNOLOGIA	51
50133	0709.002.054-6	MANEJO DE FAUNA SILVESTRE: ESPÉCIES EM RISCO	51
39117	0709.000.730-9	NOÇÕES DE ARQUEOLOGIA	34
44465	0709.001.158-3	PATOLOGIA HUMANA BÁSICA	51
51770	0709.002.308-3	PRÁTICA DE ENSINO EM BIOLOGIA CELULAR	34
51765	0709.002.303-8	PRÁTICA DE ENSINO EM BIOLOGIA MOLECULAR	34
51766	0709.002.304-7	PRÁTICA DE ENSINO EM DEUTEROSTOMIA	34
51767	0709.002.305-6	PRÁTICA DE ENSINO EM ECOLOGIA E EDUCAÇÃO AMBIENTAL	34
51763	0709.002.301-0	PRÁTICA DE ENSINO EM FISIOLOGIA VEGETAL	34
51764	0709.002.302-9	PRÁTICA DE ENSINO EM GENÉTICA	34
51768	0709.002.306-5	PRÁTICA DE ENSINO EM GEOLOGIA E PALEONTOLOGIA	34
51769	0709.002.307-4	PRÁTICA DE ENSINO EM MICROBIOLOGIA	34
51759	0709.002.297-0	PRÁTICA DE ENSINO EM MORFOFISIOLOGIA ANIMAL	34
51760	0709.002.298-0	PRÁTICA DE ENSINO EM MORFOLOGIA, ANATOMIA E SISTEMÁTICA VEGETAL	34
51761	0709.002.299-9	PRÁTICA DE ENSINO EM PARASITOLOGIA	34
51762	0709.002.300-0	PRÁTICA DE ENSINO EM QUÍMICA	34
50137	0709.002.058-2	PRÁTICAS DE IDENTIFICAÇÃO DE METAZOA	68
47093	0709.001.542-0	PRÁTICA SOLIDÁRIA	68
44460	0709.001.153-8	QUÍMICA ANALÍTICA	34
51758	0709.002.296-1	TAXONOMIA E SISTEMÁTICA BIOLÓGICA	34
44480	0709.001.173-4	TÉCNICAS DE ANÁLISE NUMÉRICA	51
39121	0709.000.734-1	TECNOLOGIA DO DNA RECOMBINANTE	51
44482	0709.001.175-2	TÓPICOS EM BIOTECNOLOGIA E BIOINFORMÁTICA APLICADA.	68
47092	0709.001.541-0	ZOONOSES	68
50534	0709.002.095-8	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
50547	0709.002.108-9	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
50546	0709.002.107-0	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
50533	0709.002.094-9	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
50551	0709.002.112-2	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
50549	0709.002.110-4	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
50543	0709.002.104-2	PRÁTICA DE ENSINO DE MATEMÁTICA A	68
50539	0709.002.100-6	CÁLCULO I	68
50550	0709.002.111-3	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
50535	0709.002.096-7	ESTRUTURAS ALGÉBRICAS I	68
50555	0709.002.116-9	LÓGICA MATEMÁTICA	68
35195	0709.000.256-0	VETORES E GEOMETRIA ANALÍTICA I	68
35197	0709.000.258-7	CÁLCULO II	68
50538	0709.002.099-4	ESTRUTURAS ALGÉBRICAS II	68
50553	0709.002.114-0	LEITURA E PRODUÇÃO DE TEXTOS	68
50527	0709.002.088-7	PRÁTICA DE ENSINO DE MATEMÁTICA B	68
50554	0709.002.115-0	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
35200	0709.000.261-7	VETORES E GEOMETRIA ANALÍTICA II	68
35201	0709.000.262-5	ÁLGEBRA LINEAR I	68
35202	0709.000.263-3	CÁLCULO III	68
50529	0709.002.090-2	ESTÁGIO OBRIGATÓRIO I	100
35214	0709.000.275-7	FÍSICA GERAL I	68
35204	0709.000.265-0	GEOMETRIA I	68
50542	0709.002.103-3	PRÁTICA DE ENSINO DE MATEMÁTICA C	68
35208	0709.000.269-2	CÁLCULO IV	68
50556	0709.002.117-8	ESTÁGIO OBRIGATÓRIO II	100
35220	0709.000.281-1	FÍSICA GERAL II	68
50545	0709.002.106-0	GEOMETRIA II	68
50544	0709.002.105-1	MATEMÁTICA DISCRETA	68
50541	0709.002.102-4	PRÁTICA DE ENSINO DE MATEMÁTICA D	68
35218	0709.000.279-0	EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	68
50536	0709.002.097-6	ESTÁGIO OBRIGATÓRIO III	100
50540	0709.002.101-5	HISTÓRIA DA MATEMÁTICA	68
50528	0709.002.089-6	INTRODUÇÃO À ANÁLISE REAL	68
50531	0709.002.092-0	PRÁTICA DE ENSINO DE MATEMÁTICA E	68
35203	0709.000.264-1	CÁLCULO NUMÉRICO	68
50552	0709.002.113-1	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
50530	0709.002.091-1	ESTÁGIO OBRIGATÓRIO IV	100
44068	0709.001.139-6	MATEMÁTICA FINANCEIRA	68
50537	0709.002.098-5	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
50532	0709.002.093-0	PRÁTICA DE ENSINO DE MATEMÁTICA F	68
35207	0709.000.268-4	ÁLGEBRA LINEAR II	68
44060	0709.001.131-3	ÁLGEBRA LINEAR III	68
44061	0709.001.132-2	ANÁLISE REAL	68
44062	0709.001.133-1	DESENHO GEOMÉTRICO	68
44059	0709.001.130-4	ESPAÇOS MÉTRICOS	68
50548	0709.002.109-8	ESTRUTURAS ALGÉBRICAS III	68
24402	0703.000.713-2	FÍSICA III	68
25684	0703.000.828-7	FÍSICA IV	34
44058	0709.001.129-8	GEOMETRIA DIFERENCIAL	68
44065	0709.001.136-9	HISTÓRIA E FILOSOFIA DA MATEMÁTICA	68
44052	0709.001.123-3	INFORMÁTICA APLICADA AO ENSINO	68
44064	0709.001.135-0	INTRODUÇÃO À ANÁLISE NUMÉRICA	68
35212	0709.000.273-0	INTRODUÇÃO À CIÊNCIA DA COMPUTAÇÃO	68
44069	0709.001.140-2	MATRIZES SISTEMAS LINEARES E POLINÔMIOS	68
35217	0709.000.278-1	PRÁTICA DE ENSINO DE MATEMÁTICA V	68
35221	0709.000.282-0	PRÁTICA DE ENSINO DE MATEMÁTICA VI	68
44049	0709.001.120-6	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
35205	0709.000.266-8	PROBABILIDADE E ESTATÍSTICA	68
44055	0709.001.126-0	PROBLEMAS MATEMÁTICOS NO ENSINO APRENDIZAGEM	68
44056	0709.001.127-0	PROGRAMAÇÃO LINEAR	68
44050	0709.001.121-5	PROJETOS DE ALGORITMOS	68
44054	0709.001.125-1	TEORIA DOS NÚMEROS	68
35193	0709.000.254-4	TRIGONOMETRIA E NÚMEROS COMPLEXOS	68
44053	0709.001.124-2	VARIÁVEIS COMPLEXAS	68
50925	0709.002.203-0	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
50927	0709.002.205-9	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
50923	0709.002.201-2	INTRODUÇÃO À CONTABILIDADE	68
50931	0709.002.209-5	MATEMÁTICA	68
50917	0709.002.195-5	TEORIA GERAL DA ADMINISTRAÇÃO	68
50918	0709.002.196-4	ECONOMIA E NEGÓCIOS	68
35130	0709.000.191-2	MATEMÁTICA FINANCEIRA	68
35230	0709.000.287-0	TECNOLOGIAS DA COMUNICAÇÃO E DA INFORMAÇÃO	68
50915	0709.002.193-7	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
50920	0709.002.198-2	ECONOMIA, GESTÃO E SOCIEDADE	68
50919	0709.002.197-3	FUNDAMENTOS DA ESTATÍSTICA	68
50924	0709.002.202-1	GESTÃO DE MARKETING	68
50935	0709.002.213-9	PESQUISA OPERACIONAL	34
50921	0709.002.199-1	FUNDAMENTOS DA ESTATÍSTICA APLICADA	68
50911	0709.002.189-3	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
50913	0709.002.191-9	GESTÃO DE PESSOAS	68
50930	0709.002.208-6	GESTÃO DO COMPOSTO DE MARKETING	68
50933	0709.002.211-0	GESTÃO FINANCEIRA	68
50928	0709.002.206-8	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
50932	0709.002.210-1	GESTÃO DE CUSTOS	68
50910	0709.002.188-4	GESTÃO DE OPERAÇÕES	68
40927	0709.000.954-9	MARKETING DIGITAL	34
35248	0709.000.305-2	COMPORTAMENTO ORGANIZACIONAL	68
46753	0709.001.384-6	EMPREENDEDORISMO	68
50912	0709.002.190-0	GESTÃO LOGÍSTICA	68
34069	0703.001.001-0	PRODUÇÃO ENXUTA	34
50922	0709.002.200-3	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
35257	0709.000.314-1	ADMINISTRAÇÃO DE SERVIÇOS	34
46789	0709.001.420-8	GESTÃO AMBIENTAL	68
46759	0709.001.390-8	GESTÃO DE PROJETOS	34
46755	0709.001.386-4	GESTÃO E CONSULTORIA EM PEQUENAS EMPRESAS	68
46791	0709.001.422-6	SISTEMAS INTEGRADOS DE GESTÃO	68
50934	0709.002.212-0	ESTÁGIO OBRIGATÓRIO	204
50926	0709.002.204-0	ESTRATÉGIAS ORGANIZACIONAIS	68
46783	0709.001.414-6	GESTÃO DE ORGANIZAÇÕES DO TERCEIRO SETOR	34
35253	0709.000.310-9	GESTÃO PÚBLICA	68
46792	0709.001.423-5	JOGOS EMPRESARIAIS	68
46786	0709.001.417-3	TEORIA DA DECISÃO E DE JOGOS	34
46761	0709.001.392-6	AGRONEGÓCIO	34
35259	0709.000.316-8	ANÁLISE ESTRATÉGICA	34
46760	0709.001.391-7	BOLSA DE VALORES E MERCADO DE CAPITAIS	34
46776	0709.001.407-5	CONTABILIDADE GERENCIAL	34
46762	0709.001.393-5	CONTABILIDADE PARA PEQUENAS EMPRESAS	34
46768	0709.001.399-0	CONTABILIDADE RURAL	34
46771	0709.001.402-0	CRIAÇÃO E GESTÃO DE STARTUPS	68
46757	0709.001.388-2	DIREITOS HUMANOS	34
40921	0709.000.948-4	ECONOMIA CRIATIVA	34
35260	0709.000.317-6	ECONOMIA E NEGÓCIOS DO TURISMO	34
46766	0709.001.397-1	EDUCAÇÃO AMBIENTAL	34
46785	0709.001.416-4	EDUCAÇÃO E TERAPIA FINANCEIRA	34
46769	0709.001.400-1	EMOÇÕES NAS ORGANIZAÇÕES	34
35120	0709.000.181-5	EMPREENDEDORISMO SOCIAL	34
40923	0709.000.950-6	ENGENHARIA ECONÔMICA	34
46772	0709.001.403-9	ENGLISH FOR BUSINESS	68
46773	0709.001.404-8	ESPAÑOL PARA NEGÓCIOS	68
34719	0709.000.151-3	ESTUDOS DE LIBRAS	34
40924	0709.000.951-4	EXCEL APLICADO À ADMINISTRAÇÃO	34
46765	0709.001.396-2	FUNDAMENTOS DE MATEMÁTICA	34
46774	0709.001.405-7	GESTÃO DA INOVAÇÃO TECNOLÓGICA	34
46782	0709.001.413-7	GESTÃO DA QUALIDADE	34
46756	0709.001.387-3	GESTÃO DE CARREIRAS	34
46758	0709.001.389-1	GESTÃO DE EMPREENDIMENTOS RURAIS DE PEQUENO PORTE	34
46764	0709.001.395-3	GESTÃO DE PESSOAS POR COMPETÊNCIAS	34
46777	0709.001.408-4	GESTÃO DO DESEMPENHO	34
46763	0709.001.394-4	GESTÃO DO VAREJO	34
46784	0709.001.415-5	GESTÃO ESTRATÉGICA DE PESSOAS	34
40925	0709.000.952-2	INSTITUIÇÕES DE DIREITO PARA ADMINISTRAÇÃO	34
40926	0709.000.953-0	MAPA ESTRATÉGICO	34
40928	0709.000.955-7	MARKETING PESSOAL	34
46778	0709.001.409-3	MARKETING SOCIAL	34
46779	0709.001.410-0	MELHORIA DE PROCESSOS	34
46775	0709.001.406-6	MÉTODOS DE PESQUISA EM ADMINISTRAÇÃO	34
35267	0709.000.324-9	MODISMO EM ADMINISTRAÇÃO	34
46770	0709.001.401-0	NEGÓCIOS INTERNACIONAIS	34
46780	0709.001.411-9	PESQUISA DE MARKETING	34
46790	0709.001.421-7	PROJETO INTEGRADOR	68
46781	0709.001.412-8	QUALIDADE DE VIDA NO TRABALHO	34
46767	0709.001.398-0	REDAÇÃO EMPRESARIAL	34
46752	0709.001.383-7	REGRESSÃO LINEAR APLICADA À ADMINISTRAÇÃO	34
35270	0709.000.327-3	TRABALHO DO EXECUTIVO	34
35129	0709.000.190-4	CONTABILIDADE INTRODUTÓRIA I	68
47278	0709.001.684-8	DIREITO EMPRESARIAL	34
47279	0709.001.685-7	DIREITO TRABALHISTA	34
49635	0709.001.924-0	FILOSOFIA, ÉTICA E LEGISLAÇÃO PROFISSIONAL CONTÁBIL	68
35133	0709.000.194-7	CONTABILIDADE INTRODUTÓRIA II	68
49648	0709.001.937-6	DIREITO TRIBUTÁRIO	68
49638	0709.001.927-8	INTRODUÇÃO À ADMINISTRAÇÃO	68
49636	0709.001.925-0	MATEMÁTICA	68
47270	0709.001.676-8	ADMINISTRAÇÃO DE MICRO E PEQUENAS EMPRESAS	68
47272	0709.001.678-6	CONTABILIDADE INTERMEDIÁRIA I	68
35154	0709.000.215-3	GESTÃO E CONTABILIDADE AMBIENTAL	68
49642	0709.001.931-1	MÉTODOS E TÉCNICAS DE PESQUISA	68
47273	0709.001.679-5	SISTEMAS DE INFORMAÇÕES GERENCIAS	34
49633	0709.001.922-2	CONTABILIDADE DE CUSTOS	68
47274	0709.001.680-1	CONTABILIDADE INTERMEDIÁRIA II	68
47275	0709.001.681-0	CONTABILIDADE SOCIETÁRIA I	68
49652	0709.001.941-0	CONTABILIDADE TRIBUTÁRIA	68
35141	0709.000.202-1	PROBABILIDADE E ESTATÍSTICA I	68
49644	0709.001.933-0	ADMINISTRAÇÃO FINANCEIRA	68
49645	0709.001.934-9	ANÁLISE DE CUSTOS	68
47276	0709.001.682-0	CONTABILIDADE SOCIETÁRIA II	68
49641	0709.001.930-2	CONTABILIDADE TRIBUTÁRIA II	68
35144	0709.000.205-6	PROBABILIDADE E ESTATÍSTICA II	68
49647	0709.001.936-7	ADMINISTRAÇÃO FINANCEIRA II	68
49632	0709.001.921-3	ANÁLISE DAS DEMONSTRAÇÕES CONTÁBEIS	68
49651	0709.001.940-0	AUDITORIA CONTÁBIL	68
49649	0709.001.938-5	CONTABILIDADE APLICADA AO AGRONEGÓCIO	68
49646	0709.001.935-8	LABORATÓRIO CONTÁBIL I	68
35152	0709.000.213-7	AUDITORIA CONTÁBIL II	68
49634	0709.001.923-1	CONTABILIDADE APLICADA AO SETOR PÚBLICO	68
35158	0709.000.219-6	INTRODUÇÃO ATUARIAL	34
49654	0709.001.943-8	LABORATÓRIO CONTÁBIL II	68
49643	0709.001.932-0	PERÍCIA E ARBITRAGEM	68
49637	0709.001.926-9	CONTABILIDADE AVANÇADA	68
49653	0709.001.942-9	CONTROLADORIA	68
49655	0709.001.944-7	LABORATÓRIO CONTÁBIL III	68
49650	0709.001.939-4	TEORIA DA CONTABILIDADE	68
47254	0709.001.660-5	AVALIAÇÃO DE EMPRESAS - VALUATION	68
49631	0709.001.920-4	COMUNICAÇÃO EMPRESARIAL E NOTAS EXPLICATIVAS	68
35107	0709.000.168-8	CONSULTORIA EMPRESARIAL	68
47255	0709.001.661-4	CONTABILIDADE APLICADA AO TERCEIRO SETOR	34
35103	0709.000.164-5	CONTABILIDADE CONTEMPORÂNEA	68
35096	0709.000.157-2	CONTABILIDADE DE INSTITUIÇÕES FINANCEIRAS	68
47256	0709.001.662-3	CONTABILIDADE ELEITORAL	34
47257	0709.001.663-2	CONTABILIDADE FINANCEIRA: INSTRUMENTOS FINANCEIROS - DERIVATIVOS	68
47258	0709.001.664-1	CONTABILIDADE PARA CONSTRUÇÃO CIVIL E IMOBILIÁRIA	34
47259	0709.001.665-0	CONTABILIDADE PARA MICRO E PEQUENAS EMPRESAS	34
47260	0709.001.666-0	CONTABILOMETRIA	34
47261	0709.001.667-9	ESPANHOL INSTRUMENTAL	68
47262	0709.001.668-8	ESTRATÉGIA EMPRESARIAL	34
35233	0709.000.290-0	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
35105	0709.000.166-1	GESTÃO E CONTABILIDADE HOSPITALAR	68
47267	0709.001.673-0	HISTÓRIA DO PENSAMENTO CONTÁBIL	34
47268	0709.001.674-0	INFORMÁTICA	34
35394	0709.000.387-7	INGLÊS INSTRUMENTAL	68
35249	0709.000.306-0	JOGOS DE EMPRESAS	68
47263	0709.001.669-7	MERCADO DE CAPITAIS	68
47264	0709.001.670-3	MÉTODOS QUANTITATIVOS APLICADOS A CONTABILIDADE I	68
47265	0709.001.671-2	MÉTODOS QUANTITATIVOS APLICADOS A CONTABILIDADE II	68
47266	0709.001.672-1	ORÇAMENTO EMPRESARIAL	34
47282	0709.001.688-4	RESPONSABILIDADE SOCIOAMBIENTAL	68
47283	0709.001.689-3	SEMINÁRIO DE PESQUISA EM CONTABILIDADE	34
47284	0709.001.690-0	TÓPICOS EM CONTABILIDADE I	68
47285	0709.001.691-9	TÓPICOS EM CONTABILIDADE II	68
47286	0709.001.692-8	TÓPICOS EM CONTABILIDADE III	68
47287	0709.001.693-7	TÓPICOS EM CONTABILIDADE IV	34
47288	0709.001.694-6	TÓPICOS EM CONTABILIDADE V	34
35113	0709.000.174-2	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO I	68
35114	0709.000.175-0	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO II	68
47289	0709.001.695-5	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO III	34
35116	0709.000.177-7	TÓPICOS ESPECIAIS EM ADMINISTRAÇÃO IV	34
50500	0709.002.061-7	GEOGRAFIA ECONÔMICA	68
50499	0709.002.060-8	GEOGRAFIA URBANA	68
47383	0709.001.703-0	PRÁTICA DE ENSINO EM GEOGRAFIA ESCOLAR	68
47380	0709.001.700-3	PRÁTICA DE ENSINO EM CARTOGRAFIA	68
50501	0709.002.062-6	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA I	100
44935	0709.001.181-4	PRÁTICA DE ENSINO EM GEOGRAFIA RELAÇÃO CAMPO E CIDADE	68
50502	0709.002.063-5	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA II	100
50510	0709.002.071-5	PRÁTICA DE ENSINO EM GEOGRAFIA E NATUREZA	68
50520	0709.002.081-3	TEORIA E MÉTODOS DA GEOGRAFIA	68
50525	0709.002.086-9	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA III	100
44973	0709.001.219-7	PRATICA DE ENSINO EM GEOGRAFIA DO BRASIL	68
50503	0709.002.064-4	ESTÁGIO OBRIGATÓRIO EM GEOGRAFIA IV	100
50511	0709.002.072-4	PRÁTICA DE ENSINO EM GEOGRAFIA DOS ESPAÇOS GLOBAIS	68
44940	0709.001.186-0	CARTOGRAFIA E AS NOVAS TECNOLOGIAS DE ENSINO	68
44957	0709.001.203-4	GEOGRAFIA, CINEMA E EDUCAÇÃO	68
44947	0709.001.193-0	GEOPROCESSAMENTO	68
50512	0709.002.073-3	MATEMÁTICA E ESTATÍSTICA APLICADA À GEOGRAFIA	68
44955	0709.001.201-6	MATERIAIS DIDÁTICOS PARA ENSINO DE GEOGRAFIA	68
50505	0709.002.066-2	MORFOLOGIA DO SOLO	68
44956	0709.001.202-5	PLANEJAMENTO AMBIENTAL	68
47398	0709.001.718-4	PLANEJAMENTO REGIONAL	68
44987	0709.001.233-9	PLANEJAMENTO RURAL E AGRÁRIO	34
47401	0709.001.721-9	PLANEJAMENTO URBANO	68
44981	0709.001.227-7	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
50507	0709.002.068-0	SEMINÁRIOS DE GRADUAÇÃO	68
44962	0709.001.208-0	VEÍCULOS AÉREOS NÃO TRIPULADOS	68
40726	0709.000.898-4	ANATOMIA HUMANA I	68
49229	0709.001.753-1	ANTROPOLOGIA E SAÚDE	51
34668	0709.000.100-9	BASES HISTÓRICAS E CONCEITUAIS DA ENFERMAGEM	68
49231	0709.001.755-0	BIOLOGIA CELULAR	51
40728	0709.000.900-0	BIOQUÍMICA	68
49235	0709.001.759-6	DIDÁTICA APLICADA À ENFERMAGEM	34
40729	0709.000.901-8	FISIOLOGIA I	68
49217	0709.001.741-5	SAÚDE E SOCIEDADE	51
40731	0709.000.903-4	ANATOMIA HUMANA II	68
49246	0709.001.770-0	BASES CONCEITUAIS DA SAÚDE COLETIVA	51
49232	0709.001.756-9	EMBRIOLOGIA	51
45531	0709.001.317-6	FISIOLOGIA II	68
49237	0709.001.761-1	HISTOLOGIA	68
49243	0709.001.767-6	INVESTIGAÇÃO EM SAÚDE I	51
49239	0709.001.763-0	MICROBIOLOGIA BÁSICA E CLÍNICA	68
49242	0709.001.766-7	PSICOLOGIA APLICADA À SAÚDE	51
49248	0709.001.772-9	ÉTICA, BIOÉTICA E EXERCÍCIO PROFISSIONAL DE ENFERMAGEM	51
49233	0709.001.757-8	FARMACOLOGIA APLICADA À ENFERMAGEM I	51
49214	0709.001.738-0	FUNDAMENTOS DE ENFERMAGEM I	119
49240	0709.001.764-9	PARASITOLOGIA HUMANA	51
49241	0709.001.765-8	PATOLOGIA GERAL	51
45323	0709.001.279-6	SEMIOLOGIA E SEMIOTÉCNICA APLICADAS À ENFERMAGEM	68
49228	0709.001.752-2	EDUCAÇÃO EM SAÚDE	51
49234	0709.001.758-7	FARMACOLOGIA APLICADA À ENFERMAGEM II	68
49247	0709.001.771-0	FUNDAMENTOS DE ENFERMAGEM II	119
49236	0709.001.760-2	GENÉTICA HUMANA	51
49238	0709.001.762-0	IMUNOLOGIA	51
45321	0709.001.277-8	PROCESSO DE ENFERMAGEM	34
49230	0709.001.754-0	BIOESTATÍSTICA	34
49209	0709.001.733-5	ENFERMAGEM EM SAÚDE COLETIVA I	85
49227	0709.001.751-3	ENFERMAGEM NA SAÚDE DA CRIANÇA E DO ADOLESCENTE I	85
52116	0709.002.313-6	ENFERMAGEM NA SAÚDE SEXUAL E REPRODUTIVA I	85
34696	0709.000.128-9	EPIDEMIOLOGIA	68
52118	0709.002.315-4	ENFERMAGEM EM DOENÇAS TRANSMISSÍVEIS	51
49211	0709.001.735-3	ENFERMAGEM EM SAÚDE COLETIVA II	85
49215	0709.001.739-0	ENFERMAGEM EM SAÚDE MENTAL I	68
49212	0709.001.736-2	ENFERMAGEM NA SAÚDE DA CRIANÇA E DO ADOLESCENTE II	85
52119	0709.002.316-3	ENFERMAGEM NA SAÚDE SEXUAL E REPRODUTIVA II	85
49210	0709.001.734-4	ENFERMAGEM EM SAÚDE MENTAL II	68
40754	0709.000.926-3	ENFERMAGEM NA SAÚDE DA PESSOA ADULTA	85
45336	0709.001.292-9	ENFERMAGEM NA SAÚDE DA PESSOA IDOSA	68
49213	0709.001.737-1	ENFERMAGEM NAS PRÁTICAS INTEGRATIVAS E COMPLEMENTARES I	68
49218	0709.001.742-4	GESTÃO EM SAÚDE COLETIVA	68
49244	0709.001.768-5	INVESTIGAÇÃO EM SAÚDE II	34
52117	0709.002.314-5	CONTROLE E PREVENÇÃO DE INFECÇÕES NOS SERVIÇOS DE SAÚDE	34
49216	0709.001.740-6	ENFERMAGEM NAS PRÁTICAS INTEGRATIVAS E COMPLEMENTARES II	68
34708	0709.000.140-8	ENFERMAGEM NO CUIDADO DO PACIENTE CRÍTICO	102
34710	0709.000.142-4	ENFERMAGEM PERIOPERATÓRIA	102
34711	0709.000.143-2	GERENCIAMENTO APLICADO À ENFERMAGEM HOSPITALAR	68
49207	0709.001.731-7	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE I	440
49245	0709.001.769-4	INVESTIGAÇÃO EM SAÚDE III	34
49208	0709.001.732-6	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE II	440
45529	0709.001.315-8	ASPECTOS BIOQUÍMICOS, IMUNOPATOLÓGICOS E TERAPÊUTICOS DE DOENÇAS INFECCIOSAS E NÃO INFECCIOSAS	68
51904	0709.002.312-7	ASSISTÊNCIA DE ENFERMAGEM À SAÚDE NEONATAL	34
49225	0709.001.749-8	COMUNICAÇÃO E LIDERANÇA EM ENFERMAGEM	34
40715	0709.000.887-9	CUIDADOS PALIATIVOS E A ENFERMAGEM	51
40716	0709.000.888-7	DIAGNÓSTICO DAS DOENÇAS TORÁCICAS POR IMAGEM	68
45528	0709.001.314-9	EDUCAÇÃO E SAÚDE NA ESCOLA	68
49223	0709.001.747-0	EDUCAÇÃO FINANCEIRA E EMPREENDEDORISMO	34
45345	0709.001.301-3	ENFERMAGEM EM SAÚDE MENTAL NA ATENÇÃO BÁSICA	68
45331	0709.001.287-6	ENFERMAGEM E SAÚDE DO TRABALHADOR	51
49219	0709.001.743-3	ENFERMAGEM NA ATENÇÃO À SAÚDE DA POPULAÇÃO LGBT+	51
49220	0709.001.744-2	ENFERMAGEM NA ATENÇÃO À SAÚDE DO HOMEM	51
45332	0709.001.288-5	ENFERMAGEM NA ATENÇÃO DOMICILIAR	51
40717	0709.000.889-5	ENFERMAGEM ONCOLÓGICA	68
45530	0709.001.316-7	ENSINO-PESQUISA-EXTENSÃO: UM EXERCÍCIO DE INDISSOCIABILIDADE NA GRADUAÇÃO	68
45338	0709.001.294-7	ESTÁGIO OPTATIVO EM ATENÇÃO BÁSICA	34
45339	0709.001.295-6	ESTÁGIO OPTATIVO HOSPITALAR	34
45316	0709.001.272-2	FISIOPATOLOGIA E TERAPÊUTICA DE DOENÇAS CRÔNICAS	51
45337	0709.001.293-8	FOTOTERAPIA E APLICAÇÕES CLÍNICAS	68
45533	0709.001.319-4	GRUPOS E RODAS DE CONVERSA PARA EDUCAÇÃO E PROMOÇÃO EM SAÚDE	68
40718	0709.000.890-9	INTERAÇÕES MEDICAMENTOSAS	68
45330	0709.001.286-7	INTERPRETAÇÃO DE EXAMES LABORATORIAIS	51
40719	0709.000.891-7	INTERPRETAÇÃO DO ELETROCARDIOGRAMA	68
45347	0709.001.303-1	MANEJO DO ALEITAMENTO MATERNO	34
49221	0709.001.745-1	MANEJO E CUIDADO NAS PATOLOGIAS E DISFUNÇÕES DA PELE	68
40720	0709.000.892-5	METODOLOGIAS ATIVAS PARA O PROCESSO ENSINO-APRENDIZAGEM EM ENFERMAGEM	68
49224	0709.001.748-9	NEUROCIÊNCIA E FISIOPATOLOGIA DAS DOENÇAS NEUROLÓGICAS	51
45319	0709.001.275-0	NEUROPSICOFARMACOLOGIA	51
45349	0709.001.305-0	NUTRIÇÃO APLICADA A SAÚDE	68
49222	0709.001.746-0	OZONIOTERAPIA E APLICAÇÕES CLÍNICAS	68
34722	0709.000.154-8	PLANTAS MEDICINAIS	51
45318	0709.001.274-0	PRÁTICAS POPULARES E INTEGRATIVAS NO ÂMBITO DA EDUCAÇÃO POPULAR EM SAÚDE	68
45532	0709.001.318-5	REDAÇÃO E DIVULGAÇÃO CIENTÍFICA	51
40722	0709.000.894-1	SAÚDE AMBIENTAL	51
40723	0709.000.895-0	SAÚDE, DIREITOS HUMANOS E CIDADANIA	51
45317	0709.001.273-1	SAÚDE E ESPIRITUALIDADE	68
40724	0709.000.896-8	SEGURANÇA DO PACIENTE	51
40725	0709.000.897-6	SUPORTE BÁSICO E AVANÇADO DE VIDA EM CARDIOLOGIA	68
45320	0709.001.276-9	TOXICOLOGIA	51
45342	0709.001.298-3	VIGILÂNCIA EM SAÚDE	51
50572	0709.002.133-8	DESENHO TÉCNICO	68
27460	0708.000.938-4	ECONOMIA	68
50557	0709.002.118-7	FUNDAMENTOS DE MECÂNICA	68
25535	0703.000.806-6	INTRODUÇÃO À ENGENHARIA DE PRODUÇÃO	34
25536	0703.000.807-4	QUÍMICA GERAL	68
50558	0709.002.119-6	VETORES E GEOMETRIA ANALÍTICA	68
50584	0709.002.145-4	ÁLGEBRA LINEAR	68
25679	0708.000.759-4	FUNDAMENTOS DA ADMINISTRAÇÃO	34
50597	0709.002.158-0	FUNDAMENTOS DE TERMODINÂMICA	34
50596	0709.002.157-0	INTRODUÇÃO À CIÊNCIA DA COMPUTAÇÃO	68
50560	0709.002.121-1	LABORATÓRIO DE MECÂNICA, FLUIDOS E TERMODINÂMICA	34
25541	0703.000.812-0	MECÂNICA APLICADA	68
50595	0709.002.156-1	QUÍMICA GERAL EXPERIMENTAL	34
50587	0709.002.148-1	QUÍMICA TECNOLÓGICA	68
50582	0709.002.143-6	CÁLCULO II	68
50559	0709.002.120-2	FUNDAMENTOS DE ELETROMAGNETISMO	68
50580	0709.002.141-8	FUNDAMENTOS DE OSCILAÇÕES, ONDAS E FLUIDOS	34
25680	0703.000.825-2	MECÂNICA DOS SÓLIDOS I	68
50586	0709.002.147-2	MÉTODOS NUMÉRICOS	68
50589	0709.002.150-7	PROBABILIDADE E ESTATÍSTICA I	68
50583	0709.002.144-5	CÁLCULO III	68
50598	0709.002.159-9	CUSTOS INDUSTRIAIS	34
50574	0709.002.135-6	GESTÃO AMBIENTAL	68
50571	0709.002.132-9	LABORATÓRIO DE ONDAS E ELETROMAGNETISMO	34
25686	0703.000.830-9	MECÂNICA DOS SÓLIDOS II	68
34047	0708.001.045-5	MERCADOLOGIA	68
50573	0709.002.134-7	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
25687	0703.000.831-7	PROBABILIDADE E ESTATÍSTICA II	68
25690	0703.000.833-3	CIÊNCIA DOS MATERIAIS I	68
50562	0709.002.123-0	ENGENHARIA ECONÔMICA	68
50569	0709.002.130-0	ERGONOMIA E SEGURANÇA NO TRABALHO	68
50590	0709.002.151-6	ESTRATÉGIA EMPRESARIAL	68
25693	0703.000.835-0	FENÔMENOS DE TRANSPORTE I	68
50576	0709.002.137-4	PESQUISA OPERACIONAL I	68
25696	0703.000.836-8	CIÊNCIA DOS MATERIAIS II	68
50600	0709.002.161-4	ELETRICIDADE APLICADA	51
25698	0703.000.838-4	FENÔMENOS DE TRANSPORTE II	68
50575	0709.002.136-5	GESTÃO DE PROJETOS	68
50577	0709.002.138-3	PESQUISA OPERACIONAL II	68
50588	0709.002.149-0	PROJETO DE SISTEMAS DE PRODUÇÃO	51
50599	0709.002.160-5	SISTEMAS DE PRODUÇÃO	34
34050	0708.001.047-1	TECNOLOGIA E GESTÃO DOS SISTEMAS DE INFORMAÇÃO	34
25702	0708.000.766-7	AGRONEGÓCIO	34
50565	0709.002.126-7	ENGENHARIA DE MÉTODOS	68
50594	0709.002.155-2	GESTÃO DE PESSOAS APLICADA À ENGENHARIA DE PRODUÇÃO	34
34052	0703.000.984-4	LOGÍSTICA E GESTÃO DA CADEIA DE SUPRIMENTOS	68
25705	0703.000.841-4	MÉTODOS PARA CONTROLE E MELHORIA DA QUALIDADE	68
50561	0709.002.122-0	OPERAÇÕES UNITÁRIAS	68
50578	0709.002.139-2	PLANEJAMENTO E CONTROLE DA PRODUÇÃO I	68
25707	0703.000.843-0	PROCESSAMENTO INDUSTRIAL DE MATERIAIS I	68
34054	0703.000.986-0	AUTOMAÇÃO INDUSTRIAL	34
25712	0703.000.846-5	GESTÃO DA QUALIDADE I	34
50579	0709.002.140-9	PLANEJAMENTO E CONTROLE DA PRODUÇÃO II	68
50592	0709.002.153-4	PROCESSAMENTO INDUSTRIAL DE MATERIAIS II	34
26089	0703.000.851-1	PROCESSAMENTO INDUSTRIAL QUÍMICO	68
34056	0703.000.988-7	PROJETO DE UNIDADES PRODUTIVAS	68
50566	0709.002.127-6	ESTÁGIO OBRIGATÓRIO I	80
50593	0709.002.154-3	FUNDAMENTOS PARA ELABORAÇÃO DE TRABALHO CIENTÍFICO	34
50591	0709.002.152-5	GESTÃO DA QUALIDADE II	68
50563	0709.002.124-9	PLANEJAMENTO E CONTROLE DA PRODUÇÃO III	68
50564	0709.002.125-8	PROJETO E DESENVOLVIMENTO DE PRODUTOS	68
50567	0709.002.128-5	ESTÁGIO OBRIGATÓRIO II	80
34062	0703.000.994-1	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS NO BRASIL	34
50568	0709.002.129-4	EDUCAÇÃO E TERAPIA FINANCEIRA	34
50570	0709.002.131-0	FUNDAMENTOS DE ELETRICIDADE	34
34063	0703.000.995-0	GESTÃO DA INOVAÇÃO TECNOLÓGICA	34
25704	0708.000.768-3	GESTÃO DE SERVIÇO	34
25544	0704.001.437-9	INGLÊS INSTRUMENTAL	34
34064	0703.000.996-8	LABORATÓRIO DE AUTOMAÇÃO	34
34065	0703.000.997-6	LOGÍSTICA EMPRESARIAL	34
34066	0703.000.998-4	MANUTENÇÃO MECÂNICA	34
34067	0703.000.999-2	MODELAGEM MATEMÁTICA	34
25543	0704.001.436-0	PORTUGUÊS	34
34068	0703.001.000-1	PROCESSO DE FABRICAÇÃO	34
34071	0703.001.003-6	TÓPICOS EM META-HEURÍSTICAS	34
34074	0703.001.006-0	TRATAMENTO DE RESÍDUOS INDUSTRIAIS	34
34072	0703.001.004-4	VIBRAÇÕES	34
49528	0805.000.407-6	ALGORITMOS E PROGRAMAÇÃO I	102
49556	0805.000.435-2	FUNDAMENTOS MATEMÁTICOS PARA COMPUTAÇÃO	34
34299	0803.000.203-1	INTRODUÇÃO A COMPUTAÇÃO	34
49549	0805.000.428-1	MODELAGEM DE PROCESSOS DE NEGÓCIO	68
49526	0805.000.405-8	ALGORITMOS E PROGRAMAÇÃO II	102
49527	0805.000.406-7	ENGENHARIA DE SOFTWARE	68
49562	0805.000.441-4	MATEMÁTICA ELEMENTAR	68
49563	0805.000.442-3	ANÁLISE DE SOFTWARE ORIENTADO A OBJETOS	68
49524	0805.000.403-0	ESTATÍSTICA	68
49542	0805.000.421-8	LINGUAGEM DE PROGRAMAÇÃO ORIENTADA A OBJETOS	68
49550	0805.000.429-0	ORGANIZAÇÃO DE COMPUTADORES	68
49522	0805.000.401-1	BANCO DE DADOS	68
49568	0805.000.447-9	ESTRUTURA DE DADOS	68
25977	0803.000.147-7	INTERAÇÃO HUMANO-COMPUTADOR	68
49540	0805.000.419-2	INTRODUÇÃO A SISTEMAS OPERACIONAIS	68
49529	0805.000.408-5	FUNDAMENTOS DA ADMINISTRAÇÃO	68
49535	0805.000.414-7	FUNDAMENTOS DE REDES DE COMPUTADORES	68
25969	0803.000.139-6	INTELIGÊNCIA ARTIFICIAL	68
49541	0805.000.420-9	LABORATÓRIO DE BANCO DE DADOS	68
49523	0805.000.402-0	PROGRAMAÇÃO PARA WEB	68
49561	0805.000.440-5	COMPUTAÇÃO DISTRIBUÍDA	68
49558	0805.000.437-0	GERÊNCIA DE PROJETOS	68
49543	0805.000.422-7	GERENCIAMENTO DE SERVIÇOS DE TECNOLOGIA DA INFORMAÇÃO	68
49521	0805.000.400-2	PROGRAMAÇÃO PARA WEB II	68
34305	0803.000.209-0	COMPORTAMENTO ORGANIZACIONAL	34
49538	0805.000.417-4	GOVERNANÇA DE TECNOLOGIA DA INFORMAÇÃO	68
49534	0805.000.413-8	QUALIDADE DE SOFTWARE	68
49557	0805.000.436-1	SISTEMAS DE APOIO À DECISÃO	68
34304	0803.000.208-2	COMPUTAÇÃO E SOCIEDADE	34
49570	0805.000.449-7	GESTÃO ESTRATÉGICA	68
25934	0803.000.113-2	SEGURANÇA E AUDITORIA DE SISTEMAS	68
30085	0803.000.161-2	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS II	68
49559	0805.000.438-0	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS II	68
25548	0803.000.083-7	CÁLCULO	68
25913	0803.000.092-6	COMPUTAÇÃO DE ALTO DESEMPENHO	68
25914	0803.000.093-4	COMPUTAÇÃO GRÁFICA	68
25915	0803.000.094-2	COMUNICAÇÃO E EXPRESSÃO	68
25916	0803.000.095-0	COMUNICAÇÃO E TRANSMISSÃO DE DADOS	68
44487	0805.000.138-8	DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	68
25980	0803.000.150-7	ENGENHARIA DE SOFTWARE II	68
31405	0803.000.174-4	ESTRUTURAS DE DADOS I	68
25919	0803.000.098-5	ESTUDO DE LIBRAS	68
25920	0803.000.099-3	GEOMETRIA COMPUTACIONAL	68
25921	0803.000.100-0	GERÊNCIA DE REDES	68
30088	0803.000.164-7	GESTÃO DE PROJETOS II	68
25923	0803.000.102-7	GOVERNANÇA DE TI II	68
49545	0805.000.424-5	HISTÓRIA DA ÁFRICA E CULTURA AFRO-BRASILEIRA	68
25489	0801.000.074-2	HISTÓRIA INDÍGENA	68
25924	0803.000.103-5	IMPLEMENTAÇÃO ALGORÍTMICA	68
49551	0805.000.430-7	INFORMÁTICA NA EDUCAÇÃO	68
49554	0805.000.433-4	INGLÊS INSTRUMENTAL	68
25925	0803.000.104-3	INTRODUÇÃO À COMPLEXIDADE COMPUTACIONAL	68
34282	0803.000.186-8	INTRODUÇÃO À CONTABILIDADE	34
25927	0803.000.106-0	INTRODUÇÃO À CRIPTOGRAFIA COMPUTACIONAL	68
49531	0805.000.410-0	INTRODUÇÃO À INFORMÁTICA	68
34284	0803.000.188-4	INTRODUÇÃO A SISTEMAS DE INFORMAÇÃO	34
34298	0803.000.202-3	INTRODUÇÃO A SISTEMAS DIGITAIS	68
49560	0805.000.439-9	INTRODUÇÃO A SISTEMAS DIGITAIS	68
30083	0803.000.159-0	INTRODUÇÃO À TEORIA DA COMPUTAÇÃO	68
49569	0805.000.448-8	INTRODUÇÃO À TEORIA DOS GRAFOS	68
25930	0803.000.109-4	LINGUAGEM DE MONTAGEM	68
25931	0803.000.110-8	LINGUAGENS FORMAIS E AUTÔMATOS	68
49564	0805.000.443-2	METODOLOGIA	68
44627	0805.000.151-0	TECNOLOGIAS DA COMUNICAÇÃO E INFORMAÇÃO	68
49580	0805.000.459-5	TÓPICOS DE EXTENSÃO I	68
49581	0805.000.460-1	TÓPICOS DE EXTENSÃO II	68
49577	0805.000.456-8	TÓPICOS DE EXTENSÃO III	68
49578	0805.000.457-7	TÓPICOS DE EXTENSÃO IV	68
49553	0805.000.432-5	TÓPICOS DE WEB SEMÂNTICA	68
49552	0805.000.431-6	TÓPICOS DE WEB SEMÂNTICA II	68
49520	0805.000.399-0	TÓPICOS EM APLICATIVOS MÓVEIS	68
49533	0805.000.412-9	TÓPICOS EM APREDIZADO DE MÁQUINA	68
49555	0805.000.434-3	TÓPICOS EM APRENDIZADO DE MÁQUINA II	68
25937	0803.000.116-7	TÓPICOS EM ARQUITETURA DE COMPUTADORES	68
49579	0805.000.458-6	TÓPICOS EM ARQUITETURA DE COMPUTADORES II	68
49576	0805.000.455-9	TÓPICOS EM BANCO DE DADOS II	68
25938	0803.000.117-5	TÓPICOS EM BANCOS DE DADOS	68
25939	0803.000.118-3	TÓPICOS EM COMPUTAÇÃO GRÁFICA	68
49575	0805.000.454-0	TÓPICOS EM COMPUTAÇÃO GRÁFICA II	68
49546	0805.000.425-4	TÓPICOS EM DESAFIOS DE PROGRAMAÇÃO	68
49530	0805.000.409-4	TÓPICOS EM DESAFIOS DE PROGRAMAÇÃO II	68
49548	0805.000.427-2	TÓPICOS EM DESENVOLVIMENTO DE APLICATIVOS MÓVEIS	68
49532	0805.000.411-0	TÓPICOS EM DESENVOLVIMENTO DE SISTEMAS ORIENTADO A OBJETOS	68
25940	0803.000.119-1	TÓPICOS EM ENGENHARIA DE SOFTWARE	68
49574	0805.000.453-0	TÓPICOS EM ENGENHARIA DE SOFTWARE II	68
49525	0805.000.404-9	TÓPICOS EM ESTRUTURA DE DADOS	68
25941	0803.000.120-5	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL	68
49547	0805.000.426-3	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL II	68
49544	0805.000.423-6	TÓPICOS EM ORIENTAÇÃO A OBJETOS	68
34294	0803.000.198-1	TÓPICOS EM PROGRAMAÇÃO	68
49573	0805.000.452-1	TÓPICOS EM PROGRAMAÇÃO II	68
49567	0805.000.446-0	TÓPICOS EM PROGRAMAÇÃO PARA WEB	68
49536	0805.000.415-6	TÓPICOS EM PROGRAMAÇÃO PARA WEB II	68
34295	0803.000.199-0	TÓPICOS EM REDES DE COMPUTADORES	68
49572	0805.000.451-2	TÓPICOS EM REDES DE COMPUTADORES II	68
49566	0805.000.445-0	TÓPICOS EM SISTEMAS DE APOIO À DECISÃO	68
49539	0805.000.418-3	TÓPICOS EM SISTEMAS DE APOIO À DECISÃO II	68
34297	0803.000.201-5	TÓPICOS EM SISTEMAS DE INFORMAÇÃO	68
49565	0805.000.444-1	TÓPICOS EM SISTEMAS OPERACIONAIS	68
49537	0805.000.416-5	TÓPICOS EM SISTEMAS OPERACIONAIS II	68
34296	0803.000.200-7	TÓPICOS EM TECNOLOGIAS EMERGENTES	68
49571	0805.000.450-3	TÓPICOS EM TECNOLOGIAS EMERGENTES II	68
46046	0805.000.238-5	TÓPICOS ESPECIAIS DE DIREITO EMPRESARIAL	34
47414	0805.000.246-5	ANATOMIA HUMANA I	51
50236	0805.000.466-6	BIOLOGIA CELULAR	51
47473	0805.000.305-0	FISIOLOGIA HUMANA I	51
50240	0805.000.470-0	GENÉTICA HUMANA	51
47411	0805.000.243-8	METODOLOGIA CIENTÍFICA	51
50231	0805.000.461-0	PSICOLOGIA APLICADA À SAÚDE	51
50253	0805.000.483-5	SAÚDE E SOCIEDADE	51
47412	0805.000.244-7	SUPORTE BÁSICO DE VIDA E BIOSSEGURANÇA	51
47434	0805.000.266-1	ANATOMIA HUMANA II	51
50249	0805.000.479-1	ANTROPOLOGIA E SAÚDE	51
50246	0805.000.476-4	BASES CONCEITUAIS DA SAÚDE COLETIVA	51
47416	0805.000.248-3	BIOQUÍMICA	51
50250	0805.000.480-8	EMBRIOLOGIA	51
50251	0805.000.481-7	ÉTICA, BIOÉTICA E EXERCÍCIO PROFISSIONAL DE ENFERMAGEM	51
47470	0805.000.302-3	FISIOLOGIA HUMANA II	51
50239	0805.000.469-3	DIDÁTICA APLICADA À ENFERMAGEM	34
47462	0805.000.294-8	FUNDAMENTOS DE ENFERMAGEM I	136
47463	0805.000.295-7	GERENCIAMENTO APLICADO À ENFERMAGEM I	68
50237	0805.000.467-5	HISTOLOGIA	68
50241	0805.000.471-9	IMUNOLOGIA	51
50242	0805.000.472-8	MICROBIOLOGIA BÁSICA E CLÍNICA	68
50245	0805.000.475-5	BIOESTATÍSTICA	34
50234	0805.000.464-8	FUNDAMENTOS DE ENFERMAGEM II	119
50243	0805.000.473-7	PARASITOLOGIA HUMANA	51
50244	0805.000.474-6	PATOLOGIA GERAL	51
47468	0805.000.300-5	PROCESSO DE ENFERMAGEM	85
47441	0805.000.273-2	ENFERMAGEM NA SAÚDE DA CRIANÇA E DO ADOLESCENTE	102
47442	0805.000.274-1	EPIDEMIOLOGIA	51
50238	0805.000.468-4	FARMACOLOGIA APLICADA À ENFERMAGEM I	51
47443	0805.000.275-0	NUTRIÇÃO APLICADA À ENFERMAGEM	51
47437	0805.000.269-9	SAÚDE COLETIVA I	119
47445	0805.000.277-9	ENFERMAGEM NA SAÚDE DA MULHER	119
47446	0805.000.278-8	ENFERMAGEM NA SAÚDE DO ADULTO I	136
50232	0805.000.462-0	INVESTIGAÇÃO EM SAÚDE I	51
47421	0805.000.253-6	SAÚDE COLETIVA II	119
47477	0805.000.309-7	ENFERMAGEM EM SAÚDE MENTAL I	68
47429	0805.000.261-6	ENFERMAGEM NA SAÚDE DA PESSOA IDOSA	68
47448	0805.000.280-3	ENFERMAGEM NA SAÚDE DO ADULTO II	136
50235	0805.000.465-7	FARMACOLOGIA APLICADA À ENFERMAGEM II	68
50252	0805.000.482-6	INVESTIGAÇÃO EM SAÚDE II	34
47449	0805.000.281-2	ENFERMAGEM EM SAÚDE MENTAL II	85
47439	0805.000.271-4	ENFERMAGEM NO CUIDADO AO PACIENTE CRÍTICO	119
47475	0805.000.307-9	GERENCIAMENTO APLICADO À ENFERMAGEM II	68
50233	0805.000.463-9	INVESTIGAÇÃO EM SAÚDE III	34
50247	0805.000.477-3	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE I	440
50248	0805.000.478-2	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE II	440
47459	0805.000.291-0	ASPECTOS TEÓRICOS/FILOSÓFICOS DO CUIDADO EM ENFERMAGEM	34
47417	0805.000.249-2	ASSISTÊNCIA DE ENFERMAGEM NA PREVENÇÃO, AVALIAÇÃO E TRATAMENTO DAS FERIDAS	51
47450	0805.000.282-1	CONTROLE E PREVENÇÃO DE INFECÇÕES NOS SERVIÇOS DE SAÚDE	34
47438	0805.000.270-5	CUIDADOS PALIATIVOS E A ENFERMAGEM	34
47460	0805.000.292-0	DIFERENÇA, DIVERSIDADE E DIREITOS HUMANOS	51
47453	0805.000.285-9	EDUCAÇÃO PARA AS RELAÇÕES ÉTNICO-RACIAIS	51
47454	0805.000.286-8	EDUCAÇÃO PARA SAÚDE SEXUAL E REPRODUTIVA	34
47455	0805.000.287-7	EMPREENDEDORISMO E INOVAÇÃO EM ENFERMAGEM	34
47456	0805.000.288-6	ENFERMAGEM APLICADA À SAÚDE DO TRABALHADOR	51
47424	0805.000.256-3	ENFERMAGEM E FAMÍLIA	34
40874	0805.000.111-1	HISTÓRIA DA ÁFRICA E CULTURA AFRO-BRASILEIRA	51
30070	0801.000.144-7	HISTÓRIA DA INFÂNCIA	68
25487	0801.000.072-6	HISTÓRIA DA SAÚDE E DA SEXUALIDADE	68
33938	0801.000.167-6	HISTÓRIA DAS MULHERES E RELAÇÕES DE GÊNERO	68
47431	0805.000.263-4	IMUNIZAÇÃO	34
47425	0805.000.257-2	INTERAÇÕES MEDICAMENTOSAS	34
47472	0805.000.304-1	INTERPRETAÇÃO DE EXAMES LABORATORIAIS	51
25494	0801.000.079-3	INTRODUÇÃO À INFORMÁTICA	68
38998	0805.000.053-0	LIBRAS: LÍNGUA BRASILEIRA DE SINAIS	68
47422	0805.000.254-5	MANEJO DO ALEITAMENTO MATERNO	51
47419	0805.000.251-8	MATEMÁTICA BÁSICA	51
47430	0805.000.262-5	PORTUGUÊS	51
33939	0801.000.168-4	PRODUÇÃO DE TEXTOS	68
40878	0805.000.115-4	PSICOLOGIA DA FAMÍLIA	68
47474	0805.000.306-0	RELACIONAMENTO INTERPESSOAL, COMUNICAÇÃO E LIDERANÇA	34
47426	0805.000.258-1	SAÚDE MENTAL NA INFÂNCIA E ADOLESCÊNCIA	34
47420	0805.000.252-7	SEGURANÇA DO PACIENTE	34
47458	0805.000.290-1	TÓPICOS ESPECIAIS EM ATENÇÃO INTEGRADA ÀS DOENÇAS EMERGENTES E PREVALENTES NO ESTADO DE MATO GROSSO DO SUL	34
47457	0805.000.289-5	TÓPICOS ESPECIAIS EM PRÁTICAS EMERGENTES DE ENFERMAGEM	34
47418	0805.000.250-9	TÓPICOS ESPECIAIS EM PRÁTICAS INTEGRATIVAS E COMPLEMENTARES	34
24472	0802.000.110-5	HISTÓRIA DA EDUCAÇÃO	51
36609	0805.000.003-4	LINGUÍSTICA	68
24501	0802.000.139-3	LITERATURA E SOCIEDADE	51
44230	0805.000.135-0	PSICOLOGIA E EDUCAÇÃO	51
36610	0805.000.004-2	TECNOLOGIA DA INFORMAÇÃO E COMUNICAÇÃO (TIC)	51
36771	0805.000.015-8	FONÉTICA E FONOLOGIA DO PORTUGUÊS	68
36773	0805.000.017-4	HISTORIOGRAFIA LITERÁRIA	51
36772	0805.000.016-6	POLÍTICAS EDUCACIONAIS	51
34584	0805.000.001-8	PRÁTICA DE ENSINO I	51
36774	0805.000.018-2	PSICOLINGUÍSTICA	51
44225	0805.000.130-5	TECNOLOGIA DA INFORMAÇÃO E COMUNICAÇÃO (TIC) II	68
33925	0801.000.155-2	FUNDAMENTOS DE DIDÁTICA	51
36778	0805.000.022-0	LINGUÍSTICA TEXTUAL	68
36775	0805.000.019-0	MORFOLOGIA DO PORTUGUÊS	68
44226	0805.000.131-4	PRÁTICA DE ENSINO II	68
36777	0805.000.021-2	TEORIA DO POEMA, DA PROSA E DO DRAMA	51
36776	0805.000.020-4	TEORIAS DA LITERATURA	51
24495	0802.000.133-4	DIDÁTICA APLICADA AO ENSINO DE LÍNGUA PORTUGUESA	51
26376	0801.000.114-5	EDUCAÇÃO ESPECIAL	51
44229	0805.000.134-1	ESTUDO DE LIBRAS	51
36780	0805.000.024-7	LITERATURA PORTUGUESA I	51
44227	0805.000.132-3	PRÁTICA DE ENSINO III	68
36779	0805.000.023-9	SINTAXE DO PORTUGUÊS	68
44231	0805.000.136-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
44221	0805.000.126-1	ENSINO DE LÍNGUA PORTUGUESA PARA SURDOS	51
44217	0805.000.122-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA I	110
36784	0805.000.028-0	LITERATURA PORTUGUESA II	51
44224	0805.000.129-9	PRÁTICA DE ENSINO IV	68
36783	0805.000.027-1	SEMÂNTICA	68
36789	0805.000.033-6	ENSINO E LETRAMENTO LITERÁRIO	51
44218	0805.000.123-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA II	110
36788	0805.000.032-8	LÍNGUA E CULTURA ESTRANGEIRAS	51
44232	0805.000.137-9	LITERATURA BRASILEIRA I	68
36791	0805.000.035-2	PRÁTICA DE ENSINO V	68
44214	0805.000.119-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA III	110
44215	0805.000.120-7	LITERATURA BRASILEIRA II	68
36795	0805.000.039-5	PRÁTICA DE ENSINO VI	68
44228	0805.000.133-2	TEORIAS DA TRADUÇÃO	68
44222	0805.000.127-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA IV	110
44223	0805.000.128-0	LITERATURA BRASILEIRA III	68
24559	0802.000.189-0	LITERATURA E HISTÓRIA	68
36799	0805.000.043-3	PRÁTICA DE ENSINO VII	68
24567	0802.000.196-2	ANÁLISE DO DISCURSO	68
36761	0805.000.005-0	DISCURSO E ENUNCIAÇÃO	68
36793	0805.000.037-9	EDUCAÇÃO AMBIENTAL	51
24556	0802.000.186-5	EDUCAÇÃO E SOCIOLOGIA	68
36762	0805.000.006-9	FILOSOFIA DA LINGUAGEM	68
24557	0802.000.187-3	HISTÓRIA DA ARTE	68
36763	0805.000.007-7	HISTÓRIA DAS IDÉIAS LINGUÍSTICAS	68
24565	0802.000.194-6	INTRODUÇÃO À FILOSOFIA	68
36764	0805.000.008-5	LÍNGUA DE SINAIS BRASILEIRA I	68
36765	0805.000.009-3	LÍNGUA DE SINAIS BRASILEIRA II	68
44216	0805.000.121-6	LITERATURA AFRICANA DE LÍNGUA PORTUGUESA	68
24566	0802.000.195-4	LITERATURA COMPARADA	68
24563	0802.000.192-0	LITERATURA CONTEMPORÂNEA	68
24560	0802.000.190-3	LITERATURA REGIONAL	68
44220	0805.000.125-2	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
36767	0805.000.011-5	POLÍTICAS PÚBLICAS DA EXTENSÃO UNIVERSITÁRIA	68
44219	0805.000.124-3	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
24562	0802.000.191-1	SOCIOLINGUÍSTICA	68
24564	0802.000.193-8	SOCIOLOGIA GERAL	68
36768	0805.000.012-3	TEORIA GRAMATICAL	68
36769	0805.000.013-1	TÓPICOS DE LITERATURA DRAMÁTICA	68
36770	0805.000.014-0	TÓPICOS EM EDUCAÇÃO: DIFICULDADES DE ENSINO E APRENDIZAGEM	68
48923	0805.000.348-0	DIREITO PENAL - PARTE GERAL I	68
48935	0805.000.360-4	DIREITOS HUMANOS	68
48940	0805.000.365-0	HISTÓRIA DO DIREITO	68
48931	0805.000.356-0	TEORIA DO DIREITO	68
48968	0805.000.393-6	TEORIA GERAL DO DIREITO PRIVADO I	68
48909	0805.000.334-6	ANTROPOLOGIA E SOCIOLOGIA JURÍDICA	68
48973	0805.000.398-1	CIÊNCIA POLÍTICA E TEORIA GERAL DO ESTADO	68
48927	0805.000.352-4	DIREITO PENAL - PARTE GERAL II	68
48947	0805.000.372-0	FORMAS CONSENSUAIS DE SOLUÇÃO DE CONFLITOS	34
48891	0805.000.316-8	PSICOLOGIA APLICADA AO DIREITO	34
48913	0805.000.338-2	TEORIA GERAL DO DIREITO PRIVADO II	68
48896	0805.000.321-0	DIREITO CONSTITUCIONAL I	68
48894	0805.000.319-5	DIREITO DAS OBRIGAÇÕES	68
48972	0805.000.397-2	DIREITO DO TRABALHO I	68
48952	0805.000.377-6	DIREITO PENAL ESPECIAL I	68
48887	0805.000.312-1	TEORIA GERAL DO PROCESSO	68
48969	0805.000.394-5	DIREITO CONSTITUCIONAL II	68
48963	0805.000.388-3	DIREITO CONTRATUAL	68
48903	0805.000.328-4	DIREITO DO TRABALHO II	68
48953	0805.000.378-5	DIREITO PENAL ESPECIAL II	68
48924	0805.000.349-0	TUTELA DE CONHECIMENTO	68
48961	0805.000.386-5	DIREITO ADMINISTRATIVO I	68
48956	0805.000.381-0	DIREITO DAS COISAS	68
48900	0805.000.325-7	DIREITO PROCESSUAL CONSTITUCIONAL	34
48966	0805.000.391-8	DIREITO PROCESSUAL DO TRABALHO	68
48941	0805.000.366-9	ECONOMIA POLÍTICA	34
48932	0805.000.357-0	TUTELA RECURSAL	68
48898	0805.000.323-9	DIREITO ADMINISTRATIVO II	68
48922	0805.000.347-1	DIREITO INTERNACIONAL PÚBLICO	34
48967	0805.000.392-7	DIREITO PROCESSUAL PENAL I	68
48890	0805.000.315-9	INTRODUÇÃO À METODOLOGIA DA PESQUISA	34
48893	0805.000.318-6	RESPONSABILIDADE CIVIL	68
48930	0805.000.355-1	TUTELA EXECUTIVA	68
48895	0805.000.320-1	DIREITO DE FAMÍLIA	68
48916	0805.000.341-7	DIREITO FINANCEIRO	34
48933	0805.000.358-9	DIREITO PROCESSUAL PENAL II	68
48942	0805.000.367-8	DIREITO TRIBUTÁRIO I	34
48960	0805.000.385-6	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA EXTENSIONISTA I	68
48928	0805.000.353-3	TUTELA DE URGÊNCIA E DIREITO PROCESSUAL COLETIVO	68
48955	0805.000.380-0	DIREITO DIGITAL E TECNOLÓGICO	34
48917	0805.000.342-6	DIREITO EMPRESARIAL I	68
48937	0805.000.362-2	DIREITO PROCESSUAL PENAL III	34
48946	0805.000.371-1	DIREITO TRIBUTÁRIO II	68
48934	0805.000.359-8	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA EXTENSIONISTA II	68
48901	0805.000.326-6	SUCESSÕES	68
48902	0805.000.327-5	DIREITO EMPRESARIAL II	68
48921	0805.000.346-2	DIREITO PREVIDENCIÁRIO E SEGURIDADE SOCIAL	68
48938	0805.000.363-1	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA EXTENSIONISTA III	68
48888	0805.000.313-0	ÉTICA PROFISSIONAL	34
48939	0805.000.364-0	FILOSOFIA GERAL E JURÍDICA	68
48964	0805.000.389-2	TUTELA JURÍDICA DOS GRUPOS MINORITÁRIOS E VULNERÁVEIS	34
48911	0805.000.336-4	DIREITO AGRÁRIO E DO AGRONEGÓCIO	68
48970	0805.000.395-4	DIREITO AMBIENTAL	68
48899	0805.000.324-8	DIREITO DO CONSUMIDOR	34
48925	0805.000.350-6	DIREITO INTERNACIONAL PRIVADO	34
48943	0805.000.368-7	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA EXTENSIONISTA IV	68
48907	0805.000.332-8	ANÁLISE ECONÔMICA DO DIREITO	34
48897	0805.000.322-0	ARBITRAGEM E NEGOCIAÇÃO	34
48957	0805.000.382-9	BIODIREITO E BIOÉTICA	34
48908	0805.000.333-7	CRIMINOLOGIA	34
46006	0805.000.198-7	DIÁLOGOS SOBRE DIREITO FUNDAMENTAL À SAÚDE	34
48904	0805.000.329-3	DIREITO APLICADO AO TURISMO	34
48959	0805.000.384-7	DIREITO, CIDADANIA E RELAÇÕES ÉTNICO-RACIAIS	34
46028	0805.000.220-4	DIREITO COMUNITÁRIO	34
46018	0805.000.210-6	DIREITO DA CRIANÇA E DO ADOLESCENTE	34
46031	0805.000.223-1	DIREITO DAS ORGANIZAÇÕES INTERNACIONAIS	34
48958	0805.000.383-8	DIREITO DESPORTIVO	34
48914	0805.000.339-1	DIREITO ELEITORAL	34
48918	0805.000.343-5	DIREITO MUNICIPAL	34
48919	0805.000.344-4	DIREITO PROCESSUAL ADMINISTRATIVO	34
48936	0805.000.361-3	DIREITOS HUMANOS, FRONTEIRAS E MIGRAÇÃO	34
46039	0805.000.231-1	ESTUDO DE LIBRAS	51
48971	0805.000.396-3	EXECUÇÃO PENAL	34
48944	0805.000.369-6	HERMENÊUTICA E ARGUMENTAÇÃO JURÍDICA	34
48892	0805.000.317-7	JURIMETRIA	34
48889	0805.000.314-0	LINGUAGEM JURÍDICA	34
48885	0805.000.310-3	MEDICINA LEGAL	34
48886	0805.000.311-2	POLÍTICAS PÚBLICAS	34
46041	0805.000.233-0	PRECEDENTES E JURISPRUDÊNCIA	34
46025	0805.000.217-0	TÓPICOS DE DIREITOS SOCIAIS	34
46026	0805.000.218-9	TÓPICOS DE JURISPRUDÊNCIA DO STF	68
46047	0805.000.239-4	TÓPICOS DE JURISPRUDÊNCIA DO STJ	68
46048	0805.000.240-0	TÓPICOS ESPECIAIS DE DIREITO	34
48951	0805.000.376-7	TÓPICOS ESPECIAIS DE DIREITO ADMINISTRATIVO	34
48949	0805.000.374-9	TÓPICOS ESPECIAIS DE DIREITO AMBIENTAL	34
48950	0805.000.375-8	TÓPICOS ESPECIAIS DE DIREITO CONSTITUCIONAL	34
48948	0805.000.373-0	TÓPICOS ESPECIAIS DE DIREITO CONTRATUAL	34
46022	0805.000.214-2	TÓPICOS ESPECIAIS DE DIREITO DE FAMÍLIA	34
48945	0805.000.370-2	TÓPICOS ESPECIAIS DE DIREITO DE FAMÍLIA E SUCESSÕES	34
48912	0805.000.337-3	TÓPICOS ESPECIAIS DE DIREITO DO TRABALHO	34
48920	0805.000.345-3	TÓPICOS ESPECIAIS DE DIREITO INTERNACIONAL	34
46023	0805.000.215-1	TÓPICOS ESPECIAIS DE DIREITO PENAL	34
46045	0805.000.237-6	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL	51
48929	0805.000.354-2	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL CIVIL	34
48926	0805.000.351-5	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL PENAL	34
48915	0805.000.340-8	TÓPICOS ESPECIAIS DE DIREITO PROCESSUAL TRABALHISTA	34
48905	0805.000.330-0	TÓPICOS ESPECIAIS DE DIREITOS FUNDAMENTAIS	34
46044	0805.000.236-7	TÓPICOS ESPECIAIS DE DIREITOS REAIS	34
48906	0805.000.331-9	TÓPICOS ESPECIAIS DE DIREITO, TECNOLOGIA E INOVAÇÃO	34
48910	0805.000.335-5	TÓPICOS ESPECIAIS DE DIREITO TRIBUTÁRIO	34
48962	0805.000.387-4	TÓPICOS ESPECIAIS DE JURISPRUDÊNCIA DO TST	34
48965	0805.000.390-9	TÓPICOS ESPECIAIS DE PRÁTICA JURÍDICA EM DIREITO PRIVADO	34
48954	0805.000.379-4	TÓPICOS ESPECIAIS DE PRÁTICA JURÍDICA EM DIREITO PÚBLICO	34
49031	0904.000.581-2	COMUNICAÇÃO EMPRESARIAL	68
49060	0904.000.610-3	FUNDAMENTOS DA ADMINISTRAÇÃO	68
49028	0904.000.578-8	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
49057	0904.000.607-9	INTRODUÇÃO À CONTABILIDADE	68
49038	0904.000.588-6	MATEMÁTICA	68
49035	0904.000.585-9	ANÁLISE DAS DEMONSTRAÇÕES FINANCEIRAS	68
49051	0904.000.601-4	DIREITO APLICADO À ADMINISTRAÇÃO	68
49045	0904.000.595-7	FUNDAMENTOS DA ESTATÍSTICA	68
49013	0904.000.563-4	MÉTODOS E TÉCNICAS DE PESQUISA EM ADMINISTRAÇÃO	68
49063	0904.000.613-0	TEORIA GERAL DA ADMINISTRAÇÃO	68
49065	0904.000.615-9	ECONOMIA E NEGÓCIOS	68
49046	0904.000.596-6	GESTÃO DE CUSTOS	68
49058	0904.000.608-8	MÉTODOS QUANTITATIVOS APLICADOS A ADMINISTRAÇÃO	68
49012	0904.000.562-5	RESPONSABILIDADE SOCIOAMBIENTAL	68
49022	0904.000.572-3	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
49042	0904.000.592-0	ADMINISTRAÇÃO DE SERVIÇOS	68
49037	0904.000.587-7	ECONOMIA, GESTÃO E SOCIEDADE	68
49073	0904.000.623-9	GESTÃO DE PESSOAS	68
49016	0904.000.566-1	GESTÃO DE PROJETOS	68
44319	0904.000.283-9	MATEMÁTICA COMERCIAL E FINANCEIRA	68
49021	0904.000.571-4	DESENVOLVIMENTO PESSOAL E PROFISSIONAL	68
49067	0904.000.617-7	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
49032	0904.000.582-1	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
49033	0904.000.583-0	GESTÃO DE MARKETING	68
49055	0904.000.605-0	GESTÃO FINANCEIRA	68
49056	0904.000.606-0	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
49040	0904.000.590-1	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
49014	0904.000.564-3	ESTRATÉGIAS ORGANIZACIONAIS	68
49015	0904.000.565-2	GESTÃO DE OPERAÇÕES	68
49064	0904.000.614-0	GESTÃO DO COMPOSTO DE MARKETING	68
44334	0904.000.298-2	GESTÃO DA INOVAÇÃO	68
49029	0904.000.579-7	GESTÃO ESTRATÉGICA	68
49020	0904.000.570-5	GESTÃO LOGÍSTICA	68
49041	0904.000.591-0	LABORATÓRIO DE GESTÃO SIMULADA	68
49024	0904.000.574-1	ATIVIDADE PRÁTICA SUPERVISIONADA	68
49030	0904.000.580-3	EMPREENDEDORISMO	68
44286	0904.000.250-7	GESTÃO DE AGRONEGÓCIOS	68
49048	0904.000.598-4	MERCADO DE CAPITAIS	68
49017	0904.000.567-0	ADMINISTRAÇÃO DE RECURSOS MATERIAIS E PATRIMONIAIS	68
49070	0904.000.620-1	ADMINISTRAÇÃO PÚBLICA	68
49069	0904.000.619-5	CONHECIMENTOS BANCÁRIOS E INVESTIMENTOS	68
49066	0904.000.616-8	CONSULTORIA EMPRESARIAL	68
46712	0904.000.356-9	CONTABILIDADE GERENCIAL	68
46683	0904.000.327-3	CONTROLADORIA E ORÇAMENTO EMPRESARIAL	68
49023	0904.000.573-2	DATA SCIENCE AND ANALYTICS	68
44310	0904.000.274-0	DESENVOLVIMENTO SUSTENTÁVEL	68
46670	0904.000.314-8	DIREITO EMPRESARIAL E TRIBUTÁRIO	68
46716	0904.000.360-2	DIREITO TRABALHISTA E PREVIDENCIÁRIO	68
46697	0904.000.341-5	ECONOMIA BRASILEIRA	68
49039	0904.000.589-5	EDUCAÇÃO FINANCEIRA	68
42994	0904.000.196-6	EDUCAÇÃO PARA AS RELAÇÕES ÉTNICO RACIAIS	68
44340	0904.000.304-0	EMPREENDEDORISMO E INOVAÇÃO	68
49071	0904.000.621-0	FELICIDADE	68
49059	0904.000.609-7	FINANÇAS COMPORTAMENTAIS	68
49061	0904.000.611-2	FINANÇAS PÚBLICAS E GESTÃO GOVERNAMENTAL	68
49072	0904.000.622-0	GESTÃO AMBIENTAL	68
49034	0904.000.584-0	GESTÃO DA QUALIDADE	68
49062	0904.000.612-1	GESTÃO DE VENDAS	68
49026	0904.000.576-0	GESTÃO DO CONHECIMENTO	68
49036	0904.000.586-8	GESTÃO TRIBUTÁRIA	68
49068	0904.000.618-6	GOVERNANÇA E COMPLIANCE	68
49043	0904.000.593-9	LEITURA E PRODUÇÃO DE TEXTOS	68
44305	0904.000.269-7	LIBRAS	68
49074	0904.000.624-8	MARKETING DIGITAL	68
49047	0904.000.597-5	NOVA ECONOMIA	68
44337	0904.000.301-2	PESQUISA DE MARKETING	68
49025	0904.000.575-0	PESQUISA OPERACIONAL	68
49018	0904.000.568-0	PLANEJAMENTO E GESTÃO EM ORGANIZAÇÕES PÚBLICAS	68
49019	0904.000.569-9	TEORIA DOS JOGOS	68
49027	0904.000.577-9	TÓPICOS AVANÇADOS EM ADMINISTRAÇÃO I	68
44324	0904.000.288-4	TÓPICOS AVANÇADOS EM ADMINISTRAÇÃO II	68
44339	0904.000.303-0	TÓPICOS DE SEMINÁRIO EM ADMINISTRAÇÃO I	68
44342	0904.000.306-8	TÓPICOS DE SEMINÁRIO EM ADMINISTRAÇÃO II	68
44317	0904.000.281-0	TÓPICOS DE SEMINÁRIO EM ADMINISTRAÇÃO III	68
49050	0904.000.600-5	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA I	68
49049	0904.000.599-3	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA II	68
49054	0904.000.604-1	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA III	68
49052	0904.000.602-3	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA IV	68
49053	0904.000.603-2	TÓPICOS EM EXTENSÃO UNIVERSITÁRIA V	34
49044	0904.000.594-8	VAREJO FÍSICO E ON-LINE	68
48103	0904.000.517-0	BASES BIOLÓGICAS DO COMPORTAMENTO	68
48104	0904.000.518-9	ESTATÍSTICA APLICADA À PSICOLOGIA	68
48101	0904.000.515-1	FILOSOFIA GERAL	68
48141	0904.000.555-4	INTRODUÇÃO À PSICOLOGIA	68
48122	0904.000.536-7	LEITURA E PRODUÇÃO DE TEXTOS	68
48105	0904.000.519-8	MÉTODOS DE PESQUISA EM PSICOLOGIA I	68
48096	0904.000.510-6	SOCIOLOGIA GERAL	68
48118	0904.000.532-0	ANTROPOLOGIA	68
48113	0904.000.527-8	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
48106	0904.000.520-4	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE HISTÓRICO-CULTURAL	68
48107	0904.000.521-3	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE PSICANALÍTICO	68
48121	0904.000.535-8	GENÉTICA HUMANA APLICADA À PSICOLOGIA	68
48095	0904.000.509-0	MÉTODOS DE PESQUISA EM PSICOLOGIA II	68
48085	0904.000.499-6	PSICOLOGIA E ÉTICA PROFISSIONAL	68
34593	0904.000.059-5	AVALIAÇÃO PSICOLÓGICA I	68
48142	0904.000.556-3	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL I	68
48087	0904.000.501-7	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL I	68
48088	0904.000.502-6	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO I	68
48119	0904.000.533-0	PSICOLOGIA DO DESENVOLVIMENTO I	68
48112	0904.000.526-9	PSICOLOGIA E DIVERSIDADE HUMANA I	68
48086	0904.000.500-8	PSICOLOGIA SOCIAL	68
48108	0904.000.522-2	AVALIAÇÃO PSICOLÓGICA II	68
48123	0904.000.537-6	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL II	68
48111	0904.000.525-0	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL II	68
48109	0904.000.523-1	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO II	68
48120	0904.000.534-9	PSICOLOGIA DO DESENVOLVIMENTO II	68
48110	0904.000.524-0	PSICOLOGIA E DIVERSIDADE HUMANA II	68
48146	0904.000.560-7	PSICOLOGIA SOCIAL II	68
48098	0904.000.512-4	ESTÁGIO OBRIGATÓRIO BÁSICO EM PSICOLOGIA IA	68
48116	0904.000.530-2	PSICOLOGIA DO TRABALHO	68
48125	0904.000.539-4	PSICOLOGIA E SAÚDE I	68
48117	0904.000.531-1	PSICOLOGIA ESCOLAR E EDUCACIONAL I	68
48124	0904.000.538-5	PSICOPATOLOGIA GERAL I	68
48147	0904.000.561-6	TEORIAS E TÉCNICAS PSICOTERÁPICAS - ENFOQUE PSICANALÍTICO	68
48102	0904.000.516-0	ESTÁGIO OBRIGATÓRIO BÁSICO EM PSICOLOGIA IIA	68
48127	0904.000.541-0	PSICOLOGIA DO TRABALHO E DAS ORGANIZAÇÕES	68
48100	0904.000.514-2	PSICOLOGIA E SAÚDE II	68
48114	0904.000.528-7	PSICOLOGIA ESCOLAR E EDUCACIONAL II	68
48126	0904.000.540-0	PSICOPATOLOGIA GERAL II	68
48131	0904.000.545-6	TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
48128	0904.000.542-9	ESTÁGIO OBRIGATÓRIO BÁSICO EM PSICOLOGIA IB	68
48099	0904.000.513-3	ESTÁGIO OBRIGATÓRIO IA: ÊNFASE EM PSICOLOGIA E PROCESSOS DE SAÚDE	136
48129	0904.000.543-8	ESTÁGIO OBRIGATÓRIO IA: ÊNFASE EM PSICOLOGIA E PROCESSOS EDUCATIVOS, DE PROTEÇÃO SOCIAL E DE DESENVOLVIMENTO	136
48115	0904.000.529-6	ORIENTAÇÃO PROFISSIONAL	68
48133	0904.000.547-4	PSICOLOGIA E PROCESSOS GRUPAIS	68
48093	0904.000.507-1	ESTÁGIO OBRIGATÓRIO BÁSICO EM PSICOLOGIA IIB	68
48134	0904.000.548-3	ESTÁGIO OBRIGATÓRIO IIA: ÊNFASE EM PSICOLOGIA E PROCESSOS DE SAÚDE	136
48144	0904.000.558-1	ESTÁGIO OBRIGATÓRIO IIA: ÊNFASE EM PSICOLOGIA E PROCESSOS EDUCATIVOS, DE PROTEÇÃO SOCIAL E DE DESENVOLVIMENTO	136
48132	0904.000.546-5	ESTÁGIO OBRIGATÓRIO IB: ÊNFASE EM PSICOLOGIA E PROCESSOS DE SAÚDE	136
48130	0904.000.544-7	ESTÁGIO OBRIGATÓRIO IB: ÊNFASE EM PSICOLOGIA E PROCESSOS EDUCATIVOS, DE PROTEÇÃO SOCIAL E DE DESENVOLVIMENTO	136
48143	0904.000.557-2	ESTÁGIO OBRIGATÓRIO IIB: ÊNFASE EM PSICOLOGIA E PROCESSOS DE SAÚDE	136
48145	0904.000.559-0	ESTÁGIO OBRIGATÓRIO IIB: ÊNFASE EM PSICOLOGIA E PROCESSOS EDUCATIVOS, DE PROTEÇÃO SOCIAL E DE DESENVOLVIMENTO	136
48089	0904.000.503-5	ANÁLISE DO COMPORTAMENTO APLICADA	68
42995	0904.000.197-4	DIREITOS HUMANOS E PSICOLOGIA	68
34638	0904.000.104-4	ESTUDO DE LIBRAS	68
34640	0904.000.106-0	INTERVENÇÃO PSICOPEDAGÓGICA	68
34641	0904.000.107-9	LUDOTERAPIA	68
34644	0904.000.110-9	PSICOFARMACOLOGIA	68
48136	0904.000.550-9	PSICOLOGIA AMBIENTAL	68
34650	0904.000.116-8	PSICOLOGIA E O SISTEMA ÚNICO DE ASSISTÊNCIA SOCIAL	68
34655	0904.000.121-4	SEMINÁRIO EM FENÔMENOS E PROCESSOS PSICOLÓGICOS	68
34656	0904.000.122-2	SEMINÁRIO EM FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS	68
48139	0904.000.553-6	SEMINÁRIOS EM AVALIAÇÃO PSICOLÓGICA	68
48092	0904.000.506-2	SEMINÁRIOS EM BASES BIOLÓGICAS DO COMPORTAMENTO	68
48140	0904.000.554-5	SEMINÁRIOS EM DESENVOLVIMENTO HUMANO	68
48091	0904.000.505-3	SEMINÁRIOS EM PROCESSOS PSICOLÓGICOS BÁSICOS	68
48097	0904.000.511-5	SEMINÁRIOS EM PSICOLOGIA CLÍNICA	68
48138	0904.000.552-7	SEMINÁRIOS EM PSICOLOGIA DO TRABALHO E DAS ORGANIZAÇÕES	68
48135	0904.000.549-2	SEMINÁRIOS EM PSICOLOGIA E SAÚDE	68
48094	0904.000.508-0	SEMINÁRIOS EM PSICOLOGIA ESCOLAR E EDUCACIONAL	68
48137	0904.000.551-8	SEMINÁRIOS EM PSICOLOGIA SOCIAL	68
48090	0904.000.504-4	TÓPICOS AVANÇADOS EM TÉCNICAS PSICOTERÁPICAS ANALÍTICO COMPORTAMENTAIS	68
49598	0904.000.640-8	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
49625	0904.000.667-8	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
43232	0904.000.218-7	POLÍTICAS EDUCACIONAIS	51
49623	0904.000.665-0	PRÁTICA DE ENSINO DE MATEMÁTICA I	68
49624	0904.000.666-9	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
49592	0904.000.634-6	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
49621	0904.000.663-1	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
38323	0904.000.148-6	FUNDAMENTOS DE DIDÁTICA	51
49620	0904.000.662-2	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
49599	0904.000.641-7	PRÁTICA DE ENSINO DE MATEMÁTICA II	68
49593	0904.000.635-5	CÁLCULO I	68
49608	0904.000.650-6	GEOMETRIA ANALÍTICA I	68
49588	0904.000.630-0	LEITURA E PRODUÇÃO DE TEXTOS	68
49615	0904.000.657-0	LÓGICA MATEMÁTICA	68
43253	0904.000.239-2	PSICOLOGIA E EDUCAÇÃO	51
49626	0904.000.668-7	CÁLCULO II	68
43240	0904.000.226-7	EDUCAÇÃO ESPECIAL	51
43243	0904.000.229-4	GEOMETRIA ANALÍTICA II	68
43244	0904.000.230-0	PROBABILIDADE E ESTATÍSTICA I	68
49627	0904.000.669-6	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
49590	0904.000.632-8	ÁLGEBRA I	68
49607	0904.000.649-0	ÁLGEBRA LINEAR I	68
49619	0904.000.661-3	CÁLCULO III	68
49609	0904.000.651-5	ESTÁGIO OBRIGATÓRIO I	100
49610	0904.000.652-4	PRÁTICA DE ENSINO EM MATEMÁTICA III	68
49606	0904.000.648-0	PROBABILIDADE E ESTATÍSTICA II	68
49583	0904.000.625-7	ÁLGEBRA II	68
49613	0904.000.655-1	ÁLGEBRA LINEAR II	68
49614	0904.000.656-0	CÁLCULO IV	68
49618	0904.000.660-4	ESTÁGIO OBRIGATÓRIO II	100
38348	0904.000.172-9	LABORATÓRIO DE ENSINO DE MATEMÁTICA	68
49612	0904.000.654-2	PRÁTICA DE ENSINO EM MATEMÁTICA IV	68
49591	0904.000.633-7	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
49630	0904.000.672-0	ESTÁGIO OBRIGATÓRIO III	100
49611	0904.000.653-3	INTRODUÇÃO À ANÁLISE REAL	68
49587	0904.000.629-3	METODOLOGIA DE PESQUISA EDUCACIONAL	68
49617	0904.000.659-8	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
49589	0904.000.631-9	PRÁTICA DE ENSINO EM MATEMÁTICA V	68
43254	0904.000.240-9	TENDÊNCIAS EM EDUCAÇÃO MATEMÁTICA	68
49604	0904.000.646-2	ESTÁGIO OBRIGATÓRIO IV	100
43225	0904.000.211-3	ESTUDO DE LIBRAS	51
49594	0904.000.636-4	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
49600	0904.000.642-6	GEOMETRIA EUCLIDIANA	68
49622	0904.000.664-0	HISTÓRIA DA MATEMÁTICA	68
49595	0904.000.637-3	PRÁTICA DE ENSINO EM MATEMÁTICA VI	68
43261	0904.000.247-2	ÁLGEBRA III	68
43262	0904.000.248-1	CÁLCULO AVANÇADO	68
49597	0904.000.639-1	CÁLCULO NUMÉRICO	68
43239	0904.000.225-8	EDUCAÇÃO DAS RELAÇÕES ETNICO-RACIAIS	51
43213	0904.000.199-4	EDUCAÇÃO E DIREITOS HUMANOS	68
43223	0904.000.209-8	EDUCAÇÃO ETNOMATEMÁTICA	68
43263	0904.000.249-0	EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	68
43224	0904.000.210-4	ESPAÇOS MÉTRICOS	68
43228	0904.000.214-0	FILOSOFIA DA EDUCAÇÃO MATEMÁTICA	68
49628	0904.000.670-2	FÍSICA	68
38329	0904.000.154-0	FUNDAMENTOS DE ÁLGEBRA	68
38324	0904.000.149-4	FUNDAMENTOS DE ÁLGEBRA E ARITMÉTICA	68
38325	0904.000.150-8	FUNDAMENTOS DE MATEMÁTICA ELEMENTAR I	68
38330	0904.000.155-9	FUNDAMENTOS DE MATEMÁTICA ELEMENTAR II	68
43216	0904.000.202-4	GEOMETRIA DIFERENCIAL	68
43217	0904.000.203-3	GESTÃO AMBIENTAL E DESENVOLVIMENTO SUSTENTÁVEL	68
43256	0904.000.242-7	HISTÓRIA DA MATEMÁTICA NO BRASIL	68
49585	0904.000.627-5	INFORMÁTICA APLICADA A EDUCAÇÃO	68
43258	0904.000.244-5	INTRODUÇÃO A CIÊNCIA DA COMPUTAÇÃO	68
43259	0904.000.245-4	MATEMÁTICA FINANCEIRA	68
43218	0904.000.204-2	PRODUÇÃO CIENTÍFICA EM MATEMÁTICA	68
49586	0904.000.628-4	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
49596	0904.000.638-2	PROGRAMAÇÃO LINEAR	68
43219	0904.000.205-1	RELAÇÕES INTERPESSOAIS NA ESCOLA	68
43220	0904.000.206-0	SABERES CIENTÍFICOS E TECNOLÓGICOS PARA FORMAÇÃO DO PROFESSOR DE MATEMÁTICA	68
43230	0904.000.216-9	TEMAS E PROBLEMAS DE MATEMÁTICA ELEMENTAR	68
43221	0904.000.207-0	TEORIA DOS NÚMEROS	68
49584	0904.000.626-6	TÓPICOS DE GEOMETRIA	68
49601	0904.000.643-5	TÓPICOS DE MATEMÁTICA DISCRETA	68
49603	0904.000.645-3	TÓPICOS EM MATEMÁTICA APLICADA	68
49602	0904.000.644-4	TÓPICOS ESPECIAIS EM ÁLGEBRA	68
49605	0904.000.647-1	TÓPICOS ESPECIAIS EM EDUCAÇÃO MATEMÁTICA	68
49616	0904.000.658-9	TÓPICOS ESPECIAIS EM FUNDAMENTOS DE MATEMÁTICA	68
49629	0904.000.671-1	VARIÁVEIS COMPLEXAS	68
47878	0904.000.369-4	ANATOMIA DOS ANIMAIS DOMÉSTICOS I	102
47901	0904.000.392-5	BIOQUÍMICA VETERINÁRIA I	51
47993	0904.000.484-2	EMBRIOLOGIA VETERINÁRIA	51
47933	0904.000.424-3	GENÉTICA VETERINÁRIA	51
47902	0904.000.393-4	HISTOLOGIA BÁSICA	51
47962	0904.000.453-9	INTRODUÇÃO À MEDICINA VETERINÁRIA	34
47894	0904.000.385-4	ANATOMIA DOS ANIMAIS DOMÉSTICOS II	102
47904	0904.000.395-2	BIOESTATÍSTICA E EXPERIMENTAÇÃO	51
47903	0904.000.394-3	BIOQUÍMICA VETERINÁRIA II	34
47916	0904.000.407-4	FISIOLOGIA VETERINÁRIA I	68
47905	0904.000.396-1	HISTOLOGIA DOS ANIMAIS DOMÉSTICOS	51
47889	0904.000.380-9	SOCIEDADE, MEIO AMBIENTE E SUSTENTABILIDADE	34
47997	0904.000.488-9	DEONTOLOGIA VETERINÁRIA E MEDICINA VETERINÁRIA LEGAL	34
47928	0904.000.419-0	EXTENSÃO E COMUNICAÇÃO NAS CIÊNCIAS VETERINÁRIAS	34
47880	0904.000.371-0	FARMACOLOGIA VETERINÁRIA	68
47925	0904.000.416-3	FISIOLOGIA VETERINÁRIA II	68
47996	0904.000.487-0	IMUNOLOGIA VETERINÁRIA	68
47877	0904.000.368-5	MICROBIOLOGIA VETERINÁRIA I	51
47922	0904.000.413-6	PARASITOLOGIA VETERINÁRIA I	51
47935	0904.000.426-1	AGROSTOLOGIA E CONSERVAÇÃO DE SOLOS	51
47888	0904.000.379-2	ALIMENTAÇÃO E NUTRIÇÃO ANIMAL	51
47890	0904.000.381-8	ETOLOGIA E BEM-ESTAR ANIMAL	34
47967	0904.000.458-4	MELHORAMENTO GENÉTICO ANIMAL	51
47891	0904.000.382-7	MICROBIOLOGIA VETERINÁRIA II	51
47936	0904.000.427-0	PARASITOLOGIA VETERINÁRIA II	51
47947	0904.000.438-8	PATOLOGIA GERAL	51
47893	0904.000.384-5	PRINCÍPIOS DE ADMINISTRAÇÃO	51
47887	0904.000.378-3	PRINCÍPIOS DE ECONOMIA	51
47961	0904.000.452-0	DOENÇAS INFECCIOSAS I	51
47875	0904.000.366-7	EPIDEMIOLOGIA	51
47919	0904.000.410-9	PATOLOGIA CLÍNICA VETERINÁRIA	68
47930	0904.000.421-6	PATOLOGIA ESPECIAL VETERINÁRIA	102
47938	0904.000.429-9	PRODUÇÃO ANIMAL I	68
47874	0904.000.365-8	SEMIOLOGIA VETERINÁRIA	85
47920	0904.000.411-8	ANESTESIOLOGIA VETERINÁRIA	85
47956	0904.000.447-7	DIAGNÓSTICO POR IMAGEM	68
47906	0904.000.397-0	DOENÇAS PARASITÁRIAS	68
47942	0904.000.433-2	INSPEÇÃO E TECNOLOGIA DE CARNES E DERIVADOS	68
47907	0904.000.398-0	PRODUÇÃO ANIMAL II	102
47876	0904.000.367-6	SAÚDE PÚBLICA	51
47991	0904.000.482-4	TÉCNICA CIRÚRGICA VETERINÁRIA	85
47886	0904.000.377-4	CLÍNICA CIRÚRGICA VETERINÁRIA	102
47921	0904.000.412-7	CLÍNICA MÉDICA E TERAPÊUTICA DE PEQUENOS ANIMAIS I	85
47968	0904.000.459-3	DOENÇAS INFECCIOSAS II	51
47931	0904.000.422-5	GINECOLOGIA E BIOTECNOLOGIA DA FÊMEA	102
47950	0904.000.441-2	INSPEÇÃO E TECNOLOGIA DE LEITES E DERIVADOS	68
47895	0904.000.386-3	OBSTETRÍCIA VETERINÁRIA	85
47908	0904.000.399-9	ANDROLOGIA E BIOTECNOLOGIA DO MACHO	102
47910	0904.000.401-0	CLÍNICA MÉDICA E TERAPÊUTICA DE EQUIDEOS	102
47932	0904.000.423-4	CLÍNICA MÉDICA E TERAPÊUTICA DE PEQUENOS ANIMAIS II	85
47943	0904.000.434-1	CLÍNICA MÉDICA E TERAPÊUTICA DE RUMINANTES	102
47957	0904.000.448-6	INSPEÇÃO E TECNOLOGIA DE OVOS, MEL E PESCADOS	34
47884	0904.000.375-6	ZOONOSES	34
47911	0904.000.402-9	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CIRURGIA, ANESTESIOLOGIA E OBSTETRÍCIA	34
47998	0904.000.489-8	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CLÍNICA MÉDICA DE GRANDES ANIMAIS	34
47900	0904.000.391-6	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CLÍNICA MEDICA DE PEQUENOS ANIMAIS E ANIMAIS SILVESTRES	34
47945	0904.000.436-0	ESTÁGIO OBRIGATÓRIO INTENSIVO EM DIAGNÓSTICO LABORATORIAL DE PATÓGENOS	34
47958	0904.000.449-5	ESTÁGIO OBRIGATÓRIO INTENSIVO EM DIAGNÓSTICO POR IMAGEM	34
47964	0904.000.455-7	ESTÁGIO OBRIGATÓRIO INTENSIVO EM INSPEÇÃO E TECNOLOGIA DE ALIMENTOS	34
47969	0904.000.460-0	ESTÁGIO OBRIGATÓRIO INTENSIVO EM PATOLOGIA ESPECIAL VETERINÁRIA	34
47974	0904.000.465-5	ESTÁGIO OBRIGATÓRIO INTENSIVO EM PRODUÇÃO ANIMAL	34
47976	0904.000.467-3	ESTÁGIO OBRIGATÓRIO INTENSIVO EM REPRODUÇÃO ANIMAL	34
47951	0904.000.442-1	ESTÁGIO OBRIGATÓRIO INTENSIVO EM SAÚDE PÚBLICA	34
47927	0904.000.418-1	ESTÁGIO OBRIGATÓRIO	300
47941	0904.000.432-3	ANATOMIA DE AVES	51
47912	0904.000.403-8	ANATOMIA TOPOGRÁFICA DE PEQUENOS ANIMAIS	68
47882	0904.000.373-8	ANESTESIOLOGIA E MEDICINA DE EMERGÊNCIA	51
47934	0904.000.425-2	APICULTURA	51
47929	0904.000.420-7	APROVEITAMENTO E TRATAMENTO DE RESÍDUOS AGROINDUSTRIAIS	34
47994	0904.000.485-1	BIOLOGIA MOLECULAR	34
47995	0904.000.486-0	BIOSSEGURANÇA	34
47879	0904.000.370-0	BIOTECNOLOGIAS APLICADAS À REPRODUÇÃO ANIMAL	51
47915	0904.000.406-5	BIOTERISMO	34
47918	0904.000.409-2	BUBALINOCULTURA	51
47944	0904.000.435-0	CAPRINOCULTURA	51
48000	0904.000.491-3	CLÍNICA MÉDICA E CIRÚRGICA DE ANIMAIS SELVAGENS	51
47953	0904.000.444-0	CONSERVAÇÃO DA NATUREZA	51
47970	0904.000.461-9	DIAGNÓSTICO PARASITOLÓGICO EM MEDICINA VETERINÁRIA	34
47954	0904.000.445-9	DOENÇAS CARENCIAIS E METABÓLICAS DE GRANDES ANIMAIS	51
47965	0904.000.456-6	DOENÇAS DE RUMINANTES E EQUÍDEOS	68
47973	0904.000.464-6	DOENÇAS INFECCIOSAS VIRAIS EMERGENTES	34
47977	0904.000.468-2	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
47984	0904.000.475-3	EFICIÊNCIA REPRODUTIVA DE ANIMAIS DOMÉSTICOS	51
47981	0904.000.472-6	EQUIDEOCULTURA	51
47986	0904.000.477-1	EROSÃO E CONSERVAÇÃO DO SOLO	68
47982	0904.000.473-5	ESTUDO DE LIBRAS	51
47988	0904.000.479-0	FUNDAMENTOS DE AGROECOLOGIA	51
47909	0904.000.400-0	FUNDAMENTOS DE BIOTECNOLOGIA	34
47892	0904.000.383-6	GESTÃO AMBIENTAL	68
47917	0904.000.408-3	GESTÃO DA QUALIDADE	51
47926	0904.000.417-2	HIGIENE E SEGURANÇA DOS ALIMENTOS	34
48001	0904.000.492-2	HISTOLOGIA COMPARADA	68
47940	0904.000.431-4	IMUNODIAGNÓSTICO EM MEDICINA VETERINÁRIA	34
47952	0904.000.443-0	INDICADORES DE SAÚDE E SISTEMAS DE INFORMAÇÕES EM SAÚDE (SIS)	34
47955	0904.000.446-8	INTRODUÇÃO A HOMEOPATIA VETERINÁRIA	51
47960	0904.000.451-0	INTRODUÇÃO A MEDICINA VETERINÁRIA INTEGRATIVA	68
47971	0904.000.462-8	LABORATÓRIO DE DIAGNÓSTICO BACTERIOLÓGICO E MICOLÓGICO	34
47979	0904.000.470-8	LEGISLAÇÃO AMBIENTAL	34
48003	0904.000.494-0	MANEJO E CONSERVAÇÃO DE ANIMAIS SELVAGENS	34
47975	0904.000.466-4	MANEJO PROFILÁTICO E SANITÁRIO DE RUMINANTES	51
48004	0904.000.495-0	MEDICINA VETERINÁRIA DE SUÍNOS	68
47897	0904.000.388-1	MELIPONICULTURA	51
47959	0904.000.450-1	ONCOLOGIA VETERINÁRIA	34
47972	0904.000.463-7	ORTOPEDIA EM PEQUENOS ANIMAIS	34
47999	0904.000.490-4	OVINOCULTURA	51
47992	0904.000.483-3	PATOLOGIA DE CÃES E GATOS	34
47949	0904.000.440-3	PISCICULTURA	51
47899	0904.000.390-7	PLANEJAMENTO E SAÚDE AMBIENTAL	51
47883	0904.000.374-7	POLUIÇÃO AMBIENTAL	34
48002	0904.000.493-1	PRÁTICA DE CAMPO, MANEJO E LIDA	51
47913	0904.000.404-7	PRATICA HOSPITALAR EM CLÍNICA MÉDICA DE GRANDES ANIMAIS	68
47885	0904.000.376-5	PRÁTICA HOSPITALAR EM DIAGNÓSTICO POR IMAGEM	68
47924	0904.000.415-4	PRATICA HOSPITALAR EM GINECOLOGIA E OBSTETRICIA	68
47896	0904.000.387-2	PRÁTICA HOSPITALAR EM REPRODUÇÃO ANIMAL	68
47946	0904.000.437-9	PRÁTICAS DE CAMPO EM DOENÇAS PARASITÁRIAS DE ANIMAIS DE PRODUÇÃO	34
47939	0904.000.430-5	PROCESSAMENTO DE PRODUTOS DE ORIGEM ANIMAL	34
47937	0904.000.428-0	PROCESSOS AGROINDUSTRIAIS	34
47923	0904.000.414-5	PRODUÇÃO ANIMAL EM PASTAGENS	51
47914	0904.000.405-6	PROGRAMAS DE MELHORAMENTO ANIMAL	51
47948	0904.000.439-7	REPRODUÇÃO DE CARNÍVOROS	34
47898	0904.000.389-0	RESTAURAÇÃO AMBIENTAL	34
47963	0904.000.454-8	SANIDADE AVÍCOLA E SUINÍCOLA	34
47966	0904.000.457-5	SANIDADE DE AVES	51
47881	0904.000.372-9	SANIDADE EM PEIXES DE PRODUÇÃO	51
47978	0904.000.469-1	SOLICITAÇÃO E INTERPRETAÇÃO DE EXAMES LABORATORIAIS APLICADOS À PRÁTICA CLÍNICA	34
47985	0904.000.476-2	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA I	51
47987	0904.000.478-0	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA II	51
47989	0904.000.480-6	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA III	34
47990	0904.000.481-5	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA IV	34
48005	0904.000.496-9	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA V	34
48006	0904.000.497-8	TÓPICOS ESPECIAIS EM TERIOGENOLOGIA DE PEQUENOS ANIMAIS	34
47980	0904.000.471-7	TOXICOLOGIA E PLANTAS TÓXICAS	51
47983	0904.000.474-4	TRATAMENTO CIRÚRGICO DA SÍNDROME CÓLICA	34
48007	0904.000.498-7	VACINAS E VACINAÇÃO	34
51489	1005.000.086-8	ATENÇÃO PRIMÁRIA I	68
51469	2701.000.436-3	BASES BIOLÓGICAS DA PRÁTICA MÉDICA I	272
51542	1005.000.139-1	BASES COMPLEMENTARES DA MEDICINA I	51
51541	1005.000.138-2	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA I	68
52284	1005.000.140-8	URGÊNCIA E EMERGÊNCIA I	34
51516	1005.000.113-0	ATENÇÃO PRIMÁRIA II	68
51470	2701.000.437-2	BASES BIOLÓGICAS DA PRÁTICA MÉDICA II	272
51530	1005.000.127-5	BASES COMPLEMENTARES DA MEDICINA II	51
51529	1005.000.126-6	CIRURGIA I	51
51527	1005.000.124-8	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA II	68
51498	1005.000.095-7	ATENÇÃO PRIMÁRIA III	68
51532	1005.000.129-3	BASES BIOLÓGICAS DA PRÁTICA MÉDICA III	272
51537	1005.000.134-6	BASES COMPLEMENTARES DA MEDICINA III	51
51533	1005.000.130-0	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA III	68
51536	1005.000.133-7	URGÊNCIA E EMERGÊNCIA II	51
51534	1005.000.131-9	ATENÇÃO PRIMÁRIA IV	68
51538	1005.000.135-5	BASES BIOLÓGICAS DA PRÁTICA MÉDICA IV	289
51540	1005.000.137-3	BASES COMPLEMENTARES DA MEDICINA IV	51
51535	1005.000.132-8	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA IV	68
51512	1005.000.109-7	URGÊNCIA E EMERGÊNCIA III	51
51494	1005.000.091-0	ATENÇÃO PRIMÁRIA V	68
51490	1005.000.087-7	BASES BIOLÓGICAS DA PRÁTICA MÉDICA V	160
51515	1005.000.112-1	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VI	160
51511	1005.000.108-8	BASES COMPLEMENTARES DA MEDICINA V	34
51539	1005.000.136-4	CIRURGIA II	68
51514	1005.000.111-2	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA V	34
51513	1005.000.110-3	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA VI	34
51495	1005.000.092-0	ATENÇÃO PRIMÁRIA VI	68
51510	1005.000.107-9	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VII	160
51509	1005.000.106-0	BASES BIOLÓGICAS DA PRÁTICA MÉDICA VIII	160
51504	1005.000.101-4	BASES COMPLEMENTARES DA MEDICINA VI	34
51505	1005.000.102-3	CIRURGIA III	68
51508	1005.000.105-0	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA VII	34
51506	1005.000.103-2	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA VIII	34
51496	1005.000.093-9	ATENÇÃO PRIMÁRIA VII	68
51526	1005.000.123-9	BASES BIOLÓGICAS DA PRÁTICA MÉDICA IX	160
51473	1005.000.070-5	BASES BIOLÓGICAS DA PRÁTICA MÉDICA X	160
51499	1005.000.096-6	BASES COMPLEMENTARES DA MEDICINA VII	34
51518	1005.000.115-9	CIRURGIA IV	68
51524	1005.000.121-0	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA IX	34
51522	1005.000.119-5	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA X	34
51497	1005.000.094-8	ATENÇÃO PRIMÁRIA VIII	68
51479	1005.000.076-0	BASES BIOLÓGICAS DA PRÁTICA MÉDICA XI	160
51521	1005.000.118-6	BASES BIOLOGICAS DA PRÁTICA MÉDICA XII	160
51517	1005.000.114-0	BASES COMPLEMENTARES DA MEDICINA VIII	34
51520	1005.000.117-7	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA XI	34
51519	1005.000.116-8	HABILIDADES CLÍNICAS DA PRÁTICA MÉDICA XII	34
51531	1005.000.128-4	URGÊNCIA E EMERGÊNCIA IV	68
51492	1005.000.089-5	ESTÁGIO OBRIGATÓRIO EM CIRURGIA I	160
51487	1005.000.084-0	ESTÁGIO OBRIGATÓRIO EM CLÍNICA MÉDICA I	160
51523	1005.000.120-1	ESTÁGIO OBRIGATÓRIO EM SAÚDE DA MULHER I	320
51476	1005.000.073-2	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS CIRÚRGICAS	160
51493	1005.000.090-1	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS CLÍNICAS	160
51485	1005.000.082-1	ESTÁGIO OBRIGATÓRIO DE ESPECIALIDADE ELETIVA	160
51507	1005.000.104-1	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA I	160
51525	1005.000.122-0	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA II	160
51474	1005.000.071-4	ESTÁGIO OBRIGATÓRIO EM PEDIATRIA I	160
51486	1005.000.083-0	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS PEDIÁTRICAS	160
51503	1005.000.100-5	ESTÁGIO OBRIGATÓRIO EM CIRURGIA II	320
51500	1005.000.097-5	ESTÁGIO OBRIGATÓRIO EM CLÍNICA MÉDICA II	320
51481	1005.000.078-8	ESTÁGIO OBRIGATÓRIO EM SAÚDE DA MULHER II	160
51484	1005.000.081-2	ESTÁGIO OBRIGATÓRIO EM URGÊNCIAS E EMERGÊNCIAS GINECOLÓGICAS E OBSTÉTRICAS	160
51482	1005.000.079-7	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA III	160
51483	1005.000.080-3	ESTÁGIO OBRIGATÓRIO EM ATENÇÃO BÁSICA: MEDICINA DA FAMÍLIA, COMUNIDADE E SAÚDE COLETIVA IV	160
51475	1005.000.072-3	ESTÁGIO OBRIGATÓRIO EM PEDIATRIA II	320
38587	1005.000.028-1	ANATOMIA CLÍNICA HUMANA	34
51491	1005.000.088-6	BIOQUIMICA E A LÓGICA DA VIDA	51
31586	2101.000.077-4	CIÊNCIAS DO AMBIENTE	34
38590	1005.000.030-3	DENGUE - CLASSIFICAÇÃO DE RISCO E ASSISTÊNCIA	34
41760	3001.000.004-8	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
41585	2701.000.195-8	ELABORAÇÃO DE ARTIGOS CIENTÍFICOS	34
41756	3101.000.095-0	ESTUDO DE LIBRAS	51
51468	2601.000.467-5	FARMACOLOGIA E TERAPEUTICA CLÍNICA	68
41586	2701.000.196-6	FUNDAMENTOS TEÓRICO-PRÁTICOS EM GENÉTICA CLÍNICA	34
51471	2801.000.172-0	HABILIDADES INTERPESSOAIS	51
38595	1005.000.033-8	INFECTOLOGIA E SUAS INTERFACES	34
41587	2801.000.092-5	INTRODUÇÃO À HOMEOPATIA	34
44746	2901.000.782-3	LEITURAS EM INGLÊS	34
41226	2701.000.067-6	MICROBIOLOGIA MÉDICA	34
40713	1005.000.043-5	PRINCÍPIOS DE CUIDADOS PALIATIVOS E TANATOLOGIA	34
38603	1005.000.039-7	RADIOLOGIA E DIAGNÓSTICO POR IMAGEM I	34
38604	1005.000.040-0	RADIOLOGIA E DIAGNÓSTICO POR IMAGEM II	34
38605	1005.000.041-9	RADIOLOGIA E DIAGNÓSTICO POR IMAGEM III	34
44799	3101.000.447-9	TECNOLOGIAS DIGITAIS APLICADAS AO ENSINO DO PORTUGUÊS	68
41589	2701.000.197-4	TÓPICOS ATUAIS EM MORFOFISIOLOGIA HUMANA	34
51480	1005.000.077-9	TÓPICOS ATUAIS EM SAÚDE DA COMUNIDADE	51
41590	2701.000.198-2	TÓPICOS ESPECIAIS EM BIOQUÍMICA MÉDICA	34
51477	1005.000.074-1	TÓPICOS ESPECIAIS EM CLÍNICA MÉDICA	68
51501	1005.000.098-4	TÓPICOS ESPECIAIS EM PRÁTICAS CLÍNICAS E CIRÚRGICAS	68
51488	1005.000.085-9	TÓPICOS ESPECIAIS EM PRÁTICAS INTEGRATIVAS E COMPLEMENTARES EM SAÚDE	51
51502	1005.000.099-3	TÓPICOS ESPECIAIS EM SAÚDE DA CRIANÇA E DO ADOLESCENTE	68
51478	1005.000.075-0	TÓPICOS ESPECIAIS EM SAÚDE DA MULHER	68
45372	1005.000.058-3	TÓPICOS ESPECIAIS EM SAÚDE I	51
45373	1005.000.059-1	TÓPICOS ESPECIAIS EM SAÚDE II	51
45374	1005.000.060-5	TÓPICOS ESPECIAIS EM SAÚDE III	51
45375	1005.000.061-3	TÓPICOS ESPECIAIS EM SAÚDE IV	51
45376	1005.000.062-1	TÓPICOS ESPECIAIS EM SAÚDE V	51
45377	1005.000.063-0	TÓPICOS ESPECIAIS EM SAÚDE VI	51
45378	1005.000.064-8	TÓPICOS ESPECIAIS EM SAÚDE VII	51
45379	1005.000.065-6	TÓPICOS ESPECIAIS EM SAÚDE VIII	51
51528	1005.000.125-7	TÓPICOS ESPECIAIS EM URGÊNCIA E EMERGÊNCIA	68
41610	2701.000.214-8	ANATOMIA GERAL E ODONTOLÓGICA I	85
45283	2701.000.296-8	BIOLOGIA GERAL	51
41627	2701.000.229-6	BIOQUIMICA GERAL E BUCAL I	34
41635	2701.000.236-9	HISTOLOGIA BÁSICA	68
51790	1104.000.137-1	ODONTOLOGIA EM SAÚDE COLETIVA I	34
51778	3001.000.730-7	PRINCÍPIOS DE SOCIOLOGIA	34
41614	2701.000.217-2	ANATOMIA GERAL E ODONTOLÓGICA II	102
41628	2701.000.230-0	BIOQUÍMICA GERAL E BUCAL II	51
41617	2701.000.220-2	FISIOLOGIA	51
45288	2701.000.297-7	HISTOLOGIA BUCAL E DE SISTEMAS	51
45300	2701.000.298-6	IMUNOLOGIA	51
51791	1104.000.138-0	INTRODUÇÃO À ODONTOLOGIA	85
45198	2701.000.293-0	MICROBIOLOGIA	34
41612	2801.000.089-5	EPIDEMIOLOGIA E BIOESTATÍSTICA	34
45860	1104.000.122-8	ÉTICA E BIOÉTICA	51
45862	2601.000.334-6	FARMACOLOGIA	51
45271	2701.000.295-9	MICROBIOLOGIA ORAL	51
51787	1104.000.134-4	ODONTOLOGIA EM SAÚDE COLETIVA II	51
41620	2701.000.223-7	PATOLOGIA GERAL	51
42899	3001.000.297-0	PSICOLOGIA APLICADA À ODONTOLOGIA	34
51799	1104.000.146-0	BIOMATERIAIS I	51
37695	1104.000.007-4	CARIOLOGIA	51
51795	1104.000.142-4	DENTÍSTICA PRÉ-CLÍNICA I	85
51792	1104.000.139-0	ESTOMATOLOGIA I	68
51783	1104.000.130-8	OCLUSÃO	68
51781	1104.000.128-2	PATOLOGIA ORAL E MAXILOFACIAL	85
51779	1104.000.126-4	RADIOLOGIA I	51
45294	1104.000.113-9	ANESTESIOLOGIA E TERAPÊUTICA	51
51786	1104.000.133-5	BIOMATERIAIS II	51
51793	1104.000.140-6	DENTÍSTICA PRÉ-CLÍNICA II	68
51798	1104.000.145-1	ERGONOMIA E BIOSSEGURANÇA EM ODONTOLOGIA	34
45297	1104.000.116-6	ESTÁGIO OBRIGATÓRIO EM SAÚDE DA COMUNIDADE	68
51784	1104.000.131-7	ESTOMATOLOGIA II	68
51794	1104.000.141-5	LABORATÓRIO DE ENDODONTIA	51
51796	1104.000.143-3	PERIODONTIA PRÉ-CLÍNICA	34
51797	1104.000.144-2	RADIOLOGIA II	51
51803	1104.000.150-4	CLÍNICA INTEGRADA I (FASE DE ADEQUAÇÃO I)	340
51804	1104.000.151-3	METODOLOGIA CIENTÍFICA I	51
37713	1104.000.024-4	ORTODONTIA PREVENTIVA E PRINCÍPIOS DE ORTODONTIA INTERCEPTATIVA I	68
51809	1104.000.156-9	CLÍNICA INTEGRADA II (FASE DE ADEQUAÇÃO II )	323
51806	1104.000.153-1	LABORATÓRIO DE PRÓTESES	51
51807	1104.000.154-0	METODOLOGIA CIENTÍFICA II	34
39409	1104.000.069-4	ORTODONTIA PREVENTIVA E PRINCÍPIOS DE ORTODONTIA INTERCEPTATIVA II	68
51814	1104.000.161-1	ESTÁGIO OBRIGATÓRIO EM CLÍNICA INTEGRADA I (FASE DE REABILITAÇÃO I)	272
51801	1104.000.148-9	ODONTOGERIATRIA E PRINCÍPIOS DE IMPLANTODONTIA ORAL	34
51800	1104.000.147-0	ODONTOLOGIA LEGAL E DO TRABALHO	51
45298	1104.000.117-5	ESTÁGIO OBRIGATÓRIO EM CLINICA DE ODONTOLOGIA DE SAÚDE COLETIVA I	68
51810	1104.000.157-8	ESTÁGIO OBRIGATÓRIO EM CLÍNICA INTEGRADA II (FASE DE REABILITAÇÃO II )	306
51805	1104.000.152-2	ODONTOLOGIA INCLUSIVA PARA PESSOAS COM DEFICIÊNCIAS E DOENÇAS SISTÊMICAS	102
51782	1104.000.129-1	ODONTOPEDIATRIA	102
45281	1104.000.102-1	ESTÁGIO OBRIGATÓRIO EM CLINICA DE ODONTOLOGIA DE SAÚDE COLETIVA II	68
51789	1104.000.136-2	ESTÁGIO OBRIGATÓRIO EM CLÍNICA INFANTIL	68
51811	1104.000.158-7	ESTÁGIO OBRIGATÓRIO EM CLÍNICA INTEGRADA III (ALTA COMPLEXIDADE)	136
51802	1104.000.149-8	ESTÁGIO OBRIGATÓRIO EM ODONTOLOGIA INCLUSIVA PARA PESSOAS COM DEFICIÊNCIAS E DOENÇAS SISTÊMICAS	51
51785	1104.000.132-6	ESTÁGIO OBRIGATÓRIO EM ODONTOLOGIA PARA BEBÊS	51
51780	1104.000.127-3	ABORDAGEM CLÍNICA AO TRAUMATISMO DENTAL	34
41623	2601.000.185-2	BIOFÍSICA	34
51813	1104.000.160-2	CIRURGIA AVANÇADA	51
51812	1104.000.159-6	DENTÍSTICA AVANÇADA	51
51808	1104.000.155-0	DOR OROFACIAL E DISFUNÇÃO TEMPOROMANDIBULAR	34
45293	1104.000.112-0	ELABORAÇÃO DE ARTIGO CIENTÍFICO	34
41624	2701.000.226-1	ELABORAÇÃO DE TRABALHO CIENTÍFICO	34
45292	1104.000.111-0	EMPREENDEDORISMO NA ODONTOLOGIA	51
45279	1104.000.100-3	ENDODONTIA AUTOMATIZADA	51
42895	3101.000.284-7	ESTUDO DE LIBRAS	34
45861	2601.000.333-7	FARMACOLOGIA E TERAPÊUTICA AVANÇADA	51
40956	1104.000.090-2	INTRODUÇÃO À METODOLOGIA CIENTÍFICA	34
51788	1104.000.135-3	ODONTOLOGIA HOSPITALAR	34
45301	1104.000.119-3	SEMINÁRIOS CLÍNICOS INTEGRADOS	51
45859	1104.000.121-9	TÓPICOS ESPECIAIS EM ODONTOLOGIA I	34
45863	1104.000.123-7	TÓPICOS ESPECIAIS EM ODONTOLOGIA II	34
45865	1104.000.125-5	TÓPICOS ESPECIAIS EM ODONTOLOGIA III	34
41632	2701.000.233-4	ANATOMIA DOS ANIMAIS DOMÉSTICOS I	102
41633	2701.000.234-2	BIOQUÍMICA VETERINÁRIA I	51
47858	2701.000.324-0	EMBRIOLOGIA VETERINÁRIA	51
36843	1203.000.129-7	GENÉTICA VETERINÁRIA	51
47838	2701.000.319-7	HISTOLOGIA BÁSICA	51
47817	1203.000.191-4	INTRODUÇÃO À MEDICINA VETERINÁRIA	34
41636	2701.000.237-7	ANATOMIA DOS ANIMAIS DOMÉSTICOS II	102
47818	1203.000.192-3	BIOESTATÍSTICA E EXPERIMENTAÇÃO	51
41637	2701.000.238-5	BIOQUÍMICA VETERINÁRIA II	34
47841	2701.000.320-3	FISIOLOGIA VETERINÁRIA I	68
47862	2701.000.325-9	HISTOLOGIA DOS ANIMAIS DOMÉSTICOS	51
47816	1203.000.190-5	SOCIEDADE, MEIO AMBIENTE E SUSTENTABILIDADE	34
36884	1203.000.157-2	DEONTOLOGIA VETERINÁRIA E MEDICINA VETERINÁRIA LEGAL	34
47815	1203.000.189-9	EXTENSÃO E COMUNICAÇÃO NAS CIÊNCIAS VETERINÁRIAS	34
41643	2601.000.193-3	FARMACOLOGIA VETERINÁRIA	68
47829	2701.000.317-9	FISIOLOGIA VETERINÁRIA II	68
47830	2701.000.318-8	IMUNOLOGIA VETERINÁRIA	68
47847	2701.000.323-0	MICROBIOLOGIA VETERINÁRIA I	51
47846	2701.000.322-1	PARASITOLOGIA VETERINÁRIA I	51
36858	1203.000.132-7	AGROSTOLOGIA E CONSERVAÇÃO DE SOLOS	51
36853	1203.000.131-9	ALIMENTAÇÃO E NUTRIÇÃO ANIMAL	51
36868	1203.000.142-4	ETOLOGIA E BEM-ESTAR ANIMAL	34
36870	1203.000.144-0	MELHORAMENTO GENÉTICO ANIMAL	51
41644	2701.000.245-8	MICROBIOLOGIA VETERINÁRIA II	51
47811	2701.000.315-0	PARASITOLOGIA VETERINÁRIA II	51
47814	2701.000.316-0	PATOLOGIA GERAL	51
36422	1203.000.069-0	PRINCÍPIOS DE ADMINISTRAÇÃO	51
36423	1203.000.070-3	PRINCÍPIOS DE ECONOMIA	51
36866	1203.000.140-8	DOENÇAS INFECCIOSAS I	51
47801	1203.000.177-2	EPIDEMIOLOGIA	51
47863	1203.000.226-0	PATOLOGIA CLÍNICA VETERINÁRIA	68
47852	1203.000.217-0	PATOLOGIA ESPECIAL VETERINÁRIA	102
47833	1203.000.203-6	PRODUÇÃO ANIMAL I	68
36863	1203.000.137-8	SEMIOLOGIA VETERINÁRIA	85
36860	1203.000.134-3	ANESTESIOLOGIA VETERINÁRIA	85
36867	1203.000.141-6	DIAGNÓSTICO POR IMAGEM	68
47864	1203.000.227-9	DOENÇAS PARASITÁRIAS	68
47789	1203.000.165-6	INSPEÇÃO E TECNOLOGIA DE CARNES E DERIVADOS	68
47851	1203.000.216-1	PRODUÇÃO ANIMAL II	102
47813	1203.000.188-0	SAÚDE PÚBLICA	51
36871	1203.000.145-9	TÉCNICA CIRÚRGICA VETERINÁRIA	85
36872	1203.000.146-7	CLÍNICA CIRÚRGICA VETERINÁRIA	102
47853	1203.000.218-0	CLÍNICA MÉDICA E TERAPÊUTICA DE PEQUENOS ANIMAIS I	85
47854	1203.000.219-9	DOENÇAS INFECCIOSAS II	51
47794	1203.000.170-9	GINECOLOGIA E BIOTECNOLOGIA DA FÊMEA	102
47827	2601.000.405-8	INSPEÇÃO E TECNOLOGIA DE LEITES E DERIVADOS	68
47855	1203.000.220-5	OBSTETRÍCIA VETERINÁRIA	85
47845	1203.000.212-5	ANDROLOGIA E BIOTECNOLOGIA DO MACHO	102
47831	1203.000.201-8	CLÍNICA MÉDICA E TERAPÊUTICA DE EQUIDEOS	102
47857	1203.000.222-3	CLÍNICA MÉDICA E TERAPÊUTICA DE PEQUENOS ANIMAIS II	85
47786	1203.000.162-9	CLÍNICA MÉDICA E TERAPÊUTICA DE RUMINANTES	102
47832	1203.000.202-7	INSPEÇÃO E TECNOLOGIA DE OVOS, MEL E PESCADOS	34
36885	1203.000.158-0	ZOONOSES	34
47843	1203.000.210-7	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CIRURGIA, ANESTESIOLOGIA E OBSTETRÍCIA	34
47820	1203.000.194-1	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CLÍNICA MÉDICA DE GRANDES ANIMAIS	34
47822	1203.000.196-0	ESTÁGIO OBRIGATÓRIO INTENSIVO EM CLÍNICA MEDICA DE PEQUENOS ANIMAIS E ANIMAIS SILVESTRES	34
47824	1203.000.198-8	ESTÁGIO OBRIGATÓRIO INTENSIVO EM DIAGNÓSTICO LABORATORIAL DE PATÓGENOS	34
47797	1203.000.173-6	ESTÁGIO OBRIGATÓRIO INTENSIVO EM DIAGNÓSTICO POR IMAGEM	34
47798	1203.000.174-5	ESTÁGIO OBRIGATÓRIO INTENSIVO EM INSPEÇÃO E TECNOLOGIA DE ALIMENTOS	34
47799	1203.000.175-4	ESTÁGIO OBRIGATÓRIO INTENSIVO EM PATOLOGIA ESPECIAL VETERINÁRIA	34
47800	1203.000.176-3	ESTÁGIO OBRIGATÓRIO INTENSIVO EM PRODUÇÃO ANIMAL	34
47834	1203.000.204-5	ESTÁGIO OBRIGATÓRIO INTENSIVO EM REPRODUÇÃO ANIMAL	34
47826	1203.000.199-7	ESTÁGIO OBRIGATÓRIO INTENSIVO EM SAÚDE PÚBLICA	34
47812	1203.000.187-0	ESTÁGIO OBRIGATÓRIO	300
41629	2701.000.231-8	ANATOMIA DE AVES	51
47790	1203.000.166-5	ANATOMIA TOPOGRÁFICA DE PEQUENOS ANIMAIS	68
47860	1203.000.224-1	ANESTESIOLOGIA E MEDICINA DE EMERGÊNCIA	51
36337	1203.000.003-7	APICULTURA	51
31970	2101.000.438-9	APROVEITAMENTO E TRATAMENTO DE RESÍDUOS AGROINDUSTRIAIS	34
47806	1203.000.182-5	BIOLOGIA MOLECULAR	34
41178	2701.000.019-6	BIOSSEGURANÇA	34
47809	1203.000.185-2	BIOTECNOLOGIAS APLICADAS À REPRODUÇÃO ANIMAL	51
47808	1203.000.184-3	BIOTERISMO	34
36343	1203.000.009-6	BUBALINOCULTURA	51
36344	1203.000.010-0	CAPRINOCULTURA	51
36809	1203.000.100-9	CLÍNICA MÉDICA E CIRÚRGICA DE ANIMAIS SELVAGENS	51
41527	2701.000.177-0	CONSERVAÇÃO DA NATUREZA	51
47819	1203.000.193-2	DIAGNÓSTICO PARASITOLÓGICO EM MEDICINA VETERINÁRIA	34
36810	1203.000.101-7	DOENÇAS CARENCIAIS E METABÓLICAS DE GRANDES ANIMAIS	51
36811	1203.000.102-5	DOENÇAS DE RUMINANTES E EQUÍDEOS	68
47850	1203.000.215-2	DOENÇAS INFECCIOSAS VIRAIS EMERGENTES	34
47802	1203.000.178-1	EFICIÊNCIA REPRODUTIVA DE ANIMAIS DOMÉSTICOS	51
36437	1203.000.084-3	EQUIDEOCULTURA	51
35081	2101.000.938-0	EROSÃO E CONSERVAÇÃO DO SOLO	68
41470	2701.000.120-6	FUNDAMENTOS DE AGROECOLOGIA	51
41524	2701.000.174-5	FUNDAMENTOS DE BIOTECNOLOGIA	34
34343	2101.000.846-5	GESTÃO AMBIENTAL	68
32013	2101.000.473-7	GESTÃO DA QUALIDADE	51
47796	1203.000.172-7	HIGIENE E SEGURANÇA DOS ALIMENTOS	34
47842	2701.000.321-2	HISTOLOGIA COMPARADA	68
47791	1203.000.167-4	IMUNODIAGNÓSTICO EM MEDICINA VETERINÁRIA	34
45516	2801.000.128-3	INDICADORES DE SAÚDE E SISTEMAS DE INFORMAÇÕES EM SAÚDE (SIS)	34
47792	1203.000.168-3	INTRODUÇÃO A HOMEOPATIA VETERINÁRIA	51
47805	1203.000.181-6	INTRODUÇÃO A MEDICINA VETERINÁRIA INTEGRATIVA	68
47840	1203.000.209-0	LABORATÓRIO DE DIAGNÓSTICO BACTERIOLÓGICO E MICOLÓGICO	34
44523	2701.000.273-4	LEGISLAÇÃO AMBIENTAL	34
47839	1203.000.208-1	MANEJO E CONSERVAÇÃO DE ANIMAIS SELVAGENS	34
36816	1203.000.105-0	MANEJO PROFILÁTICO E SANITÁRIO DE RUMINANTES	51
47859	1203.000.223-2	MEDICINA VETERINÁRIA DE SUÍNOS	68
47849	1203.000.214-3	MELIPONICULTURA	51
47793	1203.000.169-2	ONCOLOGIA VETERINÁRIA	34
47861	1203.000.225-0	ORTOPEDIA EM PEQUENOS ANIMAIS	34
36434	1203.000.081-9	OVINOCULTURA	51
47844	1203.000.211-6	PATOLOGIA DE CÃES E GATOS	34
36427	1203.000.074-6	PISCICULTURA	51
47825	2101.001.404-6	PLANEJAMENTO E SAÚDE AMBIENTAL	51
41488	2701.000.138-9	POLUIÇÃO AMBIENTAL	34
47807	1203.000.183-4	PRÁTICA DE CAMPO, MANEJO E LIDA	51
47828	1203.000.200-9	PRATICA HOSPITALAR EM CLÍNICA MÉDICA DE GRANDES ANIMAIS	68
36827	1203.000.116-5	PRÁTICA HOSPITALAR EM DIAGNÓSTICO POR IMAGEM	68
47856	1203.000.221-4	PRATICA HOSPITALAR EM GINECOLOGIA E OBSTETRICIA	68
36829	1203.000.118-1	PRÁTICA HOSPITALAR EM REPRODUÇÃO ANIMAL	68
47823	1203.000.197-9	PRÁTICAS DE CAMPO EM DOENÇAS PARASITÁRIAS DE ANIMAIS DE PRODUÇÃO	34
32040	2101.000.500-8	PROCESSAMENTO DE PRODUTOS DE ORIGEM ANIMAL	34
32000	2101.000.460-5	PROCESSOS AGROINDUSTRIAIS	34
36830	1203.000.119-0	PRODUÇÃO ANIMAL EM PASTAGENS	51
36831	1203.000.120-3	PROGRAMAS DE MELHORAMENTO ANIMAL	51
47836	1203.000.206-3	REPRODUÇÃO DE CARNÍVOROS	34
41531	2701.000.181-8	RESTAURAÇÃO AMBIENTAL	34
47835	1203.000.205-4	SANIDADE AVÍCOLA E SUINÍCOLA	34
47804	1203.000.180-7	SANIDADE DE AVES	51
47795	1203.000.171-8	SANIDADE EM PEIXES DE PRODUÇÃO	51
47848	1203.000.213-4	SOLICITAÇÃO E INTERPRETAÇÃO DE EXAMES LABORATORIAIS APLICADOS À PRÁTICA CLÍNICA	34
36836	1203.000.125-4	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA I	51
36837	1203.000.126-2	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA II	51
47788	1203.000.164-7	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA III	34
47810	1203.000.186-1	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA IV	34
47821	1203.000.195-0	TÓPICOS ESPECIAIS EM MEDICINA VETERINÁRIA V	34
47837	1203.000.207-2	TÓPICOS ESPECIAIS EM TERIOGENOLOGIA DE PEQUENOS ANIMAIS	34
36838	1203.000.127-0	TOXICOLOGIA E PLANTAS TÓXICAS	51
47803	1203.000.179-0	TRATAMENTO CIRÚRGICO DA SÍNDROME CÓLICA	34
47787	1203.000.163-8	VACINAS E VACINAÇÃO	34
51969	2701.000.440-7	ANATOMIA DOS ANIMAIS DOMÉSTICOS	68
51970	2701.000.441-6	BIOLOGIA CELULAR	51
51968	2701.000.439-0	BOTÂNICA	51
36389	2201.000.097-7	MATEMÁTICA	68
51999	1203.000.257-3	PROFISSÃO ZOOTECNISTA	34
50156	2301.000.406-1	QUÍMICA GERAL	34
50837	2301.000.409-9	QUÍMICA GERAL E ORGÂNICA EXPERIMENTAL	34
50829	2301.000.408-0	QUÍMICA ORGÂNICA	34
51972	2701.000.443-4	ZOOLOGIA DOS VERTEBRADOS	34
36394	1203.000.050-9	BIOESTATÍSTICA I	34
41445	2701.000.096-0	BIOQUÍMICA I	51
41654	2701.000.251-2	ECOLOGIA E FAUNA SILVESTRE	51
51973	2701.000.444-3	EMBRIOLOGIA	51
36399	2401.000.123-6	FÍSICA	51
41656	2701.000.253-9	FISIOLOGIA VEGETAL	51
51772	2701.000.438-1	HISTOLOGIA	51
36407	1203.000.055-0	MICROBIOLOGIA	51
36402	1203.000.052-5	BIOESTATÍSTICA II	34
41658	2701.000.255-5	BIOQUÍMICA II	68
51971	2701.000.442-5	FISIOLOGIA ANIMAL	68
51977	1203.000.235-9	GENÉTICA ANIMAL	51
36398	1203.000.051-7	IMUNOLOGIA	34
52006	1203.000.264-4	MÁQUINAS E IMPLEMENTOS AGRÍCOLAS	34
36406	1203.000.054-1	METODOLOGIA CIENTÍFICA	34
51997	1203.000.255-5	PARASITOLOGIA ANIMAL	51
51989	1203.000.247-5	SOLOS	34
51975	1203.000.233-0	ADUBAÇÃO E NUTRIÇÃO DE PLANTAS	51
52005	1203.000.263-5	AGROMETEOROLOGIA	34
36411	1203.000.059-2	ANÁLISE DE ALIMENTOS	51
36414	2101.000.954-2	CONSTRUÇÕES RURAIS	68
36412	1203.000.060-6	EXPERIMENTAÇÃO ZOOTÉCNICA	51
36413	1203.000.061-4	FISIOLOGIA DA DIGESTÃO	51
36415	1203.000.062-2	MELHORAMENTO GENÉTICO ANIMAL I	68
51982	1203.000.240-1	COMPORTAMENTO E BEM-ESTAR ANIMAL	51
36418	1203.000.065-7	FISIOLOGIA E MANEJO DA REPRODUÇÃO ANIMAL	68
36419	1203.000.066-5	FORRAGICULTURA I	68
36420	1203.000.067-3	MELHORAMENTO GENÉTICO ANIMAL II	68
36421	1203.000.068-1	NUTRIÇÃO ANIMAL	68
36424	1203.000.071-1	BIOCLIMATOLOGIA ZOOTÉCNICA	51
36425	1203.000.072-0	FORRAGICULTURA II	68
36426	1203.000.073-8	NUTRIÇÃO E ALIMENTAÇÃO DE NÃO RUMINANTES	68
51979	1203.000.237-7	PISCICULTURA	51
36428	1203.000.075-4	PROFILAXIA E HIGIENE ZOOTÉCNICA	51
36429	1203.000.076-2	TECNOLOGIA INDUSTRIAL NA ALIMENTAÇÃO ANIMAL	51
51978	1203.000.236-8	AVALIAÇÃO E TIPIFICAÇÃO DE CARCAÇAS	51
36431	1203.000.078-9	CULTURAS AGRÍCOLAS DE INTERESSE ZOOTÉCNICO	51
52000	1203.000.258-2	ÉTICA E LEGISLAÇÃO PROFISSIONAL	34
51995	1203.000.253-7	GESTÃO AMBIENTAL NA AGROPECUÁRIA	51
36433	1203.000.080-0	NUTRIÇÃO E ALIMENTAÇÃO DE RUMINANTES	68
52001	1203.000.259-1	SOCIOLOGIA, COMUNICAÇÃO E EXTENSÃO RURAL	68
36430	1203.000.077-0	AVICULTURA	51
36439	1203.000.086-0	SUINOCULTURA	51
51980	1203.000.238-6	TECNOLOGIA DE PRODUTOS DE ORIGEM ANIMAL	68
51996	1203.000.254-6	ZOOTECNIA DE PRECISÃO	51
52002	1203.000.260-8	BOVINOCULTURA DE CORTE	68
52003	1203.000.261-7	BOVINOCULTURA DE LEITE	68
36443	1203.000.090-8	EMPREENDEDORISMO E PROJETOS EMPRESARIAIS	68
51998	1203.000.256-4	ALIMENTAÇÃO E FORMULAÇÃO DE DIETAS PARA BOVINOS LEITEIROS	51
36338	1203.000.004-5	APROVEITAMENTO DE RESÍDUOS E DEJETOS DA AGROPECUÁRIA	51
36339	1203.000.005-3	AQUICULTURA	51
36340	1203.000.006-1	ASSOCIATIVISMO E COOPERATIVISMO AGRÍCOLA	51
36341	1203.000.007-0	BIOLOGIA MOLECULAR I	51
36342	1203.000.008-8	BIOLOGIA MOLECULAR II	51
36345	1203.000.011-8	CONSERVAÇÃO DO SOLO E ÁGUA	51
51988	1203.000.246-6	COTURNICULTURA	51
36346	1203.000.012-6	CRIAÇÃO DE ANIMAIS SILVESTRES	51
36347	1203.000.013-4	CRIAÇÕES NÃO TRADICIONAIS	51
36348	1203.000.014-2	CUNICULTURA	51
51994	1203.000.252-8	DESENVOLVIMENTO DE PROGRAMAS PARA FORMULAÇÃO DE RAÇÕES	51
36349	1203.000.015-0	DIREITO E LEGISLAÇÃO AMBIENTAL APLICÁVEIS À ZOOTECNIA	51
51985	1203.000.243-9	DOENÇAS DE PLANTAS FORRAGEIRAS	51
51991	1203.000.249-3	ESTRATÉGIA EMPRESARIAL APLICADA À AGROPECUÁRIA	51
51990	1203.000.248-4	ESTRUTIOCULTURA	51
51773	3101.000.660-6	ESTUDO DE LIBRAS	51
51992	1203.000.250-0	ESTUDOS DO AGRONEGÓCIO	51
36352	1203.000.018-5	EZOOGNÓSIA	51
51993	1203.000.251-9	FERRAMENTAS COMPUTACIONAIS APLICADAS AO AGRONEGÓCIO	51
51983	1203.000.241-0	FISIOLOGIA E MANEJO DA LACTAÇÃO	51
36353	1203.000.019-3	GEOREFERENCIAMENTO RURAL	51
52004	1203.000.262-6	GESTÃO DE CUSTOS PECUÁRIOS	51
51984	1203.000.242-0	IDENTIFICAÇÃO DE PLANTAS FORRAGEIRAS E PLANTAS TÓXICAS	51
36354	1203.000.020-7	INTOXICAÇÕES DE INTERESSE ZOOTÉCNICO	51
36361	1203.000.027-4	MANEJO DE BOVINOS DE CORTE EM CONFINAMENTO	51
36355	1203.000.021-5	MANEJO E LIDA DE ANIMAIS DE PRODUÇÃO	51
36357	1203.000.023-1	MARKETING RURAL	51
36358	1203.000.024-0	MERCADOS FUTUROS AGROPECUÁRIOS	51
36359	1203.000.025-8	NUTRIÇÃO DE EQUINOS	51
51986	1203.000.244-8	NUTRIÇÃO E ALIMENTAÇÃO DE CÃES E GATOS	51
51976	1203.000.234-0	PROCESSAMENTO DE CARNES E DERIVADOS	51
41648	2601.000.189-5	PROCESSAMENTO DE LEITE E DERIVADOS	51
36364	1203.000.028-2	PROCESSAMENTO NA INDÚSTRIA DE ALIMENTOS PARA ANIMAIS	51
36365	1203.000.029-0	PRODUÇÃO AGROECOLÓGICA DE ALIMENTOS	51
36366	1203.000.030-4	PRODUÇÃO DE LEITE A PASTO	51
36367	1203.000.031-2	RANICULTURA	51
36368	1203.000.032-0	SERICICULTURA	51
51974	1203.000.232-1	SISTEMAS DE CRIAÇÃO ALTERNATIVOS NA AVICULTURA	51
36369	1203.000.033-9	SISTEMAS DE GESTÃO EMPRESARIAL NO AGRONEGÓCIO	51
51981	1203.000.239-5	SISTEMAS DE INTEGRAÇÃO LAVOURA-PECUÁRIA-FLORESTA NA PRODUÇÃO ANIMAL	51
36370	1203.000.034-7	TÉCNICAS AVANÇADAS EM FORMULAÇÃO DE RAÇÕES	51
36371	1203.000.035-5	TECNOLOGIA DE COUROS E PELES	51
41649	2601.000.190-9	TECNOLOGIA DE PESCADOS	51
36373	1203.000.036-3	TÓPICOS ESPECIAIS EM AVICULTURA	51
36374	1203.000.037-1	TÓPICOS ESPECIAIS EM BOVINOCULTURA DE CORTE	51
36375	1203.000.038-0	TÓPICOS ESPECIAIS EM BOVINOCULTURA DE LEITE	51
36376	1203.000.039-8	TÓPICOS ESPECIAIS EM EQUIDEOCULTURA	51
36377	1203.000.040-1	TÓPICOS ESPECIAIS EM FORRAGICULTURA	51
36378	1203.000.041-0	TÓPICOS ESPECIAIS EM MELHORAMENTO GENÉTICO ANIMAL	51
51987	1203.000.245-7	TÓPICOS ESPECIAIS EM NUTRIÇÃO DE CÃES E GATOS	51
36379	1203.000.042-8	TÓPICOS ESPECIAIS EM OVINOCULTURA	51
36380	1203.000.043-6	TÓPICOS ESPECIAIS EM PISCICULTURA	51
36381	1203.000.044-4	TÓPICOS ESPECIAIS EM SUINOCULTURA	51
36382	1203.000.045-2	TÓPICOS ESPECIAIS EM TECNOLOGIA DE PRODUTOS DE ORIGEM ANIMAL	51
36383	1203.000.046-0	TÓPICOS ESPECIAIS EM ZOOTECNIA I	51
36384	1203.000.047-9	TÓPICOS ESPECIAIS EM ZOOTECNIA II	51
36385	1203.000.048-7	TÓPICOS ESPECIAIS EM ZOOTECNIA III	51
51939	1302.000.277-8	ANÁLISE E RESOLUÇÃO DE PROBLEMAS FLORESTAIS I	34
51938	1302.000.276-9	BIOLOGIA CELULAR VEGETAL	34
37436	1302.000.010-5	ECOLOGIA	34
51931	1302.000.269-8	EXPRESSÃO GRÁFICA	34
51928	1302.000.266-0	INTRODUÇÃO A ENGENHARIA FLORESTAL	34
51940	1302.000.278-7	MATEMÁTICA APLICADA	68
37431	1302.000.005-9	MORFOLOGIA E TAXONOMIA VEGETAL	68
51930	1302.000.268-9	ZOOLOGIA GERAL	34
37460	1302.000.034-2	AGROMETEOROLOGIA	68
37433	1302.000.007-5	ANATOMIA VEGETAL	68
51933	1302.000.271-3	DENDROLOGIA	68
51935	1302.000.273-1	FLORESTAS URBANAS E PAISAGISMO	34
51941	1302.000.279-6	METODOLOGIA CIENTÍFICA	34
37590	1302.000.094-6	SOCIOLOGIA E EXTENSÃO RURAL FLORESTAL	68
51943	1302.000.281-1	ANATOMIA DA MADEIRA	34
51936	1302.000.274-0	BIOQUÍMICA	34
51929	1302.000.267-0	ECOLOGIA FLORESTAL	34
51937	1302.000.275-0	ESTATÍSTICA	68
51948	1302.000.286-7	MÁQUINAS E MECANIZAÇÃO FLORESTAL	68
37450	1302.000.024-5	MICROBIOLOGIA AGRÍCOLA	68
51957	1302.000.295-6	QUÍMICA I	68
51917	1302.000.255-3	CONSTRUÇÕES EM AMBIENTES RURAIS	34
51932	1302.000.270-4	ENTOMOLOGIA GERAL	68
37441	1302.000.015-6	GENÉTICA APLICADA	68
37444	1302.000.018-0	MORFOLOGIA E GÊNESE DO SOLO	68
37543	1302.000.083-0	PATOLOGIA FLORESTAL	68
51956	1302.000.294-7	QUÍMICA II	34
37445	1302.000.019-9	TOPOGRAFIA E GEODESIA APLICADAS	68
37446	1302.000.020-2	CARTOGRAFIA E SISTEMAS DE INFORMAÇÕES GEOGRÁFICAS	68
37447	1302.000.021-0	CLASSIFICAÇÃO E FÍSICA DO SOLO	68
37602	1302.000.099-7	ECONOMIA FLORESTAL	68
51945	1302.000.283-0	ESTRUTURAS DE MADEIRA	34
51950	1302.000.288-5	EXPERIMENTAÇÃO AGRÍCOLA	68
37449	1302.000.023-7	FISIOLOGIA VEGETAL	68
51944	1302.000.282-0	QUÍMICA DA MADEIRA	34
51951	1302.000.289-4	ADMINISTRAÇÃO RURAL E PROJETOS FLORESTAIS	68
51918	1302.000.256-2	DENDROMETRIA	68
37458	1302.000.032-6	HIDRÁULICA	68
51942	1302.000.280-2	MANEJO DE PLANTAS DANINHAS	34
51920	1302.000.258-0	POLÍTICA E LEGISLAÇÃO FLORESTAL	34
37606	1302.000.103-9	SISTEMAS E MÉTODOS SILVICULTURAIS	68
51921	1302.000.259-0	TECNOLOGIA DA MADEIRA	68
51919	1302.000.257-1	GESTÃO DE RECURSOS NATURAIS RENOVÁVEIS	68
37525	1302.000.075-0	HIDROLOGIA	34
51953	1302.000.291-0	INVENTÁRIO FLORESTAL	68
37475	1302.000.043-1	MANEJO E CONSERVAÇÃO DO SOLO	68
37603	1302.000.100-4	MELHORAMENTO GENÉTICO FLORESTAL	68
37549	1302.000.087-3	SEMENTES E VIVEIROS FLORESTAIS	68
51922	1302.000.260-6	SENSORIAMENTO REMOTO APLICADO	34
37617	1302.000.107-1	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
51954	1302.000.292-9	COLHEITA, TRANSPORTE E LOGÍSTICA FLORESTAL	68
51923	1302.000.261-5	ENTOMOLOGIA FLORESTAL	34
51924	1302.000.262-4	FERTILIDADE DO SOLO E NUTRICÃO DAS PLANTAS FLORESTAIS	68
51912	1302.000.250-8	MANEJO DE BACIAS HIDROGRÁFICAS	34
37548	1302.000.086-5	PRODUTOS ENERGÉTICOS FLORESTAIS	68
37625	1302.000.110-1	SILVICULTURA APLICADA	68
51955	1302.000.293-8	ANÁLISE E RESOLUÇÃO DE PROBLEMAS FLORESTAIS II	34
37435	1302.000.009-1	DEONTOLOGIA E RECEITUÁRIO AGRONÔMICO	34
51916	1302.000.254-4	GESTÃO FLORESTAL	34
51959	1302.000.297-4	INCÊNDIOS FLORESTAIS	34
51960	1302.000.298-3	INDUSTRIALIZAÇÃO DE PRODUTOS FLORESTAIS	68
51958	1302.000.296-5	IRRIGAÇÃO FLORESTAL	34
51963	1302.000.301-3	MANEJO FLORESTAL	68
37512	1302.000.062-8	ACAROLOGIA	34
37513	1302.000.063-6	AGRICULTURA DE PRECISÃO	51
37648	1302.000.116-0	AGROECOLOGIA E PERMACULTURA	34
51946	1302.000.284-9	AVALIAÇÃO DE IMÓVEIS E PERÍCIAS RURAIS	34
46533	1302.000.183-2	AVALIAÇÃO DE RETARDANTES QUÍMICOS	34
51926	1302.000.264-2	BALANÇO, CRÉDITO E MERCADO DE CARBONO	68
37649	1302.000.117-9	BIODETERIORAÇÃO E PRESERVAÇÃO DA MADEIRA	34
51927	1302.000.265-1	CERTIFICAÇÃO FLORESTAL	34
37651	1302.000.119-5	CONSERVAÇÃO E MANEJO DA FAUNA SILVESTRE	68
46517	1302.000.171-6	CONTROLE BIOLÓGICO DE PRAGAS, FITOPATÓGENOS E FITONEMATOIDES	68
46523	1302.000.177-0	DESENHO TOPOGRÁFICO DIGITAL	51
37652	1302.000.120-9	DESRAMA E DESBASTE FLORESTAL	34
46520	1302.000.174-3	DIVERSIDADE MICROBIANA DO SOLO	68
37519	1302.000.069-5	ECOFISIOLOGIA VEGETAL	68
46515	1302.000.169-0	EDUCAÇÃO AMBIENTAL	34
37556	1302.000.092-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
37537	1302.000.079-2	ESTUDO DE LIBRAS	51
37653	1302.000.121-7	FÍSICA APLICADA	68
37473	1302.000.042-3	FLORICULTURA E PAISAGISMO	68
37486	1302.000.049-0	FRUTICULTURA	68
37522	1302.000.072-5	GEORREFERENCIAMENTO DE IMÓVEIS RURAIS	51
37654	1302.000.122-5	GESTÃO DE PESSOAS	51
37655	1302.000.123-3	HISTÓRIA E CULTURA AFRO-BRASILEIRA, AFRICANA E INDÍGENA	34
46524	1302.000.178-0	INTEGRAÇÃO LAVOURA-PECUÁRIA-FLORESTA	68
51947	1302.000.285-8	INTRODUÇÃO A INFORMÁTICA	34
51961	1302.000.299-2	INTRODUÇÃO A MÉTODOS INSTRUMENTAIS DE ANÁLISES QUÍMICA	34
46521	1302.000.175-2	LEITURA E INTERPRETAÇÃO DE CARTAS TOPOGRÁFICAS	34
46522	1302.000.176-1	LEVANTAMENTO TOPOGRÁFICO COM VEÍCULOS AÉREOS NÃO TRIPULADOS (VANT)	51
37657	1302.000.125-0	MANEJO DE ÁREAS SILVESTRES	68
51934	1302.000.272-2	MANEJO DE FLORESTAS NATURAIS	34
37542	1302.000.082-2	NEMATOLOGIA APLICADA	34
46532	1302.000.182-3	PROCESSAMENTO DE DADOS FLORESTAIS	68
46518	1302.000.172-5	PROGRAMAÇÃO EM LINGUAGEM R	68
37658	1302.000.126-8	QUÍMICA ORGÂNICA	51
46519	1302.000.173-4	REDAÇÃO CIENTÍFICA	34
51925	1302.000.263-3	SANIDADE DE SEMENTES AGRÍCOLAS E FLORESTAIS	51
37659	1302.000.127-6	SERRARIA E SECAGEM DA MADEIRA	34
37550	1302.000.088-1	SISTEMAS DE INFORMAÇÕES GEOGRÁFICAS AVANÇADO	51
37551	1302.000.089-0	TECNOLOGIA DE APLICAÇÃO DE DEFENSIVOS AGRÍCOLAS	51
37660	1302.000.128-4	TECNOLOGIA DE CELULOSE E PAPEL	34
51914	1302.000.252-6	TÓPICOS AVANÇADOS EM GESTÃO AMBIENTAL	34
51949	1302.000.287-6	TÓPICOS AVANÇADOS EM MANEJO FLORESTAL	34
51913	1302.000.251-7	TÓPICOS AVANÇADOS EM MENSURAÇÃO FLORESTAL	34
51952	1302.000.290-0	TÓPICOS AVANÇADOS EM SENSORIAMENTO REMOTO	34
51915	1302.000.253-5	TÓPICOS AVANÇADOS EM SILVICULTURA	34
51962	1302.000.300-4	TÓPICOS AVANÇADOS EM TECNOLOGIA DE PRODUTOS FLORESTAIS	34
46529	1302.000.179-9	TÓPICOS ESPECIAIS EM ENGENHARIA FLORESTAL I	34
46531	1302.000.181-4	TÓPICOS ESPECIAIS EM ENGENHARIA FLORESTAL II	68
37427	1302.000.001-6	BIOLOGIA CELULAR	51
37428	1302.000.002-4	DESENHO TÉCNICO	51
37429	1302.000.003-2	INICIAÇÃO A AGRONOMIA REGIONAL	34
37430	1302.000.004-0	MATEMÁTICA APLICADA	68
37432	1302.000.006-7	QUÍMICA GERAL	51
37434	1302.000.008-3	BIOQUÍMICA APLICADA	68
37437	1302.000.011-3	ESTATÍSTICA	68
37438	1302.000.012-1	QUÍMICA ANALÍTICA	51
37439	1302.000.013-0	ZOOLOGIA E PARASITOLOGIA AGRÍCOLA	51
37440	1302.000.014-8	ENTOMOLOGIA GERAL	68
37442	1302.000.016-4	INICIAÇÃO A PESQUISA APLICADA	51
37443	1302.000.017-2	MECÂNICA E MÁQUINAS MOTORAS	51
37448	1302.000.022-9	EXPERIMENTAÇÃO AGRÍCOLA	68
37451	1302.000.025-3	SOCIOLOGIA RURAL	34
37452	1302.000.026-1	ZOOTECNIA GERAL	68
37453	1302.000.027-0	CONSTRUÇÕES RURAIS	51
37454	1302.000.028-8	ENTOMOLOGIA APLICADA - PRAGAS I	68
37455	1302.000.029-6	EXTENSÃO RURAL E COMUNICAÇÃO	68
37456	1302.000.030-0	FERTILIDADE DO SOLO E NUTRIÇÃO DE PLANTAS	68
37457	1302.000.031-8	FOTOINTERPRETAÇÃO E SENSORIAMENTO REMOTO	51
37459	1302.000.033-4	NUTRIÇÃO E ALIMENTAÇÃO ANIMAL	68
37461	1302.000.035-0	BIOLOGIA E CONTROLE DE PLANTAS DANINHAS	68
37463	1302.000.036-9	ECONOMIA RURAL, MARKETING E AGRONEGÓCIOS	68
37464	1302.000.037-7	ENTOMOLOGIA APLICADA - PRAGAS II	51
37466	1302.000.038-5	FITOPATOLOGIA	68
37468	1302.000.039-3	MELHORAMENTO DE PLANTAS	68
37483	1302.000.047-4	ADMINISTRAÇÃO RURAL E PROJETOS AGROPECUÁRIOS	68
37470	1302.000.040-7	CULTURA DE CEREAIS	68
37472	1302.000.041-5	DOENÇAS DAS PLANTAS CULTIVADAS	51
37476	1302.000.044-0	MÁQUINAS E IMPLEMENTOS AGRÍCOLAS	68
37478	1302.000.045-8	OLERICULTURA	68
37497	1302.000.054-7	CULTURA DE PLANTAS OLEAGINOSAS E ESTIMULANTES	68
37489	1302.000.050-4	IRRIGAÇÃO E DRENAGEM	68
37481	1302.000.046-6	PRÉ-PROCESSAMENTO E ARMAZENAMENTO DE GRÃOS	68
37491	1302.000.051-2	PRODUÇÃO DE ANIMAIS DE PEQUENO PORTE	68
37493	1302.000.052-0	SILVICULTURA	68
37495	1302.000.053-9	BOVINOCULTURA	68
37485	1302.000.048-2	CULTURA DE PLANTAS ENERGÉTICAS E FIBROSAS	68
37499	1302.000.055-5	FORRAGICULTURA	51
37500	1302.000.056-3	MANEJO DE RECURSOS NATURAIS RENOVÁVEIS	68
37504	1302.000.057-1	TECNOLOGIA DE PRODUTOS AGROPECUÁRIOS	34
37505	1302.000.058-0	TECNOLOGIA DE SEMENTES	68
37516	1302.000.066-0	BIOMETRIA FLORESTAL	68
37517	1302.000.067-9	COMPONENTES QUÍMICOS E ANATÔMICOS DA MADEIRA	51
37518	1302.000.068-7	CULTURA DA MANDIOCA, PINHÃO MANSO E MAMONA	51
37521	1302.000.071-7	ESTRUTURAS DE MADEIRA	34
37523	1302.000.073-3	GESTÃO DE PESSOAS	68
37524	1302.000.074-1	GESTÃO FLORESTAL	68
37526	1302.000.076-8	INDUSTRIALIZAÇÃO DE PRODUTOS FLORESTAIS	68
37535	1302.000.078-4	INVENTÁRIO FLORESTAL	68
37538	1302.000.080-6	MANEJO DE BACIAS HIDROGRÁFICAS	68
51820	1302.000.249-1	SANIDADE DE SEMENTES AGRÍCOLAS E FLORESTAIS	51
46516	1302.000.170-7	SISTEMAS DE PRODUÇÃO	68
37552	1302.000.090-3	TECNOLOGIA DO AÇÚCAR E DO ÁLCOOL	51
37553	1302.000.091-1	TECNOLOGIA E UTILIZAÇÃO DE PRODUTOS FLORESTAIS	68
49713	1302.000.219-7	COMPETÊNCIAS SOCIOEMOCIONAIS	68
49699	1302.000.205-2	ECONOMIA E NEGÓCIOS	68
49711	1302.000.217-9	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
49712	1302.000.218-8	FUNDAMENTOS DE ADMINISTRAÇÃO	68
49709	1302.000.215-0	INTRODUÇÃO À CONTABILIDADE	68
49692	1302.000.198-6	DIREITO APLICADO À ADMINISTRAÇÃO	68
49740	1302.000.246-4	EXTENSÃO I: COMUNIDADES DA CIDADE	75
49714	1302.000.220-3	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
49723	1302.000.229-5	MATEMÁTICA	68
49715	1302.000.221-2	TEORIA GERAL DA ADMINISTRAÇÃO	68
49724	1302.000.230-1	ECONOMIA, GESTÃO E SOCIEDADE	68
49694	1302.000.200-7	ESTRATÉGIAS ORGANIZACIONAIS	68
49703	1302.000.209-9	FUNDAMENTOS DE ESTATÍSTICA	68
49728	1302.000.234-8	GESTÃO DE MARKETING	68
49725	1302.000.231-0	INTRODUÇÃO À PSICOLOGIA	68
49707	1302.000.213-2	EXTENSÃO II: VIDA ACADÊMICA	75
49729	1302.000.235-7	GESTÃO ÁGIL DE NEGÓCIOS E PROJETOS	68
49716	1302.000.222-1	GESTÃO DE CUSTOS	68
49700	1302.000.206-1	GESTÃO DO COMPOSTO DE MARKETING	68
49698	1302.000.204-3	GESTÃO LOGÍSTICA	68
49717	1302.000.223-0	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
49722	1302.000.228-6	GESTÃO DE PESSOAS	68
49695	1302.000.201-6	GESTÃO ESTRATÉGICA	68
49730	1302.000.236-6	GESTÃO FINANCEIRA	68
49726	1302.000.232-0	INOVAÇÃO EMPREENDEDORA	68
49727	1302.000.233-9	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
49697	1302.000.203-4	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
49708	1302.000.214-1	EXTENSÃO III: ENSINO SUPERIOR E EDUCAÇÃO BÁSICA	75
49696	1302.000.202-5	GESTÃO DE OPERAÇÕES	68
49693	1302.000.199-5	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
49718	1302.000.224-0	GESTÃO DO AGRONEGÓCIO	68
49721	1302.000.227-7	INTELIGÊNCIA DE NEGÓCIOS E ANÁLISE DE DADOS	68
49719	1302.000.225-9	RESPONSABILIDADE SOCIAL E EMPRESARIAL	68
49720	1302.000.226-8	DESIGN DE NEGÓCIOS INOVADORES	68
49686	1302.000.192-1	EXTENSÃO IV: COMUNICAÇÕES PARA A SOCIEDADE	75
49710	1302.000.216-0	MERCADO DE CAPITAIS NO AGRONEGÓCIO	68
43104	1302.000.131-3	DIREITOS HUMANOS	68
43136	1302.000.163-6	EDUCAÇÃO AMBIENTAL	68
49706	1302.000.212-3	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
49688	1302.000.194-0	ESTUDO DE LIBRAS	68
49691	1302.000.197-7	TÓPICOS EM CIÊNCIAS SOCIAIS E HUMANAS	68
49687	1302.000.193-0	TÓPICOS EM CIÊNCIAS SOCIAIS E HUMANAS II	68
49737	1302.000.243-7	TÓPICOS EM CIÊNCIAS SOCIAIS E HUMANAS III	68
49731	1302.000.237-5	TÓPICOS EM COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
49732	1302.000.238-4	TÓPICOS EM COMPORTAMENTO HUMANO E ORGANIZACIONAL II	68
49738	1302.000.244-6	TÓPICOS EM COMPORTAMENTO HUMANO E ORGANIZACIONAL III	68
49690	1302.000.196-8	TÓPICOS EM ECONOMIA E FINANÇAS	68
49733	1302.000.239-3	TÓPICOS EM ECONOMIA E FINANÇAS II	68
49739	1302.000.245-5	TÓPICOS EM ECONOMIA E FINANÇAS III	68
49701	1302.000.207-0	TÓPICOS EM EMPREENDEDORISMO E INOVAÇÃO	68
49734	1302.000.240-0	TÓPICOS EM EMPREENDEDORISMO E INOVAÇÃO II	68
49741	1302.000.247-3	TÓPICOS EM EMPREENDEDORISMO E INOVAÇÃO III	68
49704	1302.000.210-5	TÓPICOS EM GESTÃO ESTRATÉGICA	68
49735	1302.000.241-9	TÓPICOS EM GESTÃO ESTRATÉGICA II	68
49742	1302.000.248-2	TÓPICOS EM GESTÃO ESTRATÉGICA III	68
49689	1302.000.195-9	TÓPICOS EM OPERAÇÕES DA CADEIA DE SUPRIMENTOS	68
49736	1302.000.242-8	TÓPICOS EM OPERAÇÕES DA CADEIA DE SUPRIMENTOS II	68
49685	1302.000.191-2	TÓPICOS EM OPERAÇÕES DA CADEIA DE SUPRIMENTOS III	68
49705	1302.000.211-4	TÓPICOS ESPECIAIS I	68
49702	1302.000.208-0	TÓPICOS ESPECIAIS II	68
48062	1404.000.371-0	ENSINO DE HISTÓRIA E CULTURA AFRO-BRASILEIRA E AFRICANA	68
43799	1404.000.301-2	FUNDAMENTOS DE DIDÁTICA	51
48056	1404.000.365-8	HISTÓRIA ANTIGA I	68
48060	1404.000.369-4	HISTÓRIA DA AMÉRICA I	68
48073	1404.000.382-7	TECNOLOGIAS DE INFORMAÇÃO E COMUNICAÇÃO	68
48051	1404.000.360-2	EDUCAÇÃO E DIREITOS HUMANOS	68
48055	1404.000.364-9	HISTÓRIA ANTIGA II	68
48050	1404.000.359-6	HISTÓRIA DA AMÉRICA II	68
48064	1404.000.373-8	HISTÓRIA DO BRASIL I	68
48077	1404.000.386-3	PRÁTICAS DE ENSINO EM HISTÓRIA I	68
48059	1404.000.368-5	ENSINO DE HISTÓRIA INDÍGENA	68
48065	1404.000.374-7	HISTÓRIA DO BRASIL II	68
48066	1404.000.375-6	HISTÓRIA MEDIEVAL I	68
48081	1404.000.390-7	PRÁTICAS DE ENSINO EM HISTÓRIA II	68
48080	1404.000.389-0	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
48068	1404.000.377-4	HISTÓRIA MEDIEVAL II	68
48078	1404.000.387-2	PESQUISA HISTÓRICA	68
43798	1404.000.300-3	POLÍTICAS EDUCACIONAIS	51
48072	1404.000.381-8	PRÁTICAS DE ENSINO EM HISTÓRIA III	68
48074	1404.000.383-6	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
48054	1404.000.363-0	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	100
48067	1404.000.376-5	HISTÓRIA MODERNA I	68
48075	1404.000.384-5	ORGANIZAÇÃO DO TRABALHO PEDAGÓGICO	68
48076	1404.000.385-4	PRÁTICAS DE ENSINO EM HISTÓRIA IV	68
43804	1404.000.306-8	PSICOLOGIA E EDUCAÇÃO	51
48079	1404.000.388-1	SOCIOLOGIA E HISTÓRIA	68
43815	1404.000.317-5	EDUCAÇÃO ESPECIAL	51
48058	1404.000.367-6	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	100
48069	1404.000.378-3	HISTÓRIA DO MATO GROSSO DO SUL	68
48071	1404.000.380-9	HISTÓRIA MODERNA II	68
48082	1404.000.391-6	PRÁTICAS DE ENSINO EM HISTÓRIA V	68
48052	1404.000.361-1	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	100
43812	1404.000.314-8	ESTUDO DE LIBRAS	51
48053	1404.000.362-0	HISTÓRIA CONTEMPORÂNEA I	68
48070	1404.000.379-2	HISTÓRIA DO BRASIL III	68
48083	1404.000.392-5	PRÁTICAS DE ENSINO EM HISTÓRIA VI	68
43797	1404.000.299-1	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
48057	1404.000.366-7	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	100
48063	1404.000.372-9	HISTÓRIA CONTEMPORÂNEA II	68
48061	1404.000.370-0	HISTÓRIA DO BRASIL IV	68
48049	1404.000.358-7	SEMINÁRIO DE PESQUISA HISTÓRICA	68
38255	1404.000.039-7	ANTROPOLOGIA E HISTÓRIA	68
38256	1404.000.040-0	ARQUEOLOGIA E HISTÓRIA	68
38257	1404.000.041-9	CULTURA E POLÍTICA NO BRASIL CONTEMPORÂNEO	68
38258	1404.000.042-7	CULTURA E RELIGIOSIDADE	68
48084	1404.000.393-4	DIÁLOGOS CONTEMPORÂNEOS: ESTUDOS CULTURAIS, DECOLONIAIS, PÓS-COLONIAIS E AS EPISTEMOLOGIAS DO SUL	68
43793	1404.000.295-5	EDUCAÇÃO AMBIENTAL	68
38259	1404.000.043-5	EDUCAÇÃO DE JOVENS E ADULTOS	68
38260	1404.000.044-3	EDUCAÇÃO NO CAMPO	68
38261	1404.000.045-1	FILOSOFIA E HISTÓRIA	68
38186	1404.000.005-2	FUNDAMENTOS DA EDUCAÇÃO	68
38263	1404.000.047-8	FUNDAMENTOS DE ECONOMIA	68
38264	1404.000.048-6	FUNDAMENTOS DE MUSEOLOGIA	68
43795	1404.000.297-3	GÊNERO E HISTÓRIA	68
38265	1404.000.049-4	GEOGRAFIA DO BRASIL	68
38266	1404.000.050-8	GEOGRAFIA GERAL E DO BRASIL	68
38267	1404.000.051-6	GESTÃO EDUCACIONAL	68
38268	1404.000.052-4	HISTÓRIA AMBIENTAL	68
38269	1404.000.053-2	HISTÓRIA CULTURAL	68
38270	1404.000.054-0	HISTÓRIA DA ÁFRICA	68
38271	1404.000.055-9	HISTÓRIA DA AMÉRICA DO NORTE	68
43805	1404.000.307-7	HISTÓRIA DA AMÉRICA LATINA INDEPENDENTE	68
38272	1404.000.056-7	HISTÓRIA DA ARTE	68
38301	1404.000.081-8	HISTÓRIA DA ÁSIA	68
38275	1404.000.058-3	HISTÓRIA DA CIÊNCIA E DA TECNOLOGIA	68
38276	1404.000.059-1	HISTÓRIA DA EDUCAÇÃO BRASILEIRA	68
43796	1404.000.298-2	HISTÓRIA DA FILOSOFIA ANTIGA E MEDIEVAL	68
43801	1404.000.303-0	HISTÓRIA DA FILOSOFIA CONTEMPORÂNEA	68
43802	1404.000.304-0	HISTÓRIA DA FILOSOFIA MODERNA	68
38278	1404.000.061-3	HISTÓRIA DAS IDÉIAS	68
38277	1404.000.060-5	HISTÓRIA DAS IDÉIAS POLÍTICAS	68
38280	1404.000.062-1	HISTÓRIA DAS INSTITUIÇÕES	68
43810	1404.000.312-0	HISTÓRIA DO ATEÍSMO	68
38281	1404.000.063-0	HISTÓRIA DO BRASIL CONTEMPORÂNEO	68
38282	1404.000.064-8	HISTÓRIA DO PENSAMENTO ECONÔMICO	68
38283	1404.000.065-6	HISTÓRIA E CIDADES	68
38285	1404.000.066-4	HISTÓRIA E PATRIMÔNIO HISTÓRICO	68
38286	1404.000.067-2	HISTÓRIA E TURISMO	68
38287	1404.000.068-0	HISTÓRIA IBÉRICA	68
38288	1404.000.069-9	HISTÓRIA ORAL	68
38289	1404.000.070-2	HISTÓRIA REGIONAL	68
43809	1404.000.311-0	HISTÓRIA SOCIAL DA IMPRENSA	68
38294	1404.000.075-3	HISTORIOGRAFIA	68
38290	1404.000.071-0	HISTORIOGRAFIA ANTIGA	68
38291	1404.000.072-9	HISTORIOGRAFIA BRASILEIRA	68
38292	1404.000.073-7	HISTORIOGRAFIA MEDIEVAL	68
38293	1404.000.074-5	HISTORIOGRAFIA REGIONAL	68
38295	1404.000.076-1	LITERATURA E HISTÓRIA	68
38296	1404.000.077-0	NOÇÕES DE ARQUIVÍSTICA	68
43807	1404.000.309-5	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
38302	1404.000.082-6	PALEOGRAFIA	68
38298	1404.000.078-8	PESQUISA HISTÓRICA	68
38299	1404.000.079-6	POPULAÇÃO, FAMÍLIA E GÊNERO	68
43800	1404.000.302-1	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
38300	1404.000.080-0	SOCIOLOGIA DA EDUCAÇÃO	68
48765	1404.000.550-9	ECONOMIA E NEGÓCIOS	68
48758	1404.000.543-8	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
48747	1404.000.532-0	FUNDAMENTOS DA ADMINISTRAÇÃO	68
48764	1404.000.549-2	METODOLOGIA CIENTIFICA E TECNOLOGIAS	68
48767	1404.000.552-7	ECONOMIA, GESTÃO E SOCIEDADE	68
48763	1404.000.548-3	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
48789	1404.000.574-1	INTRODUÇÃO À CONTABILIDADE	68
48768	1404.000.553-6	MATEMÁTICA	68
48766	1404.000.551-8	TEORIA GERAL DA ADMINISTRAÇÃO	68
48771	1404.000.556-3	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
48785	1404.000.570-5	FUNDAMENTOS DA ESTATÍSTICA	68
48770	1404.000.555-4	GESTÃO DE MARKETING	68
48773	1404.000.558-1	INTRODUÇÃO À PSICOLOGIA	68
48743	1404.000.528-7	MATEMÁTICA FINANCEIRA	68
48790	1404.000.575-0	DIREITO APLICADO À ADMINISTRAÇÃO	68
48740	1404.000.525-0	GESTÃO DE CUSTOS	68
48781	1404.000.566-1	GESTÃO DE PESSOAS	68
48782	1404.000.567-0	GESTÃO DO COMPOSTO DE MARKETING	68
48750	1404.000.535-8	INTRODUÇAO À CIÊNCIA POLÍTICA	68
48751	1404.000.536-7	AGRONEGÓCIO	68
48753	1404.000.538-5	ESTRATÉGIAS ORGANIZACIONAIS	68
48788	1404.000.573-2	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
48744	1404.000.529-6	GESTÃO FINANCEIRA	68
48774	1404.000.559-0	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
48759	1404.000.544-7	ESTÁGIO SUPERVISIONADO OBRIGATÓRIO	68
48754	1404.000.539-4	GESTÃO DE OPERAÇÕES	68
48749	1404.000.534-9	PESQUISA OPERACIONAL	68
48757	1404.000.542-9	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
48777	1404.000.562-5	ADMINISTRAÇÃO PÚBLICA E POLÍTICAS PÚBLICAS	68
48776	1404.000.561-6	GESTÃO ESTRATÉGICA	68
48783	1404.000.568-0	GESTÃO LOGÍSTICA	68
48760	1404.000.545-6	TEORIA DAS ORGANIZAÇÕES	68
48784	1404.000.569-9	ESTATISTICA APLICADA A ADMINISTRAÇÃO	68
48755	1404.000.540-0	FUNDAMENTOS DA MATEMÁTICA	68
48745	1404.000.530-2	GESTÃO AMBIENTAL	68
48775	1404.000.560-7	GESTÃO DA QUALIDADE	68
48741	1404.000.526-9	GESTÃO DAS FINANÇAS PESSOAIS	68
48772	1404.000.557-2	GESTÃO DE DEPARTAMENTO PESSOAL	68
48752	1404.000.537-6	GESTÃO DE E-COMMERCE	68
48756	1404.000.541-0	GESTÃO DE MICRO E PEQUENAS EMPRESAS	68
48769	1404.000.554-5	GESTÃO DE PROJETOS E INOVAÇÃO	68
38242	1404.000.027-3	HISTÓRIA E CULTURA AFRO-BRASILEIRA	68
48787	1404.000.572-3	INTELIGENCIA EMOCIONAL NAS ORGANIZAÇÕES	68
48746	1404.000.531-1	LIBRAS	68
48786	1404.000.571-4	MARKETING DIGITAL	68
48742	1404.000.527-8	PESQUISA DE MARKETING	68
48748	1404.000.533-0	PRATICA DE PESQUISA	68
48779	1404.000.564-3	TÓPICOS CONTEMPORÂNEOS EM GESTÃO DA INFORMAÇÃO E TECNOLOGIAS	68
48761	1404.000.546-5	TÓPICOS CONTEMPORÂNEOS EM MARKETING	68
48778	1404.000.563-4	TÓPICOS CONTEMPORÂNEOS EM PRODUÇÃO E LOGÍSTICA	68
48780	1404.000.565-2	TOPICOS ESPECIAIS EM ADMINISTRAÇÃO CONTEMPORÂNEA	68
48762	1404.000.547-4	TÓPICOS ESPECIAS INTERDISCIPLINAR	68
48641	1404.000.511-5	INTRODUÇÃO À ADMINISTRAÇÃO	68
48649	1404.000.519-8	INTRODUÇÃO À CONTABILIDADE	68
48634	1404.000.504-4	INTRODUÇÃO À ECONOMIA	68
48626	1404.000.496-9	MATEMÁTICA	68
48644	1404.000.514-2	MÉTODOS E TÉCNICAS DE PESQUISA	68
48646	1404.000.516-0	CONTABILIDADE GERAL	68
48608	1404.000.478-0	ESTATÍSTICA APLICADA A CONTABILIDADE	68
48632	1404.000.502-6	INTRODUÇÃO À PSICOLOGIA	68
48635	1404.000.505-3	MATEMÁTICA FINANCEIRA	68
48651	1404.000.521-3	CONTABILIDADE DE CUSTOS	68
48648	1404.000.518-9	CONTABILIDADE INTERMEDIÁRIA	68
48642	1404.000.512-4	DIREITO TRIBUTÁRIO	68
48610	1404.000.480-6	MERCADO FINANCEIRO E DE CAPITAIS	68
48607	1404.000.477-1	RESPONSABILIDADE SOCIAL E CORPORATIVA	68
48647	1404.000.517-0	ADMINISTRAÇÃO FINANCEIRA	68
48654	1404.000.524-0	ANÁLISE DE CUSTOS	68
48614	1404.000.484-2	CONTABILIDADE SOCIETÁRIA I	68
43018	1404.000.153-9	DIREITO TRABALHISTA E PREVIDENCIÁRIO	68
48643	1404.000.513-3	FILOSOFIA, ÉTICA E LEGISLAÇÃO PROFISSIONAL CONTÁBIL	68
48613	1404.000.483-3	CONTABILIDADE APLICADA AO TERCEIRO SETOR	68
48652	1404.000.522-2	CONTABILIDADE SOCIETÁRIA II	68
48650	1404.000.520-4	CONTABILIDADE TRIBUTÁRIA	68
48612	1404.000.482-4	TEORIA DA CONTABILIDADE	68
48616	1404.000.486-0	ANÁLISE DAS DEMONSTRAÇÕES CONTÁBEIS	68
48618	1404.000.488-9	CONTABILIDADE APLICADA AO AGRONEGÓCIO	68
48615	1404.000.485-1	CONTABILIDADE AVANÇADA	68
48609	1404.000.479-0	PESQUISA APLICADA A CONTABILIDADE	68
48617	1404.000.487-0	AUDITORIA CONTÁBIL	68
48653	1404.000.523-1	CONTABILIDADE APLICADA AO SETOR PÚBLICO	68
48622	1404.000.492-2	LABORATÓRIO CONTÁBIL I	68
48645	1404.000.515-1	TÓPICOS ESPECIAIS EM CONTABILIDADE	68
48623	1404.000.493-1	CONTROLADORIA	68
48621	1404.000.491-3	LABORATÓRIO CONTÁBIL II	68
48628	1404.000.498-7	PERÍCIA E ARBITRAGEM	68
48636	1404.000.506-2	ANÁLISE DE PROJETOS	68
39502	1404.000.106-7	COMPORTAMENTO ORGANIZACIONAL	68
48637	1404.000.507-1	CONTABILIDADE APLICADA À INSTITUIÇÕES FINANCEIRAS	68
43031	1404.000.166-0	CONTABILIDADE ATUARIAL	68
48611	1404.000.481-5	CONTABILIDADE HOTELEIRA	68
48619	1404.000.489-8	CONTABILIDADE IMOBILIÁRIA	68
43032	1404.000.167-9	CONTABILIDADE INTERNACIONAL	68
48631	1404.000.501-7	CONTABILIDADE SOCIAL	68
43033	1404.000.168-7	COOPERATIVISMO	68
48639	1404.000.509-0	DIREITO ADMINISTRATIVO E CONSTITUCIONAL	68
43010	1404.000.145-8	DIREITO COMERCIAL E LEGISLAÇÃO SOCIETÁRIA	68
48620	1404.000.490-4	EDUCAÇÃO ÉTNICO-RACIAL, GÊNERO E DIVERSIDADE	68
48625	1404.000.495-0	EDUCAÇÃO FINANCEIRA	68
48629	1404.000.499-6	GESTÃO AMBIENTAL	68
33459	1403.000.090-4	GESTÃO DE PESSOAS	68
48638	1404.000.508-0	GOVERNANÇA CORPORATIVA	68
46534	1404.000.318-4	HISTÓRIA E CULTURA AFRO-BRASILEIRA	68
39535	1404.000.118-0	LIBRAS	68
48633	1404.000.503-5	MACROECONOMIA APLICADA	68
43040	1404.000.175-0	MICROECONOMIA APLICADA	68
48640	1404.000.510-6	ORÇAMENTO EMPRESARIAL	68
48627	1404.000.497-8	PLANEJAMENTO ESTRATÉGICO	68
48630	1404.000.500-8	SISTEMAS DE INFORMAÇÃO CONTÁBIL	68
48624	1404.000.494-0	TÓPICOS EMERGENTES EM CONTROLADORIA	68
48533	1404.000.459-3	DESENHO TÉCNICO	68
48482	1404.000.408-3	INTRODUÇÃO À ENGENHARIA DE PRODUÇÃO	34
48468	1404.000.394-3	QUÍMICA GERAL	68
48485	1404.000.411-8	QUÍMICA GERAL EXPERIMENTAL	34
48540	1404.000.466-4	VETORES E GEOMETRIA ANALÍTICA	68
48529	1404.000.455-7	ÁLGEBRA LINEAR	68
48530	1404.000.456-6	CÁLCULO I	68
48528	1404.000.454-8	CIÊNCIAS DO AMBIENTE	68
48546	1404.000.472-6	FUNDAMENTOS DE FLUIDOS, OSCILAÇÕES E ONDAS	34
48547	1404.000.473-5	FUNDAMENTOS DE MECÂNICA	68
48475	1404.000.401-0	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
48526	1404.000.452-0	ALGORITMOS E PROGRAMAÇÃO	68
48531	1404.000.457-5	CÁLCULO II	68
48525	1404.000.451-0	ESTATÍSTICA I	68
48545	1404.000.471-7	FUNDAMENTOS DE ELETROMAGNETISMO	68
48549	1404.000.475-3	FUNDAMENTOS DE TERMODINÂMICA	34
48479	1404.000.405-6	LABORATÓRIO DE MECÂNICA, FLUIDOS E TERMODINÂMICA	34
48532	1404.000.458-4	CÁLCULO III	68
48527	1404.000.453-9	CIÊNCIA E PROCESSAMENTO DOS MATERIAIS	68
48541	1404.000.467-3	ESTATÍSTICA II	68
48473	1404.000.399-9	MECÂNICA GERAL	68
48480	1404.000.406-5	MÉTODOS NUMÉRICOS	68
48535	1404.000.461-9	ENGENHARIA DA QUALIDADE	68
48538	1404.000.464-6	ERGONOMIA E SEGURANÇA NO TRABALHO	68
48483	1404.000.409-2	FÊNOMENOS DE TRANSPORTE	68
48523	1404.000.449-5	MECÂNICA DO SÓLIDOS	68
48469	1404.000.395-2	PESQUISA OPERACIONAL I	68
48524	1404.000.450-1	CONTABILIDADE E FINANÇAS	68
48470	1404.000.396-1	GESTÃO DE PROJETOS	68
48550	1404.000.476-2	PESQUISA OPERACIONAL II	68
48478	1404.000.404-7	PLANEJAMENTO E CONTROLE DA PRODUÇÃO I	68
48548	1404.000.474-4	TEORIA GERAL DA ADMINISTRAÇÃO	68
48534	1404.000.460-0	ECONOMIA	68
48542	1404.000.468-2	ESTRATÉGIAS ORGANIZACIONAIS	68
48484	1404.000.410-9	GESTÃO DE CUSTOS	68
48481	1404.000.407-4	OPERAÇÕES UNITÁRIAS	68
48477	1404.000.403-8	PLANEJAMENTO E CONTROLE DA PRODUÇÃO II	68
48519	1404.000.445-9	AUTOMAÇÃO INDUSTRIAL	34
48536	1404.000.462-8	ENGENHARIA DE MÉTODOS	68
48537	1404.000.463-7	ENGENHARIA ECONÔMICA	68
48522	1404.000.448-6	LEGISLAÇÃO, ÉTICA PROFISSIONAL E CIDADANIA	34
48472	1404.000.398-0	LOGÍSTICA E GESTÃO DA CADEIA DE SUPRIMENTOS	68
48476	1404.000.402-9	PLANEJAMENTO E CONTROLE DA PRODUÇÃO III	68
48543	1404.000.469-1	ESTÁGIO OBRIGATÓRIO I	80
48539	1404.000.465-5	GESTÃO AMBIENTAL	68
48474	1404.000.400-0	PROJETO DE UNIDADES PRODUTIVAS	68
48471	1404.000.397-0	PROJETO E DESENVOLVIMENTO DE PRODUTOS	68
48544	1404.000.470-8	ESTÁGIO OBRIGATÓRIO II	80
48491	1404.000.417-2	ADMINISTRAÇÃO ESTRATÉGICA EM AGROINDÚSTRIA	68
48489	1404.000.415-4	ADMINISTRAÇÃO MERCADOLOGICA	68
48488	1404.000.414-5	APOIO MULTICRITÉRIO À DECISÃO	68
48518	1404.000.444-0	APROVEITAMENTO E TRATAMENTO DE RESÍDUOS AGROINDUSTRIAIS	34
48517	1404.000.443-0	BIOTECNOLOGIA	34
48490	1404.000.416-3	COMUNICAÇÃO E EXPRESSÃO	34
48492	1404.000.418-1	ELETRICIDADE BÁSICA	68
48495	1404.000.421-6	ENGENHARIA E SUSTENTABILIDADE	51
48496	1404.000.422-5	ENGENHARIA, SOCIEDADE E CIDADANIA	34
48520	1404.000.446-8	GERENCIAMENTO DA MANUTENÇÃO	68
48497	1404.000.423-4	GESTÃO DA INOVAÇÃO	68
48498	1404.000.424-3	GESTÃO DE OPERAÇÕES DE SERVIÇOS	68
48499	1404.000.425-2	GESTÃO DE PESSOAS	68
48500	1404.000.426-1	GESTÃO DO CONHECIMENTO	34
48501	1404.000.427-0	GESTÃO ENERGÉTICA	68
48502	1404.000.428-0	INDUSTRIALIZAÇÃO E SOCIEDADE	34
48503	1404.000.429-9	INTELIGENCIA ARTIFICIAL	34
48504	1404.000.430-5	INTRODUÇÃO À MATEMÁTICA	68
48516	1404.000.442-1	LABORATÓRIO DE QUÍMICA ORGÂNICA	34
48505	1404.000.431-4	LIBRAS - LINGUAGEM BRASILEIRA DE SINAIS	51
48493	1404.000.419-0	MERCADOS AGROINDUSTRIAIS	68
48486	1404.000.412-7	METROLOGIA	34
48512	1404.000.438-8	PLANEJAMENTO DE RECURSOS ENERGÉTICOS PARA AGROINDÚSTRIA	34
48515	1404.000.441-2	PROCESSAMENTO DE PRODUTOS DE ORIGEM ANIMAL	34
48514	1404.000.440-3	PROCESSAMENTO DE PRODUTOS DE ORIGEM VEGETAL	34
48513	1404.000.439-7	PROCESSOS AGROINDÚSTRIAIS	34
48506	1404.000.432-3	PROJETO DE INSTALAÇÕES ELÉTRICAS INDUSTRIAIS	34
48507	1404.000.433-2	PROJETO INTEGRADOR I	68
48508	1404.000.434-1	PROJETO INTEGRADOR II	68
48521	1404.000.447-7	QUÍMICA TECNOLÓGICA	34
48494	1404.000.420-7	SISTEMA EM GESTÃO DE QUALIDADE	68
48509	1404.000.435-0	SISTEMAS DE INFORMAÇÃO	68
48510	1404.000.436-0	SISTEMAS ENXUTOS	68
48487	1404.000.413-6	TÓPICOS EM DESENVOLVIMENTO DE PROCESSOS AGROINDUSTRIAIS	68
48511	1404.000.437-9	TÓPICOS EM ENGENHARIA DE PRODUÇÃO	68
45576	1703.000.256-3	FUNDAMENTOS DA EDUCAÇÃO	68
45582	1703.000.262-5	HISTÓRIA MODERNA E CONTEMPORÂNEA	68
45577	1703.000.257-2	INTRODUÇÃO À ANTROPOLOGIA	68
39704	1703.000.003-8	INTRODUÇÃO À POLÍTICA	68
45581	1703.000.261-6	INTRODUÇÃO À SOCIOLOGIA	68
39791	1703.000.089-5	NORMALIZAÇÃO DE TRABALHOS ACADÊMICOS	68
39707	1703.000.006-2	SOCIOLOGIA DA EDUCAÇÃO	68
45580	1703.000.260-7	TEORIA ANTROPOLÓGICA I	68
39710	1703.000.009-7	TEORIA POLÍTICA I	68
45584	1703.000.264-3	TEORIA SOCIOLÓGICA I	68
45585	1703.000.265-2	FILOSOFIA DA EDUCAÇÃO	68
44198	1703.000.187-0	PSICOLOGIA E EDUCAÇÃO	51
39715	1703.000.013-5	TEORIA ANTROPOLÓGICA II	68
39716	1703.000.014-3	TEORIA POLÍTICA II	68
39717	1703.000.015-1	TEORIA SOCIOLÓGICA II	68
44206	1703.000.195-0	FUNDAMENTOS DE DIDÁTICA	51
44200	1703.000.189-8	POLÍTICAS EDUCACIONAIS	51
39720	1703.000.018-6	TEORIA ANTROPOLÓGICA III	68
39721	1703.000.019-4	TEORIA POLÍTICA III	68
39722	1703.000.020-8	TEORIA SOCIOLÓGICA III	68
39723	1703.000.021-6	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS SOCIAIS I	90
39724	1703.000.022-4	HISTÓRIA DA EDUCAÇÃO E DO ENSINO DE SOCIOLOGIA NO BRASIL	68
45575	1703.000.255-4	MÉTODOS E TÉCNICAS DE PESQUISA EM CIÊNCIAS SOCIAIS	68
45579	1703.000.259-0	PENSAMENTO SOCIAL BRASILEIRO I	68
45583	1703.000.263-4	EPISTEMOLOGIA	68
39727	1703.000.025-9	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS SOCIAIS II	100
45578	1703.000.258-1	MÉTODOS E TÉCNICAS DE ENSINO EM CIÊNCIAS SOCIAIS	68
39730	1703.000.028-3	PENSAMENTO SOCIAL BRASILEIRO II	68
39731	1703.000.029-1	SEMINÁRIO DE PESQUISA I	68
44204	1703.000.193-1	EDUCAÇÃO ESPECIAL	51
39734	1703.000.032-1	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS SOCIAIS III	100
39732	1703.000.030-5	ESTATÍSTICA APLICADA ÀS CIÊNCIAS SOCIAIS	34
44209	1703.000.198-7	ESTUDOS DE LIBRAS	51
39736	1703.000.034-8	SEMINÁRIO DE PESQUISA II	34
44205	1703.000.194-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
39738	1703.000.036-4	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS SOCIAIS IV	110
44207	1703.000.196-9	SOCIOLOGIA RURAL	68
39741	1703.000.039-9	ANÁLISE DE PROCESSOS DE DESENVOLVIMENTO SOCIOECONÔMICO	68
39742	1703.000.040-2	ANTROPOLOGIA DA EDUCAÇÃO	68
39743	1703.000.041-0	ANTROPOLOGIA DAS EMOÇÕES	68
39745	1703.000.043-7	ANTROPOLOGIA E CINEMA	68
39746	1703.000.044-5	ANTROPOLOGIA URBANA	68
39747	1703.000.045-3	CIÊNCIA POLÍTICA APLICADA: INSTITUIÇÕES, TOMADAS DE DECISÃO E NORMATIVIDADE	68
39748	1703.000.046-1	CULTURA E POLÍTICA NO BRASIL CONTEMPORÂNEO	68
39749	1703.000.047-0	DIREITOS HUMANOS: HISTÓRIA E EVOLUÇÃO	68
39750	1703.000.048-8	DISCURSO E CLASSES SOCIAIS	68
39751	1703.000.049-6	ECONOMIA POLÍTICA	68
39752	1703.000.050-0	EDUCAÇÃO AMBIENTAL	68
44202	1703.000.191-3	ESTADO E POLÍTICA NO BRASIL CONTEMPORÂNEO	68
39753	1703.000.051-8	ESTUDOS DIRIGIDOS	68
39754	1703.000.052-6	ETNOLOGIA INDÍGENA	68
39757	1703.000.055-0	GÊNERO E SEXUALIDADES	68
39755	1703.000.053-4	HISTÓRIA DA ÁFRICA CONTEMPORÂNEA	68
39756	1703.000.054-2	HISTÓRIA REGIONAL	68
39758	1703.000.056-9	INTRODUÇÃO À GEOGRAFIA HUMANA	68
44201	1703.000.190-4	LÍNGUA PORTUGUESA	68
44210	1703.000.199-6	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
39759	1703.000.057-7	ORIGEM DO HOMEM E ANTIGAS CIVILIZAÇÕES	68
44197	1703.000.186-0	PRÁTICA DE LEITURA E PRODUÇÃO DE TEXTOS	68
44203	1703.000.192-2	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
44208	1703.000.197-8	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
39760	1703.000.058-5	RELAÇÕES DE GÊNERO E EDUCAÇÃO	68
44199	1703.000.188-9	SOCIOLOGIA AMBIENTAL	68
39761	1703.000.059-3	SOCIOLOGIA DA CULTURA	68
39764	1703.000.062-3	SOCIOLOGIA DA RELIGIÃO	68
39762	1703.000.060-7	SOCIOLOGIA DA VIOLÊNCIA INSTITUCIONAL	68
39763	1703.000.061-5	SOCIOLOGIA LATINO AMERICANA (ARGENTINA CONTEMPORÂNEA)	68
49934	1703.000.419-2	EDUCAÇÃO ESPECIAL	68
49932	1703.000.417-4	FILOSOFIA DA EDUCAÇÃO	68
49939	1703.000.424-5	HISTÓRIA DA EDUCAÇÃO I	68
49938	1703.000.423-6	LUDICIDADE E EDUCAÇÃO	68
49940	1703.000.425-4	TRABALHO ACADÊMICO	68
49935	1703.000.420-9	DIDÁTICA I	68
49923	1703.000.408-5	ESTUDOS DE LIBRAS	68
49933	1703.000.418-3	HISTÓRIA DA EDUCAÇÃO II	68
49937	1703.000.422-7	PSICOLOGIA DA EDUCAÇÃO	68
49936	1703.000.421-8	SOCIOLOGIA DA EDUCAÇÃO	68
49916	1703.000.401-1	DIDÁTICA II	68
49929	1703.000.414-7	FUNDAMENTOS E METODOLOGIAS DA EDUCAÇÃO INFANTIL	68
49919	1703.000.404-9	INFÂNCIA E SOCIEDADE	68
49915	1703.000.400-2	POLÍTICAS EDUCACIONAIS	68
49917	1703.000.402-0	PSICOLOGIA DO DESENVOLVIMENTO E DA APRENDIZAGEM	68
49920	1703.000.405-8	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
49925	1703.000.410-0	FUNDAMENTOS E METODOLOGIAS DA ALFABETIZAÇÃO E LETRAMENTO	68
49912	1703.000.397-2	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE HISTÓRIA	68
49944	1703.000.429-0	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE MATEMÁTICA I	68
49926	1703.000.411-0	GESTÃO ESCOLAR	68
49924	1703.000.409-4	ARTES E EDUCAÇÃO: FUNDAMENTOS E PRÁTICAS	68
49918	1703.000.403-0	CURRÍCULO E EDUCAÇÃO	68
49945	1703.000.430-7	ESTÁGIO OBRIGATÓRIO I	100
49922	1703.000.407-6	FUNDAMENTOS E METODOLOGIAS DA LÍNGUA PORTUGUESA	68
49921	1703.000.406-7	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE MATEMÁTICA II	68
49927	1703.000.412-9	PESQUISA NA EDUCAÇÃO BÁSICA I	68
49949	1703.000.434-3	EDUCAÇÃO EM CONTEXTOS NÃO ESCOLARES	68
49947	1703.000.432-5	ESTÁGIO OBRIGATÓRIO II	100
49950	1703.000.435-2	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE CIÊNCIAS E EDUCAÇÃO AMBIENTAL	68
49911	1703.000.396-3	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE GEOGRAFIA	68
49951	1703.000.436-1	PESQUISA NA EDUCAÇÃO BÁSICA II	68
49928	1703.000.413-8	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
49946	1703.000.431-6	EDUCAÇÃO, GÊNERO E SEXUALIDADE	68
49948	1703.000.433-4	ESTÁGIO OBRIGATÓRIO III	100
49914	1703.000.399-0	GESTÃO, AVALIAÇÃO EDUCACIONAL E PLANEJAMENTO	68
49941	1703.000.426-3	PRÁTICAS DE EDUCAÇÃO EM CONTEXTOS NÃO ESCOLARES	68
49943	1703.000.428-1	DIFICULDADES E TRANSTORNOS APRENDIZAGEM	68
49942	1703.000.427-2	EDUCAÇÃO DE JOVENS E ADULTOS	68
49913	1703.000.398-1	ESTÁGIO OBRIGATÓRIO IV	100
49953	1703.000.438-0	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
49952	1703.000.437-0	LITERATURA INFANTIL E EDUCAÇÃO	68
39767	1703.000.065-8	CIDADANIA E EDUCAÇÃO	68
39768	1703.000.066-6	CULTURA BRASILEIRA	68
44212	1703.000.201-7	DIREITOS HUMANOS E EDUCAÇÃO AMBIENTAL	68
39771	1703.000.069-0	EDUCAÇÃO ECOLÓGICA-AMBIENTAL	68
39772	1703.000.070-4	EDUCAÇÃO INDÍGENA	68
39781	1703.000.079-8	LINGUAGEM E EDUCAÇÃO	68
49931	1703.000.416-5	PRÁTICAS EM EDUCAÇÃO INFANTIL	68
49930	1703.000.415-6	PRÁTICAS EM EDUCAÇÃO MIDIÁTICA E EDUCOMUNICAÇÃO	68
39786	1703.000.084-4	RECREAÇÃO E JOGOS	68
39788	1703.000.086-0	SUJEITO, SUBJETIVIDADE E PSICOLOGIA	68
51082	1703.000.501-9	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
51066	1703.000.485-3	COMUNICAÇÃO EMPRESARIAL	68
51088	1703.000.507-3	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
51080	1703.000.499-8	FUNDAMENTOS DA ADMINISTRAÇÃO	68
51084	1703.000.503-7	MATEMÁTICA	68
51075	1703.000.494-2	ECONOMIA E NEGÓCIOS	68
51072	1703.000.491-5	INTRODUÇÃO À CONTABILIDADE	68
51092	1703.000.511-7	INTRODUÇÃO À PESQUISA E REDAÇÃO CIENTÍFICA	68
51093	1703.000.512-6	MATEMÁTICA COMERCIAL E FINANCEIRA	34
51067	1703.000.486-2	OFICINA DE DESENVOLVIMENTO PESSOAL	34
51079	1703.000.498-9	TEORIA GERAL DA ADMINISTRAÇÃO	68
51063	1703.000.482-6	ESTRATÉGIAS ORGANIZACIONAIS	68
51073	1703.000.492-4	FUNDAMENTOS DA ESTATÍSTICA	68
51071	1703.000.490-6	GESTÃO DE CUSTOS	68
51078	1703.000.497-0	GESTÃO DE MARKETING	68
51081	1703.000.500-0	GESTÃO DE PESSOAS	68
45480	1703.000.251-8	GESTÃO DE PROJETOS	68
51077	1703.000.496-0	GESTÃO DO COMPOSTO DE MARKETING	68
45456	1703.000.227-8	GESTÃO DO CONHECIMENTO E INTELIGÊNCIA COMPETITIVA	68
51070	1703.000.489-0	GESTÃO FINANCEIRA	68
51089	1703.000.508-2	SUSTENTABILIDADE E GESTÃO SOCIOAMBIENTAL	68
51086	1703.000.505-5	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
45462	1703.000.233-0	EMPREENDEDORISMO	68
51064	1703.000.483-5	GESTÃO ESTRATÉGICA	68
51083	1703.000.502-8	GESTÃO LOGÍSTICA	68
51065	1703.000.484-4	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
45463	1703.000.234-9	DESENVOLVIMENTO DE NEGÓCIOS	68
51074	1703.000.493-3	ECONOMIA, GESTÃO E SOCIEDADE	68
51069	1703.000.488-0	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
51094	1703.000.513-5	MÉTODOS E TÉCNICAS DE PESQUISAS EM ADMINISTRAÇÃO	68
51087	1703.000.506-4	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
41022	1703.000.153-0	GESTÃO DA INOVAÇÃO	68
51085	1703.000.504-6	GESTÃO DE OPERAÇÕES	68
45464	1703.000.235-8	TECNOLOGIAS E ORGANIZAÇÕES	68
51076	1703.000.495-1	DIREITO APLICADO À ADMINISTRAÇÃO	68
51096	1703.000.515-3	EMPREGABILIDADE E MERCADO	68
51068	1703.000.487-1	LABORATÓRIO DE GESTÃO	68
51090	1703.000.509-1	PESQUISA OPERACIONAL	34
51091	1703.000.510-8	ANÁLISE DE DADOS E INFORMAÇÕES	68
51095	1703.000.514-4	CONSULTORIA ORGANIZACIONAL	68
45439	1703.000.210-6	COOPERATIVAS DE PRODUÇÃO E PARCERIAS ESTRATÉGICAS	34
45469	1703.000.240-0	DINÂMICAS TERRITORIAIS E DESENVOLVIMENTO REGIONAL	34
45446	1703.000.217-0	ECONOMIA DO SETOR PÚBLICO E GESTÃO ORÇAMENTÁRIA	34
45452	1703.000.223-1	ECONOMIA RURAL	34
45475	1703.000.246-5	EDUCAÇÃO FINANCEIRA E ECONOMIA COMPORTAMENTAL	34
45438	1703.000.209-0	EMPREENDEDORISMO E INOVAÇÃO	68
45448	1703.000.219-8	EMPREENDEDORISMO SOCIAL E TERCEIRO SETOR	34
45473	1703.000.244-7	FEDERALISMO E POLÍTICAS PÚBLICAS	34
41032	1703.000.163-8	GESTÃO DE AGRONEGÓCIOS	68
45453	1703.000.224-0	GESTÃO DE EVENTOS	34
45457	1703.000.228-7	GESTÃO DE SERVIÇOS E VAREJO	68
45459	1703.000.230-2	GESTÃO DO TURISMO	34
45479	1703.000.250-9	GOVERNANÇA E COMPLIANCE	34
45455	1703.000.226-9	INGLÊS BÁSICO	68
45436	1703.000.207-1	LEITURA E PRODUÇÃO DE TEXTOS	68
45445	1703.000.216-0	MARKETING DE SERVIÇOS E VAREJO	34
45450	1703.000.221-3	MERCADO DE CAPITAIS	34
41047	1703.000.178-6	NEGÓCIOS INTERNACIONAIS	68
45451	1703.000.222-2	PLANEJAMENTO DE VENDAS E TÉCNICAS DE NEGOCIAÇÃO	34
45461	1703.000.232-0	PLANEJAMENTO E GESTÃO EM ORGANIZAÇÕES PÚBLICAS	68
45476	1703.000.247-4	PLANEJAMENTO TRIBUTÁRIO	34
45447	1703.000.218-9	SOCIOLOGIA RURAL	34
45437	1703.000.208-0	TÓPICOS CONTEMPORÂNEOS EM ADMINISTRAÇÃO	34
45440	1703.000.211-5	TÓPICOS CONTEMPORÂNEOS EM AMBIENTE, CIÊNCIA E SOCIEDADE	34
45434	1703.000.205-3	TÓPICOS CONTEMPORÂNEOS EM ECONOMIA E SOCIEDADE	34
45443	1703.000.214-2	TÓPICOS CONTEMPORÂNEOS EM POLÍTICA E SOCIEDADE	34
45433	1703.000.204-4	TÓPICOS EM GESTÃO: IMERSÃO EM ORGANIZAÇÕES PÚBLICAS, PRIVADAS E DO TERCEIRO SETOR	34
52086	1703.000.525-1	DESENHO ARQUITETÔNICO I	68
47372	1703.000.391-8	DESENHO UNIVERSAL	34
50057	1703.000.462-0	ESTUDOS DA FORMA E COMPOSIÇÃO I	68
50049	1703.000.454-0	ESTUDOS SOCIAIS NA ARQ. E URBANISMO	34
50048	1703.000.453-0	FUNDAMENTOS E PRÁTICAS EM ARQUITETURA E URBANISMO	68
50069	1703.000.474-6	MATERIAIS DE CONSTRUÇÃO I	34
50044	1703.000.449-7	MATERIAIS DE CONSTRUÇÃO II	34
52082	1703.000.521-5	ATELIÊ DE PROJETO INTEGRADO I	68
52087	1703.000.526-0	DESENHO ARQUITETÔNICO II	68
52090	1703.000.529-8	ESTÁTICA DAS ESTRUTURAS	34
50076	1703.000.481-7	ESTUDOS DA FORMA E COMPOSIÇÃO II	68
50034	1703.000.439-9	GEOMETRIA DESCRITIVA	34
50070	1703.000.475-5	RESISTÊNCIA DOS MATERIAIS	68
52097	1703.000.536-9	TEORIA E ESTÉTICA DA ARQUITETURA E URBANISMO I	34
52102	1703.000.541-1	TEORIA E ESTÉTICA DA ARQUITETURA E URBANISMO II	34
52098	1703.000.537-8	TOPOGRAFIA	68
52079	1703.000.518-0	ATELIÊ DE PROJETO INTEGRADO II	68
52091	1703.000.530-4	COMUNICAÇÃO VISUAL	68
50064	1703.000.469-3	CONFORTO AMBIENTAL I	68
50052	1703.000.457-7	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO I	68
50073	1703.000.478-2	REPRESENTAÇÃO DIGITAL I	68
50063	1703.000.468-4	TECNOLOGIAS CONSTRUTIVAS I	34
50068	1703.000.473-7	TECNOLOGIAS CONSTRUTIVAS II	34
50060	1703.000.465-7	ARQUITETURA DA PAISAGEM I	68
52077	1703.000.516-2	ATELIÊ DE PROJETO INTEGRADO III	68
50065	1703.000.470-0	CONFORTO AMBIENTAL II	68
50053	1703.000.458-6	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO II	68
50072	1703.000.477-3	REPRESENTAÇÃO DIGITAL II	68
50046	1703.000.451-2	SISTEMAS CONSTRUTIVOS	68
50059	1703.000.464-8	ARQUITETURA DA PAISAGEM II	68
52084	1703.000.523-3	ATELIÊ DE PROJETO INTEGRADO IV	68
50061	1703.000.466-6	CONFORTO AMBIENTAL III	68
50071	1703.000.476-4	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO III	68
50066	1703.000.471-9	INSTALAÇÕES HIDRÁULICAS PREDIAIS	34
50067	1703.000.472-8	MECÂNICA DOS SOLOS E FUNDAÇÕES	34
50038	1703.000.443-2	PROJETO DE INSTALAÇÕES HIDRÁULICAS	34
52092	1703.000.531-3	PROJETO DE URBANISMO I	68
52080	1703.000.519-0	ATELIÊ DE PROJETO INTEGRADO V	68
52088	1703.000.527-0	ESTRUTURAS DE CONCRETO	68
50054	1703.000.459-5	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO IV	68
50062	1703.000.467-5	INSTALAÇÕES ELÉTRICAS PREDIAIS	34
50035	1703.000.440-5	PROJETO DE INSTALAÇÕES ELÉTRICAS	34
52093	1703.000.532-2	PROJETO DE URBANISMO II	68
52096	1703.000.535-0	TEORIA E TÉCNICAS DA PRESERVAÇÃO	68
52083	1703.000.522-4	ATELIÊ DE PROJETO INTEGRADO VI	68
50055	1703.000.460-1	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO V	68
52099	1703.000.538-7	INFRAESTRUTURA URBANA	68
52100	1703.000.539-6	PLANEJAMENTO URBANO E REGIONAL I	68
52094	1703.000.533-1	PROJETO DE URBANISMO III	68
52078	1703.000.517-1	ATELIÊ DE PROJETO INTEGRADO VII	68
52081	1703.000.520-6	ESTÁGIO OBRIGATÓRIO EM ARQUITETURA E URBANISMO	68
52095	1703.000.534-0	ESTRUTURAS DE AÇO E MADEIRA	68
50056	1703.000.461-0	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO VI	68
52085	1703.000.524-2	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
52089	1703.000.528-9	PLANEJAMENTO URBANO E REGIONAL II	68
50058	1703.000.463-9	ÉTICA E EXERCÍCIO PROFISSIONAL DA ARQUITETURA E URBANISMO	34
52101	1703.000.540-2	PESQUISA EM ARQUITETURA E URBANISMO	34
50075	1703.000.480-8	PLANEJAMENTO DE OBRAS	34
46149	1703.000.316-8	AVALIAÇÃO PÓS-OCUPAÇÃO	68
46148	1703.000.315-9	DETALHAMENTO DE PROJETO	68
46115	1703.000.282-1	ESTUDOS DE LIBRAS	68
46125	1703.000.292-0	ESTUDOS ESPECIAIS EM DESENHO URBANO	68
46127	1703.000.294-8	MAQUETES	68
46128	1703.000.295-7	PERSPECTIVAS	68
46157	1703.000.324-8	SUSTENTABILIDADE NA ARQUITETURA E URBANISMO	68
47350	1703.000.369-6	TÓPICOS EM PROJETO DE ARQUITETURA E URBANISMO I	68
47351	1703.000.370-2	TÓPICOS EM PROJETO DE ARQUITETURA E URBANISMO II	68
47352	1703.000.371-1	TÓPICOS EM PROJETO DE ARQUITETURA E URBANISMO III	68
47355	1703.000.374-9	TÓPICOS EM REPRESENTAÇÃO E LINGUAGEM I	68
47356	1703.000.375-8	TÓPICOS EM REPRESENTAÇÃO E LINGUAGEM II	68
47346	1703.000.365-0	TÓPICOS EM REPRESENTAÇÃO E LINGUAGEM III	68
47347	1703.000.366-9	TÓPICOS EM TECNOLOGIA DA CONSTRUÇÃO I	68
47348	1703.000.367-8	TÓPICOS EM TECNOLOGIA DA CONSTRUÇÃO II	68
47357	1703.000.376-7	TÓPICOS EM TECNOLOGIA DA CONSTRUÇÃO III	68
47349	1703.000.368-7	TÓPICOS EM TEORIA E HISTÓRIA DA ARQUITETURA E URBANISMO I	68
47353	1703.000.372-0	TÓPICOS EM TEORIA E HISTÓRIA DA ARQUITETURA E URBANISMO II	68
47354	1703.000.373-0	TÓPICOS EM TEORIA E HISTÓRIA DA ARQUITETURA E URBANISMO III	68
48554	1803.000.329-5	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
44040	1803.000.261-8	FUNDAMENTOS DE DIDÁTICA	51
48572	1803.000.347-3	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
48575	1803.000.350-8	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
44041	1803.000.262-7	POLÍTICAS EDUCACIONAIS	51
48551	1803.000.326-8	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
48565	1803.000.340-0	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
48560	1803.000.335-7	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
44038	1803.000.259-2	EDUCAÇÃO ESPECIAL	51
48573	1803.000.348-2	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
48555	1803.000.330-1	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
48558	1803.000.333-9	PRÁTICA DE ENSINO DE MATEMÁTICA I	68
44043	1803.000.264-5	PSICOLOGIA E EDUCAÇÃO	51
48576	1803.000.351-7	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
44039	1803.000.260-9	ESTUDO DE LIBRAS	51
37487	1803.000.077-0	FÍSICA ELEMENTAR	68
48579	1803.000.354-4	LEITURA E PRODUÇÃO DE TEXTOS	68
48561	1803.000.336-6	LÓGICA MATEMÁTICA	68
48566	1803.000.341-9	PRÁTICA DE ENSINO DE MATEMÁTICA II	68
48553	1803.000.328-6	CÁLCULO I	68
38921	1803.000.224-1	FÍSICA I	68
38900	1803.000.212-8	GEOMETRIA PLANA	68
48571	1803.000.346-4	PRÁTICA DE ENSINO DE MATEMÁTICA III	68
48568	1803.000.343-7	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
38961	1803.000.248-9	TRIGONOMETRIA E NÚMEROS COMPLEXOS	68
38912	1803.000.215-2	ÁLGEBRA I	68
48570	1803.000.345-5	CÁLCULO II	68
48574	1803.000.349-1	ESTÁGIO OBRIGATÓRIO I	100
38913	1803.000.216-0	GEOMETRIA ESPACIAL	68
48563	1803.000.338-4	PRÁTICA DE ENSINO DE MATEMÁTICA IV	68
37479	1803.000.073-7	VETORES E GEOMETRIA ANALÍTICA	68
38915	1803.000.218-7	ÁLGEBRA II	68
38918	1803.000.221-7	ÁLGEBRA LINEAR	102
48569	1803.000.344-6	CÁLCULO III	68
48578	1803.000.353-5	ESTÁGIO OBRIGATÓRIO II	100
48562	1803.000.337-5	PRÁTICA DE ENSINO DE MATEMÁTICA V	68
48552	1803.000.327-7	ESTÁGIO OBRIGATÓRIO III	100
48567	1803.000.342-8	INTRODUÇÃO À ANÁLISE REAL	68
38382	1803.000.192-0	INTRODUÇÃO À COMPUTAÇÃO	68
48564	1803.000.339-3	INTRODUÇÃO ÀS EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	102
48556	1803.000.331-0	PRÁTICA DE ENSINO DE MATEMÁTICA VI	68
48557	1803.000.332-0	ANÁLISE REAL	68
48559	1803.000.334-8	ESTÁGIO OBRIGATÓRIO IV	100
48577	1803.000.352-6	HISTÓRIA DA MATEMÁTICA	68
38937	1803.000.231-4	ÁLGEBRA DOS NÚMEROS	68
38938	1803.000.232-2	AVALIAÇÃO ESCOLAR	68
38939	1803.000.233-0	CÁLCULO AVANÇADO	68
37494	1803.000.081-8	CÁLCULO NUMÉRICO	68
38940	1803.000.234-9	CONSTRUÇÕES GEOMÉTRICAS	68
33580	1803.000.044-3	EDUCAÇÃO A DISTÂNCIA	68
44042	1803.000.263-6	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
33567	1803.000.031-1	EDUCAÇÃO DE JOVENS E ADULTOS	68
44045	1803.000.266-3	EDUCAÇÃO FINANCEIRA	68
33582	1803.000.046-0	ESTUDOS AFRO-BRASILEIROS E ÉTNICOS RACIAIS	68
33584	1803.000.048-6	ÉTICA NA EDUCAÇÃO	68
38941	1803.000.235-7	FÍSICA II	68
37571	1803.000.118-0	FÍSICA III	68
38942	1803.000.236-5	FÍSICA IV	68
38943	1803.000.237-3	FUNÇÕES DE UMA VARIÁVEL COMPLEXA	68
38890	1803.000.207-1	FUNDAMENTOS DE MATEMÁTICA	68
44048	1803.000.269-0	FUNDAMENTOS PARA O ENSINO DE MATEMÁTICA	68
44032	1803.000.253-8	GEOMETRIA DO ENSINO BÁSICO	68
33549	1803.000.013-3	HISTÓRIA DA EDUCAÇÃO	68
33534	1803.000.003-6	INTRODUÇÃO À METODOLOGIA CIENTÍFICA	68
33587	1803.000.051-6	INTRODUÇÃO A MODELAGEM MATEMÁTICA	68
38945	1803.000.239-0	INTRODUÇÃO ÀS EQUAÇÕES DIFERENCIAIS PARCIAIS	68
44035	1803.000.256-5	INTRODUÇÃO A TEORIA DOS NÚMEROS	68
38947	1803.000.240-3	LABORATÓRIO DE SUPORTE ÀS DISCIPLINAS BÁSICAS DE MATEMÁTICA	34
30796	1802.000.182-0	LÍNGUA PORTUGUESA	68
37467	1803.000.068-0	MATEMÁTICA ELEMENTAR	102
38949	1803.000.241-1	MATEMÁTICA FINANCEIRA	68
33555	1803.000.019-2	PLANEJAMENTO E PROJETOS EDUCACIONAIS	68
33599	1803.000.063-0	POLÍTICA DE INCLUSÃO NAS RELAÇÕES SOCIAIS	68
33559	1803.000.023-0	POLÍTICAS EDUCACIONAIS E FORMAÇÃO DE PROFESSORES	68
37488	1803.000.078-8	PROBABILIDADE E ESTATÍSTICA	68
44046	1803.000.267-2	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
44031	1803.000.252-9	RESOLUÇÃO DE PROBLEMAS NO ENSINO DE MATEMÁTICA	68
44034	1803.000.255-6	SEMINÁRIO DE PESQUISA I	34
44030	1803.000.251-0	SEMINÁRIO DE PESQUISA II	68
33550	1803.000.014-1	SOCIOLOGIA	68
38951	1803.000.242-0	TÓPICOS DE ÁLGEBRA MODERNA	68
38953	1803.000.243-8	TÓPICOS DE ANÁLISE MATEMÁTICA	68
44033	1803.000.254-7	TÓPICOS EM MATEMÁTICA BÁSICA	68
44044	1803.000.265-4	TÓPICOS EM MODELAGEM COMPUTACIONAL	68
44036	1803.000.257-4	TÓPICOS NO ENSINO DE FÍSICA	68
48670	1803.000.370-4	ALGORITMOS E PROGRAMAÇÃO I	102
48663	1803.000.363-3	FUNDAMENTOS DA ADMINISTRAÇÃO	68
48669	1803.000.369-8	INTRODUÇÃO À COMPUTAÇÃO	34
37465	1803.000.067-2	MATEMÁTICA DISCRETA	68
48674	1803.000.374-0	MATEMÁTICA ELEMENTAR	68
48673	1803.000.373-1	ALGORITMOS E PROGRAMAÇÃO II	102
48656	1803.000.356-2	CÁLCULO I	68
37469	1803.000.069-9	FUNDAMENTOS DE SISTEMAS DE INFORMAÇÃO	68
37477	1803.000.072-9	INTRODUÇÃO A SISTEMAS DIGITAIS	68
37480	1803.000.074-5	ARQUITETURA DE COMPUTADORES I	68
48662	1803.000.362-4	ESTATÍSTICA	68
37484	1803.000.076-1	ESTRUTURAS DE DADOS E PROGRAMAÇÃO	102
48668	1803.000.368-9	GESTÃO ESTRATÉGICA	68
48678	1803.000.378-7	BANCO DE DADOS	68
48655	1803.000.355-3	ENGENHARIA DE SOFTWARE	68
48659	1803.000.359-0	INTRODUÇÃO A SISTEMAS OPERACIONAIS	68
48661	1803.000.361-5	LINGUAGEM DE PROGRAMAÇÃO ORIENTADA A OBJETOS	68
48675	1803.000.375-0	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS	68
48660	1803.000.360-6	LABORATÓRIO DE BANCO DE DADOS	68
48672	1803.000.372-2	LINGUAGENS DE PROGRAMAÇÃO COMERCIAIS	68
37528	1803.000.091-5	REDES DE COMPUTADORES I	68
48679	1803.000.379-6	COMPUTAÇÃO DISTRIBUÍDA	68
48676	1803.000.376-9	COMPUTAÇÃO E SOCIEDADE	34
48677	1803.000.377-8	GERÊNCIA DE PROJETOS	68
48664	1803.000.364-2	PROGRAMAÇÃO PARA WEB	68
48666	1803.000.366-0	SISTEMAS DE APOIO À DECISÃO	68
38369	1803.000.179-2	ESTÁGIO OBRIGATÓRIO I	204
48657	1803.000.357-1	INTELIGÊNCIA ARTIFICIAL	68
48658	1803.000.358-0	INTERAÇÃO HUMANO-COMPUTADOR	68
48665	1803.000.365-1	QUALIDADE DE SOFTWARE	68
48671	1803.000.371-3	COMÉRCIO ELETRÔNICO	68
38372	1803.000.182-2	ESTÁGIO OBRIGATÓRIO II	204
48667	1803.000.367-0	SEGURANÇA E AUDITORIA DE SISTEMAS	68
37557	1803.000.104-0	ADMINISTRAÇÃO DE REDES DE COMPUTADORES	68
37482	1803.000.075-3	ÁLGEBRA LINEAR	68
37501	1803.000.084-2	ANÁLISE DE ALGORITMOS I	68
38376	1803.000.186-5	APLICAÇÕES DO CÁLCULO	34
37498	1803.000.083-4	ARQUITETURA DE COMPUTADORES II	68
38377	1803.000.187-3	COMPORTAMENTO ORGANIZACIONAL	68
37547	1803.000.101-6	COMPUTAÇÃO GRÁFICA	68
37562	1803.000.109-1	COMPUTAÇÃO MÓVEL	68
38378	1803.000.188-1	COMPUTADORES E SOCIEDADE	68
37662	1803.000.172-5	CONTABILIDADE DE CUSTOS	68
37565	1803.000.112-1	DIREITO	68
38379	1803.000.189-0	DIVERSIDADE ÉTNICO-RACIAL E ÉTICA NAS RELAÇÕES DE TRABALHO	34
37569	1803.000.116-4	ESTRUTURAS DE ARQUIVOS E PROGRAMAÇÃO	102
37570	1803.000.117-2	ESTUDO DE LIBRAS	68
38380	1803.000.190-3	FUNDAMENTOS TEÓRICOS DE COMPUTAÇÃO	34
37574	1803.000.121-0	GESTÃO AMBIENTAL EM EMPRESAS DE TI	68
38381	1803.000.191-1	GESTÃO DO CONHECIMENTO	68
37575	1803.000.122-9	GOVERNANÇA DE TI	68
37576	1803.000.123-7	HIPERMÍDIA E MULTIMÍDIA	68
33545	1803.000.009-5	INFORMÁTICA NA EDUCAÇÃO	68
37583	1803.000.130-0	INTRODUÇÃO A ECONOMIA	68
38383	1803.000.193-8	LABORATÓRIO DE ESTRUTURA DE ARQUIVOS	34
38384	1803.000.194-6	LABORATÓRIO DE ESTRUTURA DE DADOS	34
37587	1803.000.133-4	LEITURA E REDAÇÃO CIENTÍFICA	68
37507	1803.000.088-5	LINGUAGENS FORMAIS E AUTÔMATOS	68
38385	1803.000.195-4	LÍNGUA INGLESA	68
37588	1803.000.134-2	LÍNGUA PORTUGUESA	68
38386	1803.000.196-2	ORGANIZAÇÃO, SISTEMAS E MÉTODOS	68
37614	1803.000.147-4	SISTEMAS DE INFORMAÇÃO EMPRESARIAIS	68
37613	1803.000.146-6	SISTEMAS DISTRIBUÍDOS	68
37506	1803.000.087-7	SISTEMAS OPERACIONAIS II	68
38387	1803.000.197-0	TÓPICOS EM ADMINISTRAÇÃO DE EMPRESAS I	68
37616	1803.000.149-0	TÓPICOS EM ARQUITETURA DE COMPUTADORES	68
37664	1803.000.174-1	TÓPICOS EM BANCO DE DADOS	68
37621	1803.000.152-0	TÓPICOS EM COMPILADORES	68
37623	1803.000.153-9	TÓPICOS EM COMPUTAÇÃO DE ALTO DESEMPENHO	68
37624	1803.000.154-7	TÓPICOS EM CRIPTOGRAFIA	68
37628	1803.000.155-5	TÓPICOS EM ENGENHARIA DE SOFTWARE	68
37629	1803.000.156-3	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL	68
37631	1803.000.157-1	TÓPICOS EM INTERAÇÃO HUMANO-COMPUTADOR	68
37633	1803.000.158-0	TÓPICOS EM LINGUAGEM DE PROGRAMAÇÃO	68
37635	1803.000.159-8	TÓPICOS EM MODELAGEM COMPUTACIONAL I	68
37637	1803.000.161-0	TÓPICOS EM MULTIMÍDIA	68
37638	1803.000.162-8	TÓPICOS EM PROCESSAMENTO DE IMAGENS	68
38390	1803.000.200-4	TÓPICOS EM PROGRAMAÇÃO I	68
37639	1803.000.163-6	TÓPICOS EM REDES DE COMPUTADORES I	68
38393	1803.000.203-9	TÓPICOS EM SISTEMAS DE INFORMAÇÃO I	68
37641	1803.000.165-2	TÓPICOS EM SISTEMAS DISTRIBUÍDOS	68
37642	1803.000.166-0	TÓPICOS EM SISTEMAS OPERACIONAIS I	68
37643	1803.000.167-9	TÓPICOS EM SISTEMAS OPERACIONAIS II	68
37644	1803.000.168-7	TÓPICOS EM TEORIA DA COMPUTAÇÃO	68
37645	1803.000.169-5	TÓPICOS EM TEORIA DOS GRAFOS	68
49864	1803.000.400-4	EDUCAÇÃO ESPECIAL	68
49845	1803.000.381-1	FILOSOFIA DA EDUCAÇÃO	68
49861	1803.000.397-4	HISTÓRIA DA EDUCAÇÃO I	68
52113	1803.000.455-0	PRÁTICAS PEDAGÓGICAS I	51
49867	1803.000.403-1	SOCIOLOGIA DA EDUCAÇÃO	68
49859	1803.000.395-6	TRABALHO ACADÊMICO	68
49865	1803.000.401-3	CURRÍCULO E EDUCAÇÃO	68
49860	1803.000.396-5	DIDÁTICA I	68
49866	1803.000.402-2	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
49862	1803.000.398-3	HISTÓRIA DA EDUCAÇÃO II	68
52105	1803.000.447-0	PRÁTICAS PEDAGÓGICAS II	51
49863	1803.000.399-2	PSICOLOGIA DA EDUCAÇÃO	68
49868	1803.000.404-0	DIDÁTICA II	68
49879	1803.000.415-8	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
52106	1803.000.448-0	FUNDAMENTOS E METODOLOGIA DA EDUCAÇÃO INFANTIL	68
49885	1803.000.421-0	INFÂNCIA E SOCIEDADE	68
49873	1803.000.409-6	POLÍTICAS EDUCACIONAIS	68
49882	1803.000.418-5	PSICOLOGIA DA APRENDIZAGEM E DO DESENVOLVIMENTO	68
49876	1803.000.412-0	ESTÁGIO OBRIGATÓRIO I	100
49869	1803.000.405-0	ESTUDO DE LIBRAS	68
52107	1803.000.449-9	FUNDAMENTOS E METODOLOGIA DA ALFABETIZAÇÃO E LETRAMENTO	68
49875	1803.000.411-1	GESTÃO ESCOLAR	68
49907	1803.000.443-4	LUDICIDADE E EDUCAÇÃO	68
49888	1803.000.424-7	ESTÁGIO OBRIGATÓRIO EM GESTÃO ESCOLAR	68
49886	1803.000.422-9	ESTÁGIO OBRIGATÓRIO II	100
49881	1803.000.417-6	FUNDAMENTOS E METODOLOGIA DO ENSINO DE LÍNGUA PORTUGUESA	68
49883	1803.000.419-4	FUNDAMENTOS E METODOLOGIA DO ENSINO DE MATEMÁTICA	68
49874	1803.000.410-2	LITERATURA INFANTIL NA ESCOLA	68
49877	1803.000.413-0	CORPOREIDADE E MOVIMENTO	68
49890	1803.000.426-5	ESTÁGIO OBRIGATÓRIO III	100
49889	1803.000.425-6	FUNDAMENTOS E METODOLOGIA DO ENSINO DE CIÊNCIAS	68
52115	1803.000.457-9	FUNDAMENTOS E METODOLOGIA DO ENSINO DE HISTÓRIA E GEOGRAFIA	68
52114	1803.000.456-0	PRÁTICAS PEDAGÓGICAS III	102
49887	1803.000.423-8	AÇÃO EDUCATIVA EM CONTEXTOS NÃO ESCOLARES	68
49870	1803.000.406-9	ARTE E EDUCAÇÃO	68
49910	1803.000.446-1	EDUCAÇÃO DE JOVENS E ADULTOS	68
49908	1803.000.444-3	EDUCAÇÃO, DIVERSIDADE E DIREITOS HUMANOS	68
49905	1803.000.441-6	ESTÁGIO OBRIGATÓRIO IV	100
52109	1803.000.451-4	EDUCAÇÃO INTERCULTURAL	68
49897	1803.000.433-6	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
49896	1803.000.432-7	CULTURA, MULTICULTURALISMO E INTERCULTURALIDADE	68
52108	1803.000.450-5	EDUCAÇÃO AMBIENTAL E SUSTENTABILIDADE	68
49898	1803.000.434-5	EDUCAÇÃO ESCOLAR INDÍGENA	68
49891	1803.000.427-4	EDUCAÇÃO E SEXUALIDADE	68
52110	1803.000.452-3	EDUCAÇÃO ESPECIAL E INCLUSÃO ESCOLAR: DESENVOLVIMENTO DE AÇÕES AFIRMATIVAS	68
44895	1803.000.286-0	EDUCAÇÃO, MULTICULTURALISMO E INTERCULTURALIDADE	68
49853	1803.000.389-4	PRÁTICA PEDAGÓGICA E FORMAÇÃO DE PROFESSORES: EDUCAÇÃO INCLUSIVA E MULTICULTURAL	102
49852	1803.000.388-5	PRÁTICA PEDAGÓGICA EM AÇÃO: TÓPICOS ESPECIAIS EM FORMAÇÃO DE PROFESSORES	102
49856	1803.000.392-9	PRÁTICA PEDAGÓGICA EM ALFABETIZAÇÃO E LETRAMENTO	102
49854	1803.000.390-0	PRÁTICA PEDAGÓGICA EM AMBIENTES NÃO ESCOLARES: A BRINQUEDOTECA COMO ESPAÇO DE FORMAÇÃO	102
49855	1803.000.391-0	PRÁTICA PEDAGÓGICA EM CONTEXTOS NÃO ESCOLARES	102
49858	1803.000.394-7	PRÁTICA PEDAGÓGICA EM EDUCAÇÃO ESPECIAL	102
49844	1803.000.380-2	PRÁTICA PEDAGÓGICA EM JOGOS, BRINQUEDOS E BRINCADEIRAS: A LUDICIDADE COMO CAMPO DE CONSTRUÇÃO DA APRENDIZAGEM	102
49846	1803.000.382-0	PRÁTICA PEDAGÓGICA E PESQUISA ACADÊMICA: FORMAÇÃO DE PROFESSORES E PROFISSÃO DOCENTE	102
49851	1803.000.387-6	PRÁTICA PEDAGÓGICA FRONTEIRIÇA: MULTICULTURALISMO E MULTILINGUISMO	102
49901	1803.000.437-2	TÓPICOS EM AFETIVIDADE E EMOÇÕES NO ENSINO E NA APRENDIZAGEM	68
49906	1803.000.442-5	TÓPICOS EM EDUCAÇÃO ESPECIAL E INCLUSIVA: MARCOS LEGAIS E TEMPORAIS	68
49893	1803.000.429-2	TÓPICOS EM FORMAÇÃO DE PROFESSORES E FRONTEIRA	68
49904	1803.000.440-7	TÓPICOS EM HISTÓRIA DA EDUCAÇÃO BRASILEIRA E ENSINO	68
49903	1803.000.439-0	TÓPICOS EM HISTÓRIA DA EDUCAÇÃO: INSTITUIÇÕES ESCOLARES E PENSAMENTO PEDAGÓGICO	68
49899	1803.000.435-4	TÓPICOS EM METODOLOGIAS ATIVAS E TECNOLOGIAS DIGITAIS	68
49895	1803.000.431-8	TÓPICOS EM METODOLOGIAS DO ENSINO DE CIÊNCIAS	68
49892	1803.000.428-3	TÓPICOS EM POLÍTICAS EDUCACIONAIS E FRONTEIRA	68
49900	1803.000.436-3	TÓPICOS EM PROJETOS EDUCACIONAIS INTERDISCIPLINARES	68
49902	1803.000.438-1	TÓPICOS EM TEORIAS DE ENSINO E DA APRENDIZAGEM	68
52111	1803.000.453-2	TÓPICOS ESPECIAIS DE ALFABETIZAÇÃO EM CONTEXTOS MULTILÍNGUES	68
52112	1803.000.454-1	TÓPICOS ESPECIAIS EDUCAÇÃO ESPECIAL INCLUSIVA	68
45398	1919.000.402-9	ALGORITMOS E PROGRAMAÇÃO I	102
48016	2201.000.197-0	CÁLCULO I	68
45389	1919.000.393-4	COMPUTAÇÃO E SOCIEDADE	34
48585	1919.000.444-0	INTRODUÇÃO À COMPUTAÇÃO	34
48008	2201.000.195-2	VETORES E GEOMETRIA ANALÍTICA	68
45399	1919.000.403-8	ALGORITMOS E PROGRAMAÇÃO II	102
48017	2201.000.198-0	CÁLCULO II	68
45418	1919.000.422-5	FUNDAMENTOS DE TEORIA DA COMPUTAÇÃO	68
48019	2201.000.200-0	SEQUÊNCIAS E SÉRIES	34
36270	1919.000.308-2	SISTEMAS DIGITAIS	68
48330	2201.000.202-9	ÁLGEBRA LINEAR	68
48603	1919.000.455-7	BANCO DE DADOS	68
45412	1919.000.416-3	ESTRUTURAS DE DADOS	68
45405	1919.000.409-2	LINGUAGEM DE PROGRAMAÇÃO ORIENTADA A OBJETOS	68
35450	1919.000.226-4	LINGUAGENS FORMAIS E AUTÔMATOS	68
35498	1919.000.273-6	ARQUITETURA DE COMPUTADORES I	68
45416	1919.000.420-7	ENGENHARIA DE SOFTWARE	68
48009	2201.000.196-1	PROBABILIDADE E ESTATÍSTICA	68
35503	1919.000.278-7	PROJETO E ANÁLISE DE ALGORITMOS I	68
45263	1919.000.390-7	TEORIA DOS GRAFOS E SEUS ALGORITMOS	68
35427	1919.000.204-3	ARQUITETURA DE COMPUTADORES II	68
35430	1919.000.207-8	COMPILADORES I	68
45422	1919.000.426-1	INTELIGÊNCIA ARTIFICIAL	68
48582	2201.000.204-7	MÉTODOS NUMÉRICOS	68
45417	1919.000.421-6	SISTEMAS OPERACIONAIS	68
35505	1919.000.280-9	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS	68
35431	1919.000.208-6	COMPUTAÇÃO GRÁFICA	68
48581	1919.000.442-1	PROGRAMAÇÃO PARALELA	68
35507	1919.000.282-5	REDES DE COMPUTADORES	68
45397	1919.000.401-0	SISTEMAS DISTRIBUÍDOS	68
45411	1919.000.415-4	ADMINISTRAÇÃO DE SISTEMAS	68
29375	1919.000.167-5	ANÁLISE DE SINAIS E SISTEMAS	68
35426	1919.000.203-5	ANÁLISE FORENSE COMPUTACIONAL	68
39974	1919.000.365-1	ARQUITETURA DE SOFTWARE	68
48318	2201.000.201-0	CÁLCULO III	68
36156	1919.000.296-5	COMPILADORES II	68
48599	2501.000.204-2	COMPORTAMENTO HUMANO E ORGANIZACIONAL	68
45401	1919.000.405-6	COMUNICAÇÃO E TRANSMISSÃO DE DADOS	34
41084	1919.000.386-3	CONFIABILIDADE EM SISTEMAS DE SOFTWARE	68
45409	1919.000.413-6	CONSTRUÇÃO DE SOFTWARE	102
35435	1919.000.212-4	DESAFIOS DE PROGRAMAÇÃO	68
45388	1919.000.392-5	DESAFIOS DE PROGRAMAÇÃO II	68
35436	1919.000.213-2	DESENVOLVIMENTO DE LINHAS DE PRODUTO DE SOFTWARE	68
24760	2001.000.097-0	DIREITOS HUMANOS	68
45407	1919.000.411-8	ENGENHARIA DE REQUISITOS	68
48606	1919.000.458-4	ENGENHARIA DE SOFTWARE EXPERIMENTAL	68
48018	2201.000.199-9	EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	34
48596	2501.000.202-4	FUNDAMENTOS DA ADMINISTRAÇÃO	68
48032	2401.000.258-8	FUNDAMENTOS DE ELETROMAGNETISMO	68
48034	2401.000.260-3	FUNDAMENTOS DE MECÂNICA	68
35440	1919.000.217-5	GEOMETRIA COMPUTACIONAL	68
48588	1919.000.447-7	GERÊNCIA DE CONFIGURAÇÃO DE SOFTWARE	34
37052	1919.000.339-2	GERÊNCIA DE PROJETOS	68
48594	2501.000.201-5	GESTÃO ESTRATÉGICA	68
45488	1919.000.439-7	GOVERNANÇA DE TECNOLOGIA DA INFORMAÇÃO	68
45415	1919.000.419-0	INTERAÇÃO HUMANO-COMPUTADOR	68
40188	2501.000.008-4	INTRODUÇÃO À ADMINISTRAÇÃO	68
35444	1919.000.221-3	INTRODUÇÃO À BIOINFORMÁTICA	68
36259	1919.000.298-1	INTRODUÇÃO À COMPLEXIDADE COMPUTACIONAL	68
40185	2501.000.005-0	INTRODUÇÃO À CONTABILIDADE	68
35446	1919.000.223-0	INTRODUÇÃO À CRIPTOGRAFIA COMPUTACIONAL	68
42900	2501.000.134-0	INTRODUÇÃO À ECONOMIA	68
42901	3001.000.299-7	INTRODUÇÃO À PSICOLOGIA	68
42903	3001.000.301-2	INTRODUÇÃO ÀS CIÊNCIAS SOCIAIS E POLÍTICAS	68
42902	3001.000.300-4	INTRODUÇÃO À SOCIOLOGIA	68
36261	1919.000.299-0	JOGOS DIGITAIS I	68
36262	1919.000.300-7	JOGOS DIGITAIS II	68
45396	1919.000.400-0	LABORATÓRIO DE BANCO DE DADOS	68
36263	1919.000.301-5	LABORATÓRIO DE HARDWARE	68
36264	1919.000.302-3	LINGUAGEM DE MONTAGEM	68
41076	1919.000.378-3	MANUTENÇÃO DE SOFTWARE	34
41077	1919.000.379-2	MEDIÇÃO DE SOFTWARE	34
48580	1919.000.441-2	MELHORIA DE PROCESSOS DE SOFTWARE	34
45394	1919.000.398-0	METODOLOGIA CIENTÍFICA PARA COMPUTAÇÃO	68
41083	1919.000.385-4	MÉTODOS FORMAIS EM ENGENHARIA DE SOFTWARE	68
35497	1919.000.272-8	MODELAGEM DE PROCESSOS DE NEGÓCIO	68
35452	1919.000.227-2	OTIMIZAÇÃO COMBINATÓRIA	68
35453	1919.000.228-0	PROGRAMAÇÃO LINEAR	68
35454	1919.000.229-9	PROGRAMAÇÃO MULTI-CORE	68
45392	1919.000.396-1	PROGRAMAÇÃO PARA DISPOSITIVOS MÓVEIS	68
45408	1919.000.412-7	PROGRAMAÇÃO PARA REDES	34
45410	1919.000.414-5	PROGRAMAÇÃO PARA WEB	68
35511	1919.000.286-8	QUALIDADE DE SOFTWARE	68
35460	1919.000.235-3	REDES DEFINIDAS POR SOFTWARE	68
45403	1919.000.407-4	REDES SEM FIO	34
45425	1919.000.429-9	SEGURANÇA DE REDES	68
35518	1919.000.292-2	SEGURANÇA E AUDITORIA DE SISTEMAS	68
45420	1919.000.424-3	SISTEMAS DE APOIO À DECISÃO	68
45426	1919.000.430-5	TÉCNICAS AVANÇADAS DE DESENVOLVIMENTO DE SOFTWARE	68
49831	2501.000.258-0	TEORIA GERAL DA ADMINISTRAÇÃO	68
35467	1919.000.242-6	TÓPICOS EM ARQUITETURA DE COMPUTADORES	68
48604	1919.000.456-6	TÓPICOS EM BANCOS DE DADOS I	68
48586	1919.000.445-9	TÓPICOS EM BANCOS DE DADOS II	68
48590	1919.000.449-5	TÓPICOS EM BANCOS DE DADOS III	34
48592	1919.000.451-0	TÓPICOS EM BANCOS DE DADOS IV	34
35469	1919.000.244-2	TÓPICOS EM COMPUTAÇÃO GRÁFICA	68
35470	1919.000.245-0	TÓPICOS EM COMPUTAÇÃO I	68
35471	1919.000.246-9	TÓPICOS EM COMPUTAÇÃO II	68
35472	1919.000.247-7	TÓPICOS EM COMPUTAÇÃO III	68
45413	1919.000.417-2	TÓPICOS EM COMPUTAÇÃO IV	34
45419	1919.000.423-4	TÓPICOS EM COMPUTAÇÃO V	34
45406	1919.000.410-9	TÓPICOS EM COMPUTAÇÃO VI	34
41074	1919.000.376-5	TÓPICOS EM EMPREENDEDORISMO	68
37061	1919.000.348-1	TÓPICOS EM ENGENHARIA DE COMPUTAÇÃO I	68
37062	1919.000.349-0	TÓPICOS EM ENGENHARIA DE COMPUTAÇÃO II	68
37063	1919.000.350-3	TÓPICOS EM ENGENHARIA DE COMPUTAÇÃO III	68
48605	1919.000.457-5	TÓPICOS EM ENGENHARIA DE SOFTWARE I	68
48587	1919.000.446-8	TÓPICOS EM ENGENHARIA DE SOFTWARE II	68
48589	1919.000.448-6	TÓPICOS EM ENGENHARIA DE SOFTWARE III	68
48591	1919.000.450-1	TÓPICOS EM ENGENHARIA DE SOFTWARE IV	34
48593	1919.000.452-0	TÓPICOS EM ENGENHARIA DE SOFTWARE V	34
35474	1919.000.249-3	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL I	68
35475	1919.000.250-7	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL II	68
35476	1919.000.251-5	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL III	68
35477	1919.000.252-3	TÓPICOS EM PROCESSAMENTO DE IMAGENS	68
35478	1919.000.253-1	TÓPICOS EM REDES DE COMPUTADORES I	68
35479	1919.000.254-0	TÓPICOS EM REDES DE COMPUTADORES II	68
35480	1919.000.255-8	TÓPICOS EM REDES DE COMPUTADORES III	68
35481	1919.000.256-6	TÓPICOS EM SISTEMAS DE INFORMAÇÃO I	68
35482	1919.000.257-4	TÓPICOS EM SISTEMAS DE INFORMAÇÃO II	68
35483	1919.000.258-2	TÓPICOS EM SISTEMAS DE INFORMAÇÃO III	68
35484	1919.000.259-0	TÓPICOS EM SISTEMAS DIGITAIS	68
35485	1919.000.260-4	TÓPICOS EM SISTEMAS DISTRIBUÍDOS I	68
35486	1919.000.261-2	TÓPICOS EM SISTEMAS DISTRIBUÍDOS II	68
35487	1919.000.262-0	TÓPICOS EM SISTEMAS DISTRIBUÍDOS III	68
35488	1919.000.263-9	TÓPICOS EM SISTEMAS OPERACIONAIS	68
35489	1919.000.264-7	TÓPICOS EM TEORIA DOS GRAFOS	68
45423	1919.000.427-0	TÓPICOS EM TESTES DE SOFTWARE	68
45400	1919.000.404-7	TÓPICOS - INTERCÂMBIO I	68
45421	1919.000.425-2	TÓPICOS - INTERCÂMBIO II	68
45404	1919.000.408-3	TÓPICOS - INTERCÂMBIO III	68
45395	1919.000.399-9	VERIFICAÇÃO, VALIDAÇÃO E TESTE DE SOFTWARE	68
48723	2401.000.287-3	LABORATÓRIO DE MECÂNICA, FLUIDOS E TERMODINÂMICA	34
48031	2401.000.257-9	FUNDAMENTOS DE FLUIDOS, ONDAS E TERMODINÂMICA	68
48812	2401.000.290-8	LABORATÓRIO DE ONDAS E ELETRICIDADE E MAGNETISMO	34
50169	2401.000.308-4	MECÂNICA GERAL	34
37066	2101.001.023-0	CIRCUITOS ELÉTRICOS	68
34320	2101.000.823-6	MECÂNICA DOS SÓLIDOS	51
37068	1919.000.353-8	CIRCUITOS ELETRÔNICOS	102
37069	1919.000.354-6	CONTROLE E SERVOMECANISMOS	102
42904	2501.000.130-7	FUNDAMENTOS DE ECONOMIA	34
50254	2101.001.443-0	FUNDAMENTOS DE FENÔMENOS DOS TRANSPORTES	34
37070	1919.000.355-4	MICROCONTROLADORES E APLICAÇÕES	102
49467	2301.000.405-2	QUÍMICA GERAL EXPERIMENTAL	34
37071	1919.000.356-2	SISTEMAS DE INTEGRAÇÃO E AUTOMAÇÃO INDUSTRIAL	68
51771	2101.001.613-0	DESENHO POR COMPUTADOR	34
45220	2501.000.156-4	INTRODUÇÃO A GESTÃO ORGANIZACIONAL	34
45402	1919.000.406-5	ORGANIZAÇÃO DE COMPUTADORES	68
40250	2501.000.070-0	COMPORTAMENTO ORGANIZACIONAL	68
45428	1919.000.432-3	COMPUTAÇÃO DISTRIBUÍDA	68
45431	1919.000.434-1	CONTROLE DIGITAL	68
45427	1919.000.431-4	IMPLEMENTAÇÃO ALGORÍTMICA	68
35458	1919.000.233-7	PROJETO E ANÁLISE DE ALGORITMOS II	68
37059	1919.000.346-5	SISTEMAS EMBARCADOS	68
48583	2201.000.205-6	ESTATÍSTICA	68
45430	1919.000.433-2	FUNDAMENTOS MATEMÁTICOS PARA COMPUTAÇÃO	34
48584	1919.000.443-0	INTRODUÇÃO À ENGENHARIA DE SOFTWARE	34
45484	1919.000.435-0	INTRODUÇÃO A SISTEMAS OPERACIONAIS	68
45486	1919.000.437-9	FUNDAMENTOS DE REDES DE COMPUTADORES	68
48598	1919.000.454-8	PRÁTICA EM DESENVOLVIMENTO DE SOFTWARE I	272
48595	1919.000.453-9	PRÁTICA EM DESENVOLVIMENTO DE SOFTWARE II	272
32044	2101.000.504-0	DESENVOLVIMENTO DE PLANO DE NEGÓCIOS E ESTRATÉGIA DE PRODUÇÃO	34
48602	2001.000.381-9	DIREITOS HUMANOS	68
24594	2001.000.041-5	DIREITOS HUMANOS I	34
24596	2001.000.043-1	DIREITOS HUMANOS II	34
48600	2101.001.406-4	EDUCAÇÃO AMBIENTAL	51
51115	2101.001.468-1	ERGONOMIA	34
45485	1919.000.436-0	GERENCIAMENTO DE SERVIÇOS DE TECNOLOGIA DA INFORMAÇÃO	68
50144	2101.001.414-4	GESTÃO DA QUALIDADE	51
46486	2101.001.376-4	GESTÃO DE NEGÓCIOS	51
48597	2501.000.203-3	GESTÃO DE PESSOAS	68
46490	2101.001.380-8	GESTÃO DE PROJETOS NA ENGENHARIA	51
48601	3001.000.625-7	INTRODUÇÃO À PSICOLOGIA	68
48331	2201.000.203-8	MATEMÁTICA ELEMENTAR	68
51138	2101.001.491-2	MERCADOLOGIA	34
42623	3001.000.148-6	METODOLOGIA CIENTÍFICA	34
46475	2101.001.365-7	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
51120	2101.001.473-4	PESQUISA OPERACIONAL I	68
44085	2901.000.538-2	TEORIA DA COR	34
40251	2501.000.071-8	TEORIAS ADMINISTRATIVAS	68
35468	1919.000.243-4	TÓPICOS EM BANCOS DE DADOS	68
35473	1919.000.248-5	TÓPICOS EM ENGENHARIA DE SOFTWARE	68
34020	2101.000.793-0	ELETRICIDADE	51
35447	2201.000.092-6	INTRODUÇÃO AO CÁLCULO	102
35496	1919.000.271-0	INTRODUÇÃO A SISTEMAS DIGITAIS	34
49582	1919.000.460-0	TÓPICOS EM BANCOS DE DADOS IV	34
46916	2001.000.361-2	ANTROPOLOGIA E SOCIOLOGIA JURÍDICA	68
49427	2001.000.392-6	CIÊNCIA POLÍTICA E TEORIA GERAL DO ESTADO	68
46926	2001.000.371-0	COMUNICAÇÃO, LINGUAGEM E REDAÇÃO JURÍDICA	34
46917	2001.000.362-1	HISTÓRIA DO DIREITO	68
49430	2001.000.395-3	TEORIA DO DIREITO	68
46915	2001.000.360-3	TEORIA DO DIREITO PRIVADO I	68
49425	2001.000.390-8	DIREITO PENAL - PARTE GERAL I	68
49433	2001.000.398-0	ECONOMIA POLÍTICA	34
49454	2001.000.419-1	FILOSOFIA GERAL E JURÍDICA	68
49450	2001.000.415-5	INTRODUÇÃO À METODOLOGIA DA PESQUISA	34
46914	2001.000.359-7	TEORIA DO DIREITO PRIVADO II	68
49441	2001.000.406-6	DIREITO CONSTITUCIONAL I	68
49432	2001.000.397-1	DIREITO DAS OBRIGAÇÕES	68
49445	2001.000.410-0	DIREITO DO TRABALHO I	68
49426	2001.000.391-7	DIREITO PENAL - PARTE GERAL II	68
49417	2001.000.382-8	DIREITO PROCESSUAL CIVIL - PARTE GERAL I	68
46891	2001.000.336-3	TEORIA GERAL DOS DIREITOS DIFUSOS E COLETIVOS	34
46897	2001.000.342-5	DIREITO CONSTITUCIONAL II	68
49451	2001.000.416-4	DIREITO CONTRATUAL	68
49420	2001.000.385-5	DIREITO DO CONSUMIDOR	34
49446	2001.000.411-9	DIREITO DO TRABALHO II	68
49452	2001.000.417-3	DIREITO PENAL ESPECIAL I	68
49421	2001.000.386-4	DIREITO PROCESSUAL CIVIL - PARTE GERAL II	68
49448	2001.000.413-7	CONTRATOS EM ESPÉCIE	68
49424	2001.000.389-1	DIREITO AMBIENTAL	68
49442	2001.000.407-5	DIREITO PENAL ESPECIAL II	34
49447	2001.000.412-8	DIREITO PROCESSUAL DO TRABALHO	68
49453	2001.000.418-2	DIREITO PROCESSUAL PENAL I	68
49436	2001.000.401-0	TUTELA DE CONHECIMENTO	68
49418	2001.000.383-7	DIREITO DAS COISAS	68
49444	2001.000.409-3	DIREITO PREVIDENCIÁRIO E SEGURIDADE SOCIAL	68
24777	2001.000.114-4	DIREITO PROCESSUAL PENAL II	68
49429	2001.000.394-4	ÉTICA PROFISSIONAL	34
46929	2001.000.374-8	FORMAS CONSENSUAIS DE SOLUÇÃO DE CONFLITOS E ARBITRAGEM	68
49434	2001.000.399-0	TUTELA EXECUTIVA	68
49419	2001.000.384-6	DIREITO ADMINISTRATIVO I	68
27248	2001.000.173-0	DIREITO PROCESSUAL PENAL III	34
49438	2001.000.403-9	DIREITOS REAIS SOBRE COISAS ALHEIAS	68
22615	2001.000.006-7	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA I	68
46930	2001.000.375-7	TEORIA DOS DIREITOS E DEVERES FUNDAMENTAIS	34
49435	2001.000.400-1	TUTELA RECURSAL	68
49423	2001.000.388-2	DIREITO ADMINISTRATIVO II	68
46893	2001.000.338-1	DIREITO AGRÁRIO	34
49437	2001.000.402-0	DIREITO DE FAMÍLIA	68
49443	2001.000.408-4	DIREITO FINANCEIRO	34
22620	2001.000.011-3	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA II	68
49431	2001.000.396-2	PSICOLOGIA APLICADA AO DIREITO	34
49449	2001.000.414-6	DIREITO DAS SUCESSÕES	68
46888	2001.000.333-6	DIREITO EMPRESARIAL I	68
46905	2001.000.350-5	DIREITO INTERNACIONAL DOS DIREITOS HUMANOS	34
46906	2001.000.351-4	DIREITO INTERNACIONAL PÚBLICO	34
22622	2001.000.013-0	DIREITO TRIBUTÁRIO I	68
24826	2001.000.163-2	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA III	68
46896	2001.000.341-6	METODOLOGIA APLICADA AO TRABALHO DE CONCLUSÃO DE CURSO	34
49428	2001.000.393-5	DIREITO DIGITAL E TECNOLÓGICO	34
46883	2001.000.328-3	DIREITO EMPRESARIAL II	68
46886	2001.000.331-8	DIREITO INTERNACIONAL PRIVADO	68
49440	2001.000.405-7	DIREITO PROCESSUAL CONSTITUCIONAL	34
49439	2001.000.404-8	DIREITO TRIBUTÁRIO II	68
27254	2001.000.179-9	ESTÁGIO OBRIGATÓRIO - PRÁTICA JURÍDICA IV	68
46932	2001.000.377-5	AÇÕES CONSTITUCIONAIS	34
46889	2001.000.334-5	ADMINISTRAÇÃO PÚBLICA, DIREITOS FUNDAMENTAIS E DESENVOLVIMENTO SUSTENTÁVEL	34
46903	2001.000.348-0	ARGUMENTAÇÃO JURÍDICA: LÓGICA E RETÓRICA	34
46900	2001.000.345-2	BIOÉTICA E BIODIREITO	34
34091	2001.000.266-3	CRIMINOLOGIA	34
46907	2001.000.352-3	DIREITO DAS ORGANIZAÇÕES INTERNACIONAIS	34
46882	2001.000.327-4	DIREITO DESPORTIVO	34
46933	2001.000.378-4	DIREITO DO COMÉRCIO INTERNACIONAL	34
34099	2001.000.274-4	DIREITO ECONÔMICO E REGULAÇÃO	34
34101	2001.000.276-0	DIREITO EDUCACIONAL	34
49422	2001.000.387-3	DIREITO E IGUALDADE DE GÊNERO	68
46925	2001.000.370-1	DIREITO ELEITORAL	34
46874	2001.000.319-4	DIREITO INTERNACIONAL DOS REFUGIADOS E MIGRAÇÕES	34
34103	2001.000.278-7	DIREITO INTERNACIONAL DO TRABALHO	34
46922	2001.000.367-7	DIREITO INTERNACIONAL HUMANITÁRIO	34
34104	2001.000.279-5	DIREITO MUNICIPAL	34
46920	2001.000.365-9	DIREITO PENAL ESPECIAL	34
46884	2001.000.329-2	DIREITO PORTUÁRIO	34
46919	2001.000.364-0	DIREITOS ESPECIAIS	34
34107	2001.000.282-5	DIREITO URBANÍSTICO	34
46890	2001.000.335-4	EDUCAÇÃO EM DIREITOS HUMANOS	34
46904	2001.000.349-9	ÉTICA E EDUCAÇÃO AMBIENTAL	34
34115	2001.000.288-4	HERMENEUTICA JURÍDICA	34
46931	2001.000.376-6	JUIZADOS ESPECIAIS	34
34080	2001.000.255-8	MEDICINA LEGAL	34
49455	2001.000.420-8	METODOLOGIA APLICADA AO ENSINO SUPERIOR JURÍDICO	68
46923	2001.000.368-6	PROCEDIMENTOS ESPECIAIS PREVISTOS NO CPC E OUTRAS LEIS EXTRAVAGANTES	34
34121	2001.000.294-9	PROCESSO ADMINISTRATIVO TRIBUTÁRIO	34
46918	2001.000.363-0	TÓPICOS ESPECIAIS DE DIREITO PÚBLICO	34
46881	2001.000.326-5	TÓPICOS ESPECIAIS DE DIREITOS COLETIVOS	34
46921	2001.000.366-8	TUTELA INTERNACIONAL DOS DIREITOS HUMANOS	34
51319	2101.001.559-0	ESTUDOS DA FORMA E COMPOSIÇÃO I	68
51282	2101.001.522-1	ESTUDOS SOCIAIS NA ARQUITETURA E URBANISMO	34
51285	2101.001.525-9	FUNDAMENTOS E PRÁTICAS EM ARQUITETURA E URBANISMO	68
51302	2101.001.542-8	GEOMETRIA DESCRITIVA	34
51286	2101.001.526-8	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO I	68
51320	2101.001.560-6	MATERIAIS DE CONSTRUÇÃO I	34
51310	2101.001.550-8	REPRESENTAÇÃO DIGITAL I	68
38807	2101.001.178-4	SUSTENTABILIDADE NA ARQUITETURA E URBANISMO	34
51304	2101.001.544-6	TOPOGRAFIA	68
51753	2101.001.610-2	ANÁLISE E CONCEPÇÃO DE ESTRUTURAS	51
38810	2101.001.181-4	CONFORTO AMBIENTAL I	68
51288	2101.001.528-6	DESENHO UNIVERSAL	34
51324	2101.001.564-2	ESTUDOS DA FORMA E COMPOSIÇÃO II	68
51299	2101.001.539-3	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO II	68
51321	2101.001.561-5	MATERIAIS DE CONSTRUÇÃO II	34
38528	2101.001.140-7	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
51311	2101.001.551-7	REPRESENTAÇÃO DIGITAL II	68
51305	2101.001.545-5	ARQUITETURA DA PAISAGEM I	68
31527	2101.000.023-5	CONFORTO AMBIENTAL II	68
51325	2101.001.565-1	ESTÁTICA DAS ESTRUTURAS	51
51300	2101.001.540-0	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO III	68
31534	2101.000.030-8	PLANEJAMENTO URBANO I	68
40492	2101.001.262-4	PROJETO I	102
51294	2101.001.534-8	TECNOLOGIAS CONSTRUTIVAS I	34
51322	2101.001.562-4	ARQUITETURA DA PAISAGEM II	68
51291	2101.001.531-0	CONFORTO AMBIENTAL III	68
51290	2101.001.530-1	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO IV	68
40498	2101.001.268-3	MECÂNICA DOS SOLOS E FUNDAÇÕES	34
51323	2101.001.563-3	PLANEJAMENTO URBANO II	68
40496	2101.001.266-7	PROJETO II	102
51309	2101.001.549-1	RESISTÊNCIA DOS MATERIAIS	68
51295	2101.001.535-7	TECNOLOGIAS CONSTRUTIVAS II	34
51296	2101.001.536-6	CONSTRUIR E HABITAR I	51
51318	2101.001.558-0	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO V	68
40502	2101.001.272-1	INSTALAÇÕES ELÉTRICAS PREDIAIS	34
40503	2101.001.273-0	INSTALAÇÕES HIDRÁULICAS PREDIAIS	34
40500	2101.001.270-5	PLANEJAMENTO URBANO III	68
51314	2101.001.554-4	PRÉ-DIMENSIONAMENTO DE ESTRUTURAS	68
40501	2101.001.271-3	PROJETO III	102
51317	2101.001.557-1	TECNOLOGIAS CONSTRUTIVAS III	34
51297	2101.001.537-5	CONSTRUIR E HABITAR II	51
51292	2101.001.532-0	GEOPROCESSAMENTO PARA PLANEJAMENTO E PROJETO	68
51287	2101.001.527-7	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO VI	68
51303	2101.001.543-7	INFRAESTRUTURA URBANA	68
40507	2101.001.277-2	PROJETO IV	102
51326	2101.001.566-0	CONSTRUIR E HABITAR III	51
51283	2101.001.523-0	PLANEJAMENTO REGIONAL I	68
51289	2101.001.529-5	PROJETO DOS ESPAÇOS LIVRES URBANOS	51
51313	2101.001.553-5	TÉCNICA, HISTÓRIA E PROJETO I	51
38848	2101.001.219-5	TEORIA E ESTÉTICA DA ARQUITETURA E URBANISMO I	34
51327	2101.001.567-0	CONSTRUIR E HABITAR IV	51
40512	2101.001.282-9	PLANEJAMENTO REGIONAL II	68
51298	2101.001.538-4	PROJETO INTEGRADO	102
51307	2101.001.547-3	TÉCNICA, HISTÓRIA E PROJETO II	68
38854	2101.001.225-0	TEORIA E ESTÉTICA DA ARQUITETURA E URBANISMO II	34
51301	2101.001.541-9	ÉTICA E EXERCÍCIO PROFISSIONAL DA ARQUITETURA E URBANISMO	34
40473	2101.001.243-8	PLANEJAMENTO DE OBRAS	34
51308	2101.001.548-2	PLANEJAMENTO E GESTÃO AMBIENTAL	51
38757	2101.001.152-0	ARQUITETURA DE MATO GROSSO DO SUL	51
51312	2101.001.552-6	ARQUITETURA E CIDADE	51
40469	2101.001.239-0	ARQUITETURA, ENERGIA E MEIO AMBIENTE: PROJETO	51
51284	2101.001.524-0	ATELIÊ PAISAGEM E AMBIENTE	102
33950	2101.000.730-2	AVALIAÇÕES E PERÍCIAS NA CONSTRUÇÃO CIVIL	51
33956	2101.000.736-1	CONCRETO PROTENDIDO	51
33959	2101.000.739-6	CONSTRUÇÃO CIVIL	51
40470	2101.001.240-3	DESIGN PARAMÉTRICO E FABRICAÇÃO DIGITAL	51
33964	2101.000.744-2	EFICIÊNCIA ENERGÉTICA EM EDIFICAÇÕES	51
38761	2101.001.155-5	ESTRUTURAS DE AÇO	51
38763	2101.001.156-3	ESTRUTURAS DE MADEIRA	51
38765	2101.001.157-1	ESTUDOS ESPECIAIS EM CONCEPÇÃO DE ESTRUTURAS	51
40471	2101.001.241-1	ESTUDOS ESPECIAIS EM DESENHO URBANO	51
38768	2101.001.159-8	ETNOBOTÂNICA	51
38769	2101.001.160-1	FOTOGRAFIA	51
51293	2101.001.533-9	HISTÓRIA DA ARTE, ARQUITETURA E URBANISMO VII	51
38770	2101.001.161-0	HISTÓRIA E ESTÉTICA DA PAISAGEM	34
51315	2101.001.555-3	INTELIGÊNCIA ARTIFICIAL APLICADA À ARQUITETURA	51
40472	2101.001.242-0	MAQUETES	51
38772	2101.001.163-6	PATRIMÔNIO CULTURAL E ARQUITETÔNICO	51
40475	2101.001.245-4	PLANEJAMENTO E PROJETO DE ARBORIZAÇÃO URBANA	51
40828	2101.001.327-2	PLANEJAMENTO URBANO IV	68
38774	2101.001.165-2	PLANTAS E PROJETO DE PLANTAÇÃO	51
40476	2101.001.246-2	PROJETO DE COMUNICAÇÃO VISUAL	51
40477	2101.001.247-0	PROJETO DE EDIFICAÇÕES EM MADEIRA	51
40478	2101.001.248-9	PROJETO DE INTERIORES	51
51306	2101.001.546-4	PROJETO EXECUTIVO	68
40479	2101.001.249-7	REPRESENTAÇÃO E EXPRESSÃO GRÁFICA EM PROJETO	51
38783	2101.001.170-9	SANEAMENTO AMBIENTAL	68
34033	2101.000.804-0	SEGURANÇA DO TRABALHO	34
51316	2101.001.556-2	TEORIA E ESTÉTICA DA ARQUITETURA E URBANISMO III	51
40480	2101.001.250-0	TÓPICOS ESPECIAIS EM RESTAURO E CONSERVAÇÃO	51
40481	2101.001.251-9	TÓPICOS ESPECÍFICOS EM ARQUITETURA E URBANISMO	51
34010	2101.000.790-6	VENTILAÇÃO E ILUMINAÇÃO NATURAL	51
48791	1919.000.459-3	ALGORITMOS E PROGRAMAÇÃO	51
50151	2101.001.421-5	GEOMETRIA DESCRITIVA	51
31697	2101.000.179-7	INTRODUÇÃO A ENGENHARIA CIVIL	34
50139	2101.001.409-1	DESENHO TÉCNICO CIVIL	51
46512	2101.001.401-9	FUNDAMENTOS DE ECONOMIA	34
50157	2101.001.426-0	ESTÁTICA DAS ESTRUTURAS I	85
50173	2101.001.441-1	REPRESENTAÇÃO DE PROJETOS DE ENGENHARIA	51
50171	2101.001.439-6	ARQUITETURA E URBANISMO	51
50150	2101.001.420-6	CIÊNCIA E TECNOLOGIA DOS MATERIAIS	34
50164	2101.001.433-1	ELETRICIDADE	51
31859	2101.000.337-4	GEOLOGIA GERAL	68
50160	2101.001.429-8	RESISTÊNCIA DOS MATERIAIS I	85
31858	2101.000.336-6	TOPOGRAFIA	68
50159	2101.001.428-9	FENÔMENOS DE TRANSPORTE	85
46511	2101.001.400-0	FUNDAMENTOS DE ADMINISTRAÇÃO	34
31599	2101.000.083-9	MATERIAIS DE CONSTRUÇÃO CIVIL I	51
31613	2101.000.097-9	MECÂNICA DOS SOLOS	85
50165	2101.001.434-0	RESISTÊNCIA DOS MATERIAIS II	85
50146	2101.001.416-2	AÇÕES, SEGURANÇA E CONCEPÇÃO ESTRUTURAL	34
34023	2101.000.794-9	ENGENHARIA DE TRANSPORTES I	68
50166	2101.001.435-0	ESTÁTICA DAS ESTRUTURAS II	85
50161	2101.001.430-4	HIDRÁULICA	85
34024	2101.000.795-7	INSTALAÇÕES ELÉTRICAS	51
50172	2101.001.440-2	MATERIAIS DE CONSTRUÇÃO CIVIL II	51
31617	2101.000.101-0	OBRAS DE TERRA	51
50167	2101.001.436-9	CONCRETO ARMADO I	85
50158	2101.001.427-0	CONSTRUÇÕES DE EDIFÍCIOS	85
34027	2101.000.798-1	ENGENHARIA DE TRANSPORTES II	34
50168	2101.001.437-8	ESTRUTURAS METÁLICAS	51
31619	2101.000.103-7	FUNDAÇÕES I	51
31712	2101.000.193-2	HIDROLOGIA GERAL	68
31539	2101.000.035-9	INSTALAÇÕES HIDRÁULICAS PREDIAIS	68
50174	2101.001.442-0	CONCRETO ARMADO II	85
50152	2101.001.422-4	EFICIÊNCIA ENERGÉTICA EM EDIFICAÇÕES	68
45266	2101.001.351-2	ESTRADAS I	51
34028	2101.000.799-0	FUNDAÇÕES II	68
46513	2101.001.402-8	LEGISLAÇÃO, ÉTICA PROFISSIONAL E CIDADANIA	34
34035	2101.000.806-6	SISTEMAS DE ÁGUA, ESGOTO E DRENAGEM	68
50147	2101.001.417-1	ANÁLISE ECONÔMICA DE PROJETOS	34
50148	2101.001.418-0	ANÁLISE MULTIVARIADA DE DADOS	34
45267	2101.001.352-1	ESTRADAS II	85
50140	2101.001.410-8	LÓGICA DA PESQUISA CIENTÍFICA	34
50138	2101.001.408-2	PLANEJAMENTO DE OBRAS	51
50149	2101.001.419-0	PONTES DE CONCRETO	68
50153	2101.001.423-3	PROJETOS DE SISTEMAS DE ÁGUA, ESGOTO E DRENAGEM	68
34030	2101.000.801-5	ESTÁGIO OBRIGATÓRIO	160
50170	2101.001.438-7	ESTRUTURAS DE MADEIRA	34
50154	2101.001.424-2	PROJETO DE EDIFÍCIOS	85
31638	2101.000.121-5	ADUTORAS E ELEVATÓRIAS	68
33944	2101.000.724-8	AEROPORTOS, PORTOS E VIAS NAVEGÁVEIS	68
31637	2101.000.120-7	ÁGUAS SUBTERRÂNEAS	68
33945	2101.000.725-6	ALVENARIA ESTRUTURAL	51
33946	2101.000.726-4	ANÁLISE DE FLUXO E PRESSÕES EM SISTEMAS DE ARMAZENAMENTO	51
33947	2101.000.727-2	ANÁLISE DE TENSÕES E DEFORMAÇÕES EM PAVIMENTOS	51
31698	2101.000.180-0	ANÁLISE E CONTROLE DE SISTEMAS DE DISTRIBUIÇÃO DE ÁGUA	68
46476	2101.001.366-6	ANÁLISE E GERENCIAMENTO DE RISCOS	34
50145	2101.001.415-3	ANÁLISE E PRODUÇÃO DE TEXTOS E APRESENTAÇÕES PARA ENGENHARIA	34
51755	2101.001.611-1	ANÁLISE EXPERIMENTAL DE ELEMENTOS ESTRUTURAIS DE CONCRETO ARMADO	51
33948	2101.000.728-0	ANÁLISE EXPERIMENTAL EM ENGENHARIA CIVIL	34
46488	2101.001.378-2	ANÁLISE FINANCEIRA DE PROJETOS	51
33949	2101.000.729-9	ANÁLISE MATRICIAL DAS ESTRUTURAS	51
31642	2101.000.125-8	APROVEITAMENTOS HIDRÁULICOS	68
31643	2101.000.126-6	AQUAVIAS E DUTOVIAS	68
31889	2101.000.362-5	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
46482	2101.001.372-8	CIDADES INTELIGENTES DO SÉCULO XXI	51
46483	2101.001.373-7	CIÊNCIAS DE DADOS APLICADA	51
34034	2101.000.805-8	COMPLEMENTOS DE ESTRADAS	51
33951	2101.000.731-0	COMPLEMENTOS DE FUNDAÇÕES E OBRAS DE TERRA	51
33952	2101.000.732-9	COMPLEMENTOS DE MECÂNICA DOS FLUIDOS	51
46506	2101.001.395-1	COMPLEMENTOS DE MECÂNICA DOS SOLOS	34
33954	2101.000.734-5	COMPLEMENTOS DE PONTES DE CONCRETO	51
33955	2101.000.735-3	COMPLEMENTOS DE RESISTÊNCIA DOS MATERIAIS	51
46493	2101.001.383-5	COMUNICAÇÃO	51
42908	2901.000.480-5	COMUNICAÇÃO E EXPRESSÃO	34
46500	2101.001.389-0	CONFIABILIDADE ESTRUTURAL	68
33957	2101.000.737-0	CONFORTO EM EDIFICAÇÕES	51
33958	2101.000.738-8	CONSERVAÇÃO DE RODOVIAS	34
46484	2101.001.374-6	CONSTRUÇÃO 4.0	51
33960	2101.000.740-0	CONTROLE E MELHORIA DA QUALIDADE	51
46480	2101.001.370-0	DESEMPENHO TÉRMICO DE EDIFICAÇÕES	51
46501	2101.001.390-6	DIAGNÓSTICO E HIGIENE OCUPACIONAL	34
33962	2101.000.742-6	DINÂMICA DAS ESTRUTURAS	51
33963	2101.000.743-4	DRENAGEM DE VIAS TERRESTRES	51
31903	2101.000.376-5	DRENAGEM URBANA	51
31705	2101.000.187-8	EFICIÊNCIA ENERGÉTICA EM HIDRÁULICA E SANEAMENTO	51
33965	2101.000.745-0	ELEMENTOS FINITOS	51
36922	2101.000.987-9	ELETRÔNICA I	51
36925	2101.000.990-9	ELETRÔNICA II	51
46491	2101.001.381-7	EMPREENDEDORISMO E ESTRATÉGIA EMPRESARIAL	51
46481	2101.001.371-9	EMPREENDEDORISMO E INOVAÇÃO	68
31704	2101.000.186-0	EMPREENDEDORISMO E INOVAÇÃO TECNOLÓGICA	34
46510	2101.001.399-8	EMPREENDEDORISMO SOCIAL	68
46487	2101.001.377-3	ENGENHARIA DA INOVAÇÃO	51
33966	2101.000.746-9	ENGENHARIA DA QUALIDADE	51
33967	2101.000.747-7	ENGENHARIA DE TRÁFEGO	51
33968	2101.000.748-5	ENSAIOS E CONTROLE DE OBRAS DE PAVIMENTAÇÃO - SOLOS	51
33969	2101.000.749-3	ENSAIOS E CONTROLE DE OBRAS EM PAVIMENTAÇÃO - AGREGADOS E ASFALTOS	51
50143	2101.001.413-5	EQUAÇÕES DIFERENCIAIS APLICADAS À ENGENHARIA	34
46507	2101.001.396-0	ESTABILIDADE DE TALUDES E ESTRUTURAS DE CONTENÇÃO	34
33972	2101.000.752-3	ESTÁTICA DAS ESTRUTURAS III	51
33973	2101.000.753-1	ESTUDOS ESPECIAIS EM ENGENHARIA CIVIL I	51
33974	2101.000.754-0	ESTUDOS ESPECIAIS EM ENGENHARIA CIVIL II	51
33975	2101.000.755-8	ESTUDOS ESPECIAIS EM ENGENHARIA CIVIL III	51
33976	2101.000.756-6	FERROVIAS	51
33977	2101.000.757-4	FÍSICA DAS CONSTRUÇÕES	51
33979	2101.000.759-0	FUNDAMENTOS BIOLÓGICOS DO SANEAMENTO	51
50364	2601.000.431-6	EMPREENDEDORISMO	68
51756	2101.001.612-0	FUNDAMENTOS DE ESTÁTICA E MECÂNICA DAS ESTRUTURAS	51
33980	2101.000.760-4	FUNDAMENTOS SOBRE A INFRAESTRUTURA DE TRANSPORTES	51
33981	2101.000.761-2	GEOLOGIA DE ENGENHARIA	51
33982	2101.000.762-0	GEOPROCESSAMENTO	51
33983	2101.000.763-9	GEOTECNIA AMBIENTAL	51
46514	2101.001.403-7	GERENCIAMENTO DE PROJETOS SOCIAIS	68
33984	2101.000.764-7	GERENCIAMENTO NA CONSTRUÇÃO CIVIL	51
32042	2101.000.502-4	GESTÃO DA CADEIA DE SUPRIMENTOS	51
46497	2101.001.387-1	GESTÃO DA QUALIDADE, SAÚDE, MEIO AMBIENTE, SEGURANÇA E RESPONSABILIDADE SOCIAL	34
46504	2101.001.393-3	GESTÃO DE PESSOAS NA ENGENHARIA	68
50142	2101.001.412-6	GESTÃO DE PROJETOS	68
34342	2101.000.845-7	GESTÃO ENERGÉTICA	68
46489	2101.001.379-1	GESTÃO NA ENGENHARIA	51
46495	2101.001.385-3	HIDROLOGIA APLICADA	68
45265	2101.001.350-3	INFRAESTRUTURA E ECOTECNOLOGIAS	51
36936	2101.001.001-0	INSTALAÇÕES ELÉTRICAS INDUSTRIAIS I	68
36940	2101.001.005-2	INSTALAÇÕES ELÉTRICAS INDUSTRIAIS II	51
50155	2101.001.425-1	INSTRUMENTAÇÃO ELETRÔNICA	51
31949	2101.000.420-6	INSTRUMENTAÇÃO INDUSTRIAL	68
31846	2101.000.324-2	INTELIGÊNCIA ARTIFICIAL APLICADA À ENGENHARIA	51
33985	2101.000.765-5	INTERSECÇÕES RODOVIÁRIAS	51
33986	2101.000.766-3	INTRODUÇÃO À SIMULAÇÃO DE SISTEMAS DE TRANSPORTE	51
31671	2101.000.154-1	IRRIGAÇÃO E DRENAGEM	68
33987	2101.000.767-1	LOGÍSTICA E TRANSPORTES	51
33988	2101.000.768-0	LOGÍSTICA REVERSA	51
31852	2101.000.330-7	MÁQUINAS DE FLUXO E APROVEITAMENTO HIDROELÉTRICO	51
31673	2101.000.156-8	MÁQUINAS HIDRÁULICAS	68
46509	2101.001.398-9	MECÂNICA DAS ROCHAS	34
46492	2101.001.382-6	METODOLOGIA DE PESQUISA TECNOLÓGICA	68
31699	2101.000.181-9	MICROBIOLOGIA AMBIENTAL	68
31883	2101.000.356-0	MODELAGEM DE SISTEMAS AMBIENTAIS	68
33989	2101.000.769-8	MODELAGEM E SIMULAÇÃO DE SISTEMAS	51
31674	2101.000.157-6	NAVEGAÇÃO MARÍTIMA E INTERIOR	68
33990	2101.000.770-1	OBRAS DE PRÉ-MOLDADOS	51
31675	2101.000.158-4	OBRAS HIDRÁULICAS	68
50162	2101.001.431-3	PATOLOGIA DAS CONSTRUÇÕES	51
33992	2101.000.772-8	PAVIMENTOS RÍGIDOS	51
31996	2101.000.457-5	PESQUISA OPERACIONAL I	68
32007	2101.000.467-2	PESQUISA OPERACIONAL II	68
33993	2101.000.773-6	PESQUISA OPERACIONAL PARA SISTEMAS LOGÍSTICOS E ENGENHARIA DE TRANSPORTES	51
33994	2101.000.774-4	PLANEJAMENTO DE TRANSPORTE	51
31703	2101.000.185-1	PLANEJAMENTO E GESTÃO DE RECURSOS HÍDRICOS	68
33996	2101.000.776-0	PLANEJAMENTO URBANO E REGIONAL I	68
33997	2101.000.777-9	PLANEJAMENTO URBANO E REGIONAL II	68
31540	2101.000.036-7	PLANEJAMENTO URBANO II	68
31709	2101.000.190-8	PLANO DIRETOR DE RECURSOS HÍDRICOS	51
33998	2101.000.778-7	PONTES DE MADEIRA	51
33999	2101.000.779-5	PONTES METÁLICAS EM VIGA RETA	51
34000	2101.000.780-9	QUALIDADE NA CONSTRUÇÃO CIVIL	51
31702	2101.000.184-3	RESÍDUOS SÓLIDOS URBANOS E INDUSTRIAIS	68
31876	2101.000.349-8	SAÚDE AMBIENTAL	34
31874	2101.000.347-1	SENSORIAMENTO REMOTO AMBIENTAL	51
34001	2101.000.781-7	SISTEMAS DE GERÊNCIA DE PAVIMENTOS	51
34002	2101.000.782-5	SISTEMAS DE INFORMAÇÕES GEOGRÁFICAS APLICADOS À ENGENHARIA DE TRANSPORTES	68
46485	2101.001.375-5	SISTEMAS DE PRODUÇÃO 4.0 INTEGRADOS À GESTÃO 4.0	51
50163	2101.001.432-2	TECNOLOGIA DO CONCRETO	51
31684	2101.000.167-3	TECNOLOGIA E MATERIAIS NÃO-CONVENCIONAIS DE CONSTRUÇÃO	51
50141	2101.001.411-7	TÓPICOS EM CIÊNCIA E TECNOLOGIA DOS MATERIAIS	34
34005	2101.000.785-0	TÓPICOS ESPECIAIS DE CONCRETO ARMADO	51
34006	2101.000.786-8	TÓPICOS ESPECIAIS DE ESTRUTURAS DE MADEIRA	51
34007	2101.000.787-6	TÓPICOS ESPECIAIS DE ESTRUTURAS METÁLICAS	51
46508	2101.001.397-0	TÓPICOS ESPECIAIS DE FUNDAÇÕES	34
34009	2101.000.789-2	TRANSPORTE DE SEDIMENTOS E MECÂNICA FLUVIAL	68
34008	2101.000.788-4	TRANSPORTE PÚBLICO URBANO	51
31689	2101.000.172-0	TRATAMENTO DE ÁGUA	68
31911	2101.000.382-0	TRATAMENTO DE ESGOTO	85
36913	2101.000.979-8	INTRODUÇÃO A ENGENHARIA ELÉTRICA	34
48809	2101.001.407-3	DESENHO TÉCNICO	68
48719	2401.000.286-4	FUNDAMENTOS DE OSCILAÇÕES, ONDAS E FLUIDOS	34
50487	2101.001.448-5	INTRODUÇÃO AOS MATERIAIS ELÉTRICOS	34
50489	2101.001.450-0	CIRCUITOS DIGITAIS I	51
50488	2101.001.449-4	FUNDAMENTOS DE FENÔMENOS DOS TRANSPORTES	51
36917	2101.000.982-8	MEDIDAS ELÉTRICAS	51
36918	2101.000.983-6	CIRCUITOS ELÉTRICOS I	68
50486	2101.001.447-6	PROCESSAMENTO DE SINAIS	68
36923	2101.000.988-7	ANÁLISE DE SISTEMAS DINÂMICOS	68
36920	2101.000.985-2	CIRCUITOS DIGITAIS II	51
50497	2101.001.458-3	CIRCUITOS ELÉTRICOS II	68
50483	2101.001.444-9	CIRCUITOS ELETROMAGNÉTICOS	68
50493	2101.001.454-7	ELETRÔNICA I	51
36921	2101.000.986-0	PRINCÍPIOS DE COMUNICAÇÃO	51
36924	2101.000.989-5	TELEFONIA	34
36931	2101.000.996-8	CONVERSÃO ELETROMECÂNICA DE ENERGIA	51
36927	2101.000.992-5	ELETRÔNICA DE POTÊNCIA I	51
50492	2101.001.453-8	ELETRÔNICA II	51
50495	2101.001.456-5	INSTALAÇÕES ELÉTRICAS PREDIAIS	68
36928	2101.000.993-3	ONDAS E ANTENAS	51
50494	2101.001.455-6	SISTEMAS DE CONTROLE CLÁSSICO	68
36930	2101.000.995-0	TRANSFORMADORES	51
36934	2101.000.999-2	DISTRIBUIÇÃO DE ENERGIA ELÉTRICA	51
36935	2101.001.000-1	ELETRÔNICA DE POTÊNCIA II	51
36937	2101.001.002-8	MÁQUINAS ASSÍNCRONAS	51
36933	2101.000.998-4	MICROCONTROLADORES	51
50490	2101.001.451-0	SISTEMAS DE CONTROLE MODERNO	34
36938	2101.001.003-6	TRANSMISSÃO DE ENERGIA ELÉTRICA	68
36939	2101.001.004-4	ANÁLISE DE FLUXO DE POTÊNCIA	68
36944	2101.001.009-5	CIRCUITOS ELETRÔNICOS APLICADOS	34
36941	2101.001.006-0	INSTRUMENTAÇÃO INDUSTRIAL	51
36942	2101.001.007-9	MÁQUINAS SÍNCRONAS	51
36948	2101.001.013-3	ACIONAMENTOS ELETRÔNICOS DE MOTORES	51
36946	2101.001.011-7	ANÁLISE DE SISTEMAS DE POTÊNCIA	68
31741	2101.000.222-0	CONTROLADORES LÓGICOS PROGRAMÁVEIS	51
40522	2101.001.288-8	EFICIÊNCIA E GESTÃO ENERGÉTICA	51
36951	2101.001.016-8	PROTEÇÃO DE SISTEMAS ELÉTRICOS DE POTÊNCIA	51
36954	2101.001.019-2	ESTÁGIO OBRIGATÓRIO	170
36895	2101.000.962-3	ARQUITETURA DE COMPUTADORES DIGITAIS	51
42910	2501.000.107-2	COMPORTAMENTO ORGANIZACIONAL	68
36896	2101.000.963-1	CONTROLE DIGITAL	34
34016	2101.000.791-4	DESENHO TÉCNICO PARA ENGENHARIA	51
42909	3101.000.285-5	EDUCAÇÃO, CIDADANIA E DIREITOS HUMANOS	68
50496	2101.001.457-4	ELABORAÇÃO DE RELATÓRIO TÉCNICO	34
40545	2101.001.310-8	EMPREENDEDORISMO	68
40523	2101.001.289-6	FONTES DE ENERGIAS RENOVÁVEIS	51
40524	2101.001.290-0	GERAÇÃO DISTRIBUÍDA	51
40525	2101.001.291-8	INFRAESTRUTURA DE REDES COMPUTACIONAIS	68
36906	2101.000.973-9	INGLÊS TÉCNICO	34
50491	2101.001.452-9	INTRODUÇÃO AO PROJETO DE SISTEMAS FOTOVOLTAICOS ISOLADOS E CONECTADOS À REDE ELÉTRICA	34
40538	2101.001.304-3	INTRODUÇÃO À ROBÓTICA	51
42911	3001.000.307-1	INTRODUÇÃO ÀS CIÊNCIAS SOCIAIS E POLÍTICAS	68
36890	2101.000.957-7	INTRODUÇÃO À TEORIA DE DINÂMICA DE SISTEMAS	51
40526	2101.001.292-6	MANUTENÇÃO ELÉTRICA INDUSTRIAL	51
40527	2101.001.293-4	MÁQUINAS DE FLUXO E APROVEITAMENTO HIDROELÉTRICO	51
40547	2101.001.311-6	PESQUISA OPERACIONAL I	68
40548	2101.001.312-4	PESQUISA OPERACIONAL II	68
40529	2101.001.295-0	PLANEJAMENTO DE SISTEMAS ELÉTRICOS	51
50485	2101.001.446-7	PROCESSAMENTO DIGITAL DE SINAIS	34
40539	2101.001.305-1	PROJETO COM MICROCONTROLADORES	51
50484	2101.001.445-8	PROJETO INTEGRADOR	34
36900	2101.000.967-4	PROJETOS DE CIRCUITOS DIGITAIS	51
36901	2101.000.968-2	PROJETOS DE CIRCUITOS INTEGRADOS	51
40530	2101.001.296-9	QUALIDADE DE ENERGIA ELÉTRICA	51
40531	2101.001.297-7	SISTEMAS DE ENERGIA ININTERRUPTA	68
37065	1919.000.352-0	SOCIEDADE E AMBIENTE	34
43548	2401.000.221-6	TERMODINÂMICA	34
40540	2101.001.306-0	TÓPICOS EM ELETRÔNICA DE POTÊNCIA I	51
40541	2101.001.307-8	TÓPICOS EM ELETRÔNICA DE POTÊNCIA II	51
40532	2101.001.298-5	TÓPICOS EM ELETROTÉCNICA I	51
40533	2101.001.299-3	TÓPICOS EM ELETROTÉCNICA II	51
40542	2101.001.308-6	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL I	51
40543	2101.001.309-4	TÓPICOS EM INTELIGÊNCIA ARTIFICIAL II	51
40534	2101.001.300-0	TÓPICOS EM SISTEMAS ELÉTRICOS DE POTÊNCIA I	51
40535	2101.001.301-9	TÓPICOS EM SISTEMAS ELÉTRICOS DE POTÊNCIA II	51
40536	2101.001.302-7	TÓPICOS EM SMART GRID I	51
40537	2101.001.303-5	TÓPICOS EM SMART GRID II	51
31866	2101.000.341-2	INTRODUÇÃO A ENGENHARIA AMBIENTAL	34
35069	2101.000.928-3	QUÍMICA APLICADA À ENGENHARIA AMBIENTAL I	51
48798	2401.000.289-1	FUNDAMENTOS DE TERMODINÂMICA	34
35070	2101.000.929-1	QUÍMICA APLICADA À ENGENHARIA AMBIENTAL II	68
51344	2101.001.584-9	BIODIVERSIDADE E CONSERVAÇÃO	34
51339	2101.001.579-6	EPIDEMIOLOGIA E SAÚDE AMBIENTAL	34
51361	2101.001.601-3	GESTÃO AMBIENTAL	34
35095	2401.000.122-8	METEOROLOGIA E CLIMATOLOGIA	34
51340	2101.001.580-2	GEOTECNOLOGIAS AMBIENTAIS	68
51352	2101.001.592-9	MATERIAIS DE CONSTRUÇÃO CIVIL	51
51329	2101.001.569-8	QUALIDADE DA ÁGUA	68
31908	2101.000.380-3	DIREITO AMBIENTAL	34
35077	2101.000.935-6	ECOLOGIA APLICADA À ENGENHARIA AMBIENTAL	68
51360	2101.001.600-4	ENGENHARIA DAS REAÇÕES QUÍMICAS	68
51351	2101.001.591-0	HIDROLOGIA	85
51348	2101.001.588-5	MONITORAMENTO E ANÁLISES DE QUALIDADE DA ÁGUA	68
35079	2401.000.121-0	POLUIÇÃO ATMOSFÉRICA	68
51363	2101.001.603-1	MODELAGEM DE SISTEMAS AMBIENTAIS	68
51331	2101.001.571-3	PROJETOS DE SISTEMAS DE ABASTECIMENTO DE ÁGUA	51
51354	2101.001.594-7	TEORIA DAS ESTRUTURAS	68
51353	2101.001.593-8	TRATAMENTO DE ÁGUA	51
51334	2101.001.574-0	EROSÃO E CONSERVAÇÃO DO SOLO	51
51335	2101.001.575-0	ESTRUTURAS DE CONCRETO APLICADAS À ENGENHARIA AMBIENTAL	68
51362	2101.001.602-2	PLANEJAMENTO AMBIENTAL	34
51368	2101.001.608-7	PROJETO DE ESTAÇÃO DE TRATAMENTO DE ÁGUA	34
51358	2101.001.598-3	PROJETO DE INSTALAÇÕES HIDRÁULICAS, SANITÁRIAS E GÁS	51
51345	2101.001.585-8	PROJETOS DE SISTEMAS DE ESGOTAMENTO SANITÁRIO	51
51349	2101.001.589-4	TRATAMENTO DE ESGOTO	68
51347	2101.001.587-6	ÁREAS DEGRADADAS, CONTAMINADAS E ALTERADAS	51
51328	2101.001.568-9	GERENCIAMENTO AMBIENTAL DA INDÚSTRIA	51
51341	2101.001.581-1	GESTÃO DE RECURSOS HÍDRICOS	51
51350	2101.001.590-0	HIDROSSEDIMENTOLOGIA	51
51332	2101.001.572-2	PLANEJAMENTO E CONTROLE DE OBRAS	34
51369	2101.001.609-6	PROJETO DE ESTAÇÃO DE TRATAMENTO DE ESGOTO	34
51342	2101.001.582-0	PROJETOS DE SISTEMAS DE DRENAGEM PLUVIAL	51
51355	2101.001.595-6	SOCIOLOGIA E MEIO AMBIENTE	34
35094	2101.000.951-8	ESTÁGIO OBRIGATÓRIO	160
31860	2101.000.338-2	ALTERNATIVAS ECOLÓGICAS EM SANEAMENTO	68
51359	2101.001.599-2	ANÁLISE DE RISCOS EM ENGENHARIA DE RECURSOS HÍDRICOS	51
51336	2101.001.576-9	ANÁLISE ESPACIAL DE DADOS	51
51194	2101.001.509-9	APLICAÇÕES EM GEOPROCESSAMENTO	68
51364	2101.001.604-0	ÁREAS CONTAMINADAS: INVESTIGAÇÃO, ANÁLISE E GESTÃO	51
34017	2101.000.792-2	ARQUITETURA E URBANISMO	51
51330	2101.001.570-4	CAPACITAÇÃO TÉCNICA TEMÁTICA	68
51333	2101.001.573-1	ECONOMIA AMBIENTAL	51
32171	2101.000.624-1	EDUCAÇÃO AMBIENTAL	68
46648	2501.000.187-8	EDUCAÇÃO, GESTÃO E CONTABILIDADE AMBIENTAL	68
42300	3101.000.220-0	ESTUDO DE LIBRAS	68
31904	2101.000.377-3	ESTUDO ESPECIAL EM ENGENHARIA AMBIENTAL	51
51343	2101.001.583-0	FUNDAMENTOS DE FLUIDODINÂMICA COMPUTACIONAL	51
31901	2101.000.374-9	GEOBIOSSISTEMAS	51
31897	2101.000.370-6	GEOLOGIA APLICADA	68
34330	2101.000.833-3	GERENCIAMENTO DE PROJETOS	68
51366	2101.001.606-9	GESTÃO DA PROFISSÃO NA ENGENHARIA	51
51365	2101.001.605-0	GESTÃO ESTRATÉGICA EM SANEAMENTO	34
31669	2101.000.152-5	HIDROLOGIA ESTATÍSTICA	68
31896	2101.000.369-2	INSTRUMENTAÇÃO E MODELOS DIGITAIS AMBIENTAIS	34
38076	2101.001.093-1	INTRODUÇÃO AO LICENCIAMENTO AMBIENTAL	68
51337	2101.001.577-8	INTRODUÇÃO À VIDA UNIVERSITÁRIA	51
41350	2601.000.147-0	LEGISLAÇÃO E HIGIENE NA INDÚSTRIA DE ALIMENTOS	51
51356	2101.001.596-5	LIMNOLOGIA	51
34019	2401.000.119-8	MECÂNICA GERAL	51
51183	2101.001.498-6	MEIO FÍSICO DA BACIA DO PANTANAL	68
37277	2101.001.027-3	MODELAGEM DE SISTEMAS DE SANEAMENTO	34
51346	2101.001.586-7	OTIMIZAÇÃO DE SISTEMAS AMBIENTAIS	68
31899	2101.000.372-2	PEDOLOGIA	51
31861	2101.000.339-0	PERÍCIA AMBIENTAL	68
31900	2101.000.373-0	RELAÇÃO SOLO, ÁGUA E PLANTA	34
32167	2101.000.620-9	SENSORIAMENTO REMOTO E FOTOINTERPRETAÇÃO	68
51367	2101.001.607-8	SOLUÇÕES BASEADAS NA NATUREZA PARA TRATAMENTO E REÚSO DE ESGOTO SANITÁRIO	51
51338	2101.001.578-7	TECNOLOGIAS COMPACTAS DE TRATAMENTO DE EFLUENTES	51
51357	2101.001.597-4	VEGETAÇÃO E RECURSOS FLORESTAIS	51
31966	2101.000.435-4	INTRODUÇÃO À ENGENHARIA DE PRODUÇÃO	34
34314	2101.000.817-1	SISTEMAS DE PRODUÇÃO	34
34323	2101.000.826-0	PROCESSOS DE FABRICAÇÃO	68
51134	2101.001.487-9	GESTÃO ORGANIZACIONAL	68
51131	2101.001.484-1	MODELOS PROBABILÍSTICOS APLICADOS À ENGENHARIA	34
32002	2101.000.462-1	PRÁTICAS EM ENGENHARIA DE PRODUÇÃO I	34
51132	2101.001.485-0	MÉTODOS ESTATÍSTICOS APLICADOS À ENGENHARIA	34
51117	2101.001.470-7	OPERAÇÕES UNITÁRIAS	68
32006	2101.000.466-4	PLANEJAMENTO E CONTROLE DA PRODUÇÃO I	68
32019	2101.000.479-6	PRÁTICAS EM ENGENHARIA DE PRODUÇÃO II	34
51114	2101.001.467-2	PROJETO E ORGANIZAÇÃO DO TRABALHO	51
51116	2101.001.469-0	FUNDAMENTOS DE LOGÍSTICA	51
34340	2101.000.843-0	METROLOGIA INDUSTRIAL E CIENTÍFICA	68
51125	2101.001.478-0	PESQUISA OPERACIONAL II	68
32015	2101.000.475-3	PLANEJAMENTO E CONTROLE DA PRODUÇÃO II	68
34332	2101.000.835-0	PRÁTICAS EM ENGENHARIA DE PRODUÇÃO III	34
51113	2101.001.466-3	AUTOMAÇÃO INDUSTRIAL	34
51124	2101.001.477-0	CONTROLE ESTATÍSTICO DE PROCESSOS	34
34327	2101.000.830-9	CUSTOS INDUSTRIAIS	34
34331	2101.000.834-1	GESTÃO DE OPERAÇÕES DE SERVIÇOS	34
51121	2101.001.474-3	GESTÃO DO CONHECIMENTO	68
51135	2101.001.488-8	PLANEJAMENTO E CONTROLE DA PRODUÇÃO III	68
34336	2101.000.839-2	PRÁTICAS EM ENGENHARIA DE PRODUÇÃO IV	34
34333	2101.000.836-8	ENGENHARIA DE MÉTODOS	68
34335	2101.000.838-4	MANUTENÇÃO INDUSTRIAL E CONFIABILIDADE	68
32039	2101.000.499-0	MODELAGEM E SIMULAÇÃO DE SISTEMAS	68
51123	2101.001.476-1	PLANEJAMENTO DE EXPERIMENTOS	34
51118	2101.001.471-6	ENGENHARIA ECONÔMICA	68
51140	2101.001.493-0	ESTÁGIO OBRIGATÓRIO I	80
51133	2101.001.486-0	PROJETO E DESENVOLVIMENTO DE PRODUTOS	68
51141	2101.001.494-0	ESTÁGIO OBRIGATÓRIO II	80
51122	2101.001.475-2	LOGÍSTICA E GESTÃO DA CADEIA DE SUPRIMENTOS	68
51107	2101.001.460-9	PROJETO DE UNIDADES PRODUTIVAS	68
51127	2101.001.480-5	ANÁLISE DE DADOS TEXTUAIS	51
51111	2101.001.464-5	APOIO MULTICRITÉRIO À DECISÃO	34
32033	2101.000.493-1	BIOTECNOLOGIA	34
32008	2101.000.468-0	CONTABILIDADE BÁSICA, AVALIAÇÃO DE INVESTIMENTOS E FINANÇAS CORPORATIVAS	51
51129	2101.001.482-3	DECISÃO EM GRUPO E NEGOCIAÇÃO	34
51128	2101.001.481-4	ECONOMIA CIRCULAR	51
31971	2101.000.439-7	EFICIÊNCIA ENERGÉTICA NA AGROINDÚSTRIA	34
45383	2101.001.353-1	ENERGIA E INSTALAÇÕES ELÉTRICAS	68
42913	3101.000.286-3	ESTUDO DE LIBRAS	51
31972	2101.000.440-0	FONTES ALTERNATIVAS DE ENERGIA	34
51119	2101.001.472-5	FONTES RENOVÁVEIS DE ENERGIA	34
51136	2101.001.489-7	FUNDAMENTOS DE APRENDIZAGEM DE MÁQUINA	34
32020	2101.000.480-0	HIDRÁULICA	34
31965	2301.000.009-6	LABORATÓRIO DE QUÍMICA GERAL	34
32499	2301.000.145-9	LABORATÓRIO DE QUÍMICA ORGÂNICA	34
32022	2101.000.482-6	MATERIAIS DE CONSTRUÇÃO CIVIL	34
32034	2101.000.494-0	MICROBIOLOGIA	34
31973	2101.000.441-9	PLANEJAMENTO DE RECURSOS ENERGÉTICOS PARA AGROINDÚSTRIA	34
31782	2101.000.262-9	PRINCÍPIOS DE COMUNICAÇÃO I	68
32041	2101.000.501-6	PROCESSAMENTO DE PRODUTOS DE ORIGEM VEGETAL (CONSERVAÇÃO DE ALIMENTOS)	34
32532	2301.000.170-0	QUÍMICA ORGÂNICA	68
51130	2101.001.483-2	SISTEMA DE INFORMAÇÃO E APOIO À DECISÃO	34
34318	2101.000.821-0	SISTEMAS CONSTRUTIVOS	34
32021	2101.000.481-8	SISTEMAS ESTRUTURAIS E TEORIA DAS ESTRUTURAS	34
51112	2101.001.465-4	SISTEMAS INTELIGENTES NO APOIO À DECISÃO I	34
51110	2101.001.463-6	SISTEMAS INTELIGENTES NO APOIO À DECISÃO II	34
51109	2101.001.462-7	SISTEMAS INTELIGENTES NO APOIO À DECISÃO III	34
31975	2101.000.443-5	TÓPICOS EM PLANEJAMENTO E CONTROLE DA PRODUÇÃO	34
51139	2101.001.492-1	TÓPICOS ESPECIAIS EM EDUCAÇÃO EM ENGENHARIA DE PRODUÇÃO	34
34348	2101.000.850-3	TÓPICOS ESPECIAIS EM ENGENHARIA DA QUALIDADE	34
34349	2101.000.851-1	TÓPICOS ESPECIAIS EM ENGENHARIA DA SUSTENTABILIDADE	34
34346	2101.000.848-1	TÓPICOS ESPECIAIS EM ENGENHARIA DE OPERAÇÕES E PROCESSOS DA PRODUÇÃO	34
34350	2101.000.852-0	TÓPICOS ESPECIAIS EM ENGENHARIA DO PRODUTO	34
34351	2101.000.853-8	TÓPICOS ESPECIAIS EM ENGENHARIA DO TRABALHO	34
34352	2101.000.854-6	TÓPICOS ESPECIAIS EM ENGENHARIA ECONÔMICA	34
34347	2101.000.849-0	TÓPICOS ESPECIAIS EM ENGENHARIA ORGANIZACIONAL	34
51108	2101.001.461-8	TÓPICOS ESPECIAIS EM GESTÃO DA INOVAÇÃO TECNOLÓGICA	34
34353	2101.000.855-4	TÓPICOS ESPECIAIS EM LOGÍSTICA	34
34354	2101.000.856-2	TÓPICOS ESPECIAIS EM PESQUISA OPERACIONAL	34
51137	2101.001.490-3	TÓPICOS ESPECIAIS EM PESQUISA OPERACIONAL II	34
51126	2101.001.479-9	TRANSFORMAÇÃO DIGITAL EM BUSINESS INTELLIGENCE EMPREGADA NA MANUFATURA AVANÇADA	51
38502	2101.001.115-6	CARTOGRAFIA	68
38507	2101.001.119-9	GEOGRAFIA DA POPULAÇÃO	34
51200	2101.001.515-0	GEOLOGIA	68
51205	2101.001.520-3	HISTÓRIA DO PENSAMENTO GEOGRÁFICO	68
51185	2101.001.500-7	SOCIEDADE E NATUREZA	51
38508	2101.001.120-2	CARTOGRAFIA TEMÁTICA	68
38510	2101.001.122-9	CLIMATOLOGIA	68
38511	2101.001.123-7	DINÂMICAS POPULACIONAIS	34
51204	2101.001.519-7	GEOMORFOLOGIA	68
51193	2101.001.508-0	TEORIA DA GEOGRAFIA	68
51207	2201.000.246-8	ESTATÍSTICA APLICADA À GEOGRAFIA	68
38514	2101.001.126-1	GEOGRAFIA ECONÔMICA	68
38512	2101.001.124-5	PEDOLOGIA	68
38517	2101.001.129-6	BIOGEOGRAFIA	68
38524	2101.001.136-9	GEOGRAFIA CULTURAL	68
38531	2101.001.143-1	PLANEJAMENTO E GESTÃO TERRITORIAL	68
51206	2101.001.521-2	SENSORIAMENTO REMOTO	68
51192	2101.001.507-0	GEOGRAFIA AGRÁRIA	68
38522	2101.001.134-2	GEOGRAFIA URBANA	68
51199	2101.001.514-1	GEOPROCESSAMENTO	68
51196	2101.001.511-4	HIDROLOGIA	68
51186	2101.001.501-6	ESTÁGIO OBRIGATÓRIO I	124
51201	2101.001.516-0	GEOGRAFIA POLÍTICA	51
51202	2101.001.517-9	GEOGRAFIA REGIONAL E REGIONALIZAÇÃO	68
51197	2101.001.512-3	MÉTODOS E TÉCNICAS DE PESQUISA	68
38525	2101.001.137-7	PLANEJAMENTO E GESTÃO URBANA	68
51198	2101.001.513-2	ECOLOGIA APLICADA À GEOGRAFIA	68
51195	2101.001.510-5	ESTÁGIO OBRIGATÓRIO II	124
38533	2101.001.145-8	PLANEJAMENTO E GESTÃO AMBIENTAL	68
38536	2101.001.148-2	PLANEJAMENTO E GESTÃO DE RECURSOS HÍDRICOS	34
51180	2101.001.495-9	AVALIAÇÃO DE IMPACTOS AMBIENTAIS	68
51184	2101.001.499-5	EXPEDIÇÕES GEOGRÁFICAS	34
38054	2101.001.072-9	GEODÉSIA	68
51188	2101.001.503-4	AGRICULTURA URBANA	68
38028	2101.001.052-4	BIOCLIMATOLOGIA	68
38029	2101.001.053-2	CIDADE E COTIDIANO	68
38031	2101.001.055-9	CLIMATOLOGIA APLICADA	68
38032	2101.001.056-7	DEMOGRAFIA	68
38035	2101.001.059-1	DINÂMICA INTERNA DA CIDADE DE CAMPO GRANDE	68
38041	2101.001.062-1	EDUCAÇÃO DO CAMPO	68
41755	3101.000.094-1	EDUCAÇÃO ESPECIAL	51
51189	2101.001.504-3	ESPAÇOS TURÍSTICOS	68
38045	2101.001.065-6	ESTRUTURA, FUNCIONAMENTO E GESTÃO DAS ÁREAS PROTEGIDAS	68
38046	2101.001.066-4	ESTUDOS DE REDE URBANA	68
38047	2101.001.067-2	ESTUDOS FRONTEIRIÇOS	68
38048	2101.001.068-0	FOTOGRAMETRIA E FOTOINTERPRETAÇÃO	68
41761	3101.000.097-6	FUNDAMENTOS DE DIDÁTICA	51
42915	3101.000.288-0	FUNDAMENTOS HISTÓRICOS E FILOSÓFICOS DA EDUCAÇÃO	68
38051	2101.001.069-9	GEOARQUEOLOGIA	68
38052	2101.001.070-2	GEOBIOSSISTEMAS	68
51181	2101.001.496-8	GEOECOLOGIA DAS PAISAGENS	68
38053	2101.001.071-0	GEOESTATÍSTICA	68
38055	2101.001.073-7	GEOGRAFIA APLICADA A ANÁLISE AMBIENTAL	68
38056	2101.001.074-5	GEOGRAFIA DA CULTURA AFRO-BRASILEIRA	68
38057	2101.001.075-3	GEOGRAFIA DA SAÚDE	68
38058	2101.001.076-1	GEOGRAFIA DO MATO GROSSO DO SUL	68
32193	2101.000.646-2	GEOGRAFIA ELEITORAL	68
38063	2101.001.081-8	GEOGRAFIA FÍSICA DO BRASIL	68
38064	2101.001.082-6	GEOLOGIA AMBIENTAL	68
38519	2101.001.131-8	GEOMORFOLOGIA FLUVIAL	68
38069	2101.001.087-7	GEOPOLÍTICA	68
38071	2101.001.089-3	GERENCIAMENTO E ANÁLISE DE BACIAS HIDROGRÁFICAS	68
38074	2101.001.092-3	GESTÃO DE RESÍDUOS SÓLIDOS URBANOS	68
42916	3001.000.309-8	HISTÓRIA ECONÔMICA GERAL E DO BRASIL	68
51182	2101.001.497-7	INTRODUÇÃO AO UNIVERSO CONCEITUAL DA GEOGRAFIA	68
38079	2101.001.096-6	LIMNOLOGIA	68
51190	2101.001.505-2	LUGAR E TERRITÓRIO	68
51191	2101.001.506-1	MUDANÇAS AMBIENTAIS NO QUATERNÁRIO: GEOLOGIA E PALEONTOLOGIA	68
51187	2101.001.502-5	MUDANÇAS CLIMÁTICAS: IMPLICAÇÕES AMBIENTAIS E SOCIOECONOMICAS	68
51203	2101.001.518-8	O CONHECIMENTO CIENTÍFICO APLICADO À CIÊNCIA GEOGRÁFICA: CONCEITOS E PRÁTICAS	68
41759	3101.000.096-8	POLÍTICAS EDUCACIONAIS	51
38086	2101.001.102-4	POLUIÇÃO ATMOSFÉRICA	68
38087	2101.001.103-2	POLUIÇÃO DE AQUÍFEROS	68
41758	3001.000.003-0	PSICOLOGIA E EDUCAÇÃO	51
38088	2101.001.104-0	SISTEMA DE INFORMAÇÃO GEOGRÁFICA	68
42684	3101.000.279-0	SOCIOLOGIA DA EDUCAÇÃO	68
38097	2101.001.112-1	TÓPICOS ESPECIAIS EM CARTOGRAFIA	68
38098	2101.001.113-0	TÓPICOS ESPECIAIS SOBRE CAMPO GRANDE	68
50939	2201.000.212-7	ÁLGEBRA NA EDUCAÇÃO BÁSICA	68
50964	2201.000.237-9	ELEMENTOS PARA O ENSINO DE NÚMEROS E OPERAÇÕES	68
50951	2201.000.224-3	PRÁTICA DE ENSINO I	68
50940	2201.000.213-6	RACIOCÍNIO LÓGICO NA EDUCAÇÃO BÁSICA	68
50966	2201.000.239-7	CONCEITOS PARA O ENSINO DE PROBABILIDADE E ESTATÍSTICA	68
50963	2201.000.236-0	FUNDAMENTOS E METODOLOGIAS PARA O ENSINO DE FUNÇÕES	68
50938	2201.000.211-8	FUNDAMENTOS PARA O ENSINO DE GEOMETRIA, GRANDEZAS E MEDIDAS	68
50952	2201.000.225-2	PRÁTICA DE ENSINO II	68
50971	2201.000.244-0	ARITMÉTICA E ÁLGEBRA ELEMENTARES	68
50957	2201.000.230-5	CONSTRUÇÕES GEOMÉTRICAS	51
50955	2201.000.228-0	LÓGICA MATEMÁTICA	68
50953	2201.000.226-1	PRÁTICA DE ENSINO III	68
50956	2201.000.229-9	TÓPICOS DE MATEMÁTICA ELEMENTAR	68
50959	2201.000.232-3	GEOMETRIA PLANA	68
50936	2901.001.077-6	LEITURA E PRODUÇÃO DE TEXTOS	68
50960	2201.000.233-2	PRÁTICA DE ENSINO IV	68
50967	2201.000.240-3	TECNOLOGIAS DIGITAIS E O ENSINO DE MATEMÁTICA	68
50946	2201.000.219-0	ESTÁGIO OBRIGATÓRIO I	100
50958	2201.000.231-4	GEOMETRIA ESPACIAL	68
50937	3101.000.608-0	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
50961	2201.000.234-1	PRÁTICA DE ENSINO V	68
50954	2201.000.227-0	ESTÁGIO OBRIGATÓRIO II	100
50970	2201.000.243-0	FUNDAMENTOS DE ARITMÉTICA	68
50962	2201.000.235-0	PRÁTICA DE ENSINO VI	68
50972	2201.000.245-9	ESTÁGIO OBRIGATÓRIO III	100
50948	2201.000.221-6	HISTÓRIA DA MATEMÁTICA	68
50943	2201.000.216-3	INTRODUÇÃO À ANÁLISE REAL	68
50950	2201.000.223-4	INTRODUÇÃO ÀS ESTRUTURAS ALGÉBRICAS	68
50968	2201.000.241-2	AVALIAÇÃO E EDUCAÇÃO MATEMÁTICA	34
50969	2201.000.242-1	COMPLEMENTOS DE ANÁLISE REAL	68
50965	2201.000.238-8	DESENVOLVIMENTO PROFISSIONAL DOCENTE	34
50947	2201.000.220-7	ESTÁGIO OBRIGATÓRIO IV	100
50944	2201.000.217-2	FUNDAMENTOS HISTÓRICOS, SOCIOLÓGICOS E FILOSÓFICOS DA EDUCAÇÃO	51
50949	2201.000.222-5	TENDÊNCIAS E PESQUISA EM EDUCAÇÃO MATEMÁTICA	34
32253	2201.000.047-0	CÁLCULO AVANÇADO	68
42295	3101.000.215-4	EDUCAÇÃO AMBIENTAL	68
32254	2201.000.048-9	ESPAÇOS MÉTRICOS	68
38876	2201.000.105-1	FUNÇÕES DE UMA VARIÁVEL COMPLEXA	68
32255	2201.000.049-7	GEOMETRIA DIFERENCIAL	68
38877	2201.000.106-0	OTIMIZAÇÃO	68
43476	2201.000.135-3	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
43487	2201.000.146-0	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
50942	2201.000.215-4	TÓPICOS DE EDUCAÇÃO	68
50945	2201.000.218-1	TÓPICOS DE EDUCAÇÃO MATEMÁTICA	68
50941	2201.000.214-5	TÓPICOS DE MATEMÁTICA	68
32259	2201.000.053-5	TOPOLOGIA	68
52141	2201.000.247-7	FUNDAMENTOS DE MATEMÁTICA ELEMENTAR	68
45836	2201.000.172-9	ALGORITMOS E ESTRUTURA DE DADOS I	68
45839	2201.000.175-6	ALGORITMOS E ESTRUTURA DE DADOS II	68
45853	2201.000.189-0	PROBABILIDADE	68
52144	2201.000.250-1	ÁLGEBRA LINEAR II	68
45842	2201.000.178-3	ELEMENTOS DE ARITMÉTICA	68
45846	2201.000.182-7	INFERÊNCIA ESTATÍSTICA	68
38906	2201.000.127-2	ANÁLISE REAL I	68
45840	2201.000.176-5	ESTRUTURAS ALGÉBRICAS I	68
52143	2201.000.249-5	SISTEMAS DE EQUAÇÕES DIFERENCIAIS ORDINÁRIAS	68
38908	2201.000.129-9	ANÁLISE REAL II	68
45833	2201.000.169-4	CÁLCULO AVANÇADO	68
45841	2201.000.177-4	ESTRUTURAS ALGÉBRICAS II	68
45850	2201.000.186-3	OTIMIZAÇÃO LINEAR	68
45843	2201.000.179-2	FUNÇÕES DE UMA VARIÁVEL COMPLEXA	68
45849	2201.000.185-4	INTRODUÇÃO À TOPOLOGIA GERAL	68
52142	2201.000.248-6	MATEMÁTICA DISCRETA	68
45845	2201.000.181-8	GEOMETRIA DIFERENCIAL	68
45834	2201.000.170-0	ÁLGEBRA LINEAR AVANÇADA	68
45838	2201.000.174-7	EQUAÇÕES DIFERENCIAIS PARCIAIS	68
45847	2201.000.183-6	INTRODUÇÃO À ANÁLISE FUNCIONAL	68
45848	2201.000.184-5	INTRODUÇÃO À TEORIA DE GALOIS	68
45851	2201.000.187-2	OTIMIZAÇÃO NÃO LINEAR	68
45852	2201.000.188-1	PESQUISA OPERACIONAL	68
45854	2201.000.190-7	TEORIA DA MEDIDA E INTEGRAÇÃO	68
45856	2201.000.192-5	TÓPICOS DE MATEMÁTICA A	68
45832	2201.000.168-5	TÓPICOS DE MATEMÁTICA B	34
45855	2201.000.191-6	TOPOLOGIA GERAL	68
48726	2401.000.288-2	BASES CONCEITUAIS DE FÍSICA PARA O ENSINO BÁSICO	68
48727	2701.000.335-7	FUNDAMENTOS DE BIOLOGIA PARA O ENSINO DE QUÍMICA	68
48011	2301.000.327-0	FUNDAMENTOS DE QUÍMICA	34
48718	2301.000.360-9	INTRODUÇÃO AO LABORATÓRIO QUÍMICO	34
48736	2301.000.373-4	INTRODUÇÃO À PRÁTICA EM EDUCAÇÃO QUÍMICA	51
48022	2301.000.333-1	QUÍMICA GERAL	68
48041	2301.000.347-6	QUÍMICA ORGÂNICA I	51
48739	2901.001.037-3	LEITURA E PRODUÇÃO DE TEXTO	34
36058	2301.000.211-0	QUÍMICA INORGÂNICA EXPERIMENTAL I	34
48046	2301.000.352-9	QUÍMICA INORGÂNICA I	51
48012	2301.000.328-9	QUÍMICA ORGÂNICA II	34
45236	2401.000.236-3	FUNDAMENTOS DA ELETRICIDADE	34
48714	2301.000.356-5	PRÁTICA EM EDUCAÇÃO QUÍMICA I	51
48045	2301.000.351-0	QUÍMICA ANALÍTICA EXPERIMENTAL I	51
36060	2301.000.213-7	QUÍMICA ANALÍTICA I	34
48013	2301.000.329-8	QUÍMICA ORGÂNICA III	34
48027	2301.000.338-7	FÍSICO-QUÍMICA I	34
36063	2301.000.216-1	MÉTODOS ESPECTROMÉTRICOS EM QUÍMICA ORGÂNICA I	51
48716	2301.000.358-3	PRÁTICA EM EDUCAÇÃO QUÍMICA II	68
48026	2301.000.337-8	QUÍMICA INORGÂNICA EXPERIMENTAL II	34
36064	2301.000.217-0	QUÍMICA INORGÂNICA II	34
48024	2301.000.335-0	QUÍMICA ORGÂNICA EXPERIMENTAL I	34
36069	2301.000.222-6	FÍSICO-QUÍMICA II	51
48728	2301.000.366-3	PRÁTICA EM EDUCAÇÃO QUÍMICA III	68
48048	2301.000.354-7	QUÍMICA ANALÍTICA EXPERIMENTAL II	68
48023	2301.000.334-0	QUIMICA ANALÍTICA II	34
51906	2301.000.411-4	ESTÁGIO OBRIGATÓRIO I	68
36074	2301.000.227-7	FÍSICO-QUÍMICA III	51
48725	2301.000.365-4	PRÁTICA EM EDUCAÇÃO QUÍMICA IV	68
48044	2301.000.350-0	QUÍMICA ANALÍTICA INSTRUMENTAL I	51
48735	2301.000.372-5	SEGURANÇA E MEIO AMBIENTE	51
51907	2301.000.412-3	ESTÁGIO OBRIGATÓRIO II	68
48028	2301.000.339-6	FÍSICO-QUÍMICA IV	51
48047	2301.000.353-8	QUÍMICA ANALÍTICA INSTRUMENTAL EXPERIMENTAL	68
48010	2301.000.326-0	QUÍMICA ANALÍTICA INSTRUMENTAL II	34
48042	2301.000.348-5	QUÍMICA INORGÂNICA EXPERIMENTAL III	34
36077	2301.000.230-7	QUÍMICA INORGÂNICA III	34
51908	2301.000.413-2	ESTÁGIO OBRIGATÓRIO III	136
36084	2301.000.237-4	FÍSICO-QUÍMICA V	34
48721	2301.000.362-7	INVESTIGAÇÃO E PRÁTICA EM EDUCAÇÃO QUÍMICA I	51
48039	2101.001.405-5	MINERALOGIA	51
48717	2301.000.359-2	QUÍMICA DE BIOMOLÉCULAS E METABOLISMO	68
51905	2301.000.410-5	ESTÁGIO OBRIGATÓRIO IV	136
36089	2301.000.240-4	FÍSICO-QUÍMICA EXPERIMENTAL	51
48720	2301.000.361-8	INVESTIGAÇÃO E PRÁTICA EM EDUCAÇÃO QUÍMICA II	51
48015	2301.000.331-3	CORROSÃO INDUSTRIAL	51
48729	2701.000.336-6	EDUCAÇÃO AMBIENTAL	34
43181	3001.000.371-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	51
36029	2301.000.183-1	ELETROQUÍMICA INDUSTRIAL	34
36030	2301.000.184-0	ESTEREOQUÍMICA	51
43863	3001.000.394-3	FILOSOFIA DA CIÊNCIA	68
36033	2301.000.187-4	HISTÓRIA DA FÍSICO-QUÍMICA	34
36034	2301.000.188-2	HISTÓRIA DA QUÍMICA	34
36035	2301.000.189-0	INTRODUÇÃO A CINÉTICA ELETROQUÍMICA	51
36036	2301.000.190-4	INTRODUÇÃO A COSMETOLOGIA	68
36037	2301.000.191-2	INTRODUÇÃO À QUÍMICA DE MATERIAIS CERÂMICOS	34
48713	2301.000.355-6	LABORATÓRIO DE ENSINO DE CIÊNCIAS E QUÍMICA	68
48043	2301.000.349-4	MICROBIOLOGIA E BIOTECNOLOGIA INDUSTRIAL	68
44010	3101.000.360-4	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
41088	2301.000.282-0	PRÁTICA DE ENSINO EM CIÊNCIAS I	68
41089	2301.000.283-8	PRÁTICA DE ENSINO EM CIÊNCIAS II	68
41090	2301.000.284-6	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
36104	2301.000.250-1	PRINCÍPIOS DE PROCESSOS QUÍMICOS	68
48014	2301.000.330-4	PROCESSOS INDUSTRIAIS FERMENTATIVOS	68
36041	2301.000.195-5	PRODUTOS NATURAIS	34
43183	3101.000.335-5	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
36094	2301.000.245-5	QUÍMICA AMBIENTAL	51
36042	2301.000.196-3	QUÍMICA DOS POLÍMEROS	51
36043	2301.000.197-1	QUÍMICA INORGÂNICA DA VIDA	34
36044	2301.000.198-0	QUÍMICA INORGÂNICA SINTÉTICA	51
36103	2301.000.249-8	QUÍMICA ORGÂNICA EXPERIMENTAL II	68
36045	2301.000.199-8	QUÍMICA QUÂNTICA E MECÂNICA ESTATÍSTICA	34
48035	2301.000.342-0	QUÍMICA VERDE	34
48734	2301.000.371-6	SEMINÁRIOS II - DEBATES INTERDISCIPLINARES	34
48731	2301.000.368-1	SEMINÁRIOS I - TEMAS ATUAIS NO ENSINO DE CIÊNCIAS	34
36046	2301.000.200-5	SÍNTESE ORGÂNICA	51
36047	2301.000.201-3	TÉCNICAS DE EXTRAÇÃO PARA ANÁLISE CROMATOGRÁFICA	34
43926	3001.000.455-7	TÓPICOS ESPECIAIS EM FILOSOFIA DA CIÊNCIA I	68
43890	3001.000.421-6	TÓPICOS ESPECIAIS EM FILOSOFIA DA CIÊNCIA II	68
43950	3001.000.479-0	TÓPICOS ESPECIAIS EM FILOSOFIA DA CIÊNCIA III	68
48737	2301.000.374-3	TÓPICOS ESPECIAIS PARA O ENSINO DE QUÍMICA I	34
48715	2301.000.357-4	TÓPICOS ESPECIAIS PARA O ENSINO DE QUÍMICA II	51
48738	2301.000.375-2	TÓPICOS ESPECIAIS PARA O ENSINO DE QUÍMICA III	68
36050	2301.000.204-8	TRATAMENTO DE RESÍDUOS QUÍMICOS DE LABORATÓRIO	51
48730	2301.000.367-2	UNIDADES TEMÁTICAS EM CIÊNCIAS DA NATUREZA	68
48040	2301.000.346-7	QUÍMICA GERAL EXPERIMENTAL	51
48021	2701.000.326-8	BIOQUÍMICA	51
36102	2101.000.953-4	DESENHO TÉCNICO E ARQUITETÔNICO I	68
36101	2301.000.248-0	HIGIENE E SEGURANÇA	51
48025	2301.000.336-9	FUNDAMENTOS DA ENGENHARIA QUÍMICA	68
36105	2301.000.251-0	MÉTODOS ESPECTROMÉTRICOS EM QUÍMICA ORGÂNICA II	34
36106	2301.000.252-8	PROCESSOS QUÍMICOS INDUSTRIAIS INORGÂNICOS	51
36107	2301.000.253-6	OPERAÇÕES UNITÁRIAS I	68
48020	2301.000.332-2	PROCESSOS QUÍMICOS INDUSTRIAIS ORGÂNICOS	51
36108	2301.000.254-4	PROJETOS E INSTRUMENTAÇÃO INDUSTRIAL	68
36113	2301.000.259-5	OPERAÇÕES UNITÁRIAS II	51
36027	2301.000.181-5	APLICAÇÃO DE TÉCNICAS ANALÍTICAS NO ESTUDO DE POLUENTES ATMOSFÉRICOS	34
48038	2301.000.345-8	CIÊNCIA E TECNOLOGIA DOS MATERIAIS	34
48796	2301.000.380-5	EMPREENDEDORISMO	34
48037	2301.000.344-9	ÍONS LANTANÍDEOS E SUAS APLICAÇÕES:	34
36040	2301.000.194-7	PROCESSOS DE MEMBRANAS	34
36080	2301.000.233-1	QUÍMICA BIOLÓGICA	51
48036	2301.000.343-0	QUÍMICA VERDE PARA LABORATÓRIO ORGÂNICO	34
36095	2301.000.246-3	TERMODINÂMICA AVANÇADA	34
36096	2301.000.247-1	TRATAMENTO DE RESÍDUOS QUÍMICOS DE LABORATÓRIO	34
48800	2301.000.383-2	INTRODUÇÃO À ENGENHARIA QUÍMICA	34
34025	2101.000.796-5	LEGISLAÇÃO, ÉTICA PROFISSIONAL E CIDADANIA	34
46468	2301.000.323-3	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
48799	2301.000.382-3	FUNDAMENTOS DA ENGENHARIA QUÍMICA	68
44652	2301.000.302-8	FENÔMENOS DE TRANSPORTE I	68
44653	2301.000.303-7	FENÔMENOS DE TRANSPORTE II	51
48801	2301.000.384-1	OPERAÇÕES UNITÁRIAS I	68
48821	2301.000.402-5	TERMODINÂMICA I	34
44659	2301.000.309-1	FENÔMENOS DE TRANSPORTE III	51
34312	2101.000.815-5	FUNDAMENTOS DE ECONOMIA	34
46456	2401.000.253-2	MECÂNICA DOS SÓLIDOS	51
48813	2301.000.394-0	OPERAÇÕES UNITÁRIAS II	68
48823	2301.000.404-3	TERMODINÂMICA II	68
48797	2301.000.381-4	ANÁLISE E OTIMIZAÇÃO DE PROCESSOS	51
48806	2301.000.389-7	CINÉTICA E CÁLCULO DE REATORES I	51
34481	2101.000.889-9	FUNDAMENTOS DA ADMINISTRAÇÃO	34
44643	2301.000.295-1	INSTRUMENTAÇÃO INDUSTRIAL	51
44636	2301.000.288-0	LABORATÓRIO DE FENÔMENOS DE TRANSPORTE	51
48820	2301.000.401-6	OPERAÇÕES UNITÁRIAS III	68
48794	2301.000.378-0	CINÉTICA E CÁLCULO DE REATORES II	51
48817	2301.000.398-6	ENGENHARIA BIOQUÍMICA	68
34319	2101.000.822-8	INSTALAÇÕES ELÉTRICAS INDUSTRIAIS	51
48811	2301.000.393-0	LABORATÓRIO DE OPERAÇÕES UNITÁRIAS I	51
48807	2301.000.390-3	MODELAGEM E SIMULAÇÃO DE PROCESSOS	68
48792	2301.000.376-1	PROJETOS I	51
48795	2301.000.379-9	CONTROLE DE PROCESSOS	51
48808	2301.000.391-2	ENGENHARIA AMBIENTAL	51
44637	2301.000.289-0	LABORATÓRIO DE INSTRUMENTAÇÃO INDUSTRIAL	34
48805	2301.000.388-8	LABORATÓRIO DE OPERAÇÕES UNITÁRIAS II	51
48793	2301.000.377-0	PROJETO DE CONCLUSÃO DE CURSO	51
44647	2301.000.298-9	PROJETOS DE INSTALAÇÕES INDUSTRIAIS	51
31958	2101.000.429-0	AUTOMAÇÃO INDUSTRIAL	68
48814	2301.000.395-9	BIOMASSA PARA BIOENERGIA	51
41383	2701.000.085-4	BIOQUÍMICA	51
48818	2301.000.399-5	CONTROLE E QUALIDADE DE ÁGUAS	51
31817	2101.000.296-3	ENGENHARIA ECONÔMICA	51
34317	2101.000.820-1	GESTÃO ORGANIZACIONAL	68
32419	2301.000.072-0	INTRODUÇÃO A COSMETOLOGIA	68
48803	2301.000.386-0	PLANEJAMENTO EXPERIMENTAL	51
36110	2301.000.256-0	PROCESSOS INDUSTRIAIS FERMENTATIVOS I	68
36082	2301.000.235-8	QUÍMICA ANALÍTICA INSTRUMENTAL EXPERIMENTAL	68
48804	2301.000.387-9	REFINO DE PETRÓLEO E PETROQUÍMICA	51
48822	2301.000.403-4	TECNOLOGIA DE AÇÚCAR E ÁLCOOL	51
48819	2301.000.400-7	TECNOLOGIA DE PAPEL E CELULOSE	51
48816	2301.000.397-7	TECNOLOGIA ENZIMÁTICA	51
48815	2301.000.396-8	TECNOLOGIA E PROCESSAMENTO DE ALIMENTOS	51
46457	2301.000.314-4	TÓPICOS ESPECIAIS I	34
46459	2301.000.316-2	TÓPICOS ESPECIAIS II	51
46458	2301.000.315-3	TÓPICOS ESPECIAIS III	68
48802	2301.000.385-0	TRATAMENTO BIOLÓGICO DE EFLUENTES	51
48339	2401.000.285-5	EVOLUÇÃO DAS IDEIAS DA FÍSICA	68
37185	2401.000.160-0	INTRODUÇÃO AO LABORATÓRIO DE FÍSICA	34
45363	2401.000.249-9	METODOLOGIA E REDAÇÃO CIENTÍFICA	34
48333	2401.000.279-3	SEMINÁRIOS DE FÍSICA	34
48313	2401.000.262-1	FÍSICA F1	102
48312	2401.000.261-2	FÍSICA COMPUTACIONAL E INFORMÁTICA	68
48324	2401.000.272-0	FÍSICA F2	102
37188	2401.000.163-5	LABORATÓRIO DE FÍSICA F I	34
48321	2401.000.269-5	FÍSICA F3	102
37192	2401.000.167-8	LABORATÓRIO DE FÍSICA F II	34
48334	2401.000.280-0	QUÍMICA GERAL PARA FÍSICA E ENGENHARIA FÍSICA	68
48320	2401.000.268-6	ESTRUTURA DA MATÉRIA 1	68
48319	2401.000.267-7	FÍSICA F4	68
48326	2401.000.274-8	FÍSICA MATEMÁTICA 1	102
37196	2401.000.170-8	LABORATÓRIO DE FÍSICA F III	34
48327	2401.000.275-7	MECÂNICA CLÁSSICA 1	68
48325	2401.000.273-9	ESTRUTURA DA MATÉRIA 2	68
48314	2401.000.263-0	FÍSICA MATEMÁTICA 2	68
48329	2401.000.277-5	LABORATÓRIO DE FÍSICA F IV	34
48322	2401.000.270-1	MECÂNICA CLÁSSICA 2	68
37201	2401.000.175-9	TERMODINÂMICA	68
48336	2401.000.282-8	ELETROMAGNETISMO 1	68
37203	2401.000.177-5	LABORATÓRIO DE FÍSICA MODERNA E CONTEMPORÂNEA	68
48315	2401.000.264-0	MECÂNICA QUÂNTICA 1	68
48337	2401.000.283-7	ELETROMAGNETISMO 2	34
48332	2401.000.278-4	MECÂNICA ESTATÍSTICA	68
48323	2401.000.271-0	MECÂNICA QUÂNTICA 2	68
37145	2401.000.125-2	BIOFÍSICA MOLECULAR	68
37148	2401.000.126-0	EDUCAÇÃO EM ASTRONOMIA I	51
37149	2401.000.127-9	EDUCAÇÃO EM ASTRONOMIA II	51
48338	2401.000.284-6	ELETROMAGNETISMO 3	34
44450	2401.000.234-5	FÍSICA CONCEITUAL	68
37153	2401.000.131-7	FÍSICA DE FLUIDOS	68
37154	2401.000.132-5	FÍSICA DE FLUIDOS CARREGADOS	68
37155	2401.000.133-3	FÍSICA DO ESTADO SÓLIDO	68
48335	2401.000.281-9	FÍSICA MATEMÁTICA 3	68
37158	2401.000.136-8	FUNDAMENTOS DE CRISTALOGRAFIA	68
37162	2401.000.140-6	INTRODUÇÃO À ASTRONOMIA	51
37163	2401.000.141-4	INTRODUÇÃO À CIÊNCIA DOS MATERIAIS	68
37164	2401.000.142-2	INTRODUÇÃO À ESPECTROSCOPIA ÓPTICA	68
37165	2401.000.143-0	INTRODUÇÃO À FÍSICA	34
37166	2401.000.144-9	INTRODUÇÃO À FÍSICA DA ATMOSFERA	68
37167	2401.000.145-7	INTRODUÇÃO À FÍSICA DE PLASMAS	68
51887	2401.000.310-0	INTRODUÇÃO À FÍSICA DO ESTADO SÓLIDO	68
37168	2401.000.146-5	INTRODUÇÃO À ÓPTICA MODERNA	68
41091	2401.000.212-7	INTRODUÇÃO À TEORIA DA RELATIVIDADE	34
44448	2401.000.232-7	MATEMÁTICA ELEMENTAR 2	68
37170	2401.000.148-1	MÉTODOS NUMÉRICOS EM FÍSICA	68
37171	2401.000.149-0	MODELAGEM MOLECULAR EM SISTEMAS COMPLEXOS	68
37177	2401.000.154-6	TEORIA CINÉTICA EM PLASMAS	68
37178	2401.000.155-4	TÓPICOS ESPECIAIS I	34
37179	2401.000.156-2	TÓPICOS ESPECIAIS II	51
37180	2401.000.157-0	TÓPICOS ESPECIAIS III	68
48328	2401.000.276-6	TÓPICOS ESPECIAIS IV	85
48317	2401.000.266-8	TÓPICOS ESPECIAIS V	102
48316	2401.000.265-9	TÓPICOS ESPECIAIS VI	17
49478	2401.000.301-0	FÍSICA CONCEITUAL	68
44439	2401.000.223-8	LEITURA E PRODUÇÃO DE TEXTOS	34
44441	2401.000.225-6	MATEMÁTICA ELEMENTAR	68
49473	2401.000.296-2	FUNDAMENTOS COMPUTACIONAIS PARA O ENSINO DE FÍSICA	34
51892	2401.000.315-5	PRÁTICA DE ENSINO DE FÍSICA I	68
49474	2401.000.297-1	FUNDAMENTOS DE FÍSICA MATEMÁTICA	68
51893	2401.000.316-4	PRÁTICA DE ENSINO DE FÍSICA II	68
49480	2401.000.303-9	FILOSOFIA DA CIÊNCIA	68
51894	2401.000.317-3	PRÁTICA DE ENSINO DE FÍSICA III	68
49481	2401.000.304-8	ESTÁGIO OBRIGATÓRIO DE FÍSICA I	136
49472	2401.000.295-3	FÍSICA MODERNA	68
49470	2401.000.293-5	INSTRUMENTAÇÃO PARA O ENSINO DE FÍSICA I	68
37169	2401.000.147-3	INTRODUÇÃO À PESQUISA EM ENSINO DE FÍSICA	34
49482	2401.000.305-7	ESTÁGIO OBRIGATÓRIO DE FÍSICA II	136
51891	2401.000.314-6	FÍSICA CLÁSSICA AVANÇADA I	68
49471	2401.000.294-4	INSTRUMENTAÇÃO PARA O ENSINO DE FÍSICA II	68
51895	2401.000.318-2	PRÁTICA DE ENSINO EM CIÊNCIAS	34
49476	2401.000.299-0	ENSINO DE FÍSICA MODERNA E CONTEMPORÂNEA	68
49483	2401.000.306-6	ESTÁGIO OBRIGATÓRIO DE FÍSICA III	136
49475	2401.000.298-0	FÍSICA CLÁSSICA AVANÇADA II	68
51896	2401.000.319-1	PRÁTICA DE ENSINO DE FÍSICA IV	34
51888	2401.000.311-9	PRÁTICA DE ENSINO DE FÍSICA V	34
44447	2401.000.231-8	ASTRONOMIA NO ENSINO FUNDAMENTAL	34
41686	3101.000.027-5	EDUCAÇÃO, CIDADANIA E DIREITOS HUMANOS	68
37181	2401.000.158-9	EVOLUÇÃO DAS IDÉIAS DA FÍSICA I	68
37186	2401.000.161-9	EVOLUÇÃO DAS IDÉIAS DA FÍSICA II	68
44442	2401.000.226-5	FILOSOFIA E SOCIOLOGIA DA CIÊNCIA	68
43188	2401.000.217-6	FORMAÇÃO E PRÁTICA DOCENTE I	68
43186	2401.000.215-8	FORMAÇÃO E PRÁTICA DOCENTE II	68
43187	2401.000.216-7	FORMAÇÃO E PRÁTICA DOCENTE III	68
37157	2401.000.135-0	FREIRE E VYGOTSKY: CONTRIBUIÇÕES PARA ORGANIZAÇÕES CURRICULARES	68
37159	2401.000.137-6	INFORMÁTICA NA EDUCAÇÃO	68
37195	2401.000.169-4	INTRODUÇÃO À FÍSICA MATEMÁTICA	68
43185	2401.000.214-9	MICROCONTROLADORES NO ENSINO DE FÍSICA	68
43184	3101.000.336-4	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
43189	2401.000.218-5	PRÁTICAS INTEGRADORAS PARA A FORMAÇÃO DOCENTE	68
38615	2301.000.276-5	TECNOLOGIAS DIGITAIS DE INFORMAÇÃO E COMUNICAÇÃO (TDIC) NO ENSINO DE CIÊNCIAS NATURAIS	51
51890	2401.000.313-7	TÓPICOS ESPECIAIS IV	85
51889	2401.000.312-8	TÓPICOS ESPECIAIS V	102
32049	2101.000.509-1	DESENHO TÉCNICO	68
45355	2401.000.241-6	INTRODUÇÃO A ENGENHARIA FÍSICA	34
51886	2401.000.309-3	LEGISLAÇÃO, ÉTICA PROFISSIONAL E CIDADANIA	34
47705	3201.000.149-7	FUNDAMENTOS DA ECONOMIA	68
45353	2401.000.239-0	FENÔMENOS DE TRANSPORTE PARA A ENGENHARIA FÍSICA	68
47722	3201.000.166-6	FUNDAMENTOS DA ADMINISTRAÇÃO	68
45364	2401.000.250-5	DISPOSITIVOS SEMICONDUTORES	68
45358	2401.000.244-3	SENSORES	68
46613	2401.000.256-0	PESQUISA, DESENVOLVIMENTO E FABRICAÇÃO DE EQUIPAMENTOS TÉCNICOS E CIENTÍFICOS	34
45352	2401.000.238-1	DESENVOLVIMENTO E FABRICAÇÃO DE MATERIAIS AVANÇADOS	68
45354	2401.000.240-7	EMPREENDEDORISMO	68
45361	2401.000.247-0	LASERS - PRINCÍPIOS E APLICAÇÕES BIOMÉDICAS	68
32322	2401.000.079-5	MÉTODOS DE FÍSICA EXPERIMENTAL I	68
45362	2401.000.248-0	MÉTODOS DE FÍSICA EXPERIMENTAL II	68
36070	2301.000.223-4	QUÍMICA ANALÍTICA II	34
36073	2301.000.226-9	QUÍMICA ANALÍTICA INSTRUMENTAL I	51
36081	2301.000.234-0	QUÍMICA ANALÍTICA INSTRUMENTAL II	34
36054	2301.000.208-0	QUÍMICA ORGÂNICA I	51
36059	2301.000.212-9	QUÍMICA ORGÂNICA II	68
45360	2401.000.246-1	TÓPICOS ESPECIAIS EM ENGENHARIA FÍSICA I	34
45359	2401.000.245-2	TÓPICOS ESPECIAIS EM ENGENHARIA FÍSICA II	51
45365	2401.000.251-4	TÓPICOS ESPECIAIS EM ENGENHARIA FÍSICA III	68
49804	2501.000.231-0	COMPORTAMENTO EMPREENDEDOR	68
49838	2501.000.265-0	ECONOMIA, GESTÃO E SOCIEDADE	68
49799	3001.000.650-6	ESTUDOS EM FILOSOFIA, ÉTICA E POLÍTICA	68
49800	3001.000.651-5	FUNDAMENTOS DE SOCIOLOGIA E ANTROPOLOGIA	68
49801	2201.000.207-4	MATEMÁTICA	68
49842	2501.000.269-7	NEGÓCIOS SUSTENTÁVEIS	68
49822	2501.000.249-0	PRÁTICAS INTERDISCIPLINARES I	102
49802	2001.000.424-4	DIREITO APLICADO À ADMINISTRAÇÃO	68
49835	2501.000.262-3	ECONOMIA E NEGÓCIOS	68
49823	2501.000.250-7	ESTRATÉGIAS ORGANIZACIONAIS	68
49834	2501.000.261-4	MATEMÁTICA FINANCEIRA	68
49839	2501.000.266-0	FUNDAMENTOS DA ESTATÍSTICA	68
49832	2501.000.259-9	GESTÃO DE MARKETING	68
49840	2501.000.267-9	INTRODUÇÃO À CONTABILIDADE	68
49837	2501.000.264-1	PRÁTICAS INTERDISCIPLINARES II	102
49803	2501.000.230-0	ESTATÍSTICA APLICADA	68
49828	2501.000.255-2	FUNDAMENTOS E PROJETOS DE OPERAÇÕES	68
49841	2501.000.268-8	GESTÃO DE CUSTOS	68
49833	2501.000.260-5	GESTÃO DO COMPOSTO DE MARKETING	68
49829	2501.000.256-1	GESTÃO DE OPERAÇÕES	68
49819	2501.000.246-3	GESTÃO FINANCEIRA	68
49824	2501.000.251-6	PRÁTICAS INTERDISCIPLINARES III	102
49827	2501.000.254-3	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	68
49820	2501.000.247-2	ANÁLISE FINANCEIRA E DE INVESTIMENTOS	68
40268	2501.000.088-2	ELABORAÇÃO E AVALIAÇÃO DE PROJETOS	68
49821	2501.000.248-1	GESTÃO DE PESSOAS E MUDANÇA ORGANIZACIONAL	68
49830	2501.000.257-0	GESTÃO LOGÍSTICA	68
49843	2501.000.270-3	ATIVIDADE PRÁTICA SUPERVISIONADA	68
49826	2501.000.253-4	ANÁLISE MULTIVARIADA	68
42920	3001.000.311-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
49825	2501.000.252-5	NEGOCIAÇÃO	68
49836	2501.000.263-2	PESQUISA DE MERCADO	68
49805	2501.000.232-9	TÓPICO ESPECIAL EM ADMINISTRAÇÃO I	68
49806	2501.000.233-8	TOPICO ESPECIAL EM ADMINISTRAÇÃO II	68
49807	2501.000.234-7	TOPICO ESPECIAL EM ADMINISTRAÇÃO III	68
49808	2501.000.235-6	TOPICO ESPECIAL EM ADMINISTRAÇÃO IV	68
49815	2501.000.242-7	TOPICO ESPECIAL EM ADMINISTRAÇÃO IX	68
49809	2501.000.236-5	TOPICO ESPECIAL EM ADMINISTRAÇÃO V	68
49810	2501.000.237-4	TOPICO ESPECIAL EM ADMINISTRAÇÃO VI	68
49811	2501.000.238-3	TOPICO ESPECIAL EM ADMINISTRAÇÃO VII	68
49814	2501.000.241-8	TOPICO ESPECIAL EM ADMINISTRAÇÃO VIII	68
49817	2501.000.244-5	TOPICO ESPECIAL EM ADMINISTRAÇÃO X	68
49812	2501.000.239-2	TOPICO ESPECIAL EM ADMINISTRAÇÃO XI	34
49816	2501.000.243-6	TOPICO ESPECIAL EM ADMINISTRAÇÃO XII	34
49818	2501.000.245-4	TOPICO ESPECIAL EM ADMINISTRAÇÃO XIII	34
49813	2501.000.240-9	TOPICO ESPECIAL EM ADMINISTRAÇÃO XIV	34
40208	2501.000.028-9	TÓPICO ESPECIAL INTERDISCIPLINAR I	102
40209	2501.000.029-7	TÓPICO ESPECIAL INTERDISCIPLINAR II	102
40210	2501.000.030-0	TÓPICO ESPECIAL INTERDISCIPLINAR III	102
40211	2501.000.031-9	TÓPICO ESPECIAL INTERDISCIPLINAR IV	102
40212	2501.000.032-7	TÓPICO ESPECIAL INTERDISCIPLINAR V	102
40213	2501.000.033-5	TÓPICO ESPECIAL INTERDISCIPLINAR VI	102
40215	2501.000.035-1	TÓPICO ESPECIAL INTERDISCIPLINAR VII	102
40214	2501.000.034-3	TÓPICO ESPECIAL INTERDISCIPLINAR VIII	102
51237	2501.000.328-2	ÉTICA PROFISSIONAL NO TURISMO	68
51222	2501.000.313-9	FUNDAMENTOS DO TURISMO E HOSPITALIDADE	68
40184	2501.000.004-1	INTRODUÇÃO À ECONOMIA	68
51225	2501.000.316-6	PLANEJAMENTO E GESTÃO DO LAZER	68
40231	2501.000.051-3	FUNDAMENTOS GEOGRÁFICOS DO TURISMO	68
51223	2501.000.314-8	HISTÓRIA CONTEMPORÂNEA DO TURISMO	68
40232	2501.000.052-1	MEIOS DE HOSPEDAGEM	68
51238	2501.000.329-1	TURISMO, CULTURA E SOCIEDADE	68
51224	2501.000.315-7	AMBIENTAÇÃO PROFISSIONAL EM MEIOS DE HOSPEDAGEM	68
40235	2501.000.055-6	MARKETING TURÍSTICO	68
51220	2501.000.311-0	PESQUISA EM TURISMO I	68
51221	2501.000.312-0	TURISMO E ALIMENTAÇÃO	68
51217	2501.000.308-6	AGENCIAMENTO E ROTEIRIZAÇÃO	68
51216	2501.000.307-7	AMBIENTAÇÃO PROFISSIONAL PARA TURISMO E ALIMENTAÇÃO	68
51219	2501.000.310-1	PESQUISA EM TURISMO II	34
40233	2501.000.053-0	PLANEJAMENTO E ORGANIZAÇÃO DO TURISMO I	68
51215	2501.000.306-8	SEGMENTAÇÃO DO MERCADO TURÍSTICO	68
51226	2501.000.317-5	SISTEMAS DE INFORMAÇÃO PARA GESTÃO	34
51218	2501.000.309-5	AMBIENTAÇÃO PROFISSIONAL EM AGENCIAMENTO E ROTEIRIZAÇÃO	68
40234	2501.000.054-8	EVENTOS	68
51239	2501.000.330-8	LEGISLAÇÃO DO TURISMO	34
40236	2501.000.056-4	PLANEJAMENTO E ORGANIZAÇÃO DO TURISMO II	68
51210	2501.000.301-2	SISTEMA DE TRANSPORTE TURÍSTICO	34
51214	2501.000.305-9	AMBIENTAÇÃO PROFISSIONAL EM EVENTOS	68
40278	2501.000.098-0	GESTÃO CONTÁBIL, DE CUSTOS E PREÇOS	68
51211	2501.000.302-1	GESTÃO PÚBLICA DO TURISMO	68
51213	2501.000.304-0	PLANO DE NEGÓCIOS EM TURISMO	68
40240	2501.000.060-2	TURISMO EM ÁREAS NATURAIS	68
51208	2901.001.121-8	LÍNGUA ESPANHOLA	68
51209	2501.000.300-3	MÍDIAS PARA O TURISMO	34
51235	2501.000.326-4	PATRIMÔNIO CULTURAL E TURISMO	68
51233	2501.000.324-6	ABORDAGEM SISTÊMICA APLICADA AO TURISMO	68
51230	2501.000.321-9	ABORDAGENS CONTEMPORÂNEAS DO TURISMO I	68
51232	2501.000.323-7	ABORDAGENS CONTEMPORÂNEAS DO TURISMO II	68
51234	2501.000.325-5	CULTURA E ALIMENTAÇÃO	68
51231	2501.000.322-8	DESTINOS INDUTORES DO TURISMO	68
51227	2501.000.318-4	ESTRATÉGIA - VISÃO BASEADA EM RECURSOS	68
51228	2501.000.319-3	ESTUDO INTERDISCIPLINAR	68
51229	2501.000.320-0	GESTÃO DE MEIOS DE HOSPEDAGEM	68
51212	2501.000.303-0	PLANEJAMENTO DO TURISMO EM ÁREAS NATURAIS	68
51240	2501.000.331-7	PLANEJAMENTO URBANO	68
51236	2501.000.327-3	TURISMO NO ESPAÇO RURAL	68
46655	2501.000.194-9	CONTABILIDADE I	68
46639	2901.001.007-9	INGLÊS INSTRUMENTAL PARA CONTABILIDADE	68
49670	2501.000.215-0	INTRODUÇÃO À ADMINISTRAÇÃO	68
49674	2501.000.219-6	INTRODUÇÃO À ECONOMIA	68
49656	2201.000.206-5	MATEMÁTICA	68
46656	2501.000.195-8	CONTABILIDADE II	68
49658	2001.000.422-6	DIREITO CONSTITUCIONAL E EMPRESARIAL	34
49659	2001.000.423-5	DIREITOS HUMANOS, TRABALHISTA E PREVIDENCIÁRIO	34
46635	2501.000.177-0	ESTATÍSTICA APLICADA À CONTABILIDADE	51
49678	2501.000.223-0	FILOSOFIA, ÉTICA E LEGISLAÇÃO PROFISSIONAL CONTÁBIL	75
49673	2501.000.218-7	MÉTODOS E TÉCNICAS DE PESQUISA	68
46636	2501.000.178-9	NOÇÕES ATUARIAIS	17
49675	2501.000.220-2	COMUNICAÇÃO EMPRESARIAL E CONTÁBIL	75
49660	2501.000.205-1	CONTABILIDADE DE CUSTOS	68
46657	2501.000.196-7	CONTABILIDADE III	68
49672	2501.000.217-8	MATEMÁTICA FINANCEIRA	68
49680	2501.000.225-8	TEORIA DA CONTABILIDADE	68
49668	2501.000.213-1	ADMINISTRAÇÃO FINANCEIRA	68
46644	2501.000.183-1	ANÁLISE DE CUSTOS	68
49661	2501.000.206-0	CONTABILIDADE SOCIETÁRIA I	68
49657	2001.000.421-7	DIREITO TRIBUTÁRIO	68
46662	2501.000.200-6	TEORIA DAS FINANÇAS E ADMINISTRAÇÃO PÚBLICA	68
49667	2501.000.212-2	CONTABILIDADE APLICADA AO SETOR PÚBLICO	68
49679	2501.000.224-9	CONTABILIDADE E GESTÃO DO TERCEIRO SETOR	75
49662	2501.000.207-0	CONTABILIDADE SOCIETÁRIA II	68
49682	2501.000.227-6	CONTABILIDADE TRIBUTÁRIA	68
46649	2501.000.188-7	MÉTODOS QUANTITATIVOS APLICADOS À CONTABILIDADE	68
49676	2501.000.221-1	APRENDIZAGEM BASEADA EM PROJETOS EM CONTABILIDADE	75
49671	2501.000.216-9	CONTABILIDADE APLICADA AO AGRONEGÓCIO	68
49664	2501.000.209-8	CONTABILIDADE AVANÇADA	68
49677	2501.000.222-0	CONTABILIDADE TRIBUTÁRIA EMPRESARIAL	68
46651	2501.000.190-2	PLANEJAMENTO ESTRATÉGICO E ORÇAMENTÁRIO	68
49665	2501.000.210-4	ANÁLISE DAS DEMONSTRAÇÕES CONTÁBEIS	68
49669	2501.000.214-0	AUDITORIA CONTÁBIL	68
49683	2501.000.228-5	CONTROLADORIA	68
49684	2501.000.229-4	LABORATÓRIO CONTÁBIL I	68
49666	2501.000.211-3	METODOLOGIA DA PESQUISA APLICADA À CONTABILIDADE	68
49663	2501.000.208-9	LABORATÓRIO CONTÁBIL II	68
46641	2501.000.181-3	MERCADO FINANCEIRO E DE CAPITAIS	68
49681	2501.000.226-7	PERÍCIA E ARBITRAGEM	68
46630	2501.000.172-4	ADMINISTRAÇÃO DE PROJETOS VOLTADOS AO CONTROLE GERENCIAL	68
46620	2501.000.163-5	AUDITORIA GOVERNAMENTAL E CONTROLE EXTERNO	34
46653	2501.000.192-0	COMERCIALIZAÇÃO AGRÍCOLA	68
46617	2501.000.160-8	COMUNICAÇÃO EMPRESARIAL E NOTAS EXPLICATIVAS	34
46614	2501.000.157-3	CONTABILIDADE E ANÁLISE FINANCEIRA DE SOCIEDADES COOPERATIVAS	68
46627	2501.000.169-0	CONTABILIDADE SOCIAL	68
46628	2501.000.170-6	CONTABILIDADE, TRIBUTOS E CIDADANIA	34
46623	2901.001.006-0	ESPANHOL INSTRUMENTAL PARA CONTABILIDADE	34
46622	2501.000.165-3	FINANÇAS PESSOAIS	34
46629	2501.000.171-5	INOVAÇÃO E GESTÃO DO CONHECIMENTO APLICADOS À CONTABILIDADE	68
46632	2501.000.174-2	JOGOS DE EMPRESAS	68
46619	2501.000.162-6	LINGUAGEM DE PROGRAMAÇÃO APLICADA À CONTABILIDADE	68
42152	3101.000.348-7	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS I	34
46631	2501.000.173-3	MAPEAMENTO DE PROCESSOS INTERNOS VOLTADOS À CONTROLADORIA	68
46646	2501.000.185-0	MARKETING DE SERVIÇOS CONTÁBEIS	34
46634	2501.000.176-0	PLANEJAMENTO ESTRATÉGICO EM ORGANIZAÇÕES PÚBLICAS E SOCIAIS	68
46659	2501.000.197-6	RELATO INTEGRADO	68
46616	2501.000.159-1	SEMINÁRIOS DE PESQUISA EM CONTABILIDADE	68
46660	2501.000.198-5	SISTEMA DE INFORMAÇÃO CONTÁBIL	68
46661	2501.000.199-4	SOLUÇÃO DE PROBLEMAS GERENCIAIS EM PBL (EMI)	68
46633	2501.000.175-1	TÓPICO ESPECIAL E TEMAS EMERGENTES NA CONTABILIDADE	34
46647	2501.000.186-9	TÓPICO ESPECIAL E TEMAS EMERGENTES NA CONTROLADORIA	34
46624	2501.000.166-2	TÓPICOS EMERGENTES EM CONTABILIDADE	68
46625	2501.000.167-1	TÓPICOS EMERGENTES EM CONTROLADORIA	68
40276	2501.000.096-3	GESTÃO DE PESSOAS POR COMPETÊNCIAS	68
40271	2501.000.091-2	GESTÃO MERCADOLÓGICA	68
40272	2501.000.092-0	GESTÃO DE SERVIÇOS	68
40273	2501.000.093-9	PRÁTICAS DE PROCESSOS ORGANIZACIONAIS I	68
40275	2501.000.095-5	GESTÃO FINANCEIRA	68
40279	2501.000.099-8	PESQUISA APLICADA INTERDISCIPLINAR	68
40274	2501.000.094-7	PRÁTICA DE PROCESSOS ORGANIZACIONAIS II	68
42923	3001.000.312-8	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
40216	2501.000.036-0	TÓPICO ESPECIAL INTERDISCIPLINAR IX	102
40217	2501.000.037-8	TÓPICO ESPECIAL INTERDISCIPLINAR X	102
50175	2501.000.271-2	TÓPICO ESPECIAL INTERDISCIPLINAR XV - PROJETO DE EXTENSÃO	102
40186	2501.000.006-8	ESTATÍSTICA I	68
42935	2501.000.129-3	FORMAÇÃO ECONÔMICA DO CAPITALISMO	68
50278	2501.000.292-8	INTRODUÇÃO À CONTABILIDADE	34
50276	2501.000.290-0	INTRODUÇÃO À ECONOMIA	68
50275	2501.000.289-3	INTRODUÇÃO ÀS CIÊNCIAS SOCIAIS	34
50255	2201.000.208-3	MATEMÁTICA	68
42937	2501.000.108-0	CONTABILIDADE SOCIAL	68
50256	2201.000.209-2	ECONOMIA MATEMÁTICA	68
40252	2501.000.072-6	ESTATÍSTICA II	68
50274	2501.000.288-4	FUNDAMENTOS TEÓRICOS DA MACROECONOMIA	68
42938	2501.000.132-3	HISTÓRIA DO PENSAMENTO ECONÔMICO	68
50279	2501.000.293-7	ECONOMETRIA I	68
50273	2501.000.287-5	ECONOMIA MARXISTA	68
42940	2501.000.137-4	MÉTODOS MATEMÁTICOS EM ECONOMIA	68
51897	2501.000.332-6	TEORIA MACROECONÔMICA I	68
42943	2501.000.142-0	TEORIA MICROECONÔMICA I	68
42955	2501.000.121-8	ECONOMIA MONETÁRIA	68
42946	2501.000.128-5	FORMAÇÃO ECONÔMICA DO BRASIL	68
51899	2501.000.334-4	MATEMÁTICA FINANCEIRA	68
51900	2501.000.335-3	PRÁTICA EXTENSIONISTA I	102
51898	2501.000.333-5	TEORIA MACROECONÔMICA II	68
42948	2501.000.143-9	TEORIA MICROECONÔMICA II	68
42958	2501.000.105-6	ANÁLISE DE INVESTIMENTOS	68
42963	2501.000.113-7	ECONOMIA BRASILEIRA CONTEMPORÂNEA I	68
50280	2501.000.294-6	ECONOMIA INDUSTRIAL	68
42949	2501.000.119-6	ECONOMIA INTERNACIONAL I	68
51901	2501.000.336-2	PRÁTICA EXTENSIONISTA II	68
42951	2501.000.141-2	TEORIA MACROECONÔMICA III	68
42957	2501.000.110-2	DESENVOLVIMENTO SOCIOECONÔMICO	68
42960	2501.000.114-5	ECONOMIA BRASILEIRA CONTEMPORÂNEA II	68
42953	2501.000.115-3	ECONOMIA DO SETOR PÚBLICO	68
42954	2501.000.120-0	ECONOMIA INTERNACIONAL II	68
50283	2501.000.297-3	METÓDOS E TÉCNICAS DE PESQUISA EM ECONOMIA	68
51903	2501.000.338-0	PRÁTICA EXTENSIONISTA III	68
50266	2501.000.280-1	ECONOMETRIA II	68
50285	2501.000.299-1	ECONOMIA DOS RECURSOS NATURAIS	68
50259	2501.000.273-0	INTRODUÇÃO À TEORIA DA ADMINISTRAÇÃO	34
50284	2501.000.298-2	LABORATÓRIO DE ECONOMIA	34
51902	2501.000.337-1	PRÁTICA EXTENSIONISTA IV	68
50257	2001.000.425-3	DIREITO E ECONOMIA	34
50269	2501.000.283-9	ECONOMIA DO TRABALHO	68
42950	2501.000.125-0	ECONOMIA REGIONAL E URBANA	68
50277	2501.000.291-9	MERCADOS FINANCEIROS E DE CAPITAIS	68
50271	2501.000.285-7	TEORIA DOS JOGOS	68
50265	2501.000.279-5	TÓPICO EM NEGOCIAÇÃO INTERNACIONAL	68
50262	2501.000.276-8	TÓPICOS EM ECONOMIA BRASILEIRA CONTEMPORÂNEA	68
50263	2501.000.277-7	TÓPICOS EM ECONOMIA DA INOVAÇÃO TECNOLÓGICA I	68
50261	2501.000.275-9	TÓPICOS EM ECONOMIA DA INOVAÇÃO TECNOLÓGICA II	68
50260	2501.000.274-0	TÓPICOS EM ECONOMIA MONETÁRIA	68
50270	2501.000.284-8	TÓPICOS EM ECONOMIA REGIONAL E URBANA	68
50264	2501.000.278-6	TÓPICOS EM MACROECONOMIA KEYNESIANA	68
42928	2501.000.146-3	TÓPICOS ESPECIAIS EM ECONOMIA AGRÍCOLA	68
42930	2501.000.148-0	TÓPICOS ESPECIAIS EM ECONOMIA CRIATIVA	68
42931	2501.000.149-8	TÓPICOS ESPECIAIS EM ECONOMIA DE EMPRESAS	68
50272	2501.000.286-6	TÓPICOS ESPECIAIS EM MACROECONOMIA	68
42933	2501.000.151-0	TÓPICOS ESPECIAIS EM TEORIA ECONÔMICA	68
42934	2501.000.152-8	TÓPICOS ESPECIAIS MERCADO FINANCEIRO E DE CAPITAIS	68
41095	2701.000.004-8	ANATOMIA HUMANA	68
45760	2601.000.299-3	CÁLCULO FARMACÊUTICO	34
41247	2601.000.084-8	INTRODUÇÃO ÀS CIÊNCIAS FARMACÊUTICAS	34
45778	2301.000.313-5	QUÍMICA GERAL E INORGÂNICA	34
45757	2801.000.135-4	SAÚDE DA COMUNIDADE	51
45795	2701.000.303-4	BIOQUÍMICA I	51
45789	2601.000.326-6	ESTÁGIO OBRIGATÓRIO NA ATENÇÃO BÁSICA À SAÚDE	108
41251	2701.000.075-7	HISTOLOGIA DOS SISTEMAS	51
49457	2601.000.409-4	PRÁTICAS SOCIAIS EM FARMÁCIA	68
38436	2301.000.271-4	QUÍMICA ORGÂNICA PRÁTICA I	34
45753	2701.000.302-5	BIOQUÍMICA II	51
49465	2601.000.417-4	ÉTICA E BIOÉTICA	34
41254	2701.000.076-5	IMUNOLOGIA BÁSICA	68
41255	2701.000.077-3	MICROBIOLOGIA BÁSICA	51
45742	2301.000.310-8	QUÍMICA ANALÍTICA EXPERIMENTAL I	34
38442	2301.000.273-0	QUÍMICA ORGÂNICA II	51
38443	2301.000.274-9	QUÍMICA ORGÂNICA PRÁTICA II	34
45796	2601.000.332-8	BIOLOGIA CELULAR E MOLECULAR	51
41145	2601.000.042-2	BROMATOLOGIA	68
45776	2601.000.314-0	FÍSICO-QUÍMICA APLICADA À FARMÁCIA	34
41250	2701.000.074-9	FISIOLOGIA	68
45766	2601.000.305-0	METODOLOGIA CIENTÍFICA	34
41264	2701.000.078-1	PARASITOLOGIA HUMANA	68
45755	2301.000.311-7	QUÍMICA ANALÍTICA EXPERIMENTAL II	34
45774	2601.000.313-0	FARMÁCIA HOSPITALAR	34
41263	2601.000.093-7	FARMACOLOGIA BÁSICA I	51
45743	2601.000.285-9	IDENTIFICAÇÃO ESPECTROMÉTRICA DE COMPOSTOS ORGÂNICOS	51
41289	2601.000.117-8	MICROBIOLOGIA CLÍNICA	68
41268	2601.000.097-0	PARASITOLOGIA CLÍNICA	68
41265	2601.000.094-5	QUÍMICA FARMACÊUTICA I	68
41261	2601.000.091-0	DEONTOLOGIA E LEGISLAÇÃO FARMACÊUTICA	34
45750	2601.000.292-0	ESTÁGIO OBRIGATÓRIO EM FARMÁCIA HOSPITALAR	108
45748	2601.000.290-1	FARMACOBOTÂNICA	51
41267	2601.000.096-1	FARMACOLOGIA BÁSICA II	51
49460	2601.000.412-9	GERENCIAMENTO DA QUALIDADE	34
41288	2601.000.116-0	IMUNOLOGIA CLÍNICA	68
41271	2601.000.100-3	QUÍMICA FARMACÊUTICA II	68
41272	2601.000.101-1	CONTROLE DE QUALIDADE DE FÁRMACOS E MEDICAMENTOS I	68
45790	2601.000.327-5	ESTÁGIO OBRIGATÓRIO ESPECIALIZADO NO SERVIÇO PÚBLICO DE SAÚDE	108
45784	2601.000.321-0	FARMACOGNOSIA	68
45794	2601.000.331-9	FARMACOLOGIA CLÍNICA E TERAPÊUTICA I	51
41275	2601.000.103-8	FARMACOTÉCNICA I	68
45759	2601.000.298-4	FLUIDOS ORGÂNICOS	68
41276	2601.000.104-6	TOXICOLOGIA GERAL	51
41278	2601.000.106-2	CONTROLE DE QUALIDADE DE FÁRMACOS E MEDICAMENTOS II	68
45783	2601.000.320-1	COSMETOLOGIA	68
45791	2601.000.328-4	ESTÁGIO OBRIGATÓRIO EM DROGARIA	108
45773	2601.000.312-1	FARMACOLOGIA CLÍNICA E TERAPÊUTICA II	51
41283	2601.000.111-9	FARMACOTÉCNICA II	68
45785	2601.000.322-0	FITOTERAPIA E CONTROLE DE QUALIDADE DE PLANTAS MEDICINAIS	68
41285	2601.000.113-5	BIOQUÍMICA CLÍNICA	85
45752	2601.000.294-8	CUIDADO FARMACÊUTICO I	51
47548	2601.000.396-3	ESTÁGIO OBRIGATÓRIO EM ESPECIFICIDADES REGIONAIS	90
45751	2601.000.293-9	ESTÁGIO OBRIGATÓRIO EM FARMÁCIA COM MANIPULAÇÃO	108
49456	2601.000.408-5	FUNDAMENTAÇÃO PARA O PROJETO DE CONCLUSÃO DE CURSO	51
45771	2601.000.310-3	HEMATOLOGIA BÁSICA	51
41287	2601.000.115-1	TECNOLOGIA FARMACÊUTICA	68
49466	2601.000.418-3	CUIDADO FARMACÊUTICO II	51
45786	2601.000.323-9	ESTÁGIO OBRIGATÓRIO EM ANÁLISES CLÍNICAS, TOXICOLÓGICAS, GENÉTICAS E ALIMENTOS	270
45777	2601.000.315-9	GESTÃO EM SAÚDE	34
45772	2601.000.311-2	HEMATOLOGIA CLÍNICA	68
45758	2601.000.297-5	ANÁLISE E APRESENTAÇÃO DE DADOS BIOLÓGICOS	34
45238	2601.000.256-3	ANÁLISE FÍSICO-QUÍMICA DE ALIMENTOS	51
45764	2601.000.303-2	AURICULOTERAPIA	51
41421	2801.000.095-0	BIOESTATÍSTICA	34
41309	2601.000.136-4	CITOLOGIA CLÍNICA	68
41296	2601.000.123-2	CONTROLE MICROBIOLÓGICO DE FÁRMACOS E MEDICAMENTOS	51
45745	2601.000.287-7	DIAGNÓSTICO MOLECULAR DE DOENÇAS INFECCIOSAS E PARASITÁRIAS	51
42622	3001.000.147-8	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
41392	2801.000.031-3	EPIDEMIOLOGIA	34
45756	2601.000.296-6	ESTÁGIO OBRIGATÓRIO COMPLEMENTAR	34
41230	2601.000.070-8	FARMACOEPIDEMIOLOGIA	51
45749	2601.000.291-0	FUNDAMENTOS DE CROMATOGRAFIA	51
41232	2701.000.070-6	GESTÃO AMBIENTAL	51
45781	2601.000.318-6	GESTÃO DA QUALIDADE EM ANÁLISES CLÍNICAS	51
45762	2601.000.301-4	HOMEOPATIA	68
49459	2601.000.411-0	INTERPRETAÇÃO DOS EXAMES LABORATORIAIS NA ATENÇÃO FARMACÊUTICA	51
45744	2601.000.286-8	INTRODUÇÃO À VIROLOGIA HUMANA	51
41299	2601.000.126-7	MICOLOGIA CLÍNICA	51
45195	2601.000.218-9	MICROBIOLOGIA DE ALIMENTOS	68
41344	2601.000.141-0	PRINCÍPIOS DE TECNOLOGIA DE ALIMENTOS	51
49458	2601.000.410-0	SERVIÇOS FARMACÊUTICOS	68
45779	2601.000.316-8	SISTEMAS DE LIBERAÇÃO DE FÁRMACOS	34
41099	2601.000.001-5	TECNOLOGIA DE ALIMENTOS DE ORIGEM ANIMAL	51
41100	2601.000.002-3	TECNOLOGIA DE ALIMENTOS DE ORIGEM VEGETAL	51
43953	2601.000.209-0	TECNOLOGIA DE BEBIDAS ALCOÓLICAS	51
46746	2601.000.389-2	TECNOLOGIAS EMERGENTES EM CONSERVAÇÃO DE ALIMENTOS	34
45780	2601.000.317-7	TÓPICOS EM FARMÁCIA I	34
45787	2601.000.324-8	TÓPICOS EM FARMÁCIA II	34
45769	2601.000.308-8	TÓPICOS EM FARMÁCIA III	34
45782	2601.000.319-5	TÓPICOS EM FARMÁCIA IV	34
49464	2601.000.416-5	TÓPICOS EM FARMÁCIA IX	68
45747	2601.000.289-5	TÓPICOS EM FARMÁCIA V	34
49461	2601.000.413-8	TÓPICOS EM FARMÁCIA VI	51
49462	2601.000.414-7	TÓPICOS EM FARMÁCIA VII	51
49463	2601.000.415-6	TÓPICOS EM FARMÁCIA VIII	68
45767	2601.000.306-0	TÓPICOS ESPECIAIS EM GERONTOLOGIA	51
41311	2701.000.081-1	TÓPICOS ESPECIAIS EM PARASITOLOGIA	51
45765	2601.000.304-1	USO RACIONAL DE MEDICAMENTOS	51
41103	2701.000.008-0	BIOLOGIA CELULAR	51
41097	2701.000.006-4	EMBRIOLOGIA	34
47547	2601.000.395-4	ÉTICA E BIOÉTICA	34
43049	2701.000.260-9	GENÉTICA HUMANA	34
45929	2701.000.305-2	HISTOLOGIA	51
45928	2601.000.360-4	METODOLOGIA CIENTÍFICA	34
41143	2601.000.041-4	NUTRIÇÃO BÁSICA	34
45919	2701.000.304-3	FISIOLOGIA HUMANA I	51
41094	2701.000.003-0	IMUNOLOGIA	51
43047	2701.000.258-3	PARASITOLOGIA	34
42981	3001.000.361-6	PSICOLOGIA	34
45924	2601.000.356-0	QUÍMICA DOS ALIMENTOS	51
45920	2601.000.352-4	SAÚDE COLETIVA	34
45926	2601.000.358-9	SOCIOLOGIA E ANTROPOLOGIA DA ALIMENTAÇÃO	51
41108	2601.000.007-4	TÉCNICA DIETÉTICA I	68
41115	2601.000.014-7	TOXICOLOGIA DOS ALIMENTOS	34
41109	2601.000.008-2	AVALIAÇÃO NUTRICIONAL I	68
41111	2601.000.010-4	EPIDEMIOLOGIA	34
41146	2701.000.013-7	FISIOLOGIA HUMANA II	51
41102	2601.000.004-0	MICROBIOLOGIA DE ALIMENTOS	68
41147	2601.000.043-0	NUTRIÇÃO E DIETÉTICA I	34
45911	2601.000.344-4	POLÍTICAS PÚBLICAS DE SAÚDE	51
41114	2601.000.013-9	TÉCNICA DIETÉTICA II	68
41148	2601.000.044-9	ALIMENTAÇÃO COLETIVA I	51
41113	2601.000.012-0	AVALIAÇÃO NUTRICIONAL II	68
45921	2601.000.353-3	ECONOMIA E MARKETING	34
47555	2601.000.403-0	HIGIENE, CONTROLE E LEGISLAÇÃO DE ALIMENTOS	34
41119	2601.000.018-0	NUTRIÇÃO E DIETÉTICA II	68
45922	2601.000.354-2	NUTRIÇÃO E METABOLISMO	68
43046	2701.000.257-4	PATOLOGIA GERAL	51
45914	2601.000.347-1	POLÍTICAS PÚBLICAS DE ALIMENTAÇÃO E NUTRIÇÃO	51
43044	2601.000.194-0	ALIMENTAÇÃO COLETIVA II	51
45927	2601.000.359-8	EDUCAÇÃO ALIMENTAR E NUTRICIONAL	51
41150	2601.000.046-5	FARMACOLOGIA	34
45915	2601.000.348-0	FISIOPATOLOGIA DA NUTRIÇÃO E DIETOTERAPIA I	68
45912	2601.000.345-3	NUTRIÇÃO E DIETÉTICA III	68
45908	2601.000.341-7	NUTRIÇÃO E ESPORTE	51
45923	2601.000.355-1	NUTRIÇÃO EXPERIMENTAL	34
47556	2601.000.404-9	ALIMENTAÇÃO COLETIVA III	51
41122	2601.000.021-0	ÉTICA PROFISSIONAL E LEGISLAÇÃO	34
45917	2601.000.350-6	FISIOPATOLOGIA DA NUTRIÇÃO E DIETOTERAPIA II	68
45918	2601.000.351-5	METODOLOGIA DO TRABALHO DE CONCLUSÃO DE CURSO	34
41159	2601.000.055-4	NUTRIÇÃO CLÍNICA EM PEDIATRIA	51
43045	2601.000.195-0	SAÚDE E NUTRIÇÃO DE POPULAÇÕES INDÍGENAS	34
41154	2601.000.050-3	TECNOLOGIA DE ALIMENTOS	68
45925	2601.000.357-0	TERAPIA NUTRICIONAL	34
45904	2601.000.337-3	ESTÁGIO OBRIGATÓRIO DE ALIMENTAÇÃO COLETIVA	204
45916	2601.000.349-0	ESTÁGIO OBRIGATÓRIO EM NUTRIÇÃO CLÍNICA	204
45903	2601.000.336-4	ESTÁGIO OBRIGATÓRIO DE CIÊNCIAS DOS ALIMENTOS	102
45931	2601.000.362-2	ESTÁGIO OBRIGATÓRIO DE NUTRIÇÃO EM SAÚDE COLETIVA	204
41125	2601.000.024-4	ALIMENTOS E BEBIDAS	34
43059	2601.000.201-7	ALIMENTOS E MODELOS ANIMAIS DE DOENÇAS	34
45906	2601.000.339-1	ANÁLISE SENSORIAL DOS ALIMENTOS	51
45902	2601.000.335-5	APRIMORAMENTO PROFISSIONAL EM NUTRIÇÃO	34
43055	2601.000.199-6	BIOQUÍMICA DE ALIMENTOS	34
41138	2601.000.036-8	CONSERVAÇÃO PÓS-COLHEITA DE FRUTAS E HORTALIÇAS	34
42980	3001.000.360-8	DESENVOLVIMENTO PESSOAL E PROFISSIONAL	34
41663	3101.000.004-6	DIDÁTICA E RELAÇÕES PEDAGÓGICAS	68
43056	2001.000.312-0	DIREITOS HUMANOS I	34
43057	2001.000.313-0	DIREITOS HUMANOS II	34
43053	3001.000.370-0	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	68
45761	2601.000.300-5	EMPREENDEDORISMO E INOVAÇÃO	68
45910	2601.000.343-5	ENFRENTAMENTO E CONTROLE DA OBESIDADE	34
41117	2601.000.016-3	EPIDEMIOLOGIA NUTRICIONAL	34
43051	3101.000.295-7	ESTUDO DE LIBRAS	68
41135	2601.000.033-3	FISIOLOGIA DO EXERCÍCIO I	34
41136	2601.000.034-1	FISIOLOGIA DO EXERCÍCIO II	34
41167	2601.000.063-5	FITOTERAPIA	34
47551	2601.000.399-0	FUNGOS FILAMENTOSOS E MICOTOXINAS EM ALIMENTOS E BEBIDAS	68
41123	2601.000.022-8	GASTRONOMIA	51
41129	2601.000.028-7	GASTRONOMIA HOSPITALAR	34
45905	2601.000.338-2	GENÔMICA NUTRICIONAL	34
41168	2601.000.064-3	GESTÃO AMBIENTAL	34
42978	3001.000.358-6	HISTÓRIA E CULTURA INDÍGENA	34
41169	2601.000.065-1	INFORMÁTICA APLICADA À NUTRIÇÃO	34
41131	2601.000.030-9	INTERPRETAÇÃO DE EXAMES LABORATORIAIS	34
42979	3001.000.359-4	INTRODUÇÃO À HISTÓRIA E A CULTURA AFRO-BRASILEIRA E AFRICANA	34
42968	2901.000.482-1	LEITURA EM LÍNGUA INGLESA I	34
42969	2901.000.483-0	LEITURA EM LÍNGUA INGLESA II	34
42972	2901.000.484-8	LEITURA E PRODUÇÃO DE TEXTO I	34
42973	2901.000.485-6	LEITURA E PRODUÇÃO DE TEXTO II	34
45909	2601.000.342-6	MANEJO E ACONSELHAMENTO EM AMAMENTAÇÃO	34
41170	2601.000.066-0	MECANISMOS BIOENERGÉTICOS E DE METABÓLITOS	34
45930	2601.000.361-3	NUTRIÇÃO E ENVELHECIMENTO	34
41139	2601.000.037-6	SEMINÁRIOS EM NUTRIÇÃO I	34
41140	2601.000.038-4	SEMINÁRIOS EM NUTRIÇÃO II	34
41141	2601.000.039-2	SEMINÁRIOS EM NUTRIÇÃO III	34
41142	2601.000.040-6	SEMINÁRIOS EM NUTRIÇÃO IV	34
42976	3001.000.357-8	SOCIEDADE, MEIO AMBIENTE E SUSTENTABILIDADE	34
42977	2901.000.486-4	TEORIAS DA COMUNICAÇÃO	34
47554	2601.000.402-0	TÓPICOS EM CONSUMO ALIMENTAR	34
45932	2601.000.363-1	TÓPICOS EM NUTRIÇÃO CLÍNICA	34
47553	2601.000.401-1	TÓPICOS EM NUTRIÇÃO ESPORTIVA	34
47549	2601.000.397-2	TÓPICOS EM OBESIDADE	34
47552	2601.000.400-2	TÓPICOS EM PEDIATRIA	34
47550	2601.000.398-1	TÓPICOS EM TECNOLOGIA DE ALIMENTOS	34
50382	2601.000.449-7	INTRODUÇÃO À ENGENHARIA DE ALIMENTOS	34
37193	2301.000.268-4	QUÍMICA GERAL I	68
45245	3001.000.536-7	RELAÇÕES ÉTNICO-RACIAIS	34
50352	2601.000.419-2	SEGURANÇA ALIMENTAR E NUTRICIONAL	34
50363	2601.000.430-7	SISTEMA AGROINDUSTRIAL ALIMENTAR	51
50354	2601.000.421-8	FUNDAMENTOS DA NUTRIÇÃO	34
46735	2601.000.378-5	FUNDAMENTOS DE QUÍMICA ANALÍTICA	34
50353	2601.000.420-9	METODOLOGIA DA PESQUISA	34
50398	2601.000.465-7	ANÁLISE FÍSICO-QUÍMICA DE ALIMENTOS	51
45219	2601.000.239-4	BIOQUÍMICA DE ALIMENTOS I	51
46730	2601.000.373-0	MICROBIOLOGIA DE ALIMENTOS	68
50373	2601.000.440-5	QUÍMICA DE ALIMENTOS	34
50357	2601.000.424-5	ANÁLISE E CONTROLE DE QUALIDADE DE ALIMENTOS	68
50379	2601.000.446-0	BIOQUÍMICA DE ALIMENTOS II	51
46723	2601.000.366-9	FÍSICO-QUÍMICA	34
50369	2601.000.436-1	GESTÃO AMBIENTAL E SUSTENTABILIDADE	51
46751	2601.000.394-5	FENÔMENOS DE TRANSPORTE I	51
50386	2601.000.453-0	LEGISLAÇÃO NA INDÚSTRIA DE ALIMENTOS	34
46747	2601.000.390-9	TERMODINÂMICA APLICADA	68
45244	2601.000.260-7	ANÁLISE SENSORIAL	51
50359	2601.000.426-3	CIÊNCIA E TECNOLOGIA DE GRÃOS, RAÍZES E TUBÉRCULOS	85
50362	2601.000.429-0	CIÊNCIA E TECNOLOGIA DE LEITES	85
50358	2601.000.425-4	ENGENHARIA BIOQUÍMICA	34
50372	2601.000.439-9	FENÔMENOS DE TRANSPORTE II	68
45194	2401.000.235-4	FUNDAMENTOS DE CIÊNCIA DOS MATERIAIS	34
50355	2601.000.422-7	GESTÃO DA SEGURANÇA DE ALIMENTOS	51
45251	2601.000.266-1	CIÊNCIA E TECNOLOGIA DE CARNES	85
46725	2601.000.368-7	CIÊNCIA E TECNOLOGIA DE FRUTAS E HORTALIÇAS	85
50387	2601.000.454-0	EMBALAGENS PARA ALIMENTOS	51
46738	2601.000.381-0	OPERAÇÕES UNITÁRIAS NA INDÚSTRIA DE ALIMENTOS I	51
50367	2601.000.434-3	TRATAMENTO DE RESÍDUOS NA INDÚSTRIA DE ALIMENTOS	68
50389	2601.000.456-8	CIÊNCIA E TECNOLOGIA DE CANA-DE-AÇÚCAR	51
50397	2601.000.464-8	EXTENSÃO EM ENGENHARIA DE ALIMENTOS	102
50393	2601.000.460-1	INSTRUMENTAÇÃO, INSTALAÇÕES E SEGURANÇA DO TRABALHO	68
50360	2601.000.427-2	METODOLOGIA APLICADA AO TRABALHO DE CONCLUSÃO DE CURSO	51
46733	2601.000.376-7	OPERAÇÕES UNITÁRIAS NA INDÚSTRIA DE ALIMENTOS II	51
50370	2601.000.437-0	PROJETOS NA INDÚSTRIA DE ALIMENTOS I	34
50385	2601.000.452-1	DESENVOLVIMENTO E MARKETING DE NOVOS PRODUTOS	68
45214	2501.000.155-5	DESENVOLVIMENTO PESSOAL E PROFISSIONAL	34
50391	2601.000.458-6	LABORATÓRIO DE ENGENHARIA DE ALIMENTOS	34
46734	2601.000.377-6	OPERAÇÕES UNITÁRIAS NA INDÚSTRIA DE ALIMENTOS III	51
50371	2601.000.438-0	PROJETOS NA INDÚSTRIA DE ALIMENTOS II	34
46742	2601.000.385-6	ESTÁGIO OBRIGATÓRIO EM ENGENHARIA DE ALIMENTOS	300
45197	2601.000.220-4	ADITIVOS ALIMENTARES	34
45242	2601.000.259-0	ALIMENTAÇÃO E COTIDIANO	34
45202	2601.000.224-0	ALIMENTOS E EXPERIMENTAÇÃO ANIMAL	51
45246	2601.000.261-6	ALIMENTOS FUNCIONAIS	34
50388	2601.000.455-9	ATUALIDADES DO MUNDO DO TRABALHO	34
45256	2601.000.271-4	CIÊNCIA E TECNOLOGIA DE PESCADOS	34
45206	2601.000.228-7	COMPOSTOS BIOATIVOS EM ALIMENTOS	51
45258	2601.000.273-2	CONSERVAÇÃO DE ALIMENTOS	34
45261	2601.000.276-0	COOPERATIVISMO	34
46722	2601.000.365-0	CULTIVO E PROPRIEDADES DE COGUMELOS COMESTÍVEIS	34
44548	2901.000.696-0	ESTUDO DE LIBRAS	51
45207	2601.000.229-6	ÉTICA E REGULAMENTAÇÃO PROFISSIONAL	34
50378	2601.000.445-0	EXTENSÃO EM ENGENHARIA DE ALIMENTOS I	34
50380	2601.000.447-9	EXTENSÃO EM ENGENHARIA DE ALIMENTOS II	51
50399	2601.000.466-6	EXTENSÃO EM ENGENHARIA DE ALIMENTOS III	68
50366	2601.000.433-4	EXTENSÃO EM ENGENHARIA DE ALIMENTOS IV	34
50356	2601.000.423-6	FUNGOS FILAMENTOSOS E MICOTOXINAS EM ALIMENTOS E BEBIDAS	34
44651	2601.000.217-0	GESTÃO DA INOVAÇÃO	34
46741	2601.000.384-7	LEITURA E PRODUÇÃO DE TEXTOS	34
50361	2601.000.428-1	MANEJO E PÓS-COLHEITA DE GRÃOS	51
45217	2601.000.237-6	MARKETING DE PRODUTOS AGROALIMENTARES	34
31636	2201.000.006-3	MÉTODOS NUMÉRICOS	68
46732	2601.000.375-8	MODELAGEM, SIMULAÇÃO E CONTROLE DE PROCESSOS	51
45211	2601.000.233-0	PLANTAS ALIMENTÍCIAS DO CERRADO E PANTANAL	34
45225	2601.000.244-7	PRÁTICAS EM ENGENHARIA DE ALIMENTOS	34
45218	2601.000.238-5	PROCESSAMENTO DE PRODUTOS LÁCTEOS	34
50377	2601.000.444-1	QUÍMICA DE ALIMENTOS I	34
50368	2601.000.435-2	REAPROVEITAMENTO DE RESÍDUOS DA AGROINDÚSTRIA	51
45200	2601.000.222-2	REFRIGERAÇÃO INDUSTRIAL	34
34325	2101.000.828-7	SEGURANÇA NO TRABALHO	34
45223	2601.000.242-9	SISTEMAS DE QUALIDADE APLICADO NA INDÚSTRIA DE CARNES	34
43952	2601.000.208-0	TECNOLOGIA DE BEBIDAS NÃO ALCOÓLICAS	34
45201	2601.000.223-1	TECNOLOGIA DE CAFÉ E CACAU	34
50394	2601.000.461-0	TECNOLOGIA DE CHOCOLATES	34
45208	2601.000.230-2	TECNOLOGIA DE ÓLEOS, GORDURAS E MARGARINAS	34
45228	2601.000.247-4	TECNOLOGIA DE OVOS E MEL	34
46740	2601.000.383-8	TECNOLOGIA DE PANIFICAÇÃO	68
50395	2601.000.462-0	TECNOLOGIAS EMERGENTES EM CONSERVAÇÃO DE ALIMENTOS	51
50375	2601.000.442-3	TÓPICOS ESPECIAIS EM CIÊNCIA DE ALIMENTOS I	34
50381	2601.000.448-8	TÓPICOS ESPECIAIS EM CIÊNCIA DE ALIMENTOS II	51
50390	2601.000.457-7	TÓPICOS ESPECIAIS EM CIÊNCIA DE ALIMENTOS III	68
45259	2601.000.274-1	TÓPICOS ESPECIAIS EM ENGENHARIA DE ALIMENTOS I	34
50392	2601.000.459-5	TÓPICOS ESPECIAIS EM ENGENHARIA DE ALIMENTOS II	51
50376	2601.000.443-2	TÓPICOS ESPECIAIS EM ENGENHARIA DE ALIMENTOS III	68
50383	2601.000.450-3	TÓPICOS ESPECIAIS EM SAÚDE E NUTRIÇÃO	34
50396	2601.000.463-9	TÓPICOS ESPECIAIS EM TECNOLOGIA DE ALIMENTOS I	34
50365	2601.000.432-5	TÓPICOS ESPECIAIS EM TECNOLOGIA DE ALIMENTOS II	51
50374	2601.000.441-4	TÓPICOS ESPECIAIS EM TECNOLOGIA DE ALIMENTOS III	68
50384	2601.000.451-2	TÓPICOS ESPECIAIS EM TECNOLOGIA DE CARNES	34
45226	2601.000.245-6	TOXICOLOGIA DE ALIMENTOS	51
41499	2701.000.149-4	BIOLOGIA CELULAR	85
41500	2701.000.150-8	BIOLOGIA INSTRUMENTAL	51
41177	2701.000.018-8	BIOSSISTEMÁTICA	34
37772	2101.001.050-8	GEOLOGIA	51
41501	2701.000.151-6	INTRODUÇÃO À METODOLOGIA CIENTÍFICA	34
41502	2701.000.152-4	MORFOLOGIA VEGETAL	68
41503	2701.000.153-2	ANATOMIA VEGETAL	68
41504	2701.000.154-0	BIOFÍSICA	51
41387	2701.000.089-7	HISTOLOGIA	68
41505	2701.000.155-9	ORGANISMOS PROCARIOTOS E PROTISTAS	51
37786	2101.001.051-6	PALEONTOLOGIA	51
41506	2701.000.156-7	BIODIVERSIDADE DE FUNGOS	51
41507	2701.000.157-5	EMBRIOLOGIA	68
41508	2701.000.158-3	ESTATÍSTICA APLICADA À BIOLOGIA	68
41182	2701.000.023-4	GENÉTICA GERAL	68
41509	2701.000.159-1	INVERTEBRADOS I	68
41187	2701.000.028-5	BACTERIOLOGIA E VIROLOGIA BÁSICAS	51
41510	2701.000.160-5	BIOQUÍMICA II	51
41511	2701.000.161-3	ECOLOGIA I	51
41512	2701.000.162-1	GENÉTICA MOLECULAR	51
41513	2701.000.163-0	INVERTEBRADOS II	68
41514	2701.000.164-8	PARASITOLOGIA GERAL	51
41515	2701.000.165-6	SISTEMÁTICA DE CRIPTÓGAMAS	51
41516	2701.000.166-4	DEUTEROSTOMADOS I	85
41517	2701.000.167-2	ECOLOGIA II	51
41519	2701.000.169-9	FISIOLOGIA VEGETAL	85
50783	2701.000.366-0	IMUNOLOGIA	51
50818	2701.000.398-3	PRÁTICAS DE EXTENSÃO EM PESQUISA, EMPREENDEDORISMO E INOVAÇÃO EM BIOLOGIA	68
41520	2701.000.170-2	SISTEMÁTICA DE FANERÓGAMAS I	51
41521	2701.000.171-0	BIOLOGIA MOLECULAR	51
41522	2701.000.172-9	DEUTEROSTOMADOS II	85
41523	2701.000.173-7	ECOLOGIA III	68
41205	2701.000.046-3	EVOLUÇÃO	68
41525	2701.000.175-3	SISTEMÁTICA DE FANERÓGAMAS II	51
41526	2701.000.176-1	AVALIAÇÃO DE IMPACTO AMBIENTAL	34
50761	2701.000.344-6	BIOGEOGRAFIA	34
41528	2701.000.178-8	ECOLOGIA DE CAMPO	68
41529	2701.000.179-6	FISIOLOGIA ANIMAL COMPARADA	85
50859	2701.000.433-6	PRÁTICAS DE EXTENSÃO EM EDUCAÇÃO AMBIENTAL	68
50808	2701.000.389-4	ESTÁGIO OBRIGATÓRIO	360
41446	2701.000.097-8	ANATOMIA ECOLÓGICA	51
50851	2701.000.427-4	ANATOMIA FLORAL COM ÊNFASE NA REPRODUÇÃO DE ANGIOSPERMAS	51
41175	2701.000.016-1	ANATOMIA GERAL E HUMANA	51
50802	2701.000.383-0	APLICAÇÕES DE MARCADORES MOLECULARES	51
50844	2701.000.420-0	ARBOVIROSES	51
50817	2701.000.397-4	BIOÉTICA	51
50845	2701.000.421-0	BIOINFORMÁTICA	51
50819	2701.000.399-2	BIOINSPIRAÇÃO	51
50834	2701.000.412-0	BIOLOGIA DE AMBIENTES DE ÁGUA DOCE	51
41447	2701.000.098-6	BIOLOGIA DE PEIXES DE ÁGUA DOCE	51
41448	2701.000.099-4	BIOLOGIA REPRODUTIVA DE ANGIOSPERMAS	51
50841	2701.000.417-6	BIOLOGIA REPRODUTIVA EM PEIXES DE ÁGUA DOCE	51
50840	2701.000.416-7	BIOMARCADORES EM ORGANISMOS AQUÁTICOS	51
50820	2701.000.400-4	BIOMARCADORES EM PEIXES	51
50830	2701.000.408-7	BIOPROSPECÇÃO DE MICRORGANISMOS E MOLÉCULAS DE INTERESSE BIOTECNOLÓGICO	51
41449	2701.000.100-1	BIOPROSPECÇÃO E ENSAIOS BIOLÓGICOS APLICADOS À PESQUISA	51
50821	2701.000.401-3	BIORREMEDIAÇÃO	51
50843	2701.000.419-4	BIOSSEGURANÇA	51
41450	2701.000.101-0	CITOGENÉTICA GERAL	51
50839	2701.000.415-8	COLETA E HERBORIZAÇÃO DE FUNGOS E BRIÓFITAS	51
41451	2701.000.102-8	COLETA E IDENTIFICAÇÃO DE PARASITAS	51
50842	2701.000.418-5	COMUNICAÇÃO CIENTÍFICA EM BIODIVERSIDADE	51
50846	2701.000.422-9	COMUNICAÇÃO CIENTÍFICA EM ECOLOGIA	34
50822	1005.000.067-0	CULTIVO E APLICAÇÃO DE CÉLULAS: DOS ENSAIOS BIOLÓGICOS À TERAPIA CELULAR	51
50815	2701.000.395-6	DOENÇAS ENDÊMICAS E DE VIGILÂNCIA EM SAÚDE PÚBLICA NO BRASIL	51
50823	2701.000.402-2	DOENÇAS PARASITÁRIAS HUMANAS	51
47205	2701.000.314-1	DOENÇAS TROPICAIS NEGLIGENCIADAS E SUAS IMPLICAÇÕES NA SAÚDE PÚBLICA	51
50853	2701.000.429-2	ECOLOGIA DE ECOSSISTEMAS DE ÁGUA DOCE CONTINENTAIS	51
50824	2701.000.403-1	ECOLOGIA DE ICTIOPLÂNCTON	51
41456	2701.000.107-9	ECOLOGIA DE INTERAÇÕES	51
50854	2701.000.430-9	ECOLOGIA DE PAISAGENS	51
50847	2701.000.423-8	ECOLOGIA DO FOGO	51
50825	2701.000.404-0	ECOLOGIA MOLECULAR	51
41457	2701.000.108-7	ECOLOGIA URBANA	51
50836	1005.000.068-0	ENSAIOS BIOLÓGICOS APLICADOS À CARCINOGÊNESE E TERATOGÊNESE	51
50833	2701.000.411-1	ENSAIOS BIOLÓGICOS APLICADOS À PESQUISA DE NOVOS FÁRMACOS	51
50816	2701.000.396-5	ENSAIOS BIOLÓGICOS E SUAS APLICAÇÕES	34
41459	2701.000.110-9	ENTOMOLOGIA	51
50832	2701.000.410-2	EPIDEMIOLOGIA APLICADA AOS SERVIÇOS DE SAÚDE	51
41460	2701.000.111-7	ESTATÍSTICA ECOLÓGICA	51
41461	2701.000.112-5	ESTRESSE E ADAPTAÇÕES EM PLANTAS	51
41462	2701.000.113-3	ESTRUTURAS SECRETORAS EM PLANTAS VASCULARES	51
50806	2701.000.387-6	ESTUDO DO DNA E SEU ENTORNO CELULAR POR ANIMAÇÕES	51
50849	2701.000.425-6	ÉTICA E BEM-ESTAR ANIMAL EM ATIVIDADES DE ENSINO E PESQUISA	51
50807	2701.000.388-5	ETNOBIOLOGIA	51
41463	2701.000.114-1	ETNOBOTÂNICA	51
41464	2701.000.115-0	EXERCÍCIOS DE DETERMINAÇÃO DE INVERTEBRADOS	51
41465	2701.000.116-8	EXERCÍCIOS DE DETERMINAÇÃO DE VERTEBRADOS	51
50784	2701.000.367-0	EXTENSÃO EM CIÊNCIAS BIOLÓGICAS I	68
50794	2701.000.377-8	EXTENSÃO EM CIÊNCIAS BIOLÓGICAS II	68
50826	2701.000.405-0	FILOSOFIA DA CIÊNCIA	51
41467	2701.000.117-6	FISIOLOGIA GERAL E HUMANA	51
50827	2701.000.406-9	FITOSSOCIOLOGIA	68
41469	2701.000.119-2	FUNDAMENTOS DE MODELAGEM MATEMÁTICA EM ECOLOGIA E EVOLUÇÃO	51
41471	2701.000.121-4	GENÉTICA ECOLÓGICA	51
41472	2701.000.122-2	GENÉTICA HUMANA	51
50858	2701.000.432-7	GENÔMICA	51
41473	2701.000.123-0	HERPETOFAUNA REGIONAL	51
50835	2701.000.413-0	HISTOFISIOLOGIA E EMBRIOLOGIA: APLICAÇÕES CLÍNICAS.	102
50852	2701.000.428-3	HISTOLOGIA DOS SISTEMAS	68
50850	2701.000.426-5	HISTÓRIA DA BIOLOGIA	51
41474	2701.000.124-9	HORTICULTURA ORGÂNICA	51
41475	2701.000.125-7	ICTIOFAUNA REGIONAL	51
50855	1005.000.069-9	IMUNOLOGIA CLÍNICA	51
41476	2701.000.126-5	INTRODUÇÃO À ANATOMIA DA MADEIRA	51
41478	2701.000.128-1	INTRODUÇÃO À ETOLOGIA	51
41479	2701.000.129-0	INTRODUÇÃO À FITOSSOCIOLOGIA	51
41480	2701.000.130-3	INTRODUÇÃO À ORNITOLOGIA	51
41482	2701.000.132-0	LEGISLAÇÃO AMBIENTAL	34
50799	2701.000.380-2	LEGISLAÇÃO AMBIENTAL E DO PROFISSIONAL BIÓLOGO	51
41483	2701.000.133-8	LIMNOLOGIA	51
41535	2701.000.185-0	LINGUAGEM DE PROGRAMAÇÃO ESTATÍSTICA PARA BIOLOGIA	51
41484	2701.000.134-6	MANEJO DE BACIAS HIDROGRÁFICAS	51
41485	2701.000.135-4	MANEJO DE COLEÇÕES BIOLÓGICAS	51
41486	2701.000.136-2	MASTOFAUNA REGIONAL	51
50812	1005.000.066-1	MICOLOGIA MÉDICA	51
50856	2701.000.431-8	MICROBIOLOGIA AMBIENTAL	51
50804	2701.000.385-8	MICROBIOLOGIA CLÍNICA	51
50810	2701.000.391-0	MICROBIOLOGIA MÉDICA	51
50800	2701.000.381-1	MUDANÇAS CLIMÁTICAS	51
50857	2101.001.459-2	PAISAGISMO E ARBORIZAÇÃO URBANA	51
50805	2701.000.386-7	PARASITOLOGIA CLÍNICA	51
41207	2701.000.048-0	PARASITOLOGIA HUMANA	51
41487	2701.000.137-0	PATOLOGIA	51
41489	2701.000.139-7	PROPAGAÇÃO DE PLANTAS	51
50811	2701.000.392-9	QUÍMICA MEDICINAL	34
50861	2701.000.435-4	RESÍDUOS SÓLIDOS URBANOS E INDUSTRIAIS	51
41490	2701.000.140-0	RESISTÊNCIA DE PLANTAS A AGENTES BIÓTICOS	51
41491	2701.000.141-9	SAÚDE PÚBLICA	51
50809	2701.000.390-0	SERVIÇOS ECOSSISTÊMICOS	51
41492	2701.000.142-7	TAXONOMIA INTEGRATIVA ZOOLÓGICA	34
50813	2701.000.393-8	TÓPICOS ESPECIAIS EM BIODIVERSIDADE I	34
50831	2701.000.409-6	TÓPICOS ESPECIAIS EM BIODIVERSIDADE II	68
50814	2701.000.394-7	TÓPICOS ESPECIAIS EM BIOTECNOLOGIA E SAÚDE I	34
50828	2701.000.407-8	TÓPICOS ESPECIAIS EM BIOTECNOLOGIA E SAÚDE II	68
41493	2701.000.143-5	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS I	34
41494	2701.000.144-3	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS II	34
41495	2701.000.145-1	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS III	34
41496	2701.000.146-0	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS IV	51
41497	2701.000.147-8	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS V	51
41498	2701.000.148-6	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS VI	51
50838	2701.000.414-9	TÓPICOS ESPECIAIS EM ECOLOGIA I	34
50848	2701.000.424-7	TOPICOS ESPECIAIS EM ECOLOGIA II	51
50860	2701.000.434-5	TÓPICOS ESPECIAIS EM GESTÃO SOCIOAMBIENTAL I	34
50803	2701.000.384-9	TÓPICOS ESPECIAIS EM GESTÃO SOCIOAMBIENTAL II	51
50801	2701.000.382-0	TOXINOLOGIA BÁSICA	51
50798	2701.000.379-6	VIGILÂNCIA EM SAÚDE PÚBLICA	51
50797	2701.000.378-7	VITAMINAS	51
50768	2701.000.351-7	BASES DE ENSINO DE BIOLOGIA CELULAR	68
50795	2901.001.076-7	LEITURA E PRODUÇÃO DE TEXTO	34
50762	2701.000.345-5	MATEMÁTICA	34
50776	2701.000.359-0	MORFOLOGIA VEGETAL	51
50765	2701.000.348-2	BASES DE ENSINO DE GENÉTICA	68
50763	2701.000.346-4	BIOESTATÍSTICA	34
41173	2701.000.014-5	HISTOLOGIA	51
50778	2701.000.361-5	INSTRUMENTAÇÃO PARA O ENSINO E A PESQUISA EM BIOLOGIA	34
50766	2701.000.349-1	PRÁTICA DE ENSINO E SABERES NECESSÁRIOS À DOCÊNCIA	68
50796	2301.000.407-0	BASES DE ENSINO DE QUÍMICA	68
50770	2701.000.353-5	FILOSOFIA E HISTÓRIA DA EDUCAÇÃO EM CIÊNCIAS	51
50781	2701.000.364-2	GENÉTICA MOLECULAR	34
50782	2701.000.365-1	INVERTEBRADOS I	51
50793	2701.000.376-9	MICROBIOLOGIA BÁSICA	51
50769	2701.000.352-6	MÍDIAS E TECNOLOGIA DIGITAIS NO ENSINO DE CIÊNCIAS BIOLÓGICAS	34
50787	2701.000.370-4	PRÁTICA DE ENSINO E EPISTEMOLOGIAS DAS CIÊNCIAS	68
50785	2701.000.368-9	ANATOMIA VEGETAL	51
50764	2701.000.347-3	BASES PARA ENSINO DE EMBRIOLOGIA	68
44530	2701.000.280-5	FISIOLOGIA GERAL E HUMANA	51
50779	2701.000.362-4	INVERTEBRADOS II	51
50757	2701.000.340-0	PRÁTICA DE ENSINO E O CURRÍCULO	68
50773	2701.000.356-2	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS I	100
50780	2701.000.363-3	FISIOLOGIA VEGETAL	68
50767	2701.000.350-8	PRÁTICA DE ENSINO EM AVALIAÇÃO E EDUCAÇÃO INCLUSIVA	68
50758	2701.000.341-9	SISTEMÁTICA DE CRIPTÓGAMAS	51
50791	2701.000.374-0	BIOQUÍMICA II	34
50759	2701.000.342-8	DEUTEROSTOMIA I	51
50774	2701.000.357-1	ESTÁGIO OBRIGATÓRIO EM CIÊNCIAS FÍSICAS E BIOLÓGICAS II	100
50788	2701.000.371-3	PRÁTICA DE ENSINO INTERDISCIPLINAR	68
41193	2701.000.034-0	SISTEMÁTICA DE FANERÓGAMAS	68
50760	2701.000.343-7	DEUTEROSTOMIA II	51
44517	2701.000.267-2	ECOLOGIA DE ORGANISMOS E POPULAÇÃO	51
50771	2701.000.354-4	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA I	100
50792	2701.000.375-0	EVOLUÇÃO	51
50786	2701.000.369-8	PRÁTICA DE ENSINO EM CONTEÚDOS ESPECÍFICOS	68
50789	2701.000.372-2	BIOLOGIA MOLECULAR	34
50775	2701.000.358-0	CONSERVAÇÃO DA NATUREZA	51
50790	2701.000.373-1	ECOLOGIA DE COMUNIDADES E ECOSSISTEMAS	51
50772	2701.000.355-3	ESTÁGIO OBRIGATÓRIO EM BIOLOGIA II	100
44518	2701.000.268-1	ASTRONOMIA NO ENSINO FUNDAMENTAL	34
44521	2701.000.271-6	BIOÉTICA	51
41218	2701.000.059-5	BIOLOGIA INSTRUMENTAL	68
41219	2701.000.060-9	BOTÂNICA DE CAMPO	68
41220	2701.000.061-7	CITOGENETICA GERAL	68
44532	2701.000.282-3	COMPORTAMENTO DE AVES	51
44527	2701.000.277-0	ECOLOGIA DE CAMPO	68
44519	2701.000.269-0	ECOLOGIA URBANA	51
44528	2701.000.278-0	EMBRIOLOGIA DOS SISTEMAS ORGÂNICOS	68
41221	2701.000.062-5	ENSAIOS BIOLÓGICOS APLICADOS À PESQUISA	68
44522	2701.000.272-5	ENTOMOLOGIA	68
41222	2701.000.063-3	ESTUDO APLICADO À ANATOMIA DA MADEIRA	51
44520	2701.000.270-7	GENÉTICA ECOLÓGICA	68
41223	2701.000.064-1	GENÉTICA HUMANA	68
41224	2701.000.065-0	HERPETOFAUNA REGIONAL	68
41225	2701.000.066-8	HISTOLOGIA DOS SISTEMAS	68
47202	2701.000.311-4	HISTÓRIA DA BIOLOGIA	51
44526	2701.000.276-1	HISTÓRIA DA CIÊNCIA	34
47203	2701.000.312-3	INTRODUÇÃO À EDUCAÇÃO MIDIÁTICA	51
44531	2701.000.281-4	INTRODUÇÃO À ORNITOLOGIA	51
44524	2701.000.274-3	LIMNOLOGIA	51
47204	2701.000.313-2	MÉTODO CIENTÍFICO NO ENSINO BÁSICO	68
44536	2701.000.285-0	MUDANÇAS AMBIENTAIS NO QUARTENÁRIO: BACIA SEDIMENTAR DO PANTANAL	68
44538	3001.000.482-4	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
44525	2701.000.275-2	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
44534	3001.000.481-5	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
50777	2701.000.360-6	TÓPICOS DE SEMINÁRIOS EM BIOLOGIA E EDUCAÇÃO	68
44537	2701.000.286-0	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS	34
47200	2701.000.309-9	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS II	34
47201	2701.000.310-5	TÓPICOS ESPECIAIS EM CIÊNCIAS BIOLÓGICAS III	51
48189	3001.000.621-0	ANTROPOLOGIA E SAÚDE	51
48204	2801.000.149-9	BASES CONCEITUAIS DA SAÚDE COLETIVA	51
48191	2701.000.328-6	BIOLOGIA CELULAR	51
48190	2701.000.327-7	EMBRIOLOGIA	51
48196	2701.000.330-1	HISTOLOGIA	68
52104	2801.000.175-7	HISTÓRIA DA ENFERMAGEM	51
48193	3001.000.622-0	SAÚDE E SOCIEDADE	51
45515	2701.000.301-6	BIOQUÍMICA	51
48198	3101.000.552-9	DIDÁTICA APLICADA À ENFERMAGEM	34
45489	2701.000.299-5	FISIOLOGIA HUMANA	68
48194	2701.000.329-5	GENÉTICA HUMANA	51
48203	2701.000.334-8	IMUNOLOGIA	51
48201	2701.000.333-9	MICROBIOLOGIA BÁSICA E CLÍNICA	68
48195	3001.000.623-9	PSICOLOGIA APLICADA À SAÚDE	51
45514	2801.000.127-4	SUPORTE BÁSICO DE VIDA E BIOSSEGURANÇA	51
45522	2801.000.132-7	ENFERMAGEM EM SAÚDE COLETIVA I	102
48202	2601.000.406-7	FARMACOLOGIA APLICADA À ENFERMAGEM I	51
48205	2801.000.150-5	FUNDAMENTOS DE ENFERMAGEM I	102
48199	2701.000.331-0	PARASITOLOGIA HUMANA	51
48200	2701.000.332-0	PATOLOGIA GERAL	51
45520	2801.000.130-9	PROCESSO DE ENFERMAGEM E MODELOS TEÓRICOS	34
48192	2801.000.147-0	BIOESTATÍSTICA	34
48208	2801.000.152-3	ENFERMAGEM EM SAÚDE MENTAL I	102
48207	2801.000.151-4	ÉTICA, BIOÉTICA E EXERCÍCIO PROFISSIONAL DE ENFERMAGEM	51
48206	2601.000.407-6	FARMACOLOGIA APLICADA À ENFERMAGEM II	68
48197	2801.000.148-0	FUNDAMENTOS DE ENFERMAGEM II	119
45504	2601.000.283-0	NUTRIÇÃO APLICADA A ENFERMAGEM	51
45505	2801.000.119-4	ENFERMAGEM EM CLINICA BÁSICA DO ADULTO E IDOSO	221
48209	2801.000.153-2	GERENCIAMENTO EM ENFERMAGEM I	102
45508	2801.000.121-0	PROCESSO DE ENVELHECIMENTO	102
45509	2801.000.122-9	ENFERMAGEM EM SAÚDE COLETIVA II	119
48183	2801.000.141-6	ENFERMAGEM NA SAÚDE DA CRIANÇA	136
48184	2801.000.142-5	INVESTIGAÇÃO EM SAÚDE I	51
48188	2801.000.146-1	MULHER, SAÚDE E CIDADANIA	136
48187	2801.000.145-2	ENFERMAGEM EM SAÚDE DA MULHER	153
48180	2801.000.138-1	ENFERMAGEM EM SAÚDE MENTAL II	119
48178	2801.000.136-3	ENFERMAGEM PEDIÁTRICA EM CUIDADOS COMPLEXOS	153
48179	2801.000.137-2	INVESTIGAÇÃO EM SAÚDE II	34
45494	2801.000.110-2	ENFERMAGEM EM CLÍNICA AVANÇADA DO ADULTO E IDOSO	221
48210	2801.000.154-1	GERENCIAMENTO EM ENFERMAGEM II	102
48185	2801.000.143-4	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE I	440
48182	2801.000.140-7	INVESTIGAÇÃO EM SAÚDE III	34
48186	2801.000.144-3	ESTÁGIO OBRIGATÓRIO EM REDES DE SERVIÇOS DE SAÚDE II	440
41437	2801.000.071-2	AGRAVOS REGIONAIS	51
45519	3101.000.477-3	A SAÚDE E AS RELAÇÕES COM AS RELIGIÕES AFRODESCENDENTES	34
41215	2701.000.056-0	EDUCAÇÃO AMBIENTAL	34
41439	2801.000.072-0	EDUCAÇÃO, AMBIENTE E SOCIEDADE	51
41234	2601.000.073-2	INTERAÇÕES MEDICAMENTOSAS	34
52103	2801.000.174-8	INTRODUÇÃO AO CONHECIMENTO CIENTÍFICO	34
44687	2901.000.723-3	LEITURA E PRODUÇÃO DE TEXTOS CIENTÍFICOS I	34
45524	2801.000.133-6	MICROBIOLOGIA MÉDICA	34
48181	2801.000.139-0	PRÁTICAS INTEGRATIVAS E COMPLEMENTARES EM SAÚDE	51
45517	2801.000.129-2	TÓPICOS AVANÇADOS EM CIÊNCIAS BIOLÓGICAS E ENFERMAGEM	68
41384	2701.000.086-2	ANATOMIA HUMANA I	68
41385	2701.000.087-0	BIOLOGIA GERAL	68
41386	2701.000.088-9	FISIOLOGIA HUMANA I	51
41388	2701.000.090-0	IMUNOLOGIA	34
41442	2801.000.075-5	INTRODUÇÃO À FISIOTERAPIA	68
48398	2801.000.157-9	SAÚDE E CIDADANIA I	68
41390	2701.000.091-9	ANATOMIA HUMANA II	68
48411	2801.000.169-5	EPIDEMIOLOGIA	34
41393	2701.000.092-7	FISIOLOGIA HUMANA II	68
41394	2801.000.032-1	HABILIDADES INTERPESSOAIS	51
41395	2701.000.093-5	MICROBIOLOGIA	34
41396	2801.000.033-0	PROCESSO SAÚDE-DOENÇA, ESTILO E QUALIDADE DE VIDA	68
48413	2801.000.171-0	SAÚDE E CIDADANIA II	51
48401	2801.000.160-3	CINESIOLOGIA I	85
41399	2801.000.036-4	CINESIOTERAPIA I	85
48410	2801.000.168-6	LABORATÓRIO DE HABILIDADES PROFISSIONAIS I	68
48402	2801.000.161-2	METODOLOGIA DA PESQUISA BIBLIOGRÁFICA E PRODUÇÃO DE TEXTOS ACADÊMICOS	51
41402	2801.000.038-0	MÉTODOS E TÉCNICAS DE AVALIAÇÃO EM FISIOTERAPIA	68
41228	2701.000.069-2	PATOLOGIA GERAL	68
48399	2801.000.158-8	SAÚDE E CIDADANIA III	51
41404	2801.000.040-2	CINESIOLOGIA II	68
41405	2801.000.041-0	CINESIOTERAPIA II	68
44022	2601.000.215-1	FARMACOLOGIA PARA FISIOTERAPIA	51
41407	2801.000.042-9	FISIOLOGIA DO EXERCÍCIO	68
41408	2801.000.043-7	NEUROMORFOFISIOLOGIA	68
41409	2801.000.044-5	RECURSOS TERAPÊUTICOS I	51
48400	2801.000.159-7	SAÚDE E CIDADANIA IV	51
48406	2801.000.164-0	RECURSOS TERAPÊUTICOS II	85
41412	2801.000.047-0	SAÚDE DO ADULTO I	85
41413	2801.000.048-8	SAÚDE DO ATLETA	68
41414	2801.000.049-6	SAÚDE DO TRABALHADOR	68
48404	2801.000.162-1	SAÚDE E CIDADANIA V	68
48405	2801.000.163-0	ASPECTOS ÉTICOS, BIOÉTICOS E DEONTOLÓGICOS DA PRÁTICA PROFISSIONAL	51
48403	3001.000.624-8	CIÊNCIAS HUMANAS E SOCIAIS APLICADAS À SAÚDE	51
41417	2801.000.052-6	SAÚDE DA MULHER	68
41418	2801.000.053-4	SAÚDE DO ADULTO II	85
48407	2801.000.165-9	SAÚDE DO IDOSO	85
48396	2801.000.155-0	SAÚDE E CIDADANIA VI	68
44029	2801.000.106-9	GESTÃO E ADMINISTRAÇÃO DOS SERVIÇOS DE SAÚDE E FISIOTERAPÊUTICOS	51
41436	2801.000.070-4	SAÚDE DA CRIANÇA E DO ADOLESCENTE I	102
41423	2801.000.057-7	SAÚDE DO ADULTO III	85
48397	2801.000.156-0	SAÚDE E CIDADANIA VII	34
44024	2801.000.101-3	SEMINÁRIOS DE PESQUISA	51
41426	2801.000.060-7	LABORATÓRIO DE HABILIDADES PROFISSIONAIS II	85
42992	3001.000.365-9	PSICOLOGIA APLICADA À SAÚDE	34
41427	2801.000.061-5	SAÚDE DA CRIANÇA E DO ADOLESCENTE II	102
41428	2801.000.062-3	SAÚDE DO ADULTO IV	85
48408	2801.000.166-8	SAÚDE E CIDADANIA VIII	51
44027	2801.000.104-0	TECNOLOGIA ASSISTIVA	34
48412	2801.000.170-1	ESTÁGIO OBRIGATÓRIO EM TERRITÓRIO DE PRÁTICA I	221
44021	2801.000.099-2	ESTÁGIO OBRIGATÓRIO EM TERRITÓRIO DE PRÁTICA II	170
44023	2801.000.100-4	ESTÁGIO OBRIGATÓRIO EM TERRITÓRIO DE PRÁTICA III	340
44019	2801.000.097-4	ESTÁGIO OBRIGATÓRIO EM TERRITÓRIO DE PRÁTICA IV	170
41438	2801.000.090-9	CUIDADOS PALIATIVOS	51
44018	2801.000.096-5	ESTÁGIO EM REDE DE SERVIÇO DE SAÚDE	120
41440	2801.000.073-9	FISIOTERAPIA DERMATO-FUNCIONAL	51
44028	2801.000.105-0	HIDROCINESIOTERAPIA	34
48409	2801.000.167-7	PRÁTICAS INTEGRATIVAS E COMPLEMENTARES EM SAÚDE	51
41441	2801.000.074-7	SAÚDE FUNCIONAL	51
41443	2801.000.076-3	SAÚDE MENTAL	51
41444	2801.000.077-1	TÓPICOS ESPECIAIS I	51
44026	2801.000.103-1	TÓPICOS ESPECIAIS II	51
44020	2801.000.098-3	TÓPICOS ESPECIAIS III	68
44089	2901.000.542-6	CERÂMICA I	51
44078	2901.000.531-9	DESENHO I	51
44084	2901.000.537-3	FOTOGRAFIA	51
44075	2901.000.528-4	FUNDAMENTOS DA COMPOSIÇÃO	34
44124	2901.000.577-6	FUNDAMENTOS DA CULTURA E CULTURA BRASILEIRA	51
44104	2901.000.557-0	HISTÓRIA DA ARTE - DA PRÉ-HISTÓRIA AO SÉCULO XIII	34
41816	2901.000.056-7	SEMINÁRIO DE PRÁTICAS DE ENSINO DE ARTES VISUAIS	51
44116	2901.000.569-6	ARTE E EMANCIPAÇÃO HUMANA	51
44121	2901.000.574-9	ASPECTOS DA CULTURA EM MATO GROSSO DO SUL	51
44076	2901.000.529-3	DESENHO II	51
44125	2901.000.578-5	HISTÓRIA DA ARTE - DO SÉCULO XIV AO SÉCULO XVIII	34
44073	2901.000.526-6	VÍDEO	51
41797	2901.000.037-0	ARTE E LINGUAGEM I	34
44079	2901.000.532-8	DESENHO III	51
44090	2901.000.543-5	ESCULTURA	51
44091	2901.000.544-4	HISTÓRIA DA ARTE - O SÉCULO XIX	34
42733	2901.000.394-9	HISTÓRIA DO ENSINO DE ARTE	51
44131	2901.000.584-7	LINGUAGENS VISUAIS NO ENSINO DE ARTE	68
41803	2901.000.043-5	PINTURA I	51
44113	2901.000.566-9	ARTE DA AMÉRICA LATINA	34
41804	2901.000.044-3	ARTE E LINGUAGEM II	34
44074	2901.000.527-5	DESENHO IV	51
44141	2901.000.594-5	DIDÁTICA DO ENSINO DE ARTES VISUAIS	68
44138	2901.000.591-8	ESTÁGIO OBRIGATÓRIO DE ARTES VISUAIS	128
44092	2901.000.545-3	GRAVURA EM RELEVO	51
44107	2901.000.560-4	HISTÓRIA DA ARTE - O SÉCULO XX ATÉ 1960	34
41757	2901.000.001-0	PINTURA II	51
44102	2901.000.555-1	ARTE NO BRASIL: DA CONQUISTA AO ACADEMICISMO	34
44136	2901.000.589-2	ESTÁGIO OBRIGATÓRIO DE ARTES VISUAIS NO ENSINO FUNDAMENTAL	95
44118	2901.000.571-1	ESTÉTICA E TEORIA DA ARTE I	51
44094	2901.000.547-1	GRAVURA EM METAL	51
44109	2901.000.562-2	HISTÓRIA DA ARTE - DE 1970 AO SÉCULO XXI	34
44143	2901.000.596-3	TECNOLOGIAS DIGITAIS E EDUCAÇÃO	51
44120	2901.000.573-0	ARTE BRASILEIRA: DO MODERNISMO AO CONTEMPORÂNEO	34
44142	2901.000.595-4	EPISTEMOLOGIA E PESQUISA NO ENSINO DE ARTES VISUAIS	51
44139	2901.000.592-7	ESTÁGIO OBRIGATÓRIO DE ARTES VISUAIS NO ENSINO MÉDIO	102
44119	2901.000.572-0	ESTÉTICA E TEORIA DA ARTE II	51
44132	2901.000.585-6	ESTUDO DA CRIATIVIDADE NO ENSINO DE ARTES VISUAIS	51
44140	2901.000.593-6	ESTÁGIO OBRIGATÓRIO DE ARTES VISUAIS EM ESPAÇO NÃO FORMAL	75
44115	2901.000.568-7	POÉTICAS CONTEMPORÂNEAS NO ENSINO DE ARTE	68
44144	2901.000.597-2	PROJETO DE ENSINO EM ARTES VISUAIS	51
44123	2901.000.576-7	ARTE AGORA	34
44096	2901.000.549-0	ARTE, EDUCAÇÃO E PERCEPÇÃO DO OUTRO	51
44082	2901.000.535-5	ARTE E TECNOLOGIAS CONTEMPORÂNEAS I	51
44098	2901.000.551-5	CERÂMICA II	51
41810	2901.000.050-8	DESENHO ARTÍSTICO V	51
41822	2901.000.062-1	DESENHO ARTÍSTICO VI	51
44129	2901.000.582-9	ESCULTURA E CONSTRUÇÃO	51
44103	2901.000.556-0	ESPACIALIDADE	51
42524	2901.000.350-7	GESTÃO EM ARTES VISUAIS	34
44117	2901.000.570-2	HISTÓRIA EM QUADRINHOS	51
44080	2901.000.533-7	OFICINA DE CERÂMICA I	51
44086	2901.000.539-1	OFICINA DE CERÂMICA II	51
44106	2901.000.559-8	OFICINA DE DESENHO I	51
44110	2901.000.563-1	OFICINA DE DESENHO II	51
44130	2901.000.583-8	OFICINA DE ESCULTURA E CONSTRUÇÃO I	51
44081	2901.000.534-6	OFICINA DE ESCULTURA E CONSTRUÇÃO II	51
44133	2901.000.586-5	OFICINA DE EXPANSÃO DA LINGUAGEM DA GRAVURA	51
44137	2901.000.590-9	OFICINA DE EXPERIMENTAÇÃO ARTÍSTICA EM GRAVURA	51
44097	2901.000.550-6	OFICINA DE FOTOGRAFIA I	51
44099	2901.000.552-4	OFICINA DE FOTOGRAFIA II	51
44093	2901.000.546-2	OFICINA DE PINTURA I	51
44122	2901.000.575-8	OFICINA DE PINTURA II	51
44126	2901.000.579-4	OFICINA DE VÍDEO I	51
44087	2901.000.540-8	OFICINA DE VÍDEO II	51
44134	2901.000.587-4	PROCESSOS DE ENSINO E APRENDIZAGEM EM ARTES VISUAIS I	34
44135	2901.000.588-3	PROCESSOS DE ENSINO E APRENDIZAGEM EM ARTES VISUAIS II	34
43989	3101.000.355-1	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
44111	2901.000.564-0	ARTE E TECNOLOGIAS CONTEMPORÂNEAS II	51
44083	2901.000.536-4	ARTE E TECNOLOGIAS CONTEMPORÂNEAS III	51
44105	2901.000.558-9	ARTE E PESQUISA I	34
44114	2901.000.567-8	ARTE E PESQUISA II	34
44127	2901.000.580-0	SEMINÁRIOS DE ARTE E PESQUISA I	68
44128	2901.000.581-0	SEMINÁRIOS DE ARTE E PESQUISA II	68
44100	2901.000.553-3	OFICINA DE ARTE E TECNOLOGIAS CONTEMPORÂNEAS I	51
44077	2901.000.530-0	OFICINA DE ARTE E TECNOLOGIAS CONTEMPORÂNEAS II	51
44088	2901.000.541-7	OFICINA DE EXPANSÃO DA LINGUAGEM DA GRAVURA	51
44112	2901.000.565-0	OFICINA DE EXPERIMENTAÇÃO NA LINGUAGEM GRAVURA	51
44101	2901.000.554-2	PLANOGRAFIA	68
44095	2901.000.548-0	PRÁTICA DE GESTÃO EM ARTES VISUAIS	34
44108	2901.000.561-3	TEORIA E CRÍTICA EM ARTE VISUAL	34
44384	2901.000.641-4	CANTO CORAL I	34
44428	2901.000.685-3	FISIOLOGIA E TÉCNICA VOCAL	34
44429	2901.000.686-2	INSTRUMENTO MUSICALIZADOR I - VIOLÃO	34
44427	2901.000.684-4	INTRODUÇÃO À EDUCAÇÃO MUSICAL	68
44398	2901.000.655-9	INTRODUÇÃO À FILOSOFIA DA MÚSICA	34
44381	2901.000.638-0	METODOLOGIA DA PESQUISA EM MÚSICA	34
44396	2901.000.653-0	PANORAMA DA HISTÓRIA DA MÚSICA DO OCIDENTE	34
44372	2901.000.629-0	TEORIA MUSICAL I	34
44425	2901.000.682-6	CANTO CORAL II	34
44431	2901.000.688-0	INSTRUMENTO MUSICALIZADOR II - VIOLÃO	34
44352	2901.000.609-4	INTRODUÇÃO À ETNOMUSICOLOGIA	34
44343	2901.000.600-2	METODOLOGIAS DE ENSINO MUSICAL I	68
44377	2901.000.634-3	TEORIA MUSICAL II	34
44424	2901.000.681-7	CANTO CORAL III	34
44367	2901.000.624-5	CONTRAPONTO	34
44379	2901.000.636-1	HARMONIA I	34
44393	2901.000.650-3	HISTÓRIA DA MÚSICA OCIDENTAL I	34
44370	2901.000.627-2	METODOLOGIAS DE ENSINO MUSICAL II	68
44434	2901.000.691-5	MÚSICA E TECNOLOGIA	34
44416	2901.000.673-7	PERCEPÇÃO MUSICAL I	34
44426	2901.000.683-5	ASPECTOS COGNITIVOS E PSICOLÓGICOS DA EDUCAÇÃO MUSICAL	68
44350	2901.000.607-6	CANTO CORAL IV	34
44411	2901.000.668-4	HARMONIA II	34
44394	2901.000.651-2	HISTÓRIA DA MÚSICA OCIDENTAL II	34
44436	2901.000.693-3	PERCEPÇÃO MUSICAL II	34
44412	2901.000.669-3	ESTÁGIO OBRIGATÓRIO I	100
44420	2901.000.677-3	HARMONIA III	34
44407	2901.000.664-8	HISTÓRIA DA MÚSICA OCIDENTAL III	34
44347	2901.000.604-9	MÚSICA NA EDUCAÇÃO BÁSICA I	68
44357	2901.000.614-7	PERCEPÇÃO MUSICAL III	34
44408	2901.000.665-7	ANÁLISE MUSICAL I	34
44355	2901.000.612-9	ARRANJO E CRIAÇÃO MUSICAL I	34
44400	2901.000.657-7	ELABORAÇÃO DE PROJETO DE PESQUISA	34
44354	2901.000.611-0	ESTÁGIO OBRIGATÓRIO II	100
44374	2901.000.631-6	INTRODUÇÃO À SOCIOLOGIA DA MÚSICA	34
44382	2901.000.639-9	MÚSICA NA EDUCAÇÃO BÁSICA II	68
44432	2901.000.689-0	REGÊNCIA CORAL I	34
44435	2901.000.692-4	ANÁLISE MUSICAL II	34
44376	2901.000.633-4	ARRANJO E CRIAÇÃO MUSICAL II	34
44423	2901.000.680-8	ESTÁGIO OBRIGATÓRIO III	100
44344	2901.000.601-1	MÚSICA BRASILEIRA I	34
44348	2901.000.605-8	REGÊNCIA CORAL II	34
44406	2901.000.663-9	ANÁLISE MUSICAL III	34
44378	2901.000.635-2	ESTÁGIO OBRIGATÓRIO IV	100
44414	2901.000.671-9	MÚSICA BRASILEIRA II	34
44401	2901.000.658-6	REGÊNCIA DE CORO INFANTOJUVENIL	34
44422	2901.000.679-1	BANDA DE MÚSICA E ENSINO MUSICAL	34
45699	2901.000.929-2	BANDA DE MÚSICA E ENSINO MUSICAL II	34
45729	2901.000.959-7	BANDA DE MÚSICA E ENSINO MUSICAL III	34
45617	2901.000.847-3	BANDA DE MÚSICA E ENSINO MUSICAL IV	34
44438	2901.000.695-1	CANTO CORAL V	34
44380	2901.000.637-0	CANTO CORAL VI	34
44385	2901.000.642-3	CANTO CORAL VII	34
44375	2901.000.632-5	CANTO CORAL VIII	34
42763	2901.000.423-6	CANTO I	34
42764	2901.000.424-4	CANTO II	34
42765	2901.000.425-2	CANTO III	34
42766	2901.000.426-0	CANTO IV	34
42767	2901.000.427-9	CANTO V	34
42768	2901.000.428-7	CANTO VI	34
42769	2901.000.429-5	CANTO VII	34
42770	2901.000.430-9	CANTO VIII	34
45641	2901.000.871-3	COMPOSIÇÃO MUSICAL I	34
45723	2901.000.953-2	COMPOSIÇÃO MUSICAL II	34
45724	2901.000.954-1	COMPOSIÇÃO MUSICAL III	34
45642	2901.000.872-2	COMPOSIÇÃO MUSICAL IV	34
45606	2901.000.836-6	ELABORAÇÃO DE PROJETOS CULTURAIS	34
44421	2901.000.678-2	ENSINO DE MÚSICA PARA IDOSOS	34
45658	2901.000.888-5	HARMONIA IV	34
44365	2901.000.622-7	INSTRUMENTO MUSICAL/CANTO I	34
44361	2901.000.618-3	INSTRUMENTO MUSICAL/CANTO II	34
44356	2901.000.613-8	INSTRUMENTO MUSICAL/CANTO III	34
44359	2901.000.616-5	INSTRUMENTO MUSICAL/CANTO IV	34
44366	2901.000.623-6	INSTRUMENTO MUSICAL/CANTO V	34
44433	2901.000.690-6	INSTRUMENTO MUSICAL/CANTO VI	34
44388	2901.000.645-0	INSTRUMENTO MUSICAL/CANTO VII	34
44383	2901.000.640-5	INSTRUMENTO MUSICAL/CANTO VIII	34
45643	2901.000.873-1	INSTRUMENTO MUSICAL I	34
45607	2901.000.837-5	INSTRUMENTO MUSICAL II	34
45608	2901.000.838-4	INSTRUMENTO MUSICAL III	34
45609	2901.000.839-3	INSTRUMENTO MUSICAL IV	34
44413	2901.000.670-0	INSTRUMENTO MUSICALIZADOR III	34
44402	2901.000.659-5	INSTRUMENTO MUSICALIZADOR IV	34
45587	2901.000.817-9	INSTRUMENTO MUSICAL V	34
45725	2901.000.955-0	INSTRUMENTO MUSICAL VI	34
45714	2901.000.944-3	INSTRUMENTO MUSICAL VII	34
45735	2901.000.965-9	INSTRUMENTO MUSICAL VIII	34
45625	2901.000.855-3	LEITURA E DECIFRAGEM	34
45652	2901.000.882-0	LITERATURA MUSICAL APLICADA I	34
45653	2901.000.883-0	LITERATURA MUSICAL APLICADA II	34
45619	2901.000.849-1	LITERATURA MUSICAL APLICADA III	34
45601	2901.000.831-0	LITERATURA MUSICAL APLICADA IV	34
45647	2901.000.877-8	MADRIGAL I	34
45662	2901.000.892-9	MADRIGAL II	34
45596	2901.000.826-8	MADRIGAL III	34
45595	2901.000.825-9	MADRIGAL IV	34
45598	2901.000.828-6	MADRIGAL V	34
45597	2901.000.827-7	MADRIGAL VI	34
44346	2901.000.603-0	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO I	34
44415	2901.000.672-8	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO II	34
45624	2901.000.854-4	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO III	34
45620	2901.000.850-8	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO IV	34
45646	2901.000.876-9	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO V	34
45621	2901.000.851-7	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO VI	34
45622	2901.000.852-6	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO VII	34
45623	2901.000.853-5	MÚSICA DE CÂMARA E PRÁTICA EM CONJUNTO VIII	34
44371	2901.000.628-1	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL	34
45639	2901.000.869-8	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL I	34
45657	2901.000.887-6	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL II	34
45659	2901.000.889-4	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL III	34
45736	2901.000.966-8	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL IV	34
45665	2901.000.895-6	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL V	34
45612	2901.000.842-8	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL VI	34
45668	2901.000.898-3	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL VII	34
45670	2901.000.900-4	OFICINA DE PRODUÇÃO E MONTAGEM MUSICAL VIII	34
45717	2901.000.947-0	PEDAGOGIA DA PERFORMANCE I	34
45718	2901.000.948-0	PEDAGOGIA DA PERFORMANCE II	34
45719	2901.000.949-9	PEDAGOGIA DA PERFORMANCE III	34
45613	2901.000.843-7	PEDAGOGIA DA PERFORMANCE IV	34
44360	2901.000.617-4	PERCEPÇÃO MUSICAL IV	34
45691	2901.000.921-0	PRÁTICA DE BANDA SINFÔNICA I	34
45726	2901.000.956-0	PRÁTICA DE BANDA SINFÔNICA II	34
45694	2901.000.924-7	PRÁTICA DE BANDA SINFÔNICA III	34
45740	2901.000.970-1	PRÁTICA DE BANDA SINFÔNICA IV	34
45610	2901.000.840-0	PRÁTICA DE GRUPO I	68
45721	2901.000.951-4	PRÁTICA DE GRUPO II	68
45722	2901.000.952-3	PRÁTICA DE GRUPO III	68
45667	2901.000.897-4	PRÁTICA DE GRUPO IV	68
45715	2901.000.945-2	PRÁTICA DE GRUPO V	68
45716	2901.000.946-1	PRÁTICA DE GRUPO VI	68
45627	2901.000.857-1	PRÁTICA DE GRUPO VII	68
45611	2901.000.841-9	PRÁTICA DE GRUPO VIII	68
45651	2901.000.881-1	PSICOLOGIA DA PERFORMANCE	34
44419	2901.000.676-4	TÓPICOS EM ACÚSTICA	34
45648	2901.000.878-7	TÓPICOS EM ACÚSTICA II	34
44392	2901.000.649-7	TÓPICOS EM ANÁLISE DA MÚSICA DE CONCERTO DOS SÉCULOS XX E XXI - I	34
44358	2901.000.615-6	TÓPICOS EM ANÁLISE DA MÚSICA DE CONCERTO DOS SÉCULOS XX E XXI - II	34
45628	2901.000.858-0	TÓPICOS EM ANÁLISE DA MÚSICA DE CONCERTO DOS SÉCULOS XX E XXI - III	34
45626	2901.000.856-2	TÓPICOS EM ANÁLISE DA MÚSICA DE CONCERTO DOS SÉCULOS XX E XXI - IV	34
44369	2901.000.626-3	TÓPICOS EM ANÁLISE MUSICAL	34
45631	2901.000.861-5	TÓPICOS EM ANÁLISE MUSICAL II	34
45678	2901.000.908-7	TÓPICOS EM ANÁLISE MUSICAL III	34
45679	2901.000.909-6	TÓPICOS EM ANÁLISE MUSICAL IV	34
45618	2901.000.848-2	TÓPICOS EM APRECIAÇÃO MUSICAL I	34
45708	2901.000.938-1	TÓPICOS EM APRECIAÇÃO MUSICAL II	34
45711	2901.000.941-6	TÓPICOS EM APRECIAÇÃO MUSICAL III	34
45712	2901.000.942-5	TÓPICOS EM APRECIAÇÃO MUSICAL IV	34
45731	2901.000.961-2	TÓPICOS EM APRECIAÇÃO MUSICAL V	34
45732	2901.000.962-1	TÓPICOS EM APRECIAÇÃO MUSICAL VI	34
45734	2901.000.964-0	TÓPICOS EM APRECIAÇÃO MUSICAL VII	34
45713	2901.000.943-4	TÓPICOS EM APRECIAÇÃO MUSICAL VIII	34
44345	2901.000.602-0	TÓPICOS EM ARRANJO E ORQUESTRAÇÃO	34
45634	2901.000.864-2	TÓPICOS EM ARRANJO E ORQUESTRAÇÃO II	34
45637	2901.000.867-0	TÓPICOS EM ARRANJO E ORQUESTRAÇÃO III	34
45654	2901.000.884-9	TÓPICOS EM ARRANJO E ORQUESTRAÇÃO IV	34
44395	2901.000.652-1	TÓPICOS EM BAIXO CONTÍNUO I	34
44364	2901.000.621-8	TÓPICOS EM BAIXO CONTÍNUO II	34
45728	2901.000.958-8	TÓPICOS EM BAIXO CONTÍNUO III	34
45655	2901.000.885-8	TÓPICOS EM BAIXO CONTÍNUO IV	34
44437	2901.000.694-2	TÓPICOS EM COGNIÇÃO MUSICAL	34
45703	2901.000.933-6	TÓPICOS EM COGNIÇÃO MUSICAL II	34
45644	2901.000.874-0	TÓPICOS EM COGNIÇÃO MUSICAL III	34
45701	2901.000.931-8	TÓPICOS EM COGNIÇÃO MUSICAL IV	34
44391	2901.000.648-8	TÓPICOS EM CONTRAPONTO	34
45605	2901.000.835-7	TÓPICOS EM CONTRAPONTO II	34
45638	2901.000.868-9	TÓPICOS EM CONTRAPONTO III	34
45640	2901.000.870-4	TÓPICOS EM CONTRAPONTO IV	34
44390	2901.000.647-9	TÓPICOS EM EDUCAÇÃO MUSICAL	34
45661	2901.000.891-0	TÓPICOS EM EDUCAÇÃO MUSICAL II	34
45666	2901.000.896-5	TÓPICOS EM EDUCAÇÃO MUSICAL III	34
45602	2901.000.832-0	TÓPICOS EM EDUCAÇÃO MUSICAL IV	34
44368	2901.000.625-4	TÓPICOS EM ENSINO COLETIVO DE INSTRUMENTOS	34
45645	2901.000.875-0	TÓPICOS EM ENSINO COLETIVO DE INSTRUMENTOS II	34
45669	2901.000.899-2	TÓPICOS EM ENSINO COLETIVO DE INSTRUMENTOS III	34
45593	2901.000.823-0	TÓPICOS EM ENSINO COLETIVO DE INSTRUMENTOS IV	34
45709	2901.000.939-0	TÓPICOS EM ESCUTAS MUSICAIS	34
45733	2901.000.963-0	TÓPICOS EM ESCUTAS MUSICAIS II	34
45590	2901.000.820-3	TÓPICOS EM ESCUTAS MUSICAIS III	34
45663	2901.000.893-8	TÓPICOS EM ESCUTAS MUSICAIS IV	34
44389	2901.000.646-0	TÓPICOS EM ETNOMUSICOLOGIA	34
45671	2901.000.901-3	TÓPICOS EM ETNOMUSICOLOGIA II	34
45672	2901.000.902-2	TÓPICOS EM ETNOMUSICOLOGIA III	34
45720	2901.000.950-5	TÓPICOS EM ETNOMUSICOLOGIA IV	34
44373	2901.000.630-7	TÓPICOS EM FILOSOFIA DA MÚSICA	34
45673	2901.000.903-1	TÓPICOS EM FILOSOFIA E MÚSICA I	34
45674	2901.000.904-0	TÓPICOS EM FILOSOFIA E MÚSICA II	34
44418	2901.000.675-5	TÓPICOS EM HARMONIA	34
45737	2901.000.967-7	TÓPICOS EM HARMONIA II	34
45675	2901.000.905-0	TÓPICOS EM HARMONIA III	34
45660	2901.000.890-0	TÓPICOS EM HARMONIA IV	34
44410	2901.000.667-5	TÓPICOS EM HISTÓRIA E MÚSICA BRASILEIRA	34
45588	2901.000.818-8	TÓPICOS EM HISTÓRIA E MÚSICA BRASILEIRA II	34
45706	2901.000.936-3	TÓPICOS EM HISTÓRIA E MÚSICA BRASILEIRA III	34
45707	2901.000.937-2	TÓPICOS EM HISTÓRIA E MÚSICA BRASILEIRA IV	34
44351	2901.000.608-5	TÓPICOS EM HISTÓRIA E MÚSICA NO OCIDENTE	34
45676	2901.000.906-9	TÓPICOS EM HISTÓRIA E MÚSICA NO OCIDENTE II	34
45592	2901.000.822-1	TÓPICOS EM HISTÓRIA E MÚSICA NO OCIDENTE III	34
45677	2901.000.907-8	TÓPICOS EM HISTÓRIA E MÚSICA NO OCIDENTE IV	34
45615	2901.000.845-5	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA I	34
45656	2901.000.886-7	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA II	34
45630	2901.000.860-6	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA III	34
45600	2901.000.830-1	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA IV	34
45636	2901.000.866-0	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA V	34
45635	2901.000.865-1	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA VI	34
45633	2901.000.863-3	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA VII	34
45632	2901.000.862-4	TÓPICOS EM INTERPRETAÇÃO HISTÓRICA VIII	34
44362	2901.000.619-2	TÓPICOS EM INTERPRETAÇÃO MUSICAL	34
45589	2901.000.819-7	TÓPICOS EM INTERPRETAÇÃO MUSICAL II	34
45680	2901.000.910-2	TÓPICOS EM INTERPRETAÇÃO MUSICAL III	34
45681	2901.000.911-1	TÓPICOS EM INTERPRETAÇÃO MUSICAL IV	34
45682	2901.000.912-0	TÓPICOS EM INTERPRETAÇÃO MUSICAL V	34
45738	2901.000.968-6	TÓPICOS EM INTERPRETAÇÃO MUSICAL VI	34
45683	2901.000.913-0	TÓPICOS EM INTERPRETAÇÃO MUSICAL VII	34
45594	2901.000.824-0	TÓPICOS EM INTERPRETAÇÃO MUSICAL VIII	34
44363	2901.000.620-9	TÓPICOS EM MÚSICA DE MATO GROSSO DO SUL	34
45685	2901.000.915-8	TÓPICOS EM MÚSICA DE MATO GROSSO DO SUL II	34
45686	2901.000.916-7	TÓPICOS EM MÚSICA DE MATO GROSSO DO SUL III	34
45599	2901.000.829-5	TÓPICOS EM MÚSICA DE MATO GROSSO DO SUL IV	34
45698	2901.000.928-3	TÓPICOS EM MÚSICA E AUDIOVISUAL I	34
45700	2901.000.930-9	TÓPICOS EM MÚSICA E AUDIOVISUAL II	34
45710	2901.000.940-7	TÓPICOS EM MÚSICA E AUDIOVISUAL III	34
45705	2901.000.935-4	TÓPICOS EM MÚSICA E AUDIOVISUAL IV	34
44417	2901.000.674-6	TÓPICOS EM MÚSICA E TECNOLOGIA	34
45687	2901.000.917-6	TÓPICOS EM MÚSICA E TECNOLOGIA II	34
45688	2901.000.918-5	TÓPICOS EM MÚSICA E TECNOLOGIA III	34
45690	2901.000.920-0	TÓPICOS EM MÚSICA E TECNOLOGIA IV	34
44430	2901.000.687-1	TÓPICOS EM MÚSICA LATINO-AMERICANA	34
45616	2901.000.846-4	TÓPICOS EM MÚSICA LATINO-AMERICANA II	34
44397	2901.000.654-0	TÓPICOS EM MÚSICA NA 1ª INFÂNCIA	34
45692	2901.000.922-9	TÓPICOS EM MÚSICA NA 1ª INFÂNCIA II	34
44386	2901.000.643-2	TÓPICOS EM PERCEPÇÃO MUSICAL	34
45695	2901.000.925-6	TÓPICOS EM PERCEPÇÃO MUSICAL II	34
45649	2901.000.879-6	TÓPICOS EM PERCEPÇÃO MUSICAL III	34
45741	2901.000.971-0	TÓPICOS EM PERCEPÇÃO MUSICAL IV	34
44399	2901.000.656-8	TÓPICOS EM REGÊNCIA CORAL	34
45696	2901.000.926-5	TÓPICOS EM REGÊNCIA CORAL II	34
45697	2901.000.927-4	TÓPICOS EM REGÊNCIA CORAL III	34
45629	2901.000.859-0	TÓPICOS EM REGÊNCIA CORAL IV	34
44387	2901.000.644-1	TÓPICOS EM REGÊNCIA INSTRUMENTAL	34
45730	2901.000.960-3	TÓPICOS EM REGÊNCIA INSTRUMENTAL II	34
45727	2901.000.957-9	TÓPICOS EM REGÊNCIA INSTRUMENTAL III	34
45650	2901.000.880-2	TÓPICOS EM REGÊNCIA INSTRUMENTAL IV	34
44409	2901.000.666-6	TÓPICOS EM SAÚDE DO MÚSICO	34
44349	2901.000.606-7	TÓPICOS EM SOCIOLOGIA DA MÚSICA	34
45704	2901.000.934-5	TÓPICOS EM SOCIOLOGIA DA MÚSICA II	34
45684	2901.000.914-9	TÓPICOS EM SOCIOLOGIA DA MÚSICA III	34
45614	2901.000.844-6	TÓPICOS EM SOCIOLOGIA DA MÚSICA IV	34
45664	2901.000.894-7	TÓPICOS EM TRANSCRIÇÃO MUSICAL I	34
45591	2901.000.821-2	TÓPICOS EM TRANSCRIÇÃO MUSICAL II	34
45603	2901.000.833-9	TÓPICOS EM TRANSCRIÇÃO MUSICAL III	34
45604	2901.000.834-8	TÓPICOS EM TRANSCRIÇÃO MUSICAL IV	34
45689	2901.000.919-4	TÓPICOS EM TRILHA SONORA I	34
45702	2901.000.932-7	TÓPICOS EM TRILHA SONORA II	34
45693	2901.000.923-8	TÓPICOS EM TRILHA SONORA III	34
45739	2901.000.969-5	TÓPICOS EM TRILHA SONORA IV	34
41851	2901.000.088-5	GEOPOLÍTICA	68
48983	2901.001.047-1	HISTÓRIA DO JORNALISMO	68
48986	2901.001.050-6	INTERFACES DOS MEIOS DIGITAIS	51
48988	2901.001.052-4	LINGUAGEM JORNALÍSTICA I	68
48989	2901.001.053-3	TEORIAS DA COMUNICAÇÃO I	68
41859	2901.000.096-6	ENTREVISTA E PESQUISA JORNALÍSTICA	68
48998	2901.001.062-2	FOTOGRAFIA E OUTRAS IMAGENS	68
49000	2901.001.064-0	INTRODUÇÃO À IMAGEM	51
49001	2901.001.065-0	LINGUAGEM JORNALÍSTICA II	68
48990	2901.001.054-2	TEORIAS DA COMUNICAÇÃO II	68
41842	2901.000.082-6	TEORIAS DO JORNALISMO	68
49006	2901.001.070-2	COMUNICAÇÃO VISUAL	68
41843	2901.000.083-4	FILOSOFIA	68
48992	2901.001.056-0	LINGUAGEM JORNALÍSTICA III	68
48974	2901.001.038-2	SOCIOLOGIA DA COMUNICAÇÃO	68
49002	2901.001.066-9	VISUALIDADES JORNALÍSTICAS	68
48976	2901.001.040-8	EDIÇÃO	51
49007	2901.001.071-1	LABORATÓRIO DE DESIGN EM JORNALISMO	68
41845	2901.000.084-2	LEGISLAÇÃO E ÉTICA EM JORNALISMO	68
41833	2901.000.073-7	METODOLOGIA DA PESQUISA CIENTÍFICA	68
49003	2901.001.067-8	REPORTAGEM	68
41871	2901.000.108-3	EMPREENDEDORISMO E INOVAÇÃO	51
48984	2901.001.048-0	JORNAL LABORATÓRIO	68
49004	2901.001.068-7	LABORATÓRIO DE JORNALISMO AUDIOVISUAL I	68
48985	2901.001.049-0	LABORATÓRIO DE JORNALISMO SONORO I	68
41844	3001.000.005-6	PSICOLOGIA DA COMUNICAÇÃO	68
41872	2901.000.109-1	ASSESSORIA DE IMPRENSA DE COMUNICAÇÃO	68
42071	2901.000.140-7	JORNALISMO DE REVISTA	68
42096	2901.000.165-2	LABORATÓRIO DE CIBERJORNALISMO I	68
48991	2901.001.055-1	LABORATÓRIO DE JORNALISMO AUDIOVISUAL II	68
48993	2901.001.057-0	LABORATÓRIO DE JORNALISMO SONORO II	68
41846	3001.000.006-4	ANTROPOLOGIA DA CULTURA BRASILEIRA	68
42101	2901.000.170-9	LABORATÓRIO DE CIBERJORNALISMO II	68
49005	2901.001.069-6	PESQUISA EM JORNALISMO	68
46847	2901.001.017-7	SISTEMAS, MÍDIAS E CIDADANIA	68
41882	2901.000.119-9	ESTÁGIO OBRIGATÓRIO	200
41880	2901.000.117-2	JORNALISMO ESPECIALIZADO	68
49008	2901.001.072-0	CIBERJORNALISMO	34
48999	2901.001.063-1	COMUNICAÇÃO E EDUCAÇÃO	51
41834	2901.000.074-5	COMUNICAÇÃO E SAÚDE	68
41886	2901.000.123-7	DOCUMENTÁRIO II - CRIAÇÃO E PRODUÇÃO	68
41885	2901.000.122-9	DOCUMENTÁRIO I - TEORIA E HISTÓRIA	68
41887	2901.000.124-5	ENSAIO FOTOGRÁFICO	51
41889	2901.000.126-1	ESTUDOS DE RECEPÇÃO	51
41901	2901.000.138-5	FOTOGRAFIA ANALÓGICA	51
41890	2901.000.127-0	FOTOGRAFIA DOCUMENTAL	51
48977	2901.001.041-7	GESTÃO CULTURAL	51
48995	2901.001.059-8	INFOGRAFIA	68
41847	2901.000.085-0	JORNALISMO AMBIENTAL	68
41848	2901.000.086-9	JORNALISMO CIENTÍFICO	68
41835	2901.000.075-3	JORNALISMO CULTURAL	68
48981	2901.001.045-3	JORNALISMO DE DADOS	68
48975	2901.001.039-1	JORNALISMO E GÊNERO	51
41891	2901.000.128-8	JORNALISMO ESPORTIVO	68
48994	2901.001.058-9	JORNALISMO INVESTIGATIVO	51
48997	2901.001.061-3	JORNALISMO LITERÁRIO	51
48996	2901.001.060-4	JORNALISMO OPINATIVO	51
48982	2901.001.046-2	JORNALISMO POLÍTICO	51
41849	2901.000.087-7	JORNALISMO RURAL	68
48980	2901.001.044-4	JORNALISMO VISUAL	68
48979	2901.001.043-5	LABORATÓRIO DE CRIAÇÃO VISUAL DIGITAL	51
41893	2901.000.130-0	LIVRO-REPORTAGEM	68
48978	2901.001.042-6	MÍDIA, CIDADANIA E TECNOLOGIAS	68
41895	2901.000.132-6	OBSERVATÓRIO DE MÍDIA	51
41836	2901.000.076-1	PRÁTICA EM REPORTAGEM FOTOGRÁFICA	68
41897	2901.000.134-2	PRODUÇÃO DE PROGRAMAS DE TV	51
48987	2901.001.051-5	PRODUÇÃO WEB	51
49009	2901.001.073-0	RADIOJORNALISMO	51
49011	2901.001.075-8	SEMIÓTICA	68
49010	2901.001.074-9	TELEJORNALISMO	51
41898	2901.000.135-0	TÓPICOS ESPECIAIS EM FOTOGRAFIA	51
41838	2901.000.078-8	TÓPICOS ESPECIAIS EM JORNALISMO I	68
41839	2901.000.079-6	TÓPICOS ESPECIAIS EM JORNALISMO II	68
44722	2901.000.758-3	ESTUDOS DA LITERATURA CLÁSSICA NO OCIDENTE	34
51042	2901.001.091-8	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
44684	2901.000.721-5	LEITURA DOS INSTRUMENTOS LINGUÍSTICOS: GRAMÁTICAS E DICIONÁRIOS	51
44727	2901.000.763-6	LEITURA, ESCRITA E ORALIDADE: TEORIA E PRÁTICA	51
44661	2901.000.698-9	LEITURAS EM ESPANHOL	34
51038	2901.001.087-4	LÍNGUA ESPANHOLA I	68
44706	2901.000.742-0	ENSINO DE LÍNGUA ESPANHOLA: POLÍTICAS E ASPECTOS METODOLÓGICOS	68
51041	2901.001.090-9	FONÉTICA E FONOLOGIA DA LÍNGUA PORTUGUESA	68
44660	2901.000.697-0	FUNDAMENTOS DE ANÁLISE LINGUÍSTICA	68
51054	2901.001.103-0	LÍNGUA ESPANHOLA II	68
44689	2901.000.725-1	LÍNGUA LATINA I	51
51033	2901.001.082-9	TEORIA DA LITERATURA I	34
44695	2901.000.731-3	ESCRITA EM ESPANHOL	34
51046	2901.001.095-4	FORMAS NARRATIVAS NA LITERATURA PORTUGUESA I	34
44717	2901.000.753-8	LETRAMENTOS: TEORIA E PRÁTICA	34
51056	2901.001.105-8	LÍNGUA ESPANHOLA III	68
44676	2901.000.713-5	LÍNGUA LATINA II	68
51043	2901.001.092-7	MORFOLOGIA DA LÍNGUA PORTUGUESA	68
51037	2901.001.086-5	TEORIA DA LITERATURA II	34
44700	2901.000.736-9	ENSINO DE LÍNGUA ESPANHOLA: PLANEJAMENTO E PERSPECTIVAS CONTEMPORÂNEAS	68
51049	2901.001.098-1	FORMAS NARRATIVAS NA LITERATURA PORTUGUESA II	34
51057	2901.001.106-7	LÍNGUA ESPANHOLA IV	68
44713	2901.000.749-4	LINGUAGENS E TECNOLOGIA: TEORIA E PRÁTICA	34
51035	2901.001.084-7	SINTAXE DA LÍNGUA PORTUGUESA	68
51039	2901.001.088-3	TEORIA DA LITERATURA III	34
51060	2901.001.109-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA I	51
51034	2901.001.083-8	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA I	51
51045	2901.001.094-5	FORMAS NARRATIVAS NA LITERATURA BRASILEIRA I	34
51058	2901.001.107-6	LÍNGUA ESPANHOLA V	68
44721	2901.000.757-4	LITERATURAS DE LÍNGUA ESPANHOLA: CONTOS	51
44662	2901.000.699-8	PRÁTICAS DE ENSINO DE LÍNGUA PORTUGUESA I	51
51055	2901.001.104-9	SINTAXE DA LÍNGUA PORTUGUESA: FUNCIONALISMO	34
51031	2901.001.080-0	TEORIA DA LITERATURA IV	34
51032	2901.001.081-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA II	51
51036	2901.001.085-6	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA II	51
51048	2901.001.097-2	FORMAS NARRATIVAS NA LITERATURA BRASILEIRA II	34
51059	2901.001.108-5	LÍNGUA ESPANHOLA VI	68
44698	2901.000.734-0	LITERATURAS DE LÍNGUA ESPANHOLA: POESIA	51
51052	2901.001.101-1	POESIA PORTUGUESA	34
51044	2901.001.093-6	SEMÂNTICA DA LÍNGUA PORTUGUESA	51
44664	2901.000.701-9	TEORIAS DO TEXTO E DO DISCURSO	68
51061	2901.001.110-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA III	51
51040	2901.001.089-2	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA III	51
44668	2901.000.705-5	ESTUDOS DISCURSIVOS E PRAGMÁTICOS	51
51909	2901.001.122-7	LÍNGUA ESPANHOLA VII	51
51062	3101.000.609-9	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
42123	2901.000.192-0	LITERATURA COMPARADA I	34
44703	2901.000.739-6	LITERATURAS DE LÍNGUA ESPANHOLA: ROMANCE	51
51047	2901.001.096-3	O TEXTO DRAMÁTICO NA LITERATURA PORTUGUESA	34
51051	2901.001.100-2	POESIA BRASILEIRA	34
44663	2901.000.700-0	PRÁTICAS DE ENSINO DE LÍNGUA PORTUGUESA II	51
51029	2901.001.078-5	ESTÁGIO OBRIGATÓRIO DE LÍNGUA ESPANHOLA IV	51
51030	2901.001.079-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA E LITERATURA IV	51
44673	2901.000.710-8	ESTUDOS ESTILÍSTICOS	51
44702	2901.000.738-7	FORMAÇÃO HISTÓRICA DA LÍNGUA PORTUGUESA	68
51910	2901.001.123-6	LÍNGUA ESPANHOLA VIII	68
42124	2901.000.193-8	LITERATURA COMPARADA II	34
44694	2901.000.730-4	LITERATURA CONTEMPORÂNEA EM LÍNGUA ESPANHOLA	51
51053	2901.001.102-0	LITERATURA CONTEMPORÂNEA EM LÍNGUA PORTUGUESA	34
51050	2901.001.099-0	O TEXTO DRAMÁTICO NA LITERATURA BRASILEIRA	34
45809	2901.000.983-7	ANÁLISE DO DISCURSO I	34
45801	2901.000.975-7	ANÁLISE DO DISCURSO II	34
44701	2901.000.737-8	COMPREENSÃO E PRODUÇÃO ESCRITA EM LÍNGUA ESPANHOLA I	34
44690	2901.000.726-0	COMPREENSÃO E PRODUÇÃO ESCRITA EM LÍNGUA ESPANHOLA II	34
44691	2901.000.727-0	COMPREENSÃO E PRODUÇÃO ORAL EM LÍNGUA ESPANHOLA I	34
44704	2901.000.740-2	COMPREENSÃO E PRODUÇÃO ORAL EM LÍNGUA ESPANHOLA II	34
42168	2901.000.237-3	CULTURA HISPÂNICA I	34
42169	2901.000.238-1	CULTURA HISPÂNICA II	34
44728	2901.000.764-5	FORMAÇÃO E CONSTITUIÇÃO DO PORTUGUÊS BRASILEIRO	34
44682	2901.000.719-0	GRAMÁTICA SISTÊMICO-FUNCIONAL I	34
44730	2901.000.766-3	GRAMÁTICA SISTÊMICO FUNCIONAL II	34
44729	2901.000.765-4	LEITURA E PRODUÇÃO DE TEXTOS CIENTÍFICOS II	34
42970	3101.000.292-8	LÍNGUA BRASILEIRA DE SINAIS: NOÇÕES BÁSICAS I	34
42971	3101.000.293-6	LÍNGUA BRASILEIRA DE SINAIS: NOÇÕES BÁSICAS II	34
42157	3101.000.349-5	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS II	34
44677	2901.000.714-4	LINGUÍSTICA APLICADA	34
45800	2901.000.974-8	LINGUÍSTICA APLICADA: PRESSUPOSTOS PARA O ENSINO DE LÍNGUAS ADICIONAIS	34
44678	2901.000.715-3	LINGUÍSTICA ROMÂNICA	34
44709	2901.000.745-8	LINGUÍSTICA TEXTUAL	34
44712	2901.000.748-5	LITERATURA E ENSINO: TEORIA E PRÁTICA	34
44716	2901.000.752-9	LITERATURA E ESTUDOS DE GÊNERO	34
45808	2901.000.982-8	LITERATURA E PERSPECTIVAS TRANSDISCIPLINARES	34
45810	2901.000.984-6	POLÍTICAS LINGUÍSTICAS	34
44718	2901.000.754-7	RETÓRICA E ESTUDOS DE LINGUAGEM	34
42194	2901.000.263-2	SEMIÓTICA DISCURSIVA I	34
42195	2901.000.264-0	SEMIÓTICA DISCURSIVA II	34
45802	2901.000.976-6	SOCIOLINGUÍSTICA	34
42173	2901.000.242-0	TEORIA E TÉCNICA DE TRADUÇÃO EM LÍNGUA ESPANHOLA I	34
42174	2901.000.243-8	TEORIA E TÉCNICA DE TRADUÇÃO EM LÍNGUA ESPANHOLA II	34
45804	2901.000.978-4	TÓPICOS DE LEXICOLOGIA E LEXICOGRAFIA I	34
42197	2901.000.266-7	TÓPICOS DE LÍNGUA PORTUGUESA I	34
42198	2901.000.267-5	TÓPICOS DE LÍNGUA PORTUGUESA II	34
45806	2901.000.980-0	TRADUÇÃO E LITERATURA I	34
45805	2901.000.979-3	TRADUÇÃO E LITERATURA II	34
51097	2901.001.111-0	LÍNGUA INGLESA I	68
44752	2901.000.788-8	ENSINO DE LÍNGUA INGLESA: POLÍTICAS E ASPECTOS METODOLÓGICOS	68
51098	2901.001.112-9	LÍNGUA INGLESA II	68
44745	2901.000.781-4	ESCRITA EM INGLÊS	34
51099	2901.001.113-8	LÍNGUA INGLESA III	68
44751	2901.000.787-9	ENSINO DE LÍNGUA INGLESA: PLANEJAMENTO E PERSPECTIVAS CONTEMPORÂNEAS	68
51100	2901.001.114-7	LÍNGUA INGLESA IV	68
51103	2901.001.117-4	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA I	51
51101	2901.001.115-6	LÍNGUA INGLESA V	68
44742	2901.000.778-0	LITERATURAS DE LÍNGUA INGLESA: CONTOS	51
51104	2901.001.118-3	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA II	51
51102	2901.001.116-5	LÍNGUA INGLESA VI	68
44743	2901.000.779-9	LITERATURAS DE LÍNGUA INGLESA: POESIA	51
51105	2901.001.119-2	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA III	51
51964	2901.001.124-5	LÍNGUA INGLESA VII	51
44734	2901.000.770-7	LITERATURAS DE LÍNGUA INGLESA: ROMANCE	51
51106	2901.001.120-9	ESTÁGIO OBRIGATÓRIO DE LÍNGUA INGLESA IV	51
51965	2901.001.125-4	LÍNGUA INGLESA VIII	68
44741	2901.000.777-0	LITERATURA CONTEMPORÂNEA EM LÍNGUA INGLESA	51
45819	2901.000.993-5	ANÁLISE DO DISCURSO I	34
45811	2901.000.985-5	ANÁLISE DO DISCURSO II	34
44748	2901.000.784-1	ESTUDOS DE CULTURA EM LÍNGUA INGLESA	34
44744	2901.000.780-5	LABORATÓRIO DE PRÁTICA DE LÍNGUA INGLESA:PRODUÇÃO ORAL	34
42211	3101.000.205-7	LÍNGUA BRASILEIRA DE SINAIS II: NOÇÕES BÁSICAS	34
42207	3101.000.204-9	LÍNGUA BRASILEIRA DE SINAIS I: NOÇÕES BÁSICAS	34
44750	2901.000.786-0	LÍNGUA INGLESA NA INFÂNCIA: REFLEXÕES SOBRE TEORIAS E PRÁTICAS	34
45815	2901.000.989-1	LINGUÍSTICA APLICADA: PRESSUPOSTOS PARA O ENSINO DE LÍNGUAS ADICIONAIS	34
45821	2901.000.995-3	LITERATURA E PERSPECTIVAS TRANSDISCIPLINARES	34
44755	2901.000.791-2	O TEXTO LITERÁRIO NA SALA DE AULA : TEORIA E PRÁTICA	34
45812	2901.000.986-4	POLÍTICAS LINGUÍSTICAS	34
45818	2901.000.992-6	SOCIOLINGUÍSTICA	34
45820	2901.000.994-4	TÓPICOS DE LEXICOLOGIA E LEXICOGRAFIA I	34
45813	2901.000.987-3	TRADUÇÃO E LITERATURA I	34
45814	2901.000.988-2	TRADUÇÃO E LITERATURA II	34
45181	2901.000.804-3	ESCRITA CRIATIVA	68
45182	2901.000.805-2	HISTÓRIA DA ARTE	68
46838	2901.001.008-8	HISTÓRIA DO CINEMA E DO AUDIOVISUAL I	68
46841	2901.001.011-2	LINGUAGEM AUDIOVISUAL	68
41841	2901.000.081-8	TEORIAS DA COMUNICAÇÃO	68
45175	2901.000.798-6	ARGUMENTO E ROTEIRO I	51
45179	2901.000.802-5	CULTURA MIDIÁTICA	68
41854	2901.000.091-5	FOTOGRAFIA	68
45185	2901.000.808-0	TEXTO DRAMÁTICO	68
46856	2901.001.026-6	ANTROPOLOGIA DA CULTURA	68
45176	2901.000.799-5	ARGUMENTO E ROTEIRO II	51
46842	2901.001.012-1	HISTÓRIA DO CINEMA E DO AUDIOVISUAL BRASILEIRO I	68
46840	2901.001.010-3	HISTÓRIA DO CINEMA E DO AUDIOVISUAL II	68
45174	2901.000.797-7	PRODUÇÃO AUDIOVISUAL I	51
45180	2901.000.803-4	ANIMAÇÃO	68
45177	2901.000.800-7	DIREÇÃO AUDIOVISUAL I	51
46850	2901.001.020-1	FOTOGRAFIA PARA CINEMA E AUDIOVISUAL	51
45191	2901.000.814-1	DIREÇÃO AUDIOVISUAL II	51
46857	2901.001.027-5	DOCUMENTÁRIO I - TEORIA E HISTÓRIA	68
45170	2901.000.793-0	MONTAGEM E EDIÇÃO I	68
45188	2901.000.811-4	SOM I	68
45172	2901.000.795-9	TEORIAS DO CINEMA E DO AUDIOVISUAL	68
46851	2901.001.021-0	ANÁLISE FÍLMICA	68
46848	2901.001.018-6	DOCUMENTÁRIO II - CRIAÇÃO E PRODUÇÃO	51
46839	2901.001.009-7	FINALIZAÇÃO E PÓS-PRODUÇÃO	51
41850	2901.000.488-0	SOCIOLOGIA DA COMUNICAÇÃO	68
46843	2901.001.013-0	HISTÓRIA DO CINEMA E DO AUDIOVISUAL BRASILEIRO II	68
46852	2901.001.022-0	PRESERVAÇÃO AUDIOVISUAL	68
46853	2901.001.023-9	SEMINÁRIO DE PESQUISA E PRODUÇÃO EM AUDIOVISUAL I	34
46846	2901.001.016-8	COMUNICAÇÃO AUDIOVISUAL NA EDUCAÇÃO	51
46844	2901.001.014-0	LEGISLAÇÃO, CURADORIA E EXIBIÇÃO	68
46845	2901.001.015-9	SEMINÁRIO DE PESQUISA E PRODUÇÃO EM AUDIOVISUAL II	34
45822	2901.000.996-2	CINEMA CLÁSSICO HOLLYWOODIANO	51
45825	2901.000.999-0	CINEMA JAPONÊS	51
47867	2901.001.030-0	CINEMA LATINO-AMERICANO	51
46854	2901.001.024-8	CINEMAS AFRO-DIASPÓRICOS	51
41884	2901.000.121-0	COMUNICAÇÃO PARA O TERCEIRO SETOR E PARA O CIBERATIVISMO	51
45826	2901.001.000-5	CRÍTICA DE CINEMA	51
45186	2901.000.809-9	EDUCAÇÃO DAS RELAÇÕES ÉTNICO-RACIAIS	34
44723	2901.000.759-2	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
41894	2901.000.131-8	MÍDIA-EDUCAÇÃO	51
45189	2901.000.812-3	MONTAGEM E EDIÇÃO II	68
47865	2901.001.028-4	NARRATIVA TRANSMÍDIA	51
45823	2901.000.997-1	NOVÍSSIMO CINEMA BRASILEIRO	51
45824	2901.000.998-0	NUEVO CINE LATINOAMERICANO	51
46855	2901.001.025-7	OFICINA DE CRIAÇÃO FOTOGRÁFICA	51
46849	2901.001.019-5	POÉTICAS DO DOCUMENTÁRIO: ENSAIO E ARQUIVO NO CINEMA CONTEMPORÂNEO	51
45178	2901.000.801-6	PRODUÇÃO AUDIOVISUAL II	51
45190	2901.000.813-2	SOM II	68
45831	2901.001.005-0	TÓPICOS EM MÚSICA E AUDIOVISUAL I	34
45169	2901.000.792-1	TÓPICOS ESPECIAIS EM AUDIOVISUAL I	51
45193	2901.000.816-0	TÓPICOS ESPECIAIS EM AUDIOVISUAL II	51
45827	2901.001.001-4	TÓPICOS ESPECIAIS EM AUDIOVISUAL III	51
45828	2901.001.002-3	TÓPICOS ESPECIAIS EM AUDIOVISUAL IV	51
47869	2901.001.032-8	TÓPICOS ESPECIAIS EM AUDIOVISUAL IX	51
45829	2901.001.003-2	TÓPICOS ESPECIAIS EM AUDIOVISUAL V	51
45830	2901.001.004-1	TÓPICOS ESPECIAIS EM AUDIOVISUAL VI	51
47866	2901.001.029-3	TÓPICOS ESPECIAIS EM AUDIOVISUAL VII	51
47868	2901.001.031-9	TÓPICOS ESPECIAIS EM AUDIOVISUAL VIII	51
47870	2901.001.033-7	TÓPICOS ESPECIAIS EM AUDIOVISUAL X	51
47871	2901.001.034-6	TÓPICOS ESPECIAIS EM AUDIOVISUAL XI	51
47872	2901.001.035-5	TÓPICOS ESPECIAIS EM AUDIOVISUAL XII	51
47873	2901.001.036-4	TÓPICOS ESPECIAIS EM AUDIOVISUAL XIII	51
44598	3001.000.518-9	ANTROPOLOGIA	68
48831	3001.000.633-7	HISTÓRIA ANTIGA I	68
48824	3001.000.626-6	PRÁTICAS DE ENSINO EM HISTÓRIA I	68
44583	3001.000.503-5	PRÉ-HISTÓRIA	68
48838	3001.000.640-8	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
48833	3001.000.635-5	HISTÓRIA ANTIGA II	68
48829	3001.000.631-9	HISTORIA MEDIEVAL I	68
48827	3001.000.629-3	LEITURA E PRODUÇÃO DE TEXTOS ACADÊMICOS	68
48825	3001.000.627-5	PRATICAS DE ENSINO EM HISTÓRIA II	68
48839	3001.000.641-7	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
48836	3001.000.638-2	ENSINO DE HISTÓRIA E CULTURA AFROBRASILEIRA E AFRICANA	68
44600	3001.000.520-4	HISTÓRIA DA AMÉRICA I	68
48835	3001.000.637-3	HISTÓRIA MEDIEVAL II	68
48826	3001.000.628-4	PRÁTICAS DE ENSINO EM HISTÓRIA III	68
48832	3001.000.634-6	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	100
44562	3001.000.484-2	FILOSOFIA DA EDUCAÇÃO	68
42370	3001.000.059-5	HISTÓRIA DA AMÉRICA II	68
42365	3001.000.054-4	HISTÓRIA DO BRASIL I	68
44611	3001.000.530-2	HISTÓRIA INDÍGENA	68
48846	3001.000.648-0	PRÁTICAS DE ENSINO EM HISTÓRIA IV	68
48830	3001.000.632-8	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	100
42330	3001.000.019-6	HISTÓRIA DA ÁFRICA	68
44587	3001.000.507-1	HISTÓRIA DO BRASIL II	68
48840	3001.000.642-6	HISTÓRIA MODERNA I	68
48847	3001.000.649-0	PRATICAS DE ENSINO EM HISTÓRIA V	68
44595	3001.000.515-1	TEORIAS E METODOLOGIAS DA HISTÓRIA III	68
48845	3001.000.647-1	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	100
44593	3001.000.513-3	HISTÓRIA DO BRASIL III	68
48841	3001.000.643-5	HISTÓRIA MODERNA II	68
48837	3001.000.639-1	PESQUISA HISTÓRICA	68
48842	3001.000.644-4	PRATICAS DE ENSINO EM HISTÓRIA VI	68
48834	3001.000.636-4	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	100
48843	3001.000.645-3	HISTÓRIA CONTEMPORÂNEA I	68
44575	3001.000.495-0	HISTÓRIA REGIONAL	68
48828	3001.000.630-0	SEMINÁRIO DE PESQUISA	68
48844	3001.000.646-2	HISTÓRIA CONTEMPORÂNEA II	68
44603	3001.000.523-1	EDUCAÇÃO AMBIENTAL	68
42325	3001.000.014-5	EDUCAÇÃO PATRIMONIAL	68
44602	3001.000.522-2	ESTUDOS DE ARQUEOLOGIA	68
42327	3001.000.016-1	ESTUDOS DE GÊNERO	68
44601	3001.000.521-3	ESTUDOS FRONTEIRIÇOS	68
44612	3001.000.531-1	ESTUDOS SOBRE IMIGRAÇÕES OITOCENTISTAS	68
42329	3001.000.018-8	HISTÓRIA CULTURAL	68
42332	3001.000.021-8	HISTÓRIA DA EDUCAÇÃO	68
44586	3001.000.506-2	HISTÓRIA DO MOVIMENTO OPERÁRIO NO BRASIL	68
44614	3001.000.533-0	HISTÓRIA DO PENSAMENTO POLÍTICO CONTEMPORÂNEO	68
42337	3001.000.026-9	HISTÓRIA DOS ESTADOS UNIDOS DA AMÉRICA	68
42339	3001.000.028-5	HISTÓRIA ORAL	68
42341	3001.000.030-7	HISTORIOGRAFIA BRASILEIRA	68
44563	3001.000.485-1	RELIGIÕES AFRODESCENDENTES EM MATO GROSSO DO SUL	68
44613	3001.000.532-0	TÓPICOS ESPECIAIS DE GEOGRAFIA	68
42344	3001.000.033-1	TÓPICOS ESPECIAIS EM HISTÓRIA I	68
42345	3001.000.034-0	TÓPICOS ESPECIAIS EM HISTÓRIA II	68
42346	3001.000.035-8	TÓPICOS ESPECIAIS EM HISTÓRIA III	68
42347	3001.000.036-6	TÓPICOS ESPECIAIS EM HISTÓRIA IV	68
42348	3001.000.037-4	TÓPICOS ESPECIAIS EM HISTÓRIA V	68
42349	3001.000.038-2	TÓPICOS ESPECIAIS EM HISTÓRIA VI	68
42350	3001.000.039-0	TÓPICOS ESPECIAIS EM HISTÓRIA VII	68
50400	2701.000.337-5	BASES BIOLÓGICAS DO COMPORTAMENTO	68
50482	2201.000.210-9	ESTATÍSTICA APLICADA À PSICOLOGIA	68
50466	3001.000.715-6	FILOSOFIA GERAL	68
50474	3001.000.723-6	MÉTODOS DE PESQUISA EM PSICOLOGIA I	68
50467	3001.000.716-5	SOCIOLOGIA GERAL	68
50408	3001.000.657-0	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS DA PSICOLOGIA SOCIAL	68
50413	3001.000.662-2	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
50404	3001.000.653-3	FUNDAMENTOS EPISTEMOLÓGICOS E HISTÓRICOS: ENFOQUE PSICANALÍTICO	68
50402	2701.000.339-3	GENÉTICA HUMANA APLICADA À PSICOLOGIA	68
50412	3001.000.661-3	MÉTODOS DE PESQUISA EM PSICOLOGIA II	68
50442	3001.000.691-8	PROCESSOS PSICOLÓGICOS BÁSICOS	68
50437	3001.000.686-5	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL I	68
50471	3001.000.720-9	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL I	68
50405	3001.000.654-2	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO I	68
50468	3001.000.717-4	PSICOLOGIA E DIVERSIDADE HUMANA I	68
50449	3001.000.698-1	PSICOLOGIA E ÉTICA PROFISSIONAL	68
50440	3001.000.689-2	PSICOLOGIA SOCIAL	68
50470	3001.000.719-2	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE ANALÍTICO COMPORTAMENTAL II	68
50403	3001.000.652-4	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE HISTÓRICO-CULTURAL II	68
50406	3001.000.655-1	FENÔMENOS E PROCESSOS PSICOLÓGICOS: ENFOQUE PSICANALÍTICO II	68
50438	3001.000.687-4	PSICOLOGIA DO DESENVOLVIMENTO I	68
50409	3001.000.658-9	PSICOLOGIA ESCOLAR E EDUCACIONAL I	68
50478	3001.000.727-2	TEORIAS E PRÁTICAS PSICOSSOCIAIS	68
50420	3001.000.669-6	AVALIAÇÃO PSICOLÓGICA I	68
42594	3001.000.119-2	ESTÁGIO OBRIGATÓRIO BÁSICO I	102
50411	3001.000.660-4	PSICOLOGIA DO DESENVOLVIMENTO II	68
50423	3001.000.672-0	PSICOLOGIA E POLÍTICAS PÚBLICAS: SISTEMA ÚNICO DE ASSISTÊNCIA SOCIAL	68
50447	3001.000.696-3	PSICOLOGIA ESCOLAR E EDUCACIONAL II	68
50448	3001.000.697-2	PSICOPATOLOGIA GERAL I	68
50472	3001.000.721-8	AVALIAÇÃO PSICOLÓGICA II	68
42605	3001.000.130-3	ESTÁGIO OBRIGATÓRIO BÁSICO II	102
50428	3001.000.677-6	PSICOLOGIA E PROCESSOS GRUPAIS COM ÊNFASE PSICOSSOCIAL	68
50419	3001.000.668-7	PSICOPATOLOGIA GERAL II	68
50414	3001.000.663-1	TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
50443	3001.000.692-7	TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE PSICANALÍTICO	68
50450	3001.000.699-0	INTERVENÇÕES EM PSICOLOGIA: DIFERENTES PERSPECTIVAS I	68
50435	3001.000.684-7	ORIENTAÇÃO PROFISSIONAL	68
50469	3001.000.718-3	PSICOLOGIA DO TRABALHO	68
50441	3001.000.690-9	PSICOLOGIA E DIVERSIDADE HUMANA II - RAÇA E ETNIA	68
50434	3001.000.683-8	PSICOLOGIA E SAÚDE I	68
50422	3001.000.671-1	ASPECTOS PSICOSSOCIAIS DO TRABALHO	68
50475	3001.000.724-5	INTERVENÇÕES EM PSICOLOGIA: DIFERENTES PERSPECTIVAS II	68
50476	3001.000.725-4	PSICODIAGNÓSTICO E PSICOTERAPIA NO CONTEXTO DA INFÂNCIA E ADOLESCÊNCIA	68
50418	3001.000.667-8	PSICOLOGIA E DIVERSIDADE HUMANA III - GÊNERO E SEXUALIDADE	68
50417	3001.000.666-9	PSICOLOGIA E SAÚDE II	68
50407	3001.000.656-0	AVALIAÇÃO PSICÓLOGICA III	68
50459	3001.000.708-5	ANÁLISE DO COMPORTAMENTO E DIREITO	68
50458	3001.000.707-6	APRENDIZAGEM VERBAL E CONTROLE POR REGRAS NA ANÁLISE DO COMPORTAMENTO	68
50457	3001.000.706-7	APROFUNDAMENTOS EM TEORIAS E TÉCNICAS PSICOTERÁPICAS: ENFOQUE ANALÍTICO COMPORTAMENTAL	68
50455	3001.000.704-9	ARTE, PSICOLOGIA E SUBJETIVIDADE	68
50415	3001.000.664-0	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS CLÍNICOS E SAÚDE COLETIVA I	102
50416	3001.000.665-0	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS CLÍNICOS E SAÚDE COLETIVA II	102
50446	3001.000.695-4	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS CLÍNICOS E SAÚDE COLETIVA III	102
50479	3001.000.728-1	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS CLÍNICOS E SAÚDE COLETIVA IV	102
50480	3001.000.729-0	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS PSICOSSOCIAIS NAS POLÍTICAS PÚBLICAS E INSTITUIÇÕES I	102
50465	3001.000.714-7	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS PSICOSSOCIAIS NAS POLÍTICAS PÚBLICAS E INSTITUIÇÕES II	102
50421	3001.000.670-2	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS PSICOSSOCIAIS NAS POLÍTICAS PÚBLICAS E INSTITUIÇÕES III	102
50429	3001.000.678-5	ESTÁGIO OBRIGATÓRIO ÊNFASE EM PROCESSOS PSICOSSOCIAIS NAS POLÍTICAS PÚBLICAS E INSTITUIÇÕES IV	102
50481	3101.000.607-0	ESTUDO DE LIBRAS	51
50460	3001.000.709-4	FUNDAMENTOS DA PSICOLOGIA HUMANISTA-EXISTENCIAL E FENOMENOLÓGICA	68
50453	3001.000.702-0	INTERVENÇÕES EM TERAPIAS COGNITIVAS E CONTEXTUAIS	68
50432	3001.000.681-0	NEUROPSICOLOGIA	68
50456	3001.000.705-8	PRÁTICAS E VIVÊNCIAS EM ARTETERAPIA	68
50444	3001.000.693-6	PSICANÁLISE NO CONTEXTO DA INFÂNCIA	68
50410	3001.000.659-8	PSICODIAGNÓSTICO	68
50401	2701.000.338-4	PSICOFARMACOLOGIA	68
50477	3001.000.726-3	PSICOLOGIA AMBIENTAL	68
50454	3001.000.703-0	PSICOLOGIA DA COMUNICAÇÃO E DO MARKETING	68
50436	3001.000.685-6	PSICOLOGIA DA PERSONALIDADE:	68
50463	3001.000.712-9	PSICOLOGIA DA RELIGIÃO	68
50424	3001.000.673-0	PSICOLOGIA DO ESPORTE	68
50462	3001.000.711-0	PSICOLOGIA E SAÚDE COLETIVA	68
50464	3001.000.713-8	PSICOLOGIA E TANATOLOGIA	68
50425	3001.000.674-9	PSICOLOGIA HOSPITALAR E DA SAÚDE	68
50426	3001.000.675-8	PSICOLOGIA JURÍDICA	68
50452	3001.000.701-1	PSICOTERAPIA COGNITIVO-COMPORTAMENTAL	68
50427	3001.000.676-7	QUESTÕES AVANÇADAS EM ANÁLISE DO COMPORTAMENTO	68
50473	3001.000.722-7	TEORIA DAS REPRESENTAÇÕES SOCIAIS	68
50461	3001.000.710-0	TEORIAS E TÉCNICAS PSICOTERÁPICAS: HUMANISTA-EXISTENCIAL E FENOMENOLÓGICA	68
50431	3001.000.680-0	TÓPICOS CONTEMPORÂNEOS EM PSICOLOGIA I	68
50430	3001.000.679-4	TÓPICOS CONTEMPORÂNEOS EM PSICOLOGIA II	68
50433	3001.000.682-9	TÓPICOS CONTEMPORÂNEOS EM PSICOLOGIA III	68
50439	3001.000.688-3	TÓPICOS CONTEMPORÂNEOS EM PSICOLOGIA IV	68
50451	3001.000.700-2	TÓPICOS ESPECIAIS DE PSICANÁLISE	68
50445	3001.000.694-5	USO DO COMPUTADOR NA PSICOLOGIA	68
43848	3001.000.382-7	FILOSOFIA GERAL: PROBLEMAS METAFÍSICOS	68
43847	3001.000.381-8	HISTÓRIA DA FILOSOFIA ANTIGA	68
43909	3001.000.438-8	HISTÓRIA GERAL	68
43894	2901.000.491-0	LÍNGUA ESTRANGEIRA MODERNA	68
43845	3001.000.379-2	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA I	68
43878	3001.000.409-2	HISTÓRIA DA FILOSOFIA MEDIEVAL	68
43923	3001.000.452-0	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA II	68
43892	3001.000.423-4	SOCIOLOGIA GERAL	68
43851	3001.000.384-5	TEORIA DO CONHECIMENTO	68
43877	3001.000.408-3	HISTÓRIA DA FILOSOFIA MODERNA	68
43856	3001.000.388-1	LÓGICA	68
43870	3001.000.401-0	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA III	68
43882	3001.000.413-6	ÉTICA	68
43865	3001.000.396-1	FILOSOFIA DA EDUCAÇÃO	68
43869	3001.000.400-0	FILOSOFIA DA LINGUAGEM	68
43891	3001.000.422-5	HISTÓRIA DA FILOSOFIA CONTEMPORÂNEA	68
43889	3001.000.420-7	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA IV	68
43862	3001.000.393-4	ESTÁGIO OBRIGATÓRIO EM ENSINO DE FILOSOFIA I	100
43896	3001.000.425-2	ESTÉTICA	68
43876	3001.000.407-4	FILOSOFIA POLÍTICA	68
42883	3001.000.282-2	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA V	68
43864	3001.000.395-2	ESTÁGIO OBRIGATÓRIO EM ENSINO DE FILOSOFIA II	100
43937	3001.000.466-4	PENSAMENTO FILOSÓFICO I	68
43938	3001.000.467-3	PENSAMENTO FILOSÓFICO II	68
42888	3001.000.287-3	PRÁTICA DE ENSINO, LEITURA E PESQUISA EM FILOSOFIA VI	68
43879	3001.000.410-9	ESTÁGIO OBRIGATÓRIO EM ENSINO DE FILOSOFIA III	100
43867	3001.000.398-0	FILOSOFIA DA MENTE	68
43895	3001.000.424-3	ESTÁGIO OBRIGATÓRIO EM ENSINO DE FILOSOFIA IV	100
43947	3001.000.476-2	CAPITALISMO, FEMINISMO E RELAÇÕES DE GÊNERO	68
43888	3001.000.419-0	CETICISMO	68
43841	3001.000.375-6	DIALÉTICA I	68
43900	3001.000.429-9	DIALÉTICA II	68
43843	3001.000.377-4	EDUCAÇÃO AMBIENTAL	68
43920	3001.000.449-5	ELABORAÇÃO DE MATERIAL DIDÁTICO E APRENDIZAGEM EM FILOSOFIA	68
43921	3001.000.450-1	EPISTEMOLOGIA	68
47199	3001.000.585-9	EPISTEMOLOGIA DAS CIÊNCIAS HUMANAS	68
43860	3001.000.392-5	FILOSOFIA BRASILEIRA I	68
43844	3001.000.378-3	FILOSOFIA BRASILEIRA II	68
43903	3001.000.432-3	FILOSOFIA DA HISTÓRIA	68
43839	3001.000.373-8	FILOSOFIA DA MENTE I	68
43852	3001.000.385-4	FILOSOFIA DA PSICANÁLISE I	68
43922	3001.000.451-0	FILOSOFIA DA PSICANÁLISE II	68
43880	3001.000.411-8	FILOSOFIA LATINO-AMERICANA I	68
43854	3001.000.387-2	FILOSOFIA LATINO-AMERICANA II	68
43929	3001.000.458-4	FILOSOFIA LUSO-BRASILEIRA	68
43904	3001.000.433-2	FILOSOFIA SOCIAL	68
43905	3001.000.434-1	HISTÓRIA DO ENSINO DE FILOSOFIA NO BRASIL	68
47198	3001.000.584-0	METODOLOGIA DE ENSINO DE FILOSOFIA	68
43866	3001.000.397-0	ORGANIZAÇÃO CURRICULAR E GESTÃO DA ESCOLA	68
43875	3001.000.406-5	PRÁTICAS INTEGRADORAS PARA FORMAÇÃO DOCENTE	68
43868	3001.000.399-9	PROFISSÃO DOCENTE: IDENTIDADE, CARREIRA E DESENVOLVIMENTO PROFISSIONAL	68
43908	3001.000.437-9	TEORIAS DA DEMOCRACIA I	68
43850	3001.000.383-6	TEORIAS DA DEMOCRACIA II	68
43918	3001.000.447-7	TÓPICOS ESPECIAIS EM ANTROPOLOGIA FILOSÓFICA I	68
43846	3001.000.380-9	TÓPICOS ESPECIAIS EM ANTROPOLOGIA FILOSÓFICA II	68
43914	3001.000.443-0	TÓPICOS ESPECIAIS EM ESTÉTICA I	68
43853	3001.000.386-3	TÓPICOS ESPECIAIS EM ESTÉTICA II	68
43906	3001.000.435-0	TÓPICOS ESPECIAIS EM ESTÉTICA III	68
43886	3001.000.417-2	TÓPICOS ESPECIAIS EM ÉTICA I	68
43907	3001.000.436-0	TÓPICOS ESPECIAIS EM ÉTICA II	68
43859	3001.000.391-6	TÓPICOS ESPECIAIS EM ÉTICA III	68
43911	3001.000.440-3	TÓPICOS ESPECIAIS EM ÉTICA IV	68
43939	3001.000.468-2	TÓPICOS ESPECIAIS EM ÉTICA V	68
43940	3001.000.469-1	TÓPICOS ESPECIAIS EM ÉTICA VI	68
43945	3001.000.474-4	TÓPICOS ESPECIAIS EM ÉTICA VII	68
43946	3001.000.475-3	TÓPICOS ESPECIAIS EM ÉTICA VIII	68
43919	3001.000.448-6	TÓPICOS ESPECIAIS EM FILOSOFIA DA LINGUAGEM I	68
43899	3001.000.428-0	TÓPICOS ESPECIAIS EM FILOSOFIA DA LINGUAGEM II	68
43901	3001.000.430-5	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA I	68
43902	3001.000.431-4	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA II	68
43925	3001.000.454-8	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA III	68
43951	3001.000.480-6	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA IV	68
43910	3001.000.439-7	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA V	68
43930	3001.000.459-3	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA VI	68
43838	3001.000.372-9	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA VII	68
43932	3001.000.461-9	TÓPICOS ESPECIAIS EM FILOSOFIA POLÍTICA VIII	68
43912	3001.000.441-2	TÓPICOS ESPECIAIS EM HISTÓRIA DA FILOSOFIA ANTIGA I	68
43915	3001.000.444-0	TÓPICOS ESPECIAIS EM HISTÓRIA DA FILOSOFIA ANTIGA II	68
43949	3001.000.478-0	TÓPICOS ESPECIAIS EM HISTÓRIA DA FILOSOFIA MEDIEVAL I	68
43873	3001.000.404-7	TÓPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA I	68
43897	3001.000.426-1	TÓPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA II	68
43927	3001.000.456-6	TÓPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA III	68
43872	3001.000.403-8	TÓPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA IV	68
43840	3001.000.374-7	TÓPICOS ESPECIAIS EM HISTÓRIA DA FILOSOFIA MODERNA V	68
43924	3001.000.453-9	TÓPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA VI	68
43931	3001.000.460-0	TOPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA VII	68
43933	3001.000.462-8	TOPICOS ESPECIAIS EM HISTORIA DA FILOSOFIA MODERNA VIII	68
43871	3001.000.402-9	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA I	68
43916	3001.000.445-9	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA II	68
43917	3001.000.446-8	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA III	68
43842	3001.000.376-5	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA IV	68
43857	3001.000.389-0	TÓPICOS ESPECIAIS EM HISTORIA FILOSOFIA CONTEMPORÂNEA V	68
43934	3001.000.463-7	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA VI	68
43935	3001.000.464-6	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA VII	68
43936	3001.000.465-5	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA CONTEMPORÂNEA VIII	68
43874	3001.000.405-6	TÓPICOS ESPECIAIS EM HISTÓRIA FILOSOFIA MEDIEVAL II	68
43884	3001.000.415-4	TÓPICOS ESPECIAIS EM LÓGICA I	68
43881	3001.000.412-7	TÓPICOS ESPECIAIS EM LÓGICA II	68
43883	3001.000.414-5	TÓPICOS ESPECIAIS EM PROBLEMAS METAFÍSICA I	68
43948	3001.000.477-1	TÓPICOS ESPECIAIS EM PROBLEMAS METAFÍSICA II	68
43898	3001.000.427-0	TÓPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO I	68
43887	3001.000.418-1	TÓPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO II	68
43928	3001.000.457-5	TÓPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO III	68
43885	3001.000.416-3	TÓPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO IV	68
43941	3001.000.470-8	TÓPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO V	68
43942	3001.000.471-7	TOPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO VI	68
43943	3001.000.472-6	TOPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO VII	68
43944	3001.000.473-5	TOPICOS ESPECIAIS EM TEORIA DO CONHECIMENTO VIII	68
42624	3001.000.149-4	FORMAÇÃO SOCIAL, POLÍTICA E ECONÔMICA I	68
45562	3001.000.568-0	METODOLOGIA CIENTÍFICA	68
42626	3001.000.151-6	TEORIA ANTROPOLÓGICA I	68
42627	3001.000.152-4	TEORIA POLÍTICA I	68
42628	3001.000.153-2	TEORIA SOCIOLÓGICA I	68
45568	3001.000.573-2	FILOSOFIA GERAL	68
42629	3001.000.154-0	FORMAÇÃO SOCIAL, POLÍTICA E ECONÔMICA II	68
42631	3001.000.156-7	TEORIA ANTROPOLÓGICA II	68
42632	3001.000.157-5	TEORIA POLÍTICA II	68
42641	3001.000.166-4	TEORIA SOCIOLÓGICA II	68
42634	3001.000.368-3	ECONOMIA POLÍTICA I	68
42633	3001.000.158-3	TEORIA ANTROPOLÓGICA III	68
42635	3001.000.160-5	TEORIA POLÍTICA III	68
42636	3001.000.161-3	TEORIA SOCIOLÓGICA III	68
42638	3001.000.369-1	ECONOMIA POLÍTICA II	68
42639	3001.000.164-8	TEORIA ANTROPOLÓGICA IV	68
42640	3001.000.165-6	TEORIA POLÍTICA IV	68
42642	3001.000.167-2	TEORIA SOCIOLÓGICA IV	68
45566	2201.000.167-6	ESTATÍSTICA APLICADA ÀS CIÊNCIAS HUMANAS	68
42637	3001.000.162-1	METODOLOGIA DAS CIÊNCIAS SOCIAIS I	68
51966	3001.000.732-5	SOCIOLOGIA BRASILEIRA	68
51967	3001.000.733-4	METODOLOGIA DAS CIÊNCIAS SOCIAIS II	68
45573	3001.000.578-8	SEMINÁRIO DE PESQUISA	34
45541	3001.000.547-4	CONSULTORIA, PLANEJAMENTO SOCIAL E LAUDOS ANTROPOLÓGICOS	68
42649	3001.000.174-5	GEOGRAFIA SOCIAL	68
42644	3001.000.169-9	ANTROPOLOGIA BRASILEIRA	68
42646	3001.000.171-0	POLÍTICA BRASILEIRA	68
42655	3001.000.180-0	ANÁLISE DE POLÍTICAS PÚBLICAS	34
45548	3001.000.554-5	ANTROPOLOGIA DA EXPERIÊNCIA RELIGIOSA	68
45555	3001.000.561-6	ANTROPOLOGIA DA NOITE	68
42656	3001.000.181-8	ANTROPOLOGIA DA RELIGIÃO	68
42657	3001.000.182-6	ANTROPOLOGIA DO CONSUMO	68
45542	3001.000.548-3	ANTROPOLOGIA DO TRABALHO	68
46972	3001.000.581-2	ANTROPOLOGIA E HISTÓRIA DAS EPIDEMIAS	68
45563	3001.000.569-9	ANTROPOLOGIA E SEXUALIDADE	68
46974	3001.000.583-0	ANTROPOLOGIA JURÍDICA E FORENSE	68
42658	3001.000.183-4	ANTROPOLOGIA RURAL	68
42659	3001.000.184-2	ANTROPOLOGIA URBANA	68
42660	3001.000.185-0	ANTROPOLOGIA VISUAL: A IMAGEM E SEU LUGAR NA ANTROPOLOGIA	68
42661	3001.000.186-9	CIÊNCIAS SOCIAIS E TURISMO	68
42662	3001.000.187-7	CRÍTICA DA ECONOMIA POLÍTICA	68
42664	3001.000.188-5	ECOLOGIA HUMANA	68
42665	3001.000.189-3	ECONOMIA BRASILEIRA CONTEMPORÂNEA	68
42666	3001.000.367-5	ECONOMIA POLÍTICA INTERNACIONAL	68
42667	3101.000.278-2	EDUCAÇÃO AMBIENTAL	68
45557	3001.000.563-4	ÉMILE DURKHEIM: MÉTODOS E QUESTÕES	68
45564	3001.000.570-5	EPISTEMOLOGIA DAS CIÊNCIAS SOCIAIS	68
42668	3001.000.191-5	ESTADO E SOCIEDADE NA AMÉRICA LATINA	68
45565	3001.000.571-4	ESTÁGIO EM CIÊNCIAS SOCIAIS	68
42669	3001.000.192-3	ESTUDOS AFRO-BRASILEIROS	68
45567	3001.000.572-3	ÉTICA E RESPONSABILIDADE SOCIAL	34
42670	3001.000.193-1	FRONTEIRAS ÉTNICAS E NACIONAIS	68
45569	3001.000.574-1	GÊNERO E DIFERENÇAS	68
42671	3001.000.194-0	HISTÓRIA DAS IDEIAS POLÍTICAS	68
42672	3001.000.195-8	IDENTIDADES TERRITORIAIS	68
45559	3001.000.565-2	INTRODUÇÃO À SOCIOLOGIA COMPUTACIONAL	68
45558	3001.000.564-3	KARL MARX: MÉTODOS E QUESTÕES	68
45570	3001.000.575-0	MAGIA E MITO	68
45556	3001.000.562-5	MAX WEBER: MÉTODOS E QUESTÕES	68
45571	3001.000.576-0	MÉTODOS E TÉCNICAS DE PESQUISA ANTROPOLÓGICA	68
42673	3001.000.196-6	MOVIMENTOS SOCIAIS	68
45572	3001.000.577-9	PANORAMA REGIONAL DE MATO GROSSO DO SUL	68
42674	3001.000.197-4	PARADIGMAS POLÍTICOS CONTEMPORÂNEOS	68
42675	3001.000.198-2	PENSAMENTO SOCIAL E POLÍTICO BRASILEIRO	68
42676	3001.000.199-0	PESQUISA DE CAMPO EM ETNOLOGIA	68
45560	3001.000.566-1	PESQUISA DE OPINIÃO E DE MERCADO	68
42678	3001.000.201-6	PESQUISA SOCIAL	68
52285	3001.000.734-3	POBREZA E SOCIEDADE: ABORDAGENS EM ENERGIA	68
52286	3001.000.735-2	POLÍTICA ENERGÉTICA: POLÍTICAS PÚBLICAS E MERCADOS	68
42680	3001.000.203-2	POLÍTICAS SOCIAIS	68
42679	3001.000.202-4	POLÍTICA SUL-MATO-GROSSENSE	34
42681	3001.000.204-0	PSICOLOGIA SOCIAL	68
52287	3001.000.736-1	SISTEMA DE JUSTIÇA BRASILEIRO: FUNCIONAMENTO, TEORIAS E DILEMAS	68
42682	3001.000.205-9	SISTEMAS PARTIDÁRIOS E SISTEMAS ELEITORAIS	68
42683	3001.000.206-7	SOCIEDADES INDÍGENAS	68
45561	3001.000.567-0	SOCIEDADES NA ÁFRICA CONTEMPORÂNEA	68
42685	3001.000.207-5	SOCIOLOGIA DA SAÚDE	68
42686	3001.000.208-3	SOCIOLOGIA DO CORPO, GÊNERO E SEXUALIDADE	68
42687	3001.000.209-1	SOCIOLOGIA DO DESENVOLVIMENTO	68
42688	3001.000.210-5	SOCIOLOGIA DO TRABALHO	68
42689	3001.000.211-3	SOCIOLOGIA RURAL	68
42690	3001.000.212-1	SOCIOLOGIA URBANA	68
45574	3001.000.579-7	TECNOLOGIA DA INFORMAÇÃO E CIÊNCIAS SOCIAIS	68
42691	3001.000.213-0	TÓPICOS EM RELAÇÕES INTERNACIONAIS	34
45534	3001.000.540-0	TÓPICOS ESPECIAIS EM ANTROPOLOGIA I	68
45535	3001.000.541-0	TÓPICOS ESPECIAIS EM ANTROPOLOGIA II	68
45536	3001.000.542-9	TÓPICOS ESPECIAIS EM ANTROPOLOGIA III	68
45537	3001.000.543-8	TÓPICOS ESPECIAIS EM ANTROPOLOGIA IV	68
45538	3001.000.544-7	TÓPICOS ESPECIAIS EM ANTROPOLOGIA V	68
45539	3001.000.545-6	TÓPICOS ESPECIAIS EM ANTROPOLOGIA VI	34
42693	3001.000.215-6	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA	34
45540	3001.000.546-5	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA I	68
45543	3001.000.549-2	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA II	68
45544	3001.000.550-9	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA III	68
45545	3001.000.551-8	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA IV	68
45547	3001.000.553-6	TÓPICOS ESPECIAIS EM CIÊNCIA POLÍTICA VI	34
42694	3001.000.216-4	TÓPICOS ESPECIAIS EM ECONOMIA POLÍTICA	34
42696	3001.000.218-0	TÓPICOS ESPECIAIS EM HISTÓRIA CONTEMPORÂNEA	68
42695	3001.000.217-2	TÓPICOS ESPECIAIS EM SOCIOLOGIA	34
45549	3001.000.555-4	TÓPICOS ESPECIAIS EM SOCIOLOGIA I	68
45550	3001.000.556-3	TÓPICOS ESPECIAIS EM SOCIOLOGIA II	68
45551	3001.000.557-2	TÓPICOS ESPECIAIS EM SOCIOLOGIA III	68
45554	3001.000.560-7	TÓPICOS ESPECIAIS EM SOCIOLOGIA IV	68
45552	3001.000.558-1	TÓPICOS ESPECIAIS EM SOCIOLOGIA V	68
45553	3001.000.559-0	TÓPICOS ESPECIAIS EM SOCIOLOGIA VI	34
46973	3001.000.582-1	VIOLÊNCIA, CRIME E CONFLITO	68
44564	3001.000.486-0	HISTÓRIA ANTIGA I	68
44560	3001.000.483-3	HISTÓRIA MEDIEVAL I	68
44588	3001.000.508-0	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
44574	3001.000.494-0	HISTORIA ANTIGA II	68
47208	3001.000.588-6	PESQUISA HISTÓRICA EM BENS CULTURAIS	68
42363	3001.000.052-8	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
47207	3001.000.587-7	CARTOGRAFIA HISTÓRICA	68
44599	3001.000.519-8	HISTÓRIA MEDIEVAL II	68
42368	3001.000.057-9	HISTÓRIA MODERNA I	68
47221	3001.000.601-4	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I - MUSEU	68
44607	3001.000.526-9	HISTÓRIA MODERNA II	68
44576	3001.000.496-9	PESQUISA HISTÓRICA	68
47220	3001.000.600-5	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II - ARQUIVO	68
44596	3001.000.516-0	HISTÓRIA CONTEMPORÂNEA I	68
47214	3001.000.594-8	HISTORIOGRAFIA BRASILEIRA	68
44606	3001.000.525-0	SEMINÁRIO DE PESQUISA	68
44585	3001.000.505-3	HISTÓRIA CONTEMPORÂNEA II	68
44615	3001.000.534-9	LEITURA E PRODUÇÃO DE TEXTOS ACADÊMICOS	68
47213	3001.000.593-9	TÓPICOS ESPECIAIS EM HISTÓRIA CONTEMPORÂNEA I	68
47222	3001.000.602-3	TÓPICOS ESPECIAIS EM HISTÓRIA CONTEMPORÂNEA II	68
47223	3001.000.603-2	TÓPICOS ESPECIAIS EM HISTÓRIA CONTEMPORÂNEA III	68
47227	3001.000.607-9	TÓPICOS ESPECIAIS EM HISTÓRIA DA ÁFRICA E DA ÁSIA I	68
47206	3001.000.586-8	TÓPICOS ESPECIAIS EM HISTÓRIA DA ÁFRICA E DA ÁSIA II	68
47209	3001.000.589-5	TÓPICOS ESPECIAIS EM HISTÓRIA DA ÁFRICA E DA ÁSIA III	68
47224	3001.000.604-1	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA I	68
47225	3001.000.605-0	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA II	68
47226	3001.000.606-0	TÓPICOS ESPECIAIS EM HISTÓRIA DA AMÉRICA III	68
47219	3001.000.599-3	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL I	68
47229	3001.000.609-7	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL II	68
47228	3001.000.608-8	TÓPICOS ESPECIAIS EM HISTÓRIA DO BRASIL III	68
47215	3001.000.595-7	TÓPICOS ESPECIAIS EM HISTÓRIA INDÍGENA E REGIONAL I	68
47236	3001.000.616-8	TÓPICOS ESPECIAIS EM HISTÓRIA INDÍGENA E REGIONAL II	68
47237	3001.000.617-7	TÓPICOS ESPECIAIS EM HISTÓRIA INDÍGENA E REGIONAL III	68
47238	3001.000.618-6	TÓPICOS ESPECIAIS EM HISTÓRIA MEDIEVAL I	68
47239	3001.000.619-5	TÓPICOS ESPECIAIS EM HISTÓRIA MEDIEVAL II	68
47240	3001.000.620-1	TÓPICOS ESPECIAIS EM HISTÓRIA MEDIEVAL III	68
47233	3001.000.613-0	TÓPICOS ESPECIAIS EM HISTÓRIA MODERNA I	68
47234	3001.000.614-0	TÓPICOS ESPECIAIS EM HISTÓRIA MODERNA II	68
47235	3001.000.615-9	TÓPICOS ESPECIAIS EM HISTÓRIA MODERNA III	68
47216	3001.000.596-6	TÓPICOS ESPECIAIS EM PESQUISA HISTÓRICA I	68
47231	3001.000.611-2	TÓPICOS ESPECIAIS EM PESQUISA HISTÓRICA II	68
47232	3001.000.612-1	TÓPICOS ESPECIAIS EM PESQUISA HISTÓRICA III	68
47217	3001.000.597-5	TÓPICOS ESPECIAIS EM PRÉ-HISTÓRIA E HISTÓRIA ANTIGA I	68
47230	3001.000.610-3	TÓPICOS ESPECIAIS EM PRÉ-HISTÓRIA E HISTÓRIA ANTIGA II	68
47218	3001.000.598-4	TÓPICOS ESPECIAIS EM PRÉ-HISTÓRIA E HISTÓRIA ANTIGA III	68
47211	3001.000.591-0	TÓPICOS ESPECIAIS EM TEORIAS E METODOLOGIAS DA HISTÓRIA E HISTORIOGRAFIA I	68
47210	3001.000.590-1	TÓPICOS ESPECIAIS EM TEORIAS E METODOLOGIAS DA HISTÓRIA E HISTORIOGRAFIA II	68
47212	3001.000.592-0	TÓPICOS ESPECIAIS EM TEORIAS E METODOLOGIAS DA HISTÓRIA E HISTORIOGRAFIA III	68
48442	3101.000.581-4	FILOSOFIA DA EDUCAÇÃO	68
48443	3101.000.582-3	HISTÓRIA DA EDUCAÇÃO I	68
48466	3101.000.605-2	PSICOLOGIA DA EDUCAÇÃO	68
48414	3101.000.553-8	SOCIOLOGIA DA EDUCAÇÃO	68
48450	3101.000.589-7	TRABALHO ACADÊMICO	68
48448	3101.000.587-9	CURRÍCULO E EDUCAÇÃO	68
48451	3101.000.590-3	DIDÁTICA I	68
48452	3101.000.591-2	EDUCAÇÃO E ANTROPOLOGIA	68
48444	3101.000.583-2	HISTÓRIA DA EDUCAÇÃO II	68
48454	3101.000.593-0	INFÂNCIA E SOCIEDADE	68
48438	3101.000.577-0	ALFABETIZAÇÃO E LETRAMENTO	68
48453	3101.000.592-1	DIDÁTICA II	68
48455	3101.000.594-0	LUDICIDADE E EDUCAÇÃO	68
48421	3101.000.560-9	PEDAGOGIA DA EDUCAÇÃO INFANTIL	68
48445	3101.000.584-1	POLÍTICAS EDUCACIONAIS	68
48439	3101.000.578-0	FUNDAMENTOS E METODOLOGIAS DO ENSINO DA LÍNGUA, LINGUAGEM ORAL E ESCRITA	68
44244	3101.000.372-0	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE CIÊNCIAS	68
48436	3101.000.575-2	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE GEOGRAFIA	68
48437	3101.000.576-1	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE HISTÓRIA	68
44238	3101.000.366-9	FUNDAMENTOS E METODOLOGIAS DO ENSINO DE MATEMÁTICA	68
48428	3101.000.567-2	EDUCAÇÃO DE JOVENS E ADULTOS	68
48446	3101.000.585-0	EDUCAÇÃO ESPECIAL	68
41691	3101.000.032-1	EDUCAÇÃO E TRABALHO	68
48458	3101.000.597-7	ESTÁGIO OBRIGATÓRIO I	100
48447	3101.000.586-0	GESTÃO ESCOLAR	68
48422	3101.000.561-8	PRÁTICAS PEDAGÓGICAS EM EDUCAÇÃO INFANTIL I	68
51815	3001.000.731-6	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
48459	3101.000.598-6	ESTÁGIO OBRIGATÓRIO II	100
48456	3101.000.595-9	ESTUDO DE LIBRAS	68
41680	3101.000.021-6	PESQUISA EDUCACIONAL	68
48423	3101.000.562-7	PRÁTICAS PEDAGÓGICAS EM EDUCAÇÃO INFANTIL II	68
48457	3101.000.596-8	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
41665	3101.000.006-2	EDUCAÇÃO, SEXUALIDADE E GÊNERO	68
48460	3101.000.599-5	ESTÁGIO OBRIGATÓRIO III	100
48435	3101.000.574-3	PRÁTICA DE ENSINO NOS ANOS INICIAIS DO ENSINO FUNDAMENTAL I	68
48424	3101.000.563-6	TRABALHO PEDAGÓGICO NOS ANOS INICIAIS DO ENSINO FUNDAMENTAL	68
48461	3101.000.600-7	ESTÁGIO OBRIGATÓRIO IV	100
44260	3101.000.388-3	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
48441	3101.000.580-5	LITERATURA PARA A INFÂNCIA	68
48434	3101.000.573-4	PRÁTICA DE ENSINO NOS ANOS INICIAIS DO ENSINO FUNDAMENTAL II	68
51816	3101.000.661-5	ALFABETIZAÇÃO DE JOVENS E ADULTOS	68
42293	3101.000.213-8	ASPECTOS LEGAIS DOS DIREITOS DAS CRIANÇAS E DOS ADOLESCENTES	68
48425	3101.000.564-5	ATIVIDADE INTERDISCIPLINAR EDUCATIVA, CULTURAL E CIENTÍFICA I	119
48426	3101.000.565-4	ATIVIDADE INTERDISCIPLINAR EDUCATIVA, CULTURAL E CIENTÍFICA II	119
48427	3101.000.566-3	ATIVIDADE INTERDISCIPLINAR EDUCATIVA, CULTURAL E CIENTÍFICA III	119
42303	3101.000.223-5	AVALIAÇÃO EDUCACIONAL	68
42302	3101.000.222-7	AVALIAÇÃO EM INSTITUIÇÕES ESCOLARES	68
44234	2901.000.598-1	CINEMA E EDUCAÇÃO DA DIVERSIDADE E DIFERENÇA	68
42316	3101.000.236-7	CUIDAR E EDUCAR NA PRIMEIRA INFÂNCIA	68
42312	3101.000.232-4	CULTURA BRASILEIRA	68
42292	3101.000.212-0	CURRÍCULO E INSTITUIÇÕES EDUCATIVAS	68
42294	3101.000.214-6	DIVERSIDADE CULTURAL	68
42304	3101.000.224-3	ECONOMIA DA EDUCAÇÃO	68
42308	3101.000.228-6	EDUCAÇÃO A DISTÂNCIA	68
48467	3101.000.606-1	EDUCAÇÃO, CULTURA E LINGUAGENS	68
44266	3101.000.393-6	EDUCAÇÃO DO CAMPO	68
42317	3101.000.237-5	EDUCAÇÃO E ARTE	68
42313	3101.000.233-2	EDUCAÇÃO E ESPIRITUALIDADE	68
44237	3101.000.365-0	EDUCAÇÃO EM ESPAÇOS NÃO ESCOLARES	68
42309	3101.000.229-4	EDUCAÇÃO E MOVIMENTOS SOCIAIS	68
42310	3101.000.230-8	EDUCAÇÃO E RELIGIOSIDADE	68
42318	3101.000.238-3	EDUCAÇÃO INDÍGENA	68
42305	3101.000.225-1	EDUCAÇÃO LÚDICA	68
42311	3101.000.231-6	EDUCAÇÃO POPULAR	68
42306	3101.000.226-0	EDUCAÇÃO, SAÚDE E NUTRIÇÃO PARA A INFÂNCIA	68
41719	3101.000.059-3	EDUCAÇÃO, SOCIEDADE E TRABALHO	68
48432	3101.000.571-6	ESTADO, SOCIEDADE E POLÍTICAS SOCIAIS	68
48462	3101.000.601-6	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO INFANTIL	68
48463	3101.000.602-5	ESTÁGIO OBRIGATÓRIO NOS ANOS INICIAIS DO ENSINO FUNDAMENTAL	68
42297	3101.000.217-0	FAMÍLIA E INSTITUIÇÕES EDUCATIVAS	68
42298	3101.000.218-9	FILOSOFIA DA EDUCAÇÃO BRASILEIRA	68
45381	3101.000.475-5	FORMAÇÃO DOCENTE E AÇÕES ESCOLARES	68
41684	3101.000.025-9	FUNDAMENTOS DA EDUCAÇÃO E DIVERSIDADE	68
41661	3101.000.002-0	FUNDAMENTOS DA EDUCAÇÃO INCLUSIVA	68
41713	3101.000.053-4	GESTÃO DOS SISTEMAS DE ENSINO	68
44233	3101.000.362-2	HISTÓRIA DA ÁFRICA	68
41666	3101.000.007-0	HISTÓRIA DA PEDAGOGIA	68
42307	3101.000.227-8	HISTÓRIA DAS INSTITUIÇÕES ESCOLARES	68
42291	3101.000.211-1	HISTÓRIA E CULTURA DA INFÂNCIA	68
48416	3101.000.555-6	INCLUSÃO E ARTE: APRENDIZAGEM AO LONGO DA VIDA	68
48433	3101.000.572-5	INFÂNCIA E LETRAMENTO	68
45380	3101.000.474-6	INICIAÇÃO À DOCÊNCIA I	51
45382	3101.000.476-4	INICIAÇÃO À DOCÊNCIA II	51
44267	3101.000.394-5	INSTRUMENTAÇÃO DO ENSINO DE MATEMÁTICA DA EDUCAÇÃO INFANTIL	68
44250	3101.000.378-5	INSTRUMENTAÇÃO DO ENSINO DE MATEMÁTICA DOS ANOS INICIAIS DO ENSINO FUNDAMENTAL	68
42321	3101.000.241-3	JOGOS BRINQUEDOS E BRINCADEIRAS NA INFÂNCIA	68
48440	3101.000.579-9	LEITURA E PRODUÇÃO DE TEXTO	68
44268	3101.000.395-4	LIBRAS NO CONTEXTO EDUCACIONAL	68
48417	3101.000.556-5	LITERATURA INFANTO-JUVENIL	68
48429	3101.000.568-1	POLÍTICAS DE EDUCAÇÃO DE JOVENS E ADULTOS	68
41718	3101.000.058-5	POLÍTICAS DE EDUCAÇÃO PROFISSIONAL	68
42287	3101.000.207-3	POLÍTICAS PÚBLICAS EM EDUCAÇÃO INFANTIL	68
42288	3101.000.208-1	POLÍTICAS PÚBLICAS SOCIAIS	68
48464	3101.000.603-4	PRÁTICA CIENTÍFICA I	68
48465	3101.000.604-3	PRÁTICA CIENTÍFICA II	68
48431	3101.000.570-7	PRÁTICA EM EDUCAÇÃO DE JOVENS E ADULTOS	68
48420	3101.000.559-2	PRÁTICA EM EDUCAÇÃO E DIVERSIDADE	68
48419	3101.000.558-3	PRÁTICA EM EDUCAÇÃO ESPECIAL	68
48418	3101.000.557-4	PRÁTICA EM EDUCAÇÃO E TRABALHO	68
48415	3101.000.554-7	PRÁTICA EM GESTÃO ESCOLAR	68
42322	3001.000.012-9	PSICOLOGIA DO DESENVOLVIMENTO E DA APRENDIZAGEM	68
42323	3101.000.242-1	TÓPICOS ESPECIAIS DA EDUCAÇÃO BRASILEIRA	68
41688	3101.000.029-1	TÓPICOS ESPECIAIS: LEITURAS DE CURRÍCULO EM EDUCAÇÃO ESPECIAL	68
42290	3101.000.210-3	TRABALHO DOCENTE E AS INSTITUIÇÕES SOCIAIS ESCOLARES E NÃO ESCOLARES	68
42320	3101.000.240-5	VIOLÊNCIAS CONTRA CRIANÇAS E ADOLESCENTES E AS INSTITUIÇÕES EDUCATIVAS	68
41571	2701.000.188-5	ANATOMIA HUMANA	51
41991	3101.000.126-3	CIÊNCIA E EDUCAÇÃO FÍSICA I	68
51261	3101.000.629-5	HISTÓRIA DA EDUCAÇÃO FÍSICA	68
43167	3101.000.321-0	METODOLOGIA E TEORIA DO JOGO	51
51264	3101.000.632-0	METODOLOGIAS DE ENSINO DAS GINÁSTICAS	68
43541	3101.000.343-5	PEDAGOGIA DO ESPORTE	68
51242	3101.000.610-5	BASES BIOLÓGICAS PARA A ATIVIDADE FÍSICA	51
43165	3101.000.319-5	CINESIOLOGIA E BIOMECÂNICA	68
51243	3101.000.611-4	CRESCIMENTO E DESENVOLVIMENTO HUMANO	51
51262	3101.000.630-1	ESTUDOS DO LAZER	68
51274	3101.000.642-8	FUNDAMENTOS FILOSÓFICOS E EDUCAÇÃO FÍSICA	51
51268	3101.000.636-6	METODOLOGIAS DE ENSINO DO FUTEBOL E FUTSAL	68
51245	3101.000.613-2	APRENDIZAGEM MOTORA	51
42002	3101.000.137-9	AVALIAÇÃO EM EDUCAÇÃO FÍSICA ESCOLAR	68
43157	3101.000.311-2	CIÊNCIA E EDUCAÇÃO FÍSICA II	68
51244	3101.000.612-3	FISIOLOGIA HUMANA	68
51269	3101.000.637-5	METODOLOGIAS DE ENSINO DO VOLEIBOL	68
43536	3101.000.338-2	CURRÍCULO E DIDÁTICA EM EDUCAÇÃO FÍSICA	68
51376	3101.000.654-4	EDUCAÇÃO FÍSICA NA EDUCAÇÃO INFANTIL	68
43155	3101.000.309-7	FISIOLOGIA DO EXERCICIO	68
51266	3101.000.634-8	METODOLOGIAS DE ENSINO DO ATLETISMO	68
51256	3101.000.624-0	METODOLOGIAS DE ENSINO DO HANDEBOL	68
43163	3101.000.317-7	ADMINISTRAÇÃO E ORGANIZAÇÃO EM EDUCAÇÃO FÍSICA	68
51372	3101.000.650-8	EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS INICIAIS	51
51380	3101.000.658-0	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NA EDUCAÇÃO INFANTIL	100
51263	3101.000.631-0	METODOLOGIAS DE ENSINO DAS DANÇAS	68
51267	3101.000.635-7	METODOLOGIAS DE ENSINO DO BASQUETEBOL	68
51377	3101.000.655-3	EDUCAÇÃO FÍSICA E PROMOÇÃO DA SAÚDE	51
51373	3101.000.651-7	EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS FINAIS	51
51378	3101.000.656-2	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS INICIAIS	100
51259	3101.000.627-7	POLÍTICAS PÚBLICAS DE EDUCAÇÃO FÍSICA, ESPORTE E LAZER	68
51270	3101.000.638-4	PREVENÇÃO DE ACIDENTES E SOCORROS DE URGÊNCIA EM EDUCAÇÃO FÍSICA	34
43540	3101.000.342-6	EDUCAÇÃO FÍSICA INCLUSIVA	68
51381	3101.000.659-0	EDUCAÇÃO FÍSICA NO ENSINO MÉDIO	68
51374	3101.000.652-6	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO FUNDAMENTAL - ANOS FINAIS	100
51379	3101.000.657-1	METODOLOGIAS DE ENSINO DAS ATIVIDADES AQUÁTICAS	68
51265	3101.000.633-9	METODOLOGIAS DE ENSINO DAS LUTAS	68
51280	3101.000.648-2	PRÁTICA CIENTÍFICA I	34
51375	3101.000.653-5	ESTÁGIO OBRIGATÓRIO EM EDUCAÇÃO FÍSICA NO ENSINO MÉDIO	100
51281	3101.000.649-1	PRÁTICA CIENTÍFICA II	34
51248	3101.000.616-0	SOCIOLOGIA DA EDUCAÇÃO FÍSICA E DO ESPORTE	68
41964	3101.000.099-2	APROFUNDAMENTO EM ATIVIDADES AQUÁTICAS	34
41965	3101.000.100-0	APROFUNDAMENTO EM ATLETISMO	34
41966	3101.000.101-8	APROFUNDAMENTO EM BASQUETEBOL	34
41967	3101.000.102-6	APROFUNDAMENTO EM DANÇAS	34
41968	3101.000.103-4	APROFUNDAMENTO EM DESENVOLVIMENTO MOTOR	34
41969	3101.000.104-2	APROFUNDAMENTO EM FUTEBOL	34
41970	3101.000.105-0	APROFUNDAMENTO EM GINÁSTICAS	34
41971	3101.000.106-9	APROFUNDAMENTO EM HANDEBOL	34
41972	3101.000.107-7	APROFUNDAMENTO EM LUTAS	34
41973	3101.000.108-5	APROFUNDAMENTO EM MEDIDAS E AVALIAÇÃO	34
41974	3101.000.109-3	APROFUNDAMENTO EM SOCIOLOGIA DA EDUCAÇÃO FÍSICA, ESPORTE E LAZER	34
41975	3101.000.110-7	APROFUNDAMENTO EM VOLEIBOL	34
41976	3101.000.111-5	ATIVIDADE FÍSICA PARA GRUPOS ESPECIAIS	34
41978	3101.000.113-1	BRINQUEDO, BRINCADEIRA E JOGO NA EDUCAÇÃO INFANTIL	34
41979	3101.000.114-0	COMPORTAMENTO MOTOR	34
41982	3101.000.117-4	EDUCAÇÃO FÍSICA, CORPO E CULTURA	34
43537	3101.000.339-1	EDUCAÇÃO FÍSICA E ANIMAÇÃO SOCIOCULTURAL	51
51273	3101.000.641-9	EDUCAÇÃO FÍSICA E COMUNIDADE 1 - GINÁSTICAS	34
51252	3101.000.620-3	EDUCAÇÃO FÍSICA E COMUNIDADE 2 - LAZER	34
51260	3101.000.628-6	EDUCAÇÃO FÍSICA E COMUNIDADE 3 - ESPORTES COLETIVOS	34
51275	3101.000.643-7	EDUCAÇÃO FÍSICA E COMUNIDADE 4 - ESPORTES INDIVIDUAIS	34
51276	3101.000.644-6	EDUCAÇÃO FÍSICA E COMUNIDADE 5 - SAÚDE	34
51277	3101.000.645-5	EDUCAÇÃO FÍSICA E COMUNIDADE 6 - DANÇAS	34
51278	3101.000.646-4	EDUCAÇÃO FÍSICA E COMUNIDADE 7 - ATIVIDADES ADAPTADAS E INCLUSIVAS	34
51279	3101.000.647-3	EDUCAÇÃO FÍSICA E COMUNIDADE 8 - ORGANIZAÇÃO DE EVENTOS EM EDUCAÇÃO FÍSICA	34
41981	3101.000.116-6	EDUCAÇÃO FÍSICA E PROGRAMAS SÓCIO-EDUCACIONAIS	34
51257	3101.000.625-9	EPIDEMIOLOGIA DA ATIVIDADE FÍSICA E SAÚDE	51
41984	3101.000.119-0	ESPORTE COM RAQUETES	34
43543	3101.000.345-3	ESPORTES ADAPTADOS	51
43150	3101.000.304-1	ESPORTES NA NATUREZA	51
43158	3101.000.312-1	ESTATÍSTICA APLICADA A EDUCAÇÃO FÍSICA	34
41681	3101.000.022-4	GESTÃO ESCOLAR	68
43145	3101.000.299-3	IMAGEM CORPORAL	34
43156	3101.000.310-3	NUTRIÇÃO E ATIVIDADE FÍSICA	51
41988	3101.000.123-9	PSICOLOGIA DO ESPORTE	34
42040	3101.000.174-3	TERRITÓRIO E IDENTIDADE	68
51246	3101.000.614-1	TREINAMENTO DE FORÇA/MUSCULAÇÃO	68
43177	3101.000.331-9	PEDAGOGIA DO ESPORTE I	68
43142	3101.000.296-6	PEDAGOGIA DO ESPORTE II	51
43178	3101.000.332-8	ATIVIDADE MOTORA ADAPTADA	51
43154	3101.000.308-8	MEDIDAS E AVALIAÇÃO	68
43144	3101.000.298-4	ATIVIDADE FÍSICA E ENVELHECIMENTO	34
51253	3101.000.621-2	ESTÁGIO 1 - ANIMAÇÃO SOCIOCULTURAL	68
51247	3101.000.615-0	ATIVIDADES DE ACADEMIA	51
43143	3101.000.297-5	EDUCAÇÃO FÍSICA E SAÚDE PÚBLICA	51
51249	3101.000.617-9	ESTÁGIO 2 - ATIVIDADE MOTORA ADAPTADA	136
51258	3101.000.626-8	METODOLOGIAS DE ENSINO DAS ATIVIDADES AQUÁTICAS	68
51255	3101.000.623-0	PRESCRIÇÃO DE EXERCÍCIOS FÍSICOS PARA GRUPOS ESPECIAIS	68
43170	3101.000.324-8	TREINAMENTO ESPORTIVO I	51
43166	3101.000.320-1	EMPREENDEDORISMO	51
51250	3101.000.618-8	ESTÁGIO 3 - ESPORTES	158
51254	3101.000.622-1	PRÁTICAS EDUCATIVAS EM SAÚDE	51
43171	3101.000.325-7	TREINAMENTO ESPORTIVO II	51
51251	3101.000.619-7	ESTÁGIO 4 - SAÚDE COLETIVA	136
51271	3101.000.639-3	ESTÁGIO 5 - ATIVIDADES DE ACADEMIA/MUSCULAÇÃO	158
43172	3101.000.326-6	BRINQUEDO, BRINCADEIRA E JOGO NA INFÂNCIA	34
42018	3101.000.153-0	EDUCAÇÃO FÍSICA ESCOLAR E PROMOÇÃO DA SAÚDE	68
43147	3101.000.301-4	EDUCAÇÃO FÍSICA INCLUSIVA	68
43148	3101.000.302-3	ESPORTES ADAPTADOS	34
51272	3101.000.640-0	ESTÁGIO EM EDUCAÇÃO FÍSICA	102
46970	3101.000.550-0	AGRICULTURA FAMILIAR, CAMPONESAS E OS SISTEMAS AGROALIMENTARES MUNDIAIS	51
46971	3101.000.551-0	CONTEXTUALIZAÇÃO FILOSÓFICA, HISTÓRICA, SOCIAL, POLÍTICA E ECONÔMICA DO CAMPO BRASILEIRO	51
44776	3101.000.424-5	EDUCAÇÃO DO CAMPO NO BRASIL E NO MATO GROSSO SUL	51
46949	3101.000.529-8	HISTÓRIA ORAL	51
46950	3101.000.530-4	LETRAMENTO LINGUÍSTICO I	68
46966	3101.000.546-7	LETRAMENTO MATEMÁTICO I: NÚMEROS E OPERAÇÕES	68
44772	3101.000.420-9	PESQUISA E PRÁTICA PEDAGÓGICA I	68
44805	3101.000.453-0	PSICOLOGIA E EDUCAÇÃO	51
46956	3101.000.536-9	EDUCAÇÃO E ANTROPOLOGIA	68
46960	3101.000.540-2	LETRAMENTO DIGITAL	68
46953	3101.000.533-1	LETRAMENTO LINGUÍSTICO II	68
46968	3101.000.548-5	LETRAMENTO MATEMÁTICO II: TÓPICOS ESPECIAIS DA MATEMÁTICA BÁSICA	68
44785	3101.000.433-4	PESQUISA E PRÁTICA PEDAGÓGICA II	68
46964	3101.000.544-9	PRÁTICA DE HISTÓRIA ORAL NAS COMUNIDADES DO CAMPO I	51
44818	3101.000.466-6	TRABALHO E EDUCAÇÃO: UMA RELAÇÃO HISTÓRICA E ESSENCIAL	68
44820	3101.000.468-4	FUNDAMENTOS DA LINGUÍSTICA	68
44796	3101.000.444-1	IDEIAS FUNDAMENTAIS DA GEOMETRIA I	68
44781	3101.000.429-0	PESQUISA E PRÁTICA PEDAGÓGICA III	68
44816	3101.000.464-8	DESENVOLVIMENTO E SUSTENTABILIDADE NO MEIO RURAL	68
46948	3101.000.528-9	EDUCAÇÃO MATEMÁTICA I	68
46942	3101.000.522-4	ETNOLINGUÍSTICA E EDUCAÇÃO DO CAMPO	51
44779	3101.000.427-2	FONÉTICA E FONOLOGIA	68
44787	3101.000.435-2	IDEIAS FUNDAMENTAIS DA GEOMETRIA II	68
44783	3101.000.431-6	LITERATURA BRASILEIRA I	68
46937	3101.000.517-1	PESQUISA E PRÁTICA PEDAGÓGICA IV	68
44766	3101.000.414-7	EDUCAÇÃO DO CAMPO E MÉTODO: CONTRIBUIÇÕES DO MATERIALISMO HISTÓRICO DIALÉTICO	68
46943	3101.000.523-3	ESTÁGIO OBRIGATÓRIO I	100
44797	3101.000.445-0	IDEIAS FUNDAMENTAIS DA ÁLGEBRA	68
44811	3101.000.459-5	LINGUAGEM CORPORAL E SONORA NA EDUCAÇÃO DO CAMPO	68
44808	3101.000.456-8	LITERATURA SUL-MATO-GROSSENSE	68
46967	3101.000.547-6	MORFOLOGIA E POSSIBILIDADES DE ENSINO NA EDUCAÇÃO DO CAMPO	68
44792	3101.000.440-5	TÓPICOS ESPECIAIS EM EDUCAÇÃO DO CAMPO	68
46951	3101.000.531-3	TRIGONOMETRIA E FUNÇÕES TRIGONOMÉTICAS	51
46965	3101.000.545-8	CURRÍCULO E TEORIAS EDUCACIONAIS	68
44804	3101.000.452-1	EDUCAÇÃO EM AGROECOLOGIA	68
44810	3101.000.458-6	EDUCAÇÃO FINANCEIRA	68
46945	3101.000.525-1	ESTÁGIO OBRIGATÓRIO II	100
44788	3101.000.436-1	INTRODUÇÃO AO CÁLCULO I	68
44765	3101.000.413-8	METODOLOGIA DE ENSINO DE LÍNGUA E LITERATURA	68
46939	3101.000.519-0	PRÁTICA DE HISTÓRIA ORAL NAS COMUNIDADES DO CAMPO 2	51
46936	3101.000.516-2	SINTAXE DA LINGUA PORTUGUESA E POSSIBILIDADES DE ENSINO NA EDUCAÇÃO DO CAMPO I	68
46952	3101.000.532-2	EDUCAÇÃO AMBIENTAL E SISTEMAS ECOLÓGICOS	68
46940	3101.000.520-6	EDUCAÇÃO MATEMÁTICA II	68
46946	3101.000.526-0	ESTÁGIO OBRIGATÓRIO III	100
46944	3101.000.524-2	GÊNEROS TEXTUAIS, MATERIAIS DIDÁTICOS E EDUCAÇÃO DO CAMPO	68
44803	3101.000.451-2	INTRODUÇÃO AO CÁLCULO II	68
44778	3101.000.426-3	LINGUAGEM TEATRAL E POSSIBILIDADE DE INTERVENÇÃO NA EDUCAÇÃO ESCOLAR DO CAMPO	68
46934	3101.000.514-4	SINTAXE DA LINGUA PORTUGUESA E POSSIBILIDADES DE ENSINO NA EDUCAÇÃO DO CAMPO II	68
44782	3101.000.430-7	TEORIA DA LITERATURA I	68
44763	3101.000.411-0	TÓPICOS DE ANÁLISE COMBINATÓRIA E PROBABILIDADE	68
44761	3101.000.409-4	VETORES E GEOMETRIA ANALÍTICA	68
44762	3101.000.410-0	ÁLGEBRA LINEAR	68
44802	3101.000.450-3	CÁLCULO DIFERENCIAL E INTEGRAL	68
46947	3101.000.527-0	ESTÁGIO OBRIGATÓRIO IV	100
44815	3101.000.463-9	ESTATÍSTICA	68
46938	3101.000.518-0	INTRODUÇÃO A SOCIOLINGUÍSTICA E O ENSINO DA LÍNGUA PORTUGUESA	68
44771	3101.000.419-2	SEMÂNTICA E PRAGMÁTICA	68
46958	3101.000.538-7	TECNOLOGIAS DIGITAIS APLICADAS AO ENSINO DE PORTUGUÊS	68
44790	3101.000.438-0	A MÍSTICA E A MILITÂNCIA NA EDUCAÇÃO DO CAMPO	68
44793	3101.000.441-4	CULTURA BRASILEIRA E IDENTIDADE NACIONAL	68
44757	3101.000.405-8	CURRÍCULO E EDUCAÇÃO MATEMÁTICA	68
46941	3101.000.521-5	CURRÍCULO E TEORIAS EDUCACIONAIS NO ENSINO DE MATEMÁTICA	68
44809	3101.000.457-7	ECONOMIA SOLIDÁRIA, CADEIAS PRODUTIVAS E AUTOGESTÃO NO CAMPO	68
44777	3101.000.425-4	EDUCAÇÃO DE JOVENS E ADULTOS NA ESCOLA DO CAMPO	34
46962	3101.000.542-0	EDUCAÇÃO DO CAMPO, LETRAMENTOS E FORMAÇÃO DE PROFESSORES DE LÍNGUA MATERNA III	68
46957	3101.000.537-8	EDUCAÇÃO E ANTROPOLOGIA NO ENSINO DE MATEMÁTICA	68
44819	3101.000.467-5	EDUCAÇÃO E EMANCIPAÇÃO	68
44824	3101.000.472-8	ESPANHOL INSTRUMENTAL	68
44774	3101.000.422-7	ETNOLINGUÍSTICA	68
46963	3101.000.543-0	ETNOMATEMÁTICA	51
46954	3101.000.534-0	FUNDAMENTOS DE DIDÁTICA NO ENSINO DE MATEMÁTICA	68
46955	3101.000.535-0	FUNDAMENTOS DE DIDÁTICA NO ENSINO DE PORTUGUÊS	68
44760	3101.000.408-5	GÊNEROS TEXTUAIS, MATERIAIS DIDÁTICOS E ENSINO	68
44794	3101.000.442-3	HISTÓRIA, POLÍTICA E EDUCAÇÃO	68
44812	3101.000.460-1	INTRODUÇÃO ÀS LITERATURAS DE LÍNGUA PORTUGUESA DE ORIGEM AFRICANA	68
44758	3101.000.406-7	LEMA: FORMAÇÃO DE PROFESSORES E ESCOLAS DO CAMPO	68
46969	3101.000.549-4	LETRAMENTO DIGITAL NO ENSINO DE LINGUAGENS	68
44795	3101.000.443-2	LITERATURA BRASILEIRA II	68
44825	3101.000.473-7	METODOLOGIAS E TÉCNICAS DE ENSINO E PESQUISA	68
44807	3101.000.455-9	PRINCÍPIOS DA DIALETOLOGIA E DA GEOLINGUÍSTICA	68
44798	3101.000.446-0	SUSTENTABILIDADE DE AGROECOSSISTEMAS	68
46935	3101.000.515-3	TECNOLOGIAS DIGITAIS APLICADAS AO ENSINO DE MATEMÁTICA E PORTUGUÊS	68
46961	3101.000.541-1	TENDÊNCIAS DE EDUCAÇÃO MATEMÁTICA NA EDUCAÇÃO DO CAMPO	68
44800	3101.000.448-8	TENDÊNCIAS EM EDUCAÇÃO MATEMÁTICA	68
44791	3101.000.439-9	TEORIA DA LITERATURA II	68
44759	3101.000.407-6	TRATAMENTO DA INFORMAÇÃO	68
46959	3101.000.539-6	TRATAMENTO DA INFORMAÇÃO E ENSINO DE MATEMÁTICA	68
52221	3101.000.662-4	ESTÁGIO OBRIGATÓRIO DE OBSERVAÇÃO EM LIBRAS I	51
52244	3101.000.685-8	HISTÓRIA DA EDUCAÇÃO	68
52240	3101.000.681-1	LIBRAS I E PRÁTICAS BILÍNGUES	85
52241	3101.000.682-0	POLÍTICAS E PRÁTICAS EPISTEMOLÓGICAS DO ENSINO DE LÍNGUA PORTUGUESA	68
46191	3101.000.483-5	SISTEMAS DE COMUNICAÇÃO, INFORMAÇÃO E APLICATIVOS EM ALIMENTAÇÃO ESCOLAR	51
52236	3101.000.677-8	ESTÁGIO OBRIGATÓRIO DE OBSERVAÇÃO EM LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS I	51
52234	3101.000.675-0	LIBRAS II E PRÁTICAS BILÍNGUES	85
52242	3101.000.683-0	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS I E PRÁTICAS BILÍNGUES	85
52248	3101.000.689-4	DIDÁTICA	68
52258	3101.000.699-2	DIREITOS HUMANOS, CIDADANIA, DIFERENÇAS, EQUIDADE E FORMAÇÃO DOCENTE	68
52256	3101.000.697-4	ESTÁGIO OBRIGATÓRIO DE OBSERVAÇÃO EM LIBRAS II	51
52245	3101.000.686-7	FUNDAMENTOS HISTÓRICOS E POLÍTICOS DA EDUCAÇÃO BILÍNGUE DE SURDOS	68
52260	3101.000.701-3	INFÂNCIA, LUDICIDADE E JOGOS BILÍNGUES	68
52247	3101.000.688-5	LIBRAS III E PRÁTICAS BILÍNGUES	85
52227	3101.000.668-9	ALFABETIZAÇÃO, LETRAMENTO E LETRAMENTO VISUAL	68
52223	3101.000.664-2	EDUCAÇÃO, LÍNGUA, LINGUAGEM E POLÍTICA LINGUÍSTICA	68
52253	3101.000.694-7	ESTÁGIO OBRIGATÓRIO DE OBSERVAÇÃO EM LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS II	51
52254	3101.000.695-6	LIBRAS IV E PRÁTICAS BILÍNGUES	85
52224	3101.000.665-1	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS II E PRÁTICAS BILÍNGUES	85
52226	3101.000.667-0	EDUCAÇÃO, RELAÇÕES ÉTNICO-RACIAIS, DIVERSIDADE RELIGIOSA E COMUNIDADES TRADICIONAIS	68
52255	3101.000.696-5	ESTÁGIO OBRIGATÓRIO DE LIBRAS I	51
52251	3101.000.692-9	LIBRAS V E PRÁTICAS BILÍNGUES	85
52252	3101.000.693-8	POLÍTICAS, GESTÃO E DIRETRIZES CURRICULARES NA EDUCAÇÃO DE SURDOS	68
52229	3101.000.670-4	PRÁTICAS EDUCATIVAS EXTENSIONISTAS EM EDUCAÇÃO BILÍNGUE DE SURDOS I	68
52235	3101.000.676-9	ATENDIMENTO EDUCACIONAL E ATENDIMENTO EDUCACIONAL ESPECIALIZADO PARA SURDOS	68
52261	3101.000.702-2	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS I	51
52239	3101.000.680-2	LIBRAS VI E PRÁTICAS BILÍNGUES	85
52231	3101.000.672-2	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS III E PRÁTICAS BILÍNGUES	85
52232	3101.000.673-1	LITERATURA, CULTURAS E IDENTIDADES SURDAS	68
52238	3101.000.679-6	PROCESSOS DE APRENDIZAGEM E MÚLTIPLAS LINGUAGENS NA EDUCAÇÃO DE SURDOS	68
52262	3101.000.703-1	EDUCAÇÃO DE JOVENS E ADULTOS, DIVERSIDADE DE FAIXA GERACIONAL, TRABALHO E SOCIEDADE	68
52257	3101.000.698-3	ESTÁGIO OBRIGATÓRIO DE LIBRAS II	51
52263	3101.000.704-0	ESTUDOS DA TRADUÇÃO E INTERPRETAÇÃO	68
52225	3101.000.666-0	LIBRAS VII E PRÁTICAS BILÍNGUES	85
52228	3101.000.669-8	PRÁTICAS EDUCATIVAS EXTENSIONISTAS EM EDUCAÇÃO BILÍNGUE DE SURDOS II	68
52264	3101.000.705-0	EDUCAÇÃO BILÍNGUE: TECNOLOGIAS E VISUALIDADE	68
52233	3101.000.674-0	ESTÁGIO OBRIGATÓRIO DE LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS II	51
52249	3101.000.690-0	FORMAÇÃO, IDENTIDADE, ATUAÇÃO DOCENTE E PESQUISA NA EDUCAÇÃO	68
52250	3101.000.691-0	LABORATÓRIO DE PRÁTICAS LINGUÍSTICAS: PRODUTO EDUCACIONAL BILÍNGUE	68
52243	3101.000.684-9	LIBRAS VIII E PRÁTICAS BILÍNGUES	85
52222	3101.000.663-3	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS IV E PRÁTICAS BILÍNGUES	85
52246	3101.000.687-6	ENSINO DE LÍNGUAS: PERSPECTIVAS CONTEMPORÂNEAS	68
52230	3101.000.671-3	LIBRAS: DIDÁTICAS E METODOLOGIAS PARA CRIANÇAS OUVINTES	68
52237	3101.000.678-7	LÍNGUA PORTUGUESA ESCRITA PARA SURDOS: PRÁTICAS DO IDIOMA	68
52259	3101.000.700-4	LÍNGUAS INDÍGENAS DE SINAIS PARA SURDOS NO PROCESSO DE ESCOLARIZAÇÃO	68
46201	3101.000.493-3	EDUCAÇÃO E TRABALHO COMO PRINCÍPIO EDUCATIVO	68
46220	3101.000.512-6	FUNDAMENTOS FILOSÓFICOS E HISTÓRICOS DA EDUCAÇÃO	68
46219	3101.000.511-7	LÍNGUA PORTUGUESA: LEITURA, ESCRITA E INTERAÇÃO	68
46217	3101.000.509-1	PLANEJAMENTO EDUCACIONAL, LICITAÇÃO E PROCESSOS DE TRABALHO EM ALIMENTAÇÃO ESCOLAR	51
46202	3101.000.494-2	SOCIEDADE, EDUCAÇÃO E CULTURA	68
46204	3101.000.496-0	TEORIAS DA ADMINISTRAÇÃO E EDUCAÇÃO	51
46187	3101.000.479-1	ADMINISTRAÇÃO EDUCACIONAL: SISTEMAS E INSTITUIÇÕES	51
46215	3101.000.507-3	DIDÁTICA E PRÁTICA PEDAGÓGICA EM ALIMENTAÇÃO ESCOLAR I	51
46190	3101.000.482-6	EDUCAÇÃO, CIÊNCIAS DOS ALIMENTOS E CONTROLE DE QUALIDADE	51
43988	3101.000.354-2	EDUCAÇÃO ESPECIAL	51
46193	3101.000.485-3	FINANCIAMENTO DA EDUCAÇÃO BÁSICA: POLÍTICAS E PROGRAMAS	51
46211	3101.000.503-7	GESTÃO DEMOCRÁTICA DA EDUCAÇÃO, DOS SISTEMAS DE ENSINO E DAS INSTITUIÇÕES	68
46194	3101.000.486-2	RELAÇÕES INTERPESSOAIS NAS INSTITUIÇÕES EDUCATIVAS	51
46207	3101.000.499-8	ALIMENTAÇÃO ESCOLAR E A INSTITUIÇÃO EDUCATIVA COMO LOCAL DE TRABALHO	68
46203	3101.000.495-1	CULTURA, ARTE E EDUCAÇÃO	68
46208	3101.000.500-0	DIDÁTICA E PRÁTICA PEDAGÓGICA EM ALIMENTAÇÃO ESCOLAR II	51
46188	3101.000.480-8	EDUCAÇÃO, COMUNICAÇÃO E MÍDIAS	51
46210	3101.000.502-8	ESTATÍSTICA E INDICADORES DE ALIMENTAÇÃO ESCOLAR	51
44001	3101.000.357-0	ESTUDO DE LIBRAS	51
46198	3101.000.490-6	NUTRIÇÃO E EDUCAÇÃO: TEORIAS, CONSUMO, CONSERVAÇÃO E UTILIZAÇÃO BIOLÓGICA DOS ALIMENTOS	68
46189	3101.000.481-7	EDUCAÇÃO AMBIENTAL	51
46206	3101.000.498-9	EDUCAÇÃO, DIREITOS HUMANOS E DIVERSIDADE	51
46195	3101.000.487-1	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR I	102
46209	3101.000.501-9	MICROBIOLOGIA DE ALIMENTOS	51
46213	3101.000.505-5	PESQUISA EDUCACIONAL: MÉTODOS E TÉCNICAS	51
46221	3101.000.513-5	SOCIEDADE, CULTURA E EDUCAÇÃO DE CRIANÇAS, JOVENS E ADULTOS	51
46216	3101.000.508-2	ALIMENTAÇÃO ESCOLAR: GESTÃO, PLANEJAMENTO, LICITAÇÃO E ORGANIZAÇÃO	68
46212	3101.000.504-6	AVALIAÇÃO EDUCACIONAL DA EDUCAÇÃO BÁSICA	51
46214	3101.000.506-4	CURRÍCULOS E PROGRAMAS PARA A EDUCAÇÃO BÁSICA	68
46196	3101.000.488-0	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR II	102
46205	3101.000.497-0	LEGISLAÇÃO E HIGIENE NA MANIPULAÇÃO DE ALIMENTOS	51
46199	3101.000.491-5	PESQUISA E PRÁTICA PEDAGÓGICA EM ALIMENTAÇÃO ESCOLAR I	51
46192	3101.000.484-4	PRÁTICA CIENTÍFICA	51
46218	3101.000.510-8	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR III	102
46200	3101.000.492-4	PESQUISA E PRÁTICA PEDAGÓGICA EM ALIMENTAÇÃO ESCOLAR II	51
41735	3101.000.075-5	EDUCAÇÃO INDÍGENA	51
41739	3101.000.079-8	EDUCAÇÃO, SAÚDE E NUTRIÇÃO PARA A INFÂNCIA	51
41667	3101.000.008-9	LEITURA E PRODUÇÃO DE TEXTO	68
41748	3101.000.088-7	POLÍTICAS PÚBLICAS SOCIAIS	51
47596	3201.000.040-8	EDUCAÇÃO, CULTURA DIGITAL E SOCIEDADE	68
47597	3201.000.041-7	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
47579	3201.000.023-9	FUNDAMENTOS DA EDUCAÇÃO	68
47587	3201.000.031-9	POLÍTICAS EDUCACIONAIS	68
47578	3201.000.022-0	PROJETO DE VIDA	68
47595	3201.000.039-1	DIDÁTICA E MATÉTICA	68
47599	3201.000.043-5	FORMAÇÃO, INOVAÇÃO E PESQUISA NA EDUCAÇÃO BÁSICA	68
47609	3201.000.053-3	GESTÃO ESCOLAR	34
47580	3201.000.024-8	METODOLOGIAS ATIVAS E TECNOLOGIAS DIGITAIS	68
47601	3201.000.045-3	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO DOCENTE I	102
47607	3201.000.051-5	TEORIAS DO DESENVOLVIMENTO E DA APRENDIZAGEM	34
47614	3201.000.058-9	ALFABETIZAÇÃO, LETRAMENTO LINGUAGENS E CÓDIGOS	85
47617	3201.000.061-3	CULTURA, ESCOLA E CURRÍCULO	68
47582	3201.000.026-6	EDUCAÇÃO ESPECIAL, DIVERSIDADE E INCLUSÃO	68
47588	3201.000.032-8	EDUCAÇÃO, NEUROCIÊNCIAS E APRENDIZAGEM	68
47581	3201.000.025-7	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO DOCENTE II	102
47640	3201.000.084-7	PSICOLOGIA E EDUCAÇÃO	68
47605	3201.000.049-0	EDUCAÇÃO MIDIÁTICA E EDUCOMUNICAÇÃO	68
47608	3201.000.052-4	EMPREENDEDORISMO, EDUCAÇÃO E INOVAÇÃO	68
47618	3201.000.062-2	HISTÓRIA DA EDUCAÇÃO E DO PENSAMENTO PEDAGÓGICO	68
47619	3201.000.063-1	LÍNGUA PORTUGUESA: CONTEXTOS E ESTRATÉGIAS DE ENSINO E APRENDIZAGEM	85
47643	3201.000.087-4	LITERATURA E EDUCAÇÃO LITERÁRIA	68
47628	3201.000.072-0	PRÁTICA PEDAGÓGICA PARA FORMAÇÃO ESPECÍFICA I	102
47630	3201.000.074-9	CIÊNCIAS NATURAIS: CONTEXTOS E ESTRATÉGIAS DE ENSINO E APRENDIZAGEM	85
47616	3201.000.060-4	EDUCAÇÃO INFANTIL E TEORIAS PEDAGÓGICAS	68
47583	3201.000.027-5	ESTÁGIO OBRIGATÓRIO EM GESTÃO ESCOLAR	100
47615	3201.000.059-8	MATEMÁTICA: CONTEXTOS E ESTRATÉGIAS DE ENSINO E APRENDIZAGEM	85
47623	3201.000.067-8	PRÁTICA PEDAGÓGICA PARA FORMAÇÃO ESPECÍFICA II	102
47606	3201.000.050-6	PROCESSOS DE LEITURA, PRODUÇÃO E ANÁLISE DE TEXTOS MULTIMODAIS	34
47626	3201.000.070-2	CULTURAS, SABERES E FAZERES NA EDUCAÇÃO INFANTIL	68
47629	3201.000.073-0	EDUCAÇÃO, LUDICIDADE E BRINCADEIRAS	68
47642	3201.000.086-5	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA I	100
47627	3201.000.071-1	GEOGRAFIA: CONTEXTOS E ESTRATÉGIAS DE ENSINO E APRENDIZAGEM	68
47634	3201.000.078-5	HISTÓRIA: CONTEXTOS E ESTRATÉGIAS DE ENSINO E APRENDIZAGEM	68
47586	3201.000.030-0	LIBRAS E LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	68
47635	3201.000.079-4	APRENDIZAGENS SOCIOEMOCIONAIS	68
47621	3201.000.065-0	AVALIAÇÃO EDUCACIONAL	68
47638	3201.000.082-9	EDUCAÇÃO, MULTICULTURALIDADE E INTERCULTURALIDADE	68
47625	3201.000.069-6	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA II	100
47584	3201.000.028-4	LABORATÓRIO DE INOVAÇÃO PEDAGÓGICA I	34
47610	3201.000.054-2	LETRAMENTO MATEMÁTICO	34
47641	3201.000.085-6	SAÚDE, CORPO E MOVIMENTO	68
47620	3201.000.064-0	ANDRAGOGIA E EDUCAÇÃO DE JOVENS E ADULTOS	68
47631	3201.000.075-8	EDUCAÇÃO INTEGRAL E EM TEMPO INTEGRAL	68
47624	3201.000.068-7	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA III	100
47585	3201.000.029-3	LABORATÓRIO DE INOVAÇÃO PEDAGÓGICA II	34
47637	3201.000.081-0	PEDAGOGIA DO AFETO	68
47622	3201.000.066-9	PEDAGOGIA EMPRESARIAL, ORGANIZACIONAL E SOCIAL	68
47565	3201.000.009-7	CORPO HUMANO E SAÚDE	51
47639	3201.000.083-8	LABORATÓRIO DE MATEMÁTICA E CULTURA MAKER	68
47632	3201.000.076-7	TÓPICOS ESPECIFICOS EM EDUCAÇÃO I	68
47633	3201.000.077-6	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO II	68
47636	3201.000.080-0	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO III	68
52075	3201.000.397-4	TÓPICOS INTERDISCIPLINARES I	34
52076	3201.000.398-3	TÓPICOS INTERDISCIPLINARES II	51
52074	3201.000.396-5	TÓPICOS INTERDISCIPLINARES III	68
47568	3201.000.012-1	BIOLOGIA GERAL	68
47590	3201.000.034-6	MOVIMENTOS: VARIAÇÕES E CONSERVAÇÕES	68
47561	3201.000.005-0	QUÍMICA GERAL	68
47559	3201.000.003-2	QUÍMICA INORGÂNICA	68
47594	3201.000.038-2	CALOR, AMBIENTE E USOS DE ENERGIA	68
47571	3201.000.015-9	GENÉTICA	68
47592	3201.000.036-4	LABORATÓRIO DE CIÊNCIAS	34
47569	3201.000.013-0	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO ESPECÍFICA I	102
47558	3201.000.002-3	QUÍMICA ORGÂNICA	68
47593	3201.000.037-3	EVOLUÇÃO	68
47602	3201.000.046-2	FENÔMENOS ELÉTRICOS E MAGNÉTICOS	68
47563	3201.000.007-9	FUNDAMENTOS DE BIOQUÍMICA	68
47560	3201.000.004-1	MORFOLOGIA E SISTEMÁTICA VEGETAL	68
47591	3201.000.035-5	OSCILAÇÕES , ONDAS E ÓPTICA	68
47576	3201.000.020-1	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO ESPECÍFICA II	102
47612	3201.000.056-0	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA I	100
47564	3201.000.008-8	FÍSICA MODERNA	34
47567	3201.000.011-2	LABORATÓRIO DE FÍSICA	51
47566	3201.000.010-3	MICROBIOLOGIA	68
47562	3201.000.006-0	QUÍMICA ANALÍTICA	68
47600	3201.000.044-4	ZOOLOGIA GERAL	68
47598	3201.000.042-6	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA II	100
47572	3201.000.016-8	FUNDAMENTOS DE ECOLOGIA E ECOSSISTEMAS	68
47573	3201.000.017-7	LABORATÓRIO DE BIOLOGIA	51
47589	3201.000.033-7	TERMOQUÍMICA E ELETROQUÍMICA	68
47575	3201.000.019-5	CIÊNCIA, TECNOLOGIA, SOCIEDADE E AMBIENTE	68
51241	3201.000.219-0	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA III	100
47570	3201.000.014-0	ETNOBOTÂNICA	68
47574	3201.000.018-6	INTRODUÇÃO À ASTRONOMIA	34
47577	3201.000.021-0	LABORATÓRIO DE QUÍMICA	51
47557	3201.000.001-4	QUÍMICA CONTEMPORÂNEA	34
47611	3201.000.055-1	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO I	68
47604	3201.000.048-0	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO II	68
47613	3201.000.057-0	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO III	68
47660	3201.000.104-9	HISTÓRIA DA MATEMÁTICA E DA EDUCAÇÃO MATEMÁTICA	68
47665	3201.000.109-4	TÓPICOS DE MATEMÁTICA I	68
47648	3201.000.092-7	TÓPICOS DE MATEMÁTICA II	68
47669	3201.000.113-8	CÁLCULO I	68
47644	3201.000.088-3	CURRÍCULO, POLÍTICAS EDUCACIONAIS, AVALIAÇÃO E PLANEJAMENTO EM EDUCAÇÃO MATEMÁTICA	68
47659	3201.000.103-0	GEOMETRIAS I	68
47650	3201.000.094-5	INTRODUÇÃO À ÁLGEBRA	68
47647	3201.000.091-8	MATEMÁTICA FINANCEIRA: FUNDAMENTOS, CONTEXTOS E ESTRATÉGIAS DE ENSINO E DE APRENDIZAGEM	68
47652	3201.000.096-3	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO ESPECÍFICA I	102
47668	3201.000.112-9	CÁLCULO II	68
47645	3201.000.089-2	NÚMEROS E OPERAÇÕES: FUNDAMENTOS, CONTEXTOS E ESTRATÉGIAS DE ENSINO E DE APRENDIZAGEM	68
47653	3201.000.097-2	PRÁTICA PEDAGÓGICA PARA A FORMAÇÃO ESPECÍFICA II	102
47667	3201.000.111-0	PROJETOS E APRENDIZAGEM MATEMÁTICA	68
47666	3201.000.110-0	VETORES E GEOMETRIA ANALÍTICA	68
47646	3201.000.090-9	ÁLGEBRA: FUNDAMENTOS, CONTEXTOS E ESTRATÉGIAS DE ENSINO E DE APRENDIZAGEM	68
47670	3201.000.114-7	CÁLCULO III	68
47654	3201.000.098-1	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA I	100
47649	3201.000.093-6	GEOMETRIAS II	68
51371	3201.000.221-5	LABORATÓRIO DE MATEMÁTICA E CULTURA MAKER	68
47662	3201.000.106-7	METODOLOGIAS DE APRENDIZAGEM MATEMÁTICA	68
47671	3201.000.115-6	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA II	100
47657	3201.000.101-1	GEOMETRIA, GRANDEZAS E MEDIDAS: FUNDAMENTOS, CONTEXTOS E ESTRATÉGIAS DE ENSINO E DE APRENDIZAGEM	68
47661	3201.000.105-8	INTRODUÇÃO À ÁLGEBRA LINEAR	68
47664	3201.000.108-5	TECNOLOGIAS DIGITAIS E EDUCAÇÃO MATEMÁTICA	68
47656	3201.000.100-2	EPISTEMOLOGIA E TENDÊNCIAS EM EDUCAÇÃO MATEMÁTICA	68
47655	3201.000.099-0	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA III	100
51370	3201.000.220-6	INTRODUÇÃO À ANÁLISE REAL	68
47663	3201.000.107-6	MÉTODOS NUMÉRICOS APLICADOS	68
47658	3201.000.102-0	PROBABILIDADE E ESTATÍSTICA: FUNDAMENTOS, CONTEXTOS E ESTRATÉGIAS DE ENSINO E DE APRENDIZAGEM	68
47673	3201.000.117-4	TÓPICOS ESPECÍFICOS EM EDUCAÇÃO MATEMÁTICA	68
47672	3201.000.116-5	TÓPICOS ESPECÍFICOS EM MATEMÁTICA	68
47687	3201.000.131-6	EDUCAÇÃO LINGUÍSTICA	68
47679	3201.000.123-6	FONÉTICA E FONOLOGIA DO PORTUGUÊS	68
47675	3201.000.119-2	LITERATURA E SOCIEDADE	68
47694	3201.000.138-0	LITERATURA INFANTIL E JUVENIL	68
47676	3201.000.120-9	LITERATURA PORTUGUESA	68
47690	3201.000.134-3	MORFOLOGIA DO PORTUGUÊS	68
47695	3201.000.139-9	PRÁTICA PEDAGÓGICA PARA FORMAÇÃO ESPECÍFICA I	102
47678	3201.000.122-7	TEORIAS DA LITERATURA	68
47693	3201.000.137-0	TEORIAS LINGUÍSTICAS	68
47681	3201.000.125-4	LITERATURA BRASILEIRA I	68
47688	3201.000.132-5	LITERATURA E ENSINO	68
47699	3201.000.143-2	POLÍTICAS LINGUÍSTICAS	68
47701	3201.000.145-0	PRÁTICA PEDAGÓGICA PARA FORMAÇÃO ESPECÍFICA II	102
47700	3201.000.144-1	SINTAXE DO PORTUGUÊS	68
47684	3201.000.128-1	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA I	100
47674	3201.000.118-3	ESTUDOS SEMÂNTICOS E PRAGMÁTICOS	68
47682	3201.000.126-3	FORMAÇÃO HISTÓRICA DA LÍNGUA PORTUGUESA	68
47683	3201.000.127-2	LITERATURA BRASILEIRA II	68
47692	3201.000.136-1	TECNOLOGIA ASSISTIVA PARA O ENSINO DE LÍNGUA PORTUGUESA	68
47686	3201.000.130-7	DIDÁTICA APLICADA AO ENSINO DE LÍNGUA PORTUGUESA	68
47696	3201.000.140-5	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA II	100
47680	3201.000.124-5	HISTORIOGRAFIA LITERÁRIA	68
47685	3201.000.129-0	LITERATURA BRASILEIRA III	68
47677	3201.000.121-8	SOCIOLINGUÍSTICA	68
47603	3201.000.047-1	ESTÁGIO OBRIGATÓRIO NA EDUCAÇÃO BÁSICA III	100
47698	3201.000.142-3	ESTUDOS DO TEXTO E DO DISCURSO	68
47697	3201.000.141-4	LÍNGUAS BRASILEIRAS	68
47689	3201.000.133-4	LITERATURAS AFRICANAS DE LÍNGUA PORTUGUESA	68
47691	3201.000.135-2	(MULTI)LETRAMENTOS E ENSINO DE LÍNGUAS	68
47702	3201.000.146-0	TÓPICOS ESPECÍFICOS EM LÍNGUA PORTUGUESA	68
47703	3201.000.147-9	TÓPICOS ESPECÍFICOS EM LITERATURA	68
51619	3201.000.262-7	CURRÍCULO E EDUCAÇÃO	68
51616	3201.000.259-2	EAD E SISTEMAS DE INFORMAÇÃO DA UFMS	34
51638	3201.000.281-4	GESTÃO ESCOLAR	68
52132	3201.000.411-1	LEITURA E PRODUÇÃO DE TEXTOS	85
51641	3201.000.284-1	POLÍTICAS EDUCACIONAIS	68
51640	3201.000.283-2	TRABALHO ACADÊMICO	68
51636	3201.000.279-9	EDUCAÇÃO, MÍDIAS E TECNOLOGIAS	68
52136	3201.000.415-8	ÉTICA, CIDADANIA E SOCIEDADE	34
52181	3201.000.438-1	PLANEJAMENTO EDUCACIONAL E PROCESSOS DE TRABALHO NA SECRETARIA ESCOLAR	68
52180	3201.000.437-2	PRÁTICAS DE GESTÃO NA SECRETARIA ESCOLAR I	102
51642	3201.000.285-0	PSICOLOGIA DA EDUCAÇÃO	68
51626	3201.000.269-0	EDUCAÇÃO E RELAÇÕES ÉTNICO-RACIAIS	68
52183	3201.000.440-7	LEGISLAÇÃO E PROCESSOS DE DOCUMENTAÇÃO ESCOLAR	68
47724	3201.000.168-4	MATEMÁTICA BÁSICA	68
52179	3201.000.436-3	PRÁTICAS DE GESTÃO NA SECRETARIA ESCOLAR II	102
52182	3201.000.439-0	SECRETARIA ESCOLAR: GESTÃO, PLANEJAMENTO E ORGANIZAÇÃO	68
52185	3201.000.442-5	ESTÁGIO OBRIGATÓRIO EM SECRETARIA ESCOLAR I	102
52187	3201.000.444-3	GESTÃO DE SISTEMAS E TECNOLOGIAS DIGITAIS	68
52186	3201.000.443-4	RELAÇÕES INTERPESSOAIS NAS INSTITUIÇÕES EDUCATIVAS	68
52178	3201.000.435-4	ESTÁGIO OBRIGATÓRIO EM SECRETARIA ESCOLAR II	102
51628	3201.000.271-6	INFÂNCIA E SOCIEDADE	68
52188	3201.000.445-2	SECRETARIA ESCOLAR: ESPAÇO DE GESTÃO E APOIO EDUCACIONAL	68
51631	3201.000.274-3	EDUCAÇÃO ESPECIAL	68
52177	3201.000.434-5	ESTÁGIO OBRIGATÓRIO EM SECRETARIA ESCOLAR III	102
51637	3201.000.280-5	ESTUDO DE LIBRAS	68
52184	3201.000.441-6	GESTÃO FINANCEIRA DAS INSTITUIÇÕES EDUCATIVAS	68
51625	3201.000.268-1	ARTE E EDUCAÇÃO	68
51594	3201.000.237-8	DESIGN THINKING	68
51583	3201.000.226-0	EMPREENDEDORISMO E INOVAÇÃO	68
52166	3201.000.423-8	GESTÃO E PROCESSOS DE TRABALHO	102
52169	3201.000.426-5	ALIMENTAÇÃO ESCOLAR, NUTRIÇÃO, CULTURA NO ESPAÇO EDUCATIVO	68
52167	3201.000.424-7	PRÁTICAS EM ALIMENTAÇÃO ESCOLAR I	102
52172	3201.000.429-2	EDUCAÇÃO, CIÊNCIAS DOS ALIMENTOS E CONTROLE DE QUALIDADE	68
52174	3201.000.431-8	MICROBIOLOGIA DE ALIMENTOS	68
52171	3201.000.428-3	NUTRIÇÃO E EDUCAÇÃO: POLÍTICAS, SEGURANÇA E SUSTENTABILIDADE ALIMENTAR	68
52170	3201.000.427-4	PRÁTICAS EM ALIMENTAÇÃO ESCOLAR II	102
52164	3201.000.421-0	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR I	102
52175	3201.000.432-7	LEGISLAÇÃO E HIGIENE NA MANIPULAÇÃO DE ALIMENTOS	68
52168	3201.000.425-6	POLÍTICAS PÚBLICAS DE ALIMENTAÇÃO ESCOLAR	68
52176	3201.000.433-6	ALIMENTAÇÃO ESCOLAR: GESTÃO, PLANEJAMENTO, LICITAÇÃO E ORGANIZAÇÃO	68
52173	3201.000.430-9	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR II	102
52163	3201.000.420-0	RELAÇÕES INTERPESSOAIS NAS INSTITUIÇÕES EDUCATIVAS	68
52165	3201.000.422-9	ESTÁGIO OBRIGATÓRIO EM ALIMENTAÇÃO ESCOLAR III	102
52135	3201.000.414-9	EAD, MÍDIAS E TECNOLOGIAS DIGITAIS	51
47710	3201.000.154-0	INGLÊS	68
47741	3201.000.185-3	PENSAMENTO COMPUTACIONAL	68
47736	3201.000.180-8	ALGORITMOS E PROGRAMAÇÃO I	85
47746	3201.000.190-6	ALGORITMOS E PROGRAMAÇÃO II	85
47731	3201.000.175-5	CÁLCULO I	68
47745	3201.000.189-0	ESTATÍSTICA E PROBABILIDADE	68
47755	3201.000.199-8	FUNDAMENTOS DE WEB	68
47737	3201.000.181-7	INTRODUÇÃO A CONCEITOS DE COMPUTAÇÃO	51
52134	3201.000.413-0	BANCO DE DADOS	68
52133	3201.000.412-0	ESTRUTURA DE DADOS	68
52130	3201.000.409-6	FORMAÇÃO PROFISSIONAL EM COMPUTAÇÃO	34
47738	3201.000.182-6	GEOMETRIA ANALÍTICA E ÁLGEBRA LINEAR	68
52131	3201.000.410-2	GESTÃO DE INOVAÇÃO E DESENVOLVIMENTO DE PRODUTOS	34
47740	3201.000.184-4	PROGRAMAÇÃO ORIENTADA A OBJETOS	68
47739	3201.000.183-5	INTRODUÇÃO A CIÊNCIA DE DADOS	68
52189	3201.000.446-1	MINERAÇÃO DE DADOS	85
47744	3201.000.188-0	MODELAGEM E INFERÊNCIA ESTATÍSTICA	85
52190	3201.000.447-0	PROJETO INTEGRADOR DE CIÊNCIA DOS DADOS I	51
47733	3201.000.177-3	SISTEMAS COMPUTACIONAIS	68
47734	3201.000.178-2	APLICAÇÕES EM APRENDIZADO DE MÁQUINA	85
52191	3201.000.448-0	PROJETO INTEGRADOR DE CIÊNCIA DOS DADOS II	51
47752	3201.000.196-0	REDES NEURAIS	85
47730	3201.000.174-6	VISUALIZAÇÃO COMPUTACIONAL	85
47749	3201.000.193-3	APRENDIZADO PROFUNDO	85
47753	3201.000.197-0	COMPUTAÇÃO ESCALÁVEL	68
52192	3201.000.449-9	PROJETO INTEGRADOR DE CIÊNCIA DOS DADOS III	51
47748	3201.000.192-4	SEGURANÇA DA INFORMAÇÃO	68
47754	3201.000.198-9	ANÁLISE MULTIVARIADA DE DADOS	68
52139	3201.000.418-5	ANÁLISE ORGANIZACIONAL E SOLUÇÕES TECNOLÓGICAS	102
47750	3201.000.194-2	BLOCKCHAIN E SUAS APLICAÇÕES	68
47706	3201.000.150-3	PLANEJAMENTO ESTRATÉGICO DE NEGÓCIOS	68
47751	3201.000.195-1	PROCESSAMENTO DE LINGUAGEM NATURAL	68
47758	3201.000.202-8	VISÃO COMPUTACIONAL	68
47726	3201.000.170-0	ADMINISTRAÇÃO DE MATERIAIS E LOGÍSTICA	68
47707	3201.000.151-2	GESTÃO ESTRATÉGICA DE PESSOAS	68
47708	3201.000.152-1	MATEMÁTICA FINANCEIRA	68
47723	3201.000.167-5	PLANEJAMENTO ESTRATÉGICO	68
52205	3201.000.462-1	PROJETO INTEGRADOR DE GESTÃO I	68
47711	3201.000.155-9	ADMINISTRAÇÃO DE PRODUÇÃO E OPERAÇÕES	68
47709	3201.000.153-0	GESTÃO CONTÁBIL, DE CUSTOS E DE PREÇOS	68
47713	3201.000.157-7	GESTÃO FINANCEIRA	68
47721	3201.000.165-7	PRÁTICAS DE PROCESSOS ORGANIZACIONAIS I	68
52206	3201.000.463-0	PROJETO INTEGRADOR DE GESTÃO II	68
47720	3201.000.164-8	ADMINISTRAÇÃO DE SISTEMAS DE INFORMAÇÃO	68
47718	3201.000.162-0	COMPORTAMENTO ORGANIZACIONAL	68
47719	3201.000.163-9	GESTÃO MERCADOLÓGICA	68
47717	3201.000.161-0	PRÁTICAS DE PROCESSOS ORGANIZACIONAIS II	68
52204	3201.000.461-2	PROJETO INTEGRADOR DE GESTÃO III	34
52200	3201.000.457-9	EMPREENDEDORISMO E INOVAÇÃO	68
47716	3201.000.160-1	GESTÃO CONTEMPORÂNEA DE PROCESSOS GERENCIAIS	34
51597	3201.000.240-2	GESTÃO DE MARCAS	51
51596	3201.000.239-6	INTRODUÇÃO AO METAVERSO	34
51726	3201.000.369-8	LEGISLAÇÃO TRABALHISTA E PREVIDENCIÁRIA	68
52194	3201.000.451-4	PENSAMENTO CRIATIVO	51
47725	3201.000.169-3	RESPONSABILIDADE SOCIAL NAS ORGANIZAÇÕES	34
51732	3201.000.375-0	ROTINAS TRABALHISTAS E DEPARTAMENTO PESSOAL	68
51733	3201.000.376-9	SAÚDE, SEGURANÇA E QUALIDADE DE VIDA NO TRABALHO	68
51590	3201.000.233-1	TRANSFORMAÇÃO DIGITAL E SOCIEDADE	51
47767	3201.000.211-7	ENGENHARIA DE SOFTWARE	68
47773	3201.000.217-1	INFRAESTRUTURA PARA SISTEMAS DE SOFTWARE	85
47765	3201.000.209-1	INTERFACE HUMANO-COMPUTADOR	68
47772	3201.000.216-2	PLANEJAMENTO ESTRATÉGICO DE NEGÓCIOS	68
47762	3201.000.206-4	SISTEMAS DE INFORMAÇÃO	68
47759	3201.000.203-7	TÉCNICAS AVANÇADAS DE DESENVOLVIMENTO DE SOFTWARE	68
47774	3201.000.218-0	ANÁLISE E PROJETO DE SOFTWARE ORIENTADO A OBJETOS	68
47760	3201.000.204-6	DESENVOLVIMENTO PARA DISPOSITIVOS MÓVEIS	68
47770	3201.000.214-4	GERÊNCIA DE PROJETOS	68
47771	3201.000.215-3	LABORATÓRIO DE BANCO DE DADOS	68
52137	3201.000.416-7	PROJETO INTEGRADOR DE TECNOLOGIA DA INFORMAÇÃO I	68
52138	3201.000.417-6	PROJETO INTEGRADOR DE TECNOLOGIA DA INFORMAÇÃO II	68
52140	3201.000.419-4	PROJETO INTEGRADOR DE TECNOLOGIA DA INFORMAÇÃO III	68
47761	3201.000.205-5	VERIFICAÇÃO, VALIDAÇÃO E TESTE DE SOFTWARE	68
47769	3201.000.213-5	GERENCIAMENTO DE SERVIÇOS DE TECNOLOGIA DA INFORMAÇÃO	68
47768	3201.000.212-6	GOVERNANÇA DE TECNOLOGIA DA INFORMAÇÃO	68
51581	3201.000.224-2	COMPORTAMENTO DO CONSUMIDOR NA ERA DIGITAL	68
52198	3201.000.455-0	FERRAMENTAS DE MODELAGEM DE NEGÓCIOS	68
52199	3201.000.456-0	GESTÃO CONTÁBIL, DE CUSTOS E DE PREÇOS	68
51579	3201.000.222-4	MARKETING DIGITAL E MÍDIAS SOCIAIS	68
52195	3201.000.452-3	CANAIS ESTRATÉGICOS	68
51585	3201.000.228-9	RELACIONAMENTO COM CLIENTES	68
51589	3201.000.232-2	CAMPANHA DE VENDAS	51
52196	3201.000.453-2	DIREITO EMPRESARIAL	68
51588	3201.000.231-3	GESTÃO DE POLÍTICAS COMERCIAIS E PRÁTICAS DE NEGOCIAÇÃO	68
52197	3201.000.454-1	SISTEMAS DE INFORMAÇÕES MERCADOLÓGICAS	51
51600	3201.000.243-0	AVALIAÇÃO DE DESEMPENHO	68
51599	3201.000.242-0	E-COMMERCE	68
51592	3201.000.235-0	ESPANHOL	51
51593	3201.000.236-9	ESTUDO DE LIBRAS	51
47727	3201.000.171-9	GESTÃO DE INOVAÇÃO E DESENVOLVIMENTO DE PRODUTOS	34
47712	3201.000.156-8	LEITURA E PRODUÇÃO DE TEXTOS	85
52193	3201.000.450-5	MARKETING SOCIOAMBIENTAL	68
51598	3201.000.241-1	PLANEJAMENTO DAS MÍDIAS SOCIAIS DIGITAIS	51
51595	3201.000.238-7	RESPONSABILIDADE CIVIL	68
51734	3201.000.377-8	PSICOLOGIA ORGANIZACIONAL	68
51727	3201.000.370-4	FUNDAMENTOS DE CONTABILIDADE	51
51606	3201.000.249-4	GESTÃO DE PROJETOS E SISTEMAS DE INFORMAÇÃO	68
52207	3201.000.464-0	GESTÃO SOCIOAMBIENTAL	51
51731	3201.000.374-0	RECRUTAMENTO E SELEÇÃO	68
51725	3201.000.368-9	REMUNERAÇÃO, CARGOS E SALÁRIOS	68
51728	3201.000.371-3	TREINAMENTO E DESENVOLVIMENTO DE PESSOAS	68
52203	3201.000.460-3	ENDOMARKETING	68
51729	3201.000.372-2	GESTÃO DE PROCESSOS	68
51604	3201.000.247-6	GESTÃO DE CONTEÚDOS DIGITAIS	51
52201	3201.000.458-8	GESTÃO DE PROJETOS DIGITAIS	51
51601	3201.000.244-9	FUNDAMENTOS DAS MÍDIAS SOCIAIS DIGITAIS	51
51607	3201.000.250-0	COMUNICAÇÃO BASEADA EM ALGORITMOS	34
51602	3201.000.245-8	COMUNICAÇÃO, LINGUAGEM E SEMIÓTICA	51
51605	3201.000.248-5	GESTÃO DE RELACIONAMENTO	51
52202	3201.000.459-7	CAMPANHA DE VENDAS	51
51586	3201.000.229-8	DIREITO EMPRESARIAL	68
52213	3201.000.470-1	DIREITO, PODER JUDICIÁRIO E FUNÇÕES ESSENCIAIS À JUSTIÇA	68
52215	3201.000.472-0	DIREITO CONSTITUCIONAL: ESTADO E PROCESSO LEGISLATIVO	68
52219	3201.000.476-6	DIREITO DO TRABALHO	51
51742	3201.000.385-8	TEORIA GERAL DOS ATOS NOTARIAIS	51
52214	3201.000.471-0	TUTELA JURÍDICA DAS PESSOAS E BENS	68
52210	3201.000.467-7	DIREITO PENAL GERAL	68
51746	3201.000.389-4	DIREITOS REAIS	68
51748	3201.000.391-0	NEGÓCIO JURÍDICO E CONTRATOS	68
51747	3201.000.390-0	SISTEMAS ELETRÔNICOS JUDICIAIS	34
52217	3201.000.474-8	DIREITO DE FAMÍLIA E SUCESSÃO	68
52211	3201.000.468-6	MEDIAÇÃO E CONCILIAÇÃO DE CONFLITOS	51
52208	3201.000.465-9	REGISTRO CIVIL DAS PESSOAS NATURAIS, TÍTULOS E DOCUMENTOS	68
51741	3201.000.384-9	REGISTRO DE IMÓVEIS	68
51745	3201.000.388-5	SISTEMA JURÍDICO DA PRIVACIDADE E INFORMAÇÃO	68
52216	3201.000.473-9	ATIVIDADE EXTRAJUDICIAL EMPRESARIAL	34
52212	3201.000.469-5	DIREITO ADMINISTRATIVO	51
52209	3201.000.466-8	DIREITO DO CONSUMIDOR	68
51749	3201.000.392-9	LÍNGUA PORTUGUESA APLICADA AO DIREITO	68
52218	3201.000.475-7	RESPONSABILIDADE CIVIL	68
51682	3201.000.325-9	FUNDAMENTOS DE DIDÁTICA	51
51689	3201.000.332-0	PRÁTICAS PEDAGÓGICAS EM HISTÓRIA I	102
51690	3201.000.333-9	ENSINO DE HISTÓRIA E CULTURA AFRICANA E AFRO-BRASILEIRA	68
51691	3201.000.334-8	HISTÓRIA ANTIGA	68
51721	3201.000.364-2	PRÁTICAS PEDAGÓGICAS EM HISTÓRIA II	102
51703	3201.000.346-4	TEORIAS E METODOLOGIAS DA HISTÓRIA I	68
51716	3201.000.359-0	HISTÓRIA DA AMÉRICA I	68
51709	3201.000.352-6	HISTÓRIA DO BRASIL I	68
51693	3201.000.336-6	HISTÓRIA MEDIEVAL	68
51712	3201.000.355-3	PRÁTICAS PEDAGÓGICAS EM HISTÓRIA III	102
51704	3201.000.347-3	TEORIAS E METODOLOGIAS DA HISTÓRIA II	68
51694	3201.000.337-5	EDUCAÇÃO PATRIMONIAL	68
52129	3201.000.408-7	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA I	102
51695	3201.000.338-4	HISTÓRIA DA AMÉRICA II	68
51696	3201.000.339-3	HISTÓRIA DO BRASIL II	68
51697	3201.000.340-0	TEORIAS E METODOLOGIAS DA HISTÓRIA III	68
52127	3201.000.406-9	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA II	102
51714	3201.000.357-1	HISTÓRIA DO BRASIL III	68
51710	3201.000.353-5	HISTÓRIA MODERNA I	68
51698	3201.000.341-9	HISTORIOGRAFIA BRASILEIRA	68
51692	3201.000.335-7	PRÁTICAS PEDAGÓGICAS EM HISTÓRIA IV	102
52128	3201.000.407-8	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA III	102
51699	3201.000.342-8	HISTÓRIA CONTEMPORÂNEA I	68
51707	3201.000.350-8	HISTÓRIA DE MATO GROSSO DO SUL I	68
51700	3201.000.343-7	HISTÓRIA INDÍGENA	68
51702	3201.000.345-5	HISTÓRIA MODERNA II	68
51718	3201.000.361-5	ENSINO DE HISTÓRIA, JUVENTUDE E CULTURA	51
52126	3201.000.405-0	ESTÁGIO OBRIGATÓRIO EM HISTÓRIA IV	102
51717	3201.000.360-6	HISTÓRIA CONTEMPORÂNEA II	68
51724	3201.000.367-0	HISTÓRIA DA ÁFRICA	68
51705	3201.000.348-2	HISTÓRIA DE MATO GROSSO DO SUL II	68
51713	3201.000.356-2	PESQUISA HISTÓRICA	68
51719	3201.000.362-4	HISTÓRIA DA EDUCAÇÃO BRASILEIRA	68
51708	3201.000.351-7	HISTÓRIA E EDUCAÇÃO AMBIENTAL	68
51715	3201.000.358-0	HISTÓRIA E ESTUDOS DE GÊNERO	68
51723	3201.000.366-0	HISTÓRIA, MULHERES E INFÂNCIAS	68
51711	3201.000.354-4	HISTÓRIA ORAL E MEMÓRIA	68
52124	3201.000.403-1	PRODUÇÃO DE MATERIAL DIDÁTICO PARA EDUCAÇÃO BÁSICA I	34
52125	3201.000.404-0	PRODUÇÃO DE MATERIAL DIDÁTICO PARA EDUCAÇÃO BÁSICA II	85
51629	3201.000.272-5	FILOSOFIA DA EDUCAÇÃO	68
51618	3201.000.261-8	SOCIOLOGIA DA EDUCAÇÃO	68
51620	3201.000.263-6	DIDÁTICA I	68
51630	3201.000.273-4	HISTÓRIA DA EDUCAÇÃO I	68
51609	3201.000.252-9	PRÁTICAS PEDAGÓGICAS I	102
51622	3201.000.265-4	DIDÁTICA II	68
51633	3201.000.276-1	HISTÓRIA DA EDUCAÇÃO II	68
51632	3201.000.275-2	ESTÁGIO OBRIGATÓRIO I	102
51614	3201.000.257-4	FUNDAMENTOS E METODOLOGIAS DA EDUCAÇÃO INFANTIL I	68
51617	3201.000.260-9	FUNDAMENTOS E METODOLOGIAS DA EDUCAÇÃO INFANTIL II	68
51610	3201.000.253-8	FUNDAMENTOS E METODOLOGIAS DA ALFABETIZAÇÃO E LETRAMENTO I	68
51611	3201.000.254-7	PRÁTICAS PEDAGÓGICAS II	102
51621	3201.000.264-5	ESTÁGIO OBRIGATÓRIO II	102
51615	3201.000.258-3	FUNDAMENTOS E METODOLOGIAS DA ALFABETIZAÇÃO E LETRAMENTO II	68
51623	3201.000.266-3	ESTÁGIO OBRIGATÓRIO III	102
51612	3201.000.255-6	PRÁTICAS PEDAGÓGICAS III	102
51624	3201.000.267-2	EDUCAÇÃO DE JOVENS E ADULTOS	68
51627	3201.000.270-7	ESTÁGIO OBRIGATÓRIO IV	102
51639	3201.000.282-3	LÍNGUA PORTUGUESA COMO SEGUNDA LÍNGUA PARA SURDOS	34
51613	3201.000.256-5	PRÁTICAS PEDAGÓGICAS IV	102
51670	3201.000.313-2	LÍNGUA ESPANHOLA PARA FORMAÇÃO DE PROFESSORES I	51
51686	3201.000.329-5	LITERATURA E FORMAÇÃO DOCENTE	34
51648	3201.000.291-2	FUNDAMENTOS DE ANÁLISE LINGUÍSTICA PARA FORMAÇÃO DOCENTE	68
51678	3201.000.321-2	LEITURA DOS INSTRUMENTOS LINGUÍSTICOS E FORMAÇÃO DOCENTE	51
51683	3201.000.326-8	LÍNGUA ESPANHOLA PARA FORMAÇÃO DE PROFESSORES II	51
51654	3201.000.297-7	PRÁTICA DE ENSINO DE LÍNGUAS E LITERATURA I	102
51685	3201.000.328-6	FONÉTICA E FONOLOGIA DA LÍNGUA PORTUGUESA	68
51687	3201.000.330-1	INTRODUÇÃO AOS ESTUDOS LINGUÍSTICOS	68
51688	3201.000.331-0	LÍNGUA ESPANHOLA I	68
51649	3201.000.292-1	TEORIA DA LITERATURA I	51
51684	3201.000.327-7	TEXTO E DISCURSO NA FORMAÇÃO DOCENTE	51
51651	3201.000.294-0	INTRODUÇÃO À CULTURA HISPÂNICA	51
51656	3201.000.299-5	LÍNGUA ESPANHOLA II	68
51661	3201.000.304-3	MORFOLOGIA DA LÍNGUA PORTUGUESA	68
51645	3201.000.288-8	POLÍTICAS LINGUÍSTICAS E CULTURA ESCOLAR	34
51663	3201.000.306-1	PRÁTICA DE ENSINO DE LÍNGUAS E LITERATURA II: PRÁTICAS DE LEITURA E PRODUÇÃO DE TEXTO	102
51667	3201.000.310-5	TEORIA DA LITERATURA II	34
52121	3201.000.400-4	ESTÁGIO OBRIGATÓRIO SUPERVISIONADO DE LÍNGUA PORTUGUESA I	102
51676	3201.000.319-7	LÍNGUA ESPANHOLA III	68
51679	3201.000.322-1	LITERATURA ESPANHOLA I	51
51644	3201.000.287-9	PRÁTICA DE ENSINO DE LÍNGUAS E LITERATURA III: ENSINO DE ESPANHOL	102
51653	3201.000.296-8	SINTAXE DA LÍNGUA PORTUGUESA	68
51646	3201.000.289-7	TEORIA DA LITERATURA III	34
52122	3201.000.401-3	ESTÁGIO OBRIGATÓRIO SUPERVISIONADO DE LÍNGUA PORTUGUESA II	102
51665	3201.000.308-0	LÍNGUA ESPANHOLA IV	68
51671	3201.000.314-1	LITERATURA ESPANHOLA II	51
51672	3201.000.315-0	LITERATURA PORTUGUESA I	68
51677	3201.000.320-3	SEMÂNTICA DA LÍNGUA PORTUGUESA	51
51680	3201.000.323-0	TEORIA DA LITERATURA IV	34
52120	3201.000.399-2	ESTÁGIO OBRIGATÓRIO SUPERVISIONADO DE LÍNGUA ESPANHOLA I	102
51657	3201.000.300-7	LÍNGUA ESPANHOLA V	68
51652	3201.000.295-9	LITERATURA PORTUGUESA II	68
51655	3201.000.298-6	PRÁTICA DE ENSINO DE LÍNGUAS E LITERATURA IV: ENSINO DE LITERATURA	102
52123	3201.000.402-2	ESTÁGIO OBRIGATÓRIO SUPERVISIONADO DE LÍNGUA ESPANHOLA II	102
51669	3201.000.312-3	LÍNGUA ESPANHOLA VI	68
51674	3201.000.317-9	LITERATURA CONTEMPORÂNEA EM LÍNGUA ESPANHOLA	51
51675	3201.000.318-8	LITERATURA CONTEMPORÂNEA EM LÍNGUA PORTUGUESA	51
51664	3201.000.307-0	LITERATURA E INFÂNCIA	34
51666	3201.000.309-9	LITERATURA HISPANO-AMERICANA	68
51647	3201.000.290-3	GRAMÁTICA DE LÍNGUA ESPANHOLA	51
51681	3201.000.324-0	LINGUÍSTICA APLICADA	51
\.


--
-- Data for Name: disciplinas_prequisitos; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.disciplinas_prequisitos (disciplina_id, prequisito_id) FROM stdin;
44191	44192
48382	48362
48383	48382
50891	46561
50891	50877
50895	50877
50895	50883
50897	50877
50897	50879
50896	50878
50896	50883
50900	50887
50900	50907
50899	50887
46547	50887
46547	50889
50872	50887
50872	50888
50901	50887
50901	50907
50884	50881
50884	50892
50866	46560
50866	50890
50866	50892
37043	46560
37043	50892
37043	50898
50886	50890
50886	50892
50886	50898
50905	50874
50905	50908
50902	50893
50902	50899
50902	50906
50863	50893
50863	50906
50863	50908
47525	47533
48695	47533
48706	48695
48688	47525
48708	48688
43567	43562
43568	43565
49970	49973
36207	49970
49957	49958
36210	49970
49963	36195
49976	49957
45868	36209
49964	36195
36216	49980
49962	49973
36220	49970
49968	49970
45877	36207
49974	49955
36225	49970
36159	36158
44505	36210
38550	49970
36164	45878
36166	49970
44508	36210
36168	36159
36169	36220
44496	49973
36176	49980
44493	36207
35557	35551
36192	49970
50200	50213
50216	50214
50178	50214
50177	50214
50215	50218
50196	50197
50207	50204
50217	50216
50181	50178
50176	50177
35953	35947
50229	50217
50179	50181
50230	50176
50186	50189
50194	50229
35959	35953
50226	50227
50184	50197
50224	50183
35966	35959
50182	50184
50187	50229
50188	50230
35973	35966
50195	50220
50199	50176
50198	50187
50185	50188
50202	35973
50202	50182
50202	50185
50202	50198
50205	35972
50205	35973
50205	50180
50205	50182
50203	50202
50206	50205
49122	49093
49075	49079
49108	49087
49104	49122
49102	49108
49127	49086
49127	49098
49078	49108
49096	49088
49106	49108
49091	49108
49107	49123
49099	49108
49147	49118
49147	49119
49155	49096
51386	51385
24634	51399
51389	51401
24641	24634
34178	51400
51388	51390
51413	34187
51387	51402
51382	51413
44958	50518
50514	50614
50620	50618
47386	50606
47196	50606
38995	47141
44470	44469
39065	39058
49353	49349
49396	49348
49399	49350
49366	49378
49351	49378
49388	49351
49389	49351
49325	49351
49363	49351
49397	49367
49370	49357
49359	49388
49390	49351
47241	49397
49327	49393
47242	47241
49371	49362
49377	49355
51424	51428
34545	51427
51466	51418
47075	47051
51463	47075
52157	51466
51458	51428
51455	51463
51444	51457
47072	52157
51421	51450
51433	51450
51437	51450
52156	34545
46996	51463
51422	51421
51464	47075
46993	47051
51417	51458
51423	51437
52150	51421
46990	51421
51443	51421
51438	52155
51461	47075
34540	46993
51419	51423
52149	51421
52148	51444
51449	51421
51440	51438
51462	47075
51425	51463
34544	46993
34548	34545
51416	51438
52151	52150
51439	51438
51459	51461
51451	51452
51446	51452
51446	51458
51453	51416
52152	52149
51435	51452
47065	51452
34553	51436
47079	51417
47079	51440
34556	34545
47057	51464
51415	51427
47012	51464
34558	34545
47016	51464
47041	51427
47044	51424
47084	51427
34563	34545
47018	51440
47045	51445
47014	51419
47020	51428
47083	51426
51456	51428
47031	51421
47029	51466
46975	51440
51448	46996
34569	51417
34570	51419
34570	51421
46980	47036
47066	51438
47061	51428
46976	47075
47067	47075
46977	51461
34572	51461
47076	51463
47090	51457
34573	46993
47054	51427
46983	47075
46991	34545
46991	51428
34574	51466
47046	51421
46985	51421
46984	51433
46978	51422
46987	51437
46986	52156
34576	51464
47043	51424
47021	51438
47025	51436
46998	51429
47068	51417
47074	51445
47071	51422
47087	51421
47087	51423
46981	51454
47023	47075
47024	34491
46979	51426
47069	47078
47070	47075
37810	37831
35275	49513
35275	49517
49514	49513
49514	49517
49486	49513
49486	49517
35284	35275
35284	49514
49503	35275
49503	49514
49501	49503
35276	35273
49497	50585
49519	49486
49518	49503
49496	35275
49496	49497
49496	49514
49505	35275
49505	35276
49505	49514
49494	49518
35282	35273
35282	35275
35282	49514
49485	35282
35289	35282
49490	49496
49499	49503
49492	35278
49507	49504
49488	49492
49495	35278
35367	35284
35368	35274
35368	35284
35371	35278
35372	35276
35374	35282
35375	35284
35375	52162
35376	35375
35377	35284
35378	35284
35401	35289
35407	35289
35409	35289
35413	35274
35416	35289
35419	35418
35420	35284
43602	43649
43602	43674
43602	51562
43602	51563
43677	43625
43677	43628
43677	43675
43677	43676
43586	43582
43586	43583
43586	43584
43586	43614
43633	43584
43633	43630
43633	43631
43633	43632
43633	43636
43633	43674
43633	43676
43633	51561
43650	43649
43650	43674
43650	51562
43650	51563
43678	43625
43678	43628
43678	43675
43678	43676
51559	51567
43587	43582
43587	43583
43587	43584
43587	43614
43634	43582
43634	43583
43634	43630
43634	43631
43634	43632
43634	43636
43634	51567
51555	43582
51555	43583
51555	43584
51555	43586
51555	43587
51555	43602
51555	43614
51555	43616
51555	43621
51555	43625
51555	43628
51555	43630
51555	43631
51555	43632
51555	43633
51555	43634
51555	43636
51555	43637
51555	43646
51555	43649
51555	43650
51555	43651
51555	43661
51555	43674
51555	43675
51555	43676
51555	43677
51555	43678
51555	43679
51555	51558
51555	51559
51555	51560
51555	51561
51555	51562
51555	51563
51555	51564
51555	51566
51555	51567
51555	51570
51556	43582
51556	43583
51556	43584
51556	43586
51556	43587
51556	43602
51556	43614
51556	43616
51556	43621
51556	43625
51556	43628
51556	43630
51556	43631
51556	43632
51556	43633
51556	43634
51556	43636
51556	43637
51556	43646
51556	43649
51556	43650
51556	43651
51556	43661
51556	43674
51556	43675
51556	43676
51556	43677
51556	43678
51556	43679
51556	51558
51556	51559
51556	51560
51556	51561
51556	51562
51556	51563
51556	51564
51556	51566
51556	51567
51556	51570
51553	43582
51553	43583
51553	43584
51553	43586
51553	43587
51553	43602
51553	43614
51553	43616
51553	43621
51553	43625
51553	43628
51553	43630
51553	43631
51553	43632
51553	43633
51553	43634
51553	43636
51553	43637
51553	43646
51553	43649
51553	43650
51553	43651
51553	43661
51553	43674
51553	43675
51553	43676
51553	43677
51553	43678
51553	43679
51553	51558
51553	51559
51553	51560
51553	51561
51553	51562
51553	51563
51553	51564
51553	51566
51553	51567
51553	51570
51552	43582
51552	43583
51552	43584
51552	43586
51552	43587
51552	43602
51552	43614
51552	43616
51552	43621
51552	43625
51552	43628
51552	43630
51552	43631
51552	43632
51552	43633
51552	43634
51552	43636
51552	43637
51552	43646
51552	43649
51552	43650
51552	43651
51552	43661
51552	43674
51552	43675
51552	43676
51552	43677
51552	43678
51552	43679
51552	51558
51552	51559
51552	51560
51552	51561
51552	51562
51552	51563
51552	51564
51552	51566
51552	51567
51552	51570
51568	43582
51568	43583
51568	43584
51568	43586
51568	43587
51568	43602
51568	43614
51568	43616
51568	43621
51568	43625
51568	43628
51568	43630
51568	43631
51568	43632
51568	43633
51568	43634
51568	43636
51568	43637
51568	43646
51568	43649
51568	43650
51568	43651
51568	43661
51568	43674
51568	43675
51568	43676
51568	43677
51568	43678
51568	43679
51568	51558
51568	51559
51568	51560
51568	51561
51568	51562
51568	51563
51568	51564
51568	51566
51568	51567
51568	51570
51548	43582
51548	43583
51548	43584
51548	43586
51548	43587
51548	43602
51548	43614
51548	43616
51548	43621
51548	43625
51548	43628
51548	43630
51548	43631
51548	43632
51548	43633
51548	43634
51548	43636
51548	43637
51548	43646
51548	43649
51548	43650
51548	43651
51548	43661
51548	43674
51548	43675
51548	43676
51548	43677
51548	43678
51548	43679
51548	51558
51548	51559
51548	51560
51548	51561
51548	51562
51548	51563
51548	51564
51548	51566
51548	51567
51548	51570
51557	43582
51557	43583
51557	43584
51557	43586
51557	43587
51557	43602
51557	43614
51557	43616
51557	43621
51557	43625
51557	43628
51557	43630
51557	43631
51557	43632
51557	43633
51557	43634
51557	43636
51557	43637
51557	43646
51557	43649
51557	43650
51557	43651
51557	43661
51557	43674
51557	43675
51557	43676
51557	43677
51557	43678
51557	43679
51557	51558
51557	51559
51557	51560
51557	51561
51557	51562
51557	51563
51557	51564
51557	51566
51557	51567
51557	51570
51569	43582
51569	43583
51569	43584
51569	43586
51569	43587
51569	43602
51569	43614
51569	43616
51569	43621
51569	43625
51569	43628
51569	43630
51569	43631
51569	43632
51569	43633
51569	43634
51569	43636
51569	43637
51569	43646
51569	43649
51569	43650
51569	43651
51569	43661
51569	43674
51569	43675
51569	43676
51569	43677
51569	43678
51569	43679
51569	51558
51569	51559
51569	51560
51569	51561
51569	51562
51569	51563
51569	51564
51569	51566
51569	51567
51569	51570
51543	51568
51543	51569
51549	51548
51550	51557
51565	51556
51551	51556
51554	51553
49255	35198
49253	49255
49256	49253
49258	49256
39059	38990
47191	47160
50132	44481
39081	44481
47171	50111
50539	50551
50535	50533
35197	50539
50538	50535
35200	35195
35202	35197
35214	35197
35208	35202
35220	35214
50545	35204
35207	35201
35205	35197
35248	35111
50934	50914
50934	50924
50934	50931
50934	50932
50934	50933
49646	35129
49646	35133
49654	49646
49655	49654
50502	50501
50525	50502
50503	50525
47401	50499
50514	50499
49233	40729
49233	45531
49214	40726
49214	40729
49214	40731
45323	40726
45323	40731
45323	45531
49234	49233
49247	49214
45321	45323
49209	45321
49209	49247
49227	45321
49227	49247
52116	45321
52116	49247
34696	49246
49211	49209
49215	49242
49212	49227
52119	52116
49210	49215
40754	45321
40754	49247
45336	45321
45336	49247
49218	49211
49244	49243
49216	49213
34708	45321
34708	49234
34708	49247
34710	45321
34710	49247
34711	40754
49207	34668
49207	34696
49207	49212
49207	49218
49207	52119
49245	49244
49208	34708
49208	34710
49208	34711
51904	49212
40716	40731
45338	45321
45338	49234
45338	49247
45339	45321
45339	49234
45339	49247
40718	49234
45330	49247
40719	40729
40725	49234
50560	50557
25541	50557
50595	25536
50582	50581
50582	50585
25680	25541
50583	50581
50583	50585
50571	50559
25686	25680
50573	25535
25687	50589
25690	25536
50590	25679
25693	50557
25693	50582
25696	25690
50600	50559
25698	25693
50575	50590
50577	50576
50588	50590
50588	50596
50599	25535
50565	50569
34052	50599
25705	25687
50561	25698
50578	50599
25707	25696
43686	34047
25712	50599
50579	50578
50592	25707
26089	25698
34056	50572
34056	50599
50593	50573
50591	25705
50591	25712
50563	50579
50564	50592
34064	34054
34065	34052
34066	25541
34067	50581
34067	50582
34068	25690
34068	25696
34069	50599
34071	50596
34074	25536
34074	25698
34074	50587
34072	25686
49526	49528
49568	49526
49561	49535
49521	49523
49521	49526
47462	47414
47462	47434
47462	47470
47462	47473
47468	47462
47441	47468
47437	47468
47445	47468
47446	47468
47421	47437
47477	47468
47429	47468
47448	47446
47449	47477
47439	47448
47475	47421
47475	47463
49035	49057
49015	49032
48095	48105
48142	48113
48087	48106
48088	48107
48108	34593
48123	48142
48111	48087
48109	48088
48120	48119
48110	48112
48146	48086
48098	48095
48147	48109
48102	48098
48127	48116
48100	48125
48114	48117
48126	48124
48131	48123
48128	48102
48099	48100
48099	48108
48099	48126
48129	48108
48129	48114
48129	48127
48129	48146
48093	48128
48134	48099
48144	48129
48132	48100
48132	48108
48132	48126
48132	48131
48132	48147
48130	48108
48130	48114
48130	48127
48130	48146
48143	48132
48145	48130
49626	49593
43243	49608
49619	49626
49609	38323
49614	49619
49622	49626
51533	51527
51533	51541
51536	52284
51535	51527
51535	51541
51512	52284
51514	51527
51514	51541
51513	51527
51513	51541
51505	51529
51508	51527
51508	51541
51506	51527
51506	51541
51518	51529
51524	51527
51524	51541
51522	51527
51522	51541
51520	51527
51520	51541
51519	51527
51519	51541
51531	52284
51492	51469
51492	51470
51492	51473
51492	51479
51492	51489
51492	51490
51492	51494
51492	51495
51492	51496
51492	51497
51492	51498
51492	51499
51492	51504
51492	51505
51492	51506
51492	51508
51492	51509
51492	51510
51492	51511
51492	51512
51492	51513
51492	51514
51492	51515
51492	51516
51492	51517
51492	51518
51492	51519
51492	51520
51492	51521
51492	51522
51492	51524
51492	51526
51492	51527
51492	51529
51492	51530
51492	51531
51492	51532
51492	51533
51492	51534
51492	51535
51492	51536
51492	51537
51492	51538
51492	51539
51492	51540
51492	51541
51492	51542
51492	52284
51487	51469
51487	51470
51487	51473
51487	51479
51487	51489
51487	51490
51487	51494
51487	51495
51487	51496
51487	51497
51487	51498
51487	51499
51487	51504
51487	51505
51487	51506
51487	51508
51487	51509
51487	51510
51487	51511
51487	51512
51487	51513
51487	51514
51487	51515
51487	51516
51487	51517
51487	51518
51487	51519
51487	51520
51487	51521
51487	51522
51487	51524
51487	51526
51487	51527
51487	51529
51487	51530
51487	51531
51487	51532
51487	51533
51487	51534
51487	51535
51487	51536
51487	51537
51487	51538
51487	51539
51487	51540
51487	51541
51487	51542
51487	52284
51523	51469
51523	51470
51523	51473
51523	51479
51523	51489
51523	51490
51523	51494
51523	51495
51523	51496
51523	51497
51523	51498
51523	51499
51523	51504
51523	51505
51523	51506
51523	51508
51523	51509
51523	51510
51523	51511
51523	51512
51523	51513
51523	51514
51523	51515
51523	51516
51523	51517
51523	51518
51523	51519
51523	51520
51523	51521
51523	51522
51523	51524
51523	51526
51523	51527
51523	51529
51523	51530
51523	51531
51523	51532
51523	51533
51523	51534
51523	51535
51523	51536
51523	51537
51523	51538
51523	51539
51523	51540
51523	51541
51523	51542
51523	52284
51476	51469
51476	51470
51476	51473
51476	51479
51476	51489
51476	51490
51476	51494
51476	51495
51476	51496
51476	51497
51476	51498
51476	51499
51476	51504
51476	51505
51476	51506
51476	51508
51476	51509
51476	51510
51476	51511
51476	51512
51476	51513
51476	51514
51476	51515
51476	51516
51476	51517
51476	51518
51476	51519
51476	51520
51476	51521
51476	51522
51476	51524
51476	51526
51476	51527
51476	51529
51476	51530
51476	51531
51476	51532
51476	51533
51476	51534
51476	51535
51476	51536
51476	51537
51476	51538
51476	51539
51476	51540
51476	51541
51476	51542
51476	52284
51493	51469
51493	51470
51493	51473
51493	51479
51493	51489
51493	51490
51493	51494
51493	51495
51493	51496
51493	51497
51493	51498
51493	51499
51493	51504
51493	51505
51493	51506
51493	51508
51493	51509
51493	51510
51493	51511
51493	51512
51493	51513
51493	51514
51493	51515
51493	51516
51493	51517
51493	51518
51493	51519
51493	51520
51493	51521
51493	51522
51493	51524
51493	51526
51493	51527
51493	51529
51493	51530
51493	51531
51493	51532
51493	51533
51493	51534
51493	51535
51493	51536
51493	51537
51493	51538
51493	51539
51493	51540
51493	51541
51493	51542
51493	52284
51507	51469
51507	51470
51507	51473
51507	51479
51507	51489
51507	51490
51507	51494
51507	51495
51507	51496
51507	51497
51507	51498
51507	51499
51507	51504
51507	51505
51507	51506
51507	51508
51507	51509
51507	51510
51507	51511
51507	51512
51507	51513
51507	51514
51507	51515
51507	51516
51507	51517
51507	51518
51507	51519
51507	51520
51507	51521
51507	51522
51507	51524
51507	51526
51507	51527
51507	51529
51507	51530
51507	51531
51507	51532
51507	51533
51507	51534
51507	51535
51507	51536
51507	51537
51507	51538
51507	51539
51507	51540
51507	51541
51507	51542
51507	52284
51525	51469
51525	51470
51525	51473
51525	51479
51525	51489
51525	51490
51525	51494
51525	51495
51525	51496
51525	51497
51525	51498
51525	51499
51525	51504
51525	51505
51525	51506
51525	51508
51525	51509
51525	51510
51525	51511
51525	51512
51525	51513
51525	51514
51525	51515
51525	51516
51525	51517
51525	51518
51525	51519
51525	51520
51525	51521
51525	51522
51525	51524
51525	51526
51525	51527
51525	51529
51525	51530
51525	51531
51525	51532
51525	51533
51525	51534
51525	51535
51525	51536
51525	51537
51525	51538
51525	51539
51525	51540
51525	51541
51525	51542
51525	52284
51474	51469
51474	51470
51474	51473
51474	51479
51474	51489
51474	51490
51474	51494
51474	51495
51474	51496
51474	51497
51474	51498
51474	51499
51474	51504
51474	51505
51474	51506
51474	51508
51474	51509
51474	51510
51474	51511
51474	51512
51474	51513
51474	51514
51474	51515
51474	51516
51474	51517
51474	51518
51474	51519
51474	51520
51474	51521
51474	51522
51474	51524
51474	51526
51474	51527
51474	51529
51474	51530
51474	51531
51474	51532
51474	51533
51474	51534
51474	51535
51474	51536
51474	51537
51474	51538
51474	51539
51474	51540
51474	51541
51474	51542
51474	52284
51486	51469
51486	51470
51486	51473
51486	51479
51486	51489
51486	51490
51486	51494
51486	51495
51486	51496
51486	51497
51486	51498
51486	51499
51486	51504
51486	51505
51486	51506
51486	51508
51486	51509
51486	51510
51486	51511
51486	51512
51486	51513
51486	51514
51486	51515
51486	51516
51486	51517
51486	51518
51486	51519
51486	51520
51486	51521
51486	51522
51486	51524
51486	51526
51486	51527
51486	51529
51486	51530
51486	51531
51486	51532
51486	51533
51486	51534
51486	51535
51486	51536
51486	51537
51486	51538
51486	51539
51486	51540
51486	51541
51486	51542
51486	52284
51503	51492
51503	51493
51500	51487
51500	51493
51481	51523
51484	51523
51482	51507
51482	51510
51482	51525
51483	51507
51483	51525
51475	51474
51475	51486
38587	51469
38587	51470
38603	51527
38603	51541
38604	38603
38604	51527
38604	51541
38605	38603
38605	38604
38605	51527
38605	51541
41628	41627
45288	41635
45300	45283
45862	41617
45271	45198
51787	51790
41620	45288
51799	41614
37695	41628
37695	45271
37695	45288
51795	41614
51795	45288
51792	41610
51792	41614
51792	51791
51783	41614
51781	41620
51781	45300
51779	41614
45294	41614
45294	45862
51786	51799
51793	51795
45297	51787
51784	37695
51784	51792
51794	51779
51796	41614
51796	51781
51797	51779
51797	51781
51803	42899
51803	45294
51803	45297
51803	45860
51803	51778
51803	51784
51803	51786
51803	51793
51803	51794
51803	51796
51803	51797
51803	51798
37713	51797
51809	51803
51806	51803
51807	41612
51807	51804
39409	37713
39409	51783
39409	51784
39409	51797
51814	51806
51814	51809
51801	51809
51800	51809
45298	51814
51810	51814
51805	51814
51782	51814
45281	45298
51789	51782
51811	39409
51811	51810
51802	51805
51785	51782
51780	37713
51780	51803
51813	51814
51812	51810
51808	51783
45279	51809
45861	45862
51788	51809
45301	51809
41636	41632
41637	41633
47841	41632
47862	47838
41643	47841
47829	47841
36853	47829
36870	36843
47811	47846
47814	47862
36866	47847
47801	47818
47863	47829
47852	47814
47833	36853
36863	41636
36863	47829
36860	41643
36867	41636
47864	47811
47789	41633
47789	47847
47851	36853
47851	36858
47851	36870
36871	36863
36872	36871
47853	36863
47853	36867
47853	41643
47853	47863
47854	41644
47794	36863
47794	47852
47827	41633
47827	47847
47855	36867
47855	36871
47845	36863
47845	47852
47831	36863
47831	36866
47831	36867
47831	47854
47831	47863
47831	47864
47857	47853
47857	47854
47857	47864
47786	36863
47786	36866
47786	47854
47786	47863
47786	47864
47832	41633
47832	47847
36885	36866
36885	47854
36885	47864
47843	36885
47843	47786
47843	47831
47843	47832
47843	47845
47843	47857
47820	36885
47820	47786
47820	47831
47820	47832
47820	47845
47820	47857
47822	36885
47822	47789
47822	47831
47822	47832
47822	47845
47822	47857
47824	36885
47824	47786
47824	47831
47824	47832
47824	47845
47824	47857
47797	36885
47797	47786
47797	47831
47797	47832
47797	47845
47797	47857
47798	36885
47798	47786
47798	47831
47798	47832
47798	47845
47798	47857
47799	36885
47799	47786
47799	47831
47799	47832
47799	47845
47799	47857
47800	36885
47800	47786
47800	47831
47800	47832
47800	47845
47800	47857
47834	36885
47834	47786
47834	47831
47834	47832
47834	47845
47834	47857
47826	36885
47826	47786
47826	47831
47826	47832
47826	47845
47826	47857
47812	47797
47812	47798
47812	47799
47812	47800
47812	47820
47812	47822
47812	47824
47812	47826
47812	47834
47812	47843
41629	41632
47790	41636
47860	36860
47806	36843
47809	47845
47808	47829
47819	47811
36810	36863
36811	36863
36811	47852
47802	47794
47802	47845
36437	36853
36437	36858
47796	47789
47796	47827
47842	47838
47791	47830
47792	36863
47805	36863
47805	41643
47840	36866
47859	47814
47859	47833
47793	36843
47793	36863
47793	36867
47793	47852
47793	47863
47861	36867
47861	36871
47844	47852
36427	36853
47807	47786
47807	47831
47828	36872
47828	47854
36827	36867
47856	47855
36829	36863
47823	47811
36830	36858
36831	36870
47836	36863
47835	47852
47804	47814
47804	47833
47795	47862
47848	47863
47837	36863
36838	47814
47803	36872
47787	47830
51973	51970
41656	51968
51772	51970
36402	36394
41658	41445
51971	51969
51975	51989
36411	50156
36411	50837
36412	36402
36413	41658
36415	51977
36418	51971
36419	41656
36420	51977
36421	36411
36424	51971
36425	51975
36426	36421
36428	36398
36429	36407
51978	51971
36431	51989
51995	41654
36433	36421
36430	36424
36437	36421
36439	36421
51980	36407
52002	36421
52003	36421
36443	36423
37448	37437
37449	37433
37449	37434
37450	37427
37453	37428
37454	37440
37455	37451
37456	37444
37456	37449
37457	37446
37458	37430
37459	37452
37460	37430
37461	37449
37463	37430
37464	37440
37466	37450
37468	37441
37483	37463
37470	37456
37472	37466
37473	37431
37475	37447
37476	37443
37478	37456
37497	37456
37486	37456
37489	37458
37489	37460
37481	37434
37481	37460
37491	37459
37493	37456
37495	37459
37485	37456
37499	37456
37500	37475
37504	37434
37505	37431
37505	37449
37512	37440
37513	37476
37516	37437
37517	37433
46517	37440
37518	37456
46520	37450
37519	37449
46515	37455
37521	37453
37522	37457
37524	37483
37525	37460
37526	37553
46524	37447
46524	37456
37535	37516
37542	37439
37543	37450
37548	37434
37548	37553
46518	37448
46519	37442
51820	37466
37549	37449
37550	37446
46516	37470
37551	37476
37552	37434
37552	37450
37553	37517
37447	37444
51945	51917
51950	51937
37449	51936
51921	51943
51953	51918
37603	37441
51954	51948
51924	37444
51912	37475
37625	37606
51955	51912
51960	51921
51963	51918
37513	51948
37648	37436
51946	51951
37651	37436
37652	51918
37522	37446
37657	37436
51934	51918
46519	51941
51925	37450
37551	51948
39723	44206
39727	39723
39731	45575
39734	39727
39736	39731
39738	39734
49947	49945
49951	49927
49913	49948
45463	45462
52082	52086
52079	52086
52079	52087
50046	50044
50046	50069
50059	50060
52088	50070
50055	50054
50055	50071
52078	52083
50056	50055
52089	52092
52089	52100
52101	52085
48566	48558
48553	48573
38921	37487
38912	48554
48570	48553
48574	48566
38913	38900
38915	38912
38918	37479
38918	48565
48569	48570
48578	48566
48578	48574
48552	48578
48567	48553
48567	48570
48564	48570
48557	48567
48559	48552
48673	48670
48656	48674
37480	37477
37484	48673
48661	48673
48675	48655
48660	48678
48672	48673
37528	48659
48679	37528
48677	48655
48664	48660
48666	48673
38372	38369
49862	49861
49876	52106
49886	52106
49890	49881
49890	49883
49905	49881
49905	49889
49905	52115
49897	49869
45399	45398
48017	48016
48019	48016
45412	45399
45405	45398
35450	45418
35498	36270
35498	45398
35503	45399
35503	45418
45263	45418
35427	35498
35430	35450
35430	45412
45422	45399
45422	48009
45417	35498
45417	45399
35505	45405
35431	45399
35431	48008
48581	45412
35507	45417
45397	45417
29375	48018
29375	48318
35426	35507
39974	35505
48318	48017
36156	35430
48599	48596
41084	35505
35435	45399
45388	45399
35436	35505
48606	41077
48606	48009
48018	48017
48032	48034
35440	45399
48588	37052
48594	48596
35446	45399
35446	45418
36261	35431
36262	36261
45396	48603
36263	36270
36264	36270
36264	45398
41076	45416
41077	45416
41083	35450
41083	48580
35452	35503
35452	45263
35453	48330
35454	45412
45392	45405
45408	45417
45410	45405
35511	45416
35460	35507
45403	35507
45425	35507
45420	45422
45426	45410
45395	35505
48031	48034
50169	48034
37066	48032
34320	50169
37068	37066
37069	29375
50254	48318
37070	35498
37070	37068
37071	37070
45428	45417
35431	45398
45409	35505
45431	37069
45427	45399
35458	35503
37059	37070
39974	45407
45484	45399
45486	45402
41077	48580
45428	45484
48606	48583
45422	48583
41076	45407
48598	39974
48598	45392
48598	45395
48598	45410
48598	48588
48595	39974
48595	45392
48595	45395
48595	45410
48595	48588
45411	45486
35426	45486
45409	45410
24596	24594
45418	45430
45485	48585
34343	31586
50144	48596
35446	45430
36263	45398
36263	45402
36264	45402
35450	45398
35450	45430
51138	48596
51120	48582
35453	45399
35503	45430
35507	45484
35460	45486
45403	45486
45425	45486
45397	45484
45417	45402
45263	45430
45408	45484
45423	45395
51322	51285
51290	51286
51290	51299
51290	51300
51309	51325
40500	31534
40500	51285
40500	51323
51314	51309
51314	51325
40501	40492
51317	51294
51317	51295
51287	51300
51287	51318
40507	40492
40507	40496
51283	51292
51283	51305
51283	51322
51289	31534
51289	40500
51289	51305
51289	51322
51289	51323
40512	31534
40512	40500
40512	51323
51298	40500
51298	40501
51298	40507
51307	51313
51308	40500
48017	48008
50139	50151
48723	48034
50157	48008
50157	48016
48009	48017
50173	50139
50171	50173
50150	49467
50150	50156
50164	48017
48018	48318
50160	48034
50160	50157
50159	48031
50159	48318
31599	31859
31599	50150
31613	31859
31613	50160
48582	48330
48582	48791
50165	50160
50146	50160
34023	48009
34023	48582
50166	50160
50161	50159
34024	50164
50172	31599
31617	31613
50167	50146
50167	50166
50158	50172
34027	34023
50168	50146
50168	50165
31619	31613
31712	50159
31539	50161
50174	50167
50152	50158
45266	31858
45266	34027
34028	31619
34033	50158
34035	31712
34035	50161
50147	48009
50148	48009
45267	45266
50138	50158
50149	50174
50153	34035
50170	50146
50170	50165
50154	31539
50154	34024
50154	34028
50154	50174
31638	50161
33944	34027
31637	31859
33945	50165
33946	50165
33946	50166
31698	34035
46476	34033
51755	50166
33948	50160
33948	50164
33949	50166
31642	50161
31643	50161
33950	50158
34034	45267
33951	31613
33951	31617
33951	31619
33952	50159
46506	31613
33954	50149
33955	50165
33956	50174
46500	50167
33957	50171
33957	50172
33959	50158
46480	50172
46501	34033
33962	48582
33962	50166
31705	34035
33965	50166
33967	34023
50143	48018
46507	31617
33972	50166
33977	48016
33977	48031
48032	48031
51756	50157
51756	50160
33981	31859
33982	31858
33983	31859
33984	50158
50144	46511
46497	34033
50142	46511
34342	34024
46495	31712
45265	31712
50155	50164
31671	31712
31671	50161
48812	48031
48812	48032
31673	50159
46509	31613
31883	48582
31674	50161
33990	34028
33990	50174
31675	50161
50162	34024
50162	34028
50162	50172
50162	50174
33992	50172
33994	34023
33998	50170
33999	50168
34000	46511
34000	50158
48019	48318
50163	50172
31684	50172
50141	50150
34005	50174
34006	50170
34007	50168
46508	34028
34010	50158
50488	48719
36918	36917
48582	48318
50486	48318
36923	48018
36920	50489
50497	36918
50483	48032
50493	36918
36921	50486
36931	50483
36927	50497
50492	50493
50495	50497
36928	36921
50494	36923
36930	50483
36934	50497
36935	36927
36936	50495
36937	36930
36933	36920
50490	50494
36938	50497
36939	36938
36944	50492
36940	36936
36941	50492
36942	36931
36942	36937
36948	36935
36948	36937
36946	36938
31741	36936
40522	50497
36951	36938
36954	36936
36895	36920
36896	50494
34016	48809
40523	50497
40524	50497
40525	50495
50491	50497
40526	36936
40527	50488
40548	40547
40529	50497
50485	50486
40539	36933
50484	50494
36900	36920
36901	50492
40530	50497
40531	36927
40540	36927
40541	36935
40532	36937
40533	31741
40534	36934
40535	36938
40536	50483
40537	50497
51329	35069
51360	35069
51348	51329
51331	50161
51353	51329
51335	51354
51368	51353
51345	50161
51349	51329
51350	50161
51350	51334
51369	51349
51342	50161
51342	51351
51356	51329
31861	31889
31861	31908
48330	48008
48034	48016
48318	48016
51138	46511
51134	34314
51134	46511
48723	48798
51132	51131
32006	34314
51114	51134
51116	34314
50144	34314
34340	51132
51125	51120
51125	51132
32015	32006
51113	34024
51124	51132
51121	51134
51135	32015
34333	51115
34335	51132
32039	51125
51123	51132
50148	51132
51133	32006
51133	50142
43686	51134
51122	51116
51107	51135
51111	51125
51136	50148
51112	51125
51110	51125
51109	51125
31975	32015
34350	51133
34354	51125
51137	51125
36058	48022
36058	48718
48046	48011
48012	48041
48018	48016
48013	48041
48716	48736
48026	48022
48026	48718
36064	48022
48024	48041
48728	48714
51906	48714
48725	48714
51907	48716
48042	48022
48042	48718
36077	48022
51908	48728
48721	48728
48721	51906
48039	48046
48717	48013
51905	48725
48720	48725
48720	51907
48015	48044
48015	48046
36029	48028
36030	48012
36035	36074
36036	48012
36037	36077
36094	48022
36042	48013
36043	48046
36043	48717
36044	36064
36044	48026
36103	48024
36045	36084
48035	36060
48035	48041
48035	48046
48734	48736
48734	48739
48731	48736
48731	48739
36046	48024
36047	48023
36050	48022
48312	45398
37188	37185
48321	48016
37192	37185
48319	48321
48326	48016
37196	37185
48327	48313
48325	48320
48314	48326
48329	37185
48322	48327
37201	48324
48336	48321
37203	37185
37203	48320
48315	48320
48337	48336
48332	37201
48323	48315
48338	48336
37164	48320
49474	44441
49481	51892
49481	51893
49481	51894
49472	48321
49482	49481
51891	48321
51891	49474
49476	49472
49483	49481
49475	48324
49475	49474
37203	37188
37203	49472
50493	48321
50489	50493
46456	48313
45353	48324
45364	48325
45358	36920
46613	50489
48314	48016
36070	36060
36081	36073
36059	36054
49663	49684
42937	50276
40252	40186
51897	50274
42955	51897
51898	51897
42948	42943
42958	51899
42963	42946
42949	42943
42951	51898
42960	42963
42953	42951
42954	51897
50266	50279
50277	42955
50262	42960
50260	42955
45789	45757
45753	45795
38442	48041
38443	48041
41250	41095
41263	41250
45743	38442
41289	41255
41268	41264
41620	41251
41265	48041
45750	41263
45750	45774
41267	41263
41288	41254
41271	41265
41272	45755
41272	48023
45790	41267
45790	45789
45784	45748
45784	48041
45794	41267
41275	45776
45759	41620
41276	41267
41278	41272
45783	41275
45791	45794
45773	45794
41283	41275
45785	45784
41285	41250
41285	41620
41285	45753
45752	41267
45751	41272
45751	41283
49456	45766
45771	41620
41287	41283
49466	45752
45786	41145
45786	41268
45786	41285
45786	41288
45786	41289
45786	45759
45786	45771
45772	45771
45745	45796
45749	38442
45749	48023
45781	41261
45744	45796
49458	45752
45779	41275
41311	41264
45919	41095
41108	41143
41145	45924
41146	45919
41147	41143
45911	45920
41114	41108
41113	41109
47555	45924
41119	41147
45922	45753
43046	41095
43046	41146
43046	45929
45914	45911
45927	41119
45927	45911
41150	41146
41150	45753
45915	41113
45915	41119
45915	43046
45915	45922
45912	41119
45908	41113
45908	41119
45908	45922
45917	45915
45918	43044
45918	45914
45918	45915
45918	45928
41159	45912
43045	41111
43045	45914
41154	41145
45925	41113
45925	41119
45925	43046
45904	41108
45904	41114
45904	41148
45904	43044
45904	47556
45916	41150
45916	41159
45916	45915
45916	45917
45916	45925
45903	41154
45931	41111
45931	41159
45931	45914
45931	45917
45931	45921
45931	45925
45931	45926
45931	45927
45931	47556
41117	41111
41136	41135
45905	41103
45905	43049
41169	41113
41169	41147
42969	42968
42973	42972
45909	41119
45930	41113
41099	41145
41100	41145
46730	45198
50379	45219
48798	48016
46747	48798
50362	45219
50358	45219
50372	46751
46738	46751
50393	46751
50360	46738
46733	50372
50370	46738
50391	46733
46734	50372
50371	50370
41387	41499
41507	41387
41507	41499
41509	41505
41187	41499
41513	41509
41516	41513
50783	41499
41520	41502
41522	41516
41205	41182
41205	41512
41525	41520
41528	41511
41528	41517
41531	41523
41446	41503
41447	41516
41450	41499
41456	41511
41456	41517
41457	41511
41459	41513
41463	41520
41471	41182
41472	41182
50852	41387
41475	41516
41483	41511
50810	41187
41492	41177
50773	41758
50773	41761
50773	50766
50774	50773
50771	50773
50771	50774
50772	50771
50772	50773
50772	50774
41220	50768
44527	44517
44527	50790
44528	50764
44522	50779
41223	50765
41225	41173
41226	50793
44536	37786
45522	48204
48202	45489
48205	41095
48205	45489
48205	45514
48208	48195
48206	48202
48197	48202
48197	48205
45505	45515
45505	45520
45505	48197
45505	48206
45505	48207
48209	41392
48209	45522
48209	48192
48209	48197
48209	48206
48209	48207
45508	48189
45508	48197
45508	48207
45508	48208
45509	45522
48183	48197
48188	45505
48188	48190
48188	48194
48188	48197
48187	48188
48180	48206
48180	48208
48178	48183
48179	48184
45494	45505
48210	48209
48185	41095
48185	41392
48185	45489
48185	45494
48185	45504
48185	45505
48185	45508
48185	45509
48185	45514
48185	45515
48185	45520
48185	45522
48185	48178
48185	48179
48185	48180
48185	48183
48185	48184
48185	48187
48185	48188
48185	48189
48185	48190
48185	48191
48185	48192
48185	48193
48185	48194
48185	48195
48185	48196
48185	48197
48185	48198
48185	48199
48185	48200
48185	48201
48185	48202
48185	48203
48185	48204
48185	48205
48185	48206
48185	48207
48185	48208
48185	48209
48185	48210
48185	52104
48182	48179
48186	48185
48412	41228
48412	41383
48412	41384
48412	41385
48412	41386
48412	41387
48412	41388
48412	41390
48412	41393
48412	41394
48412	41395
48412	41396
48412	41399
48412	41402
48412	41404
48412	41405
48412	41407
48412	41408
48412	41409
48412	41412
48412	41413
48412	41414
48412	41417
48412	41418
48412	41423
48412	41426
48412	41427
48412	41428
48412	41436
48412	41442
48412	42992
48412	44022
48412	44029
48412	48396
48412	48397
48412	48398
48412	48399
48412	48400
48412	48401
48412	48403
48412	48404
48412	48405
48412	48406
48412	48407
48412	48408
48412	48410
48412	48411
48412	48413
44021	41228
44021	41383
44021	41384
44021	41385
44021	41386
44021	41387
44021	41388
44021	41390
44021	41393
44021	41394
44021	41395
44021	41396
44021	41399
44021	41402
44021	41404
44021	41405
44021	41407
44021	41408
44021	41409
44021	41412
44021	41413
44021	41414
44021	41417
44021	41418
44021	41421
44021	41423
44021	41426
44021	41427
44021	41428
44021	41436
44021	41442
44021	42992
44021	44022
44021	44029
44021	48396
44021	48397
44021	48398
44021	48399
44021	48400
44021	48401
44021	48403
44021	48404
44021	48405
44021	48406
44021	48407
44021	48408
44021	48410
44021	48411
44021	48413
44023	41228
44023	41383
44023	41384
44023	41385
44023	41386
44023	41387
44023	41388
44023	41390
44023	41393
44023	41394
44023	41395
44023	41396
44023	41399
44023	41402
44023	41404
44023	41405
44023	41407
44023	41408
44023	41409
44023	41412
44023	41413
44023	41414
44023	41417
44023	41418
44023	41421
44023	41423
44023	41426
44023	41427
44023	41428
44023	41436
44023	41442
44023	42992
44023	44022
44023	44029
44023	48396
44023	48397
44023	48398
44023	48399
44023	48400
44023	48401
44023	48403
44023	48404
44023	48405
44023	48406
44023	48407
44023	48408
44023	48410
44023	48411
44023	48413
44019	41228
44019	41383
44019	41384
44019	41385
44019	41386
44019	41387
44019	41388
44019	41390
44019	41393
44019	41394
44019	41395
44019	41396
44019	41399
44019	41402
44019	41404
44019	41405
44019	41407
44019	41408
44019	41409
44019	41412
44019	41413
44019	41414
44019	41417
44019	41418
44019	41421
44019	41423
44019	41426
44019	41427
44019	41428
44019	41436
44019	41442
44019	42992
44019	44022
44019	44029
44019	48396
44019	48397
44019	48398
44019	48399
44019	48400
44019	48401
44019	48403
44019	48404
44019	48405
44019	48406
44019	48407
44019	48408
44019	48410
44019	48411
44019	48413
44018	41228
44018	41383
44018	41384
44018	41385
44018	41386
44018	41387
44018	41388
44018	41390
44018	41393
44018	41394
44018	41395
44018	41396
44018	41399
44018	41402
44018	41404
44018	41405
44018	41407
44018	41408
44018	41409
44018	41412
44018	41413
44018	41414
44018	41417
44018	41418
44018	41421
44018	41423
44018	41426
44018	41427
44018	41428
44018	41436
44018	41442
44018	42992
44018	44022
44018	44029
44018	48396
44018	48397
44018	48398
44018	48399
44018	48400
44018	48401
44018	48404
44018	48405
44018	48406
44018	48407
44018	48408
44018	48410
44018	48411
44018	48413
44076	44078
44079	44076
41804	41797
44074	44079
44141	42733
44138	42733
41757	41803
44136	42733
44120	44102
44142	44141
44139	44141
44119	44118
44140	44141
44144	44142
44098	44089
41810	44074
41822	44074
44129	44090
44080	44098
44086	44080
44106	44074
44110	44106
44130	44129
44081	44130
44133	44092
44133	44094
44137	44092
44137	44094
44097	44084
44099	44097
44093	41803
44122	44093
44126	44073
44087	44126
44134	44142
44135	44134
44111	44082
44083	44111
44090	44089
44114	44105
44127	44114
44128	44127
44103	44089
44100	44083
44077	44100
44130	44090
44088	44092
44088	44094
44112	44092
44112	44094
44093	41757
44101	44084
44095	42524
44108	44109
44431	44429
44379	44377
44416	44377
44411	44379
44436	44377
44420	44379
44357	44377
44400	44381
44354	44412
44435	44408
44423	44354
44348	44432
44378	44423
49001	48988
48990	48989
48992	49001
49002	48998
48976	48992
49007	49006
49003	48992
48984	48992
49004	48992
48985	48992
41872	48992
42071	49003
42096	48992
48991	49004
48993	48985
42101	42096
49005	41833
46847	48974
41880	42071
45175	45181
45176	45175
46840	46838
41871	45174
45191	45177
46848	46857
46839	45170
46843	46842
41887	41854
41889	41841
44668	44664
41901	41854
41890	41854
44660	44723
44394	44393
44407	44394
45189	45170
45178	45174
45190	45188
44664	44660
48832	48824
48832	48825
48830	48824
48830	48825
48845	48826
48845	48846
48834	48845
42594	50449
42605	50449
50415	50449
50416	50449
50446	50449
50479	50449
50480	50449
50465	50449
50421	50449
50429	50449
48444	48443
48453	48451
48458	48421
48422	48421
48459	48422
48423	48422
48460	44238
48460	48439
48461	48424
44260	48456
48434	48435
51816	48428
41686	51815
41719	41691
48432	48447
41684	51815
41661	48446
41713	48447
48429	48428
41718	41691
48431	48428
48420	51815
48419	48446
48418	41691
48415	48447
41688	48446
43165	41571
43155	51244
51372	51376
51380	51376
51373	51372
51378	51372
43540	41755
51381	51372
51381	51373
51381	51376
51374	51373
51280	41991
51280	43157
51375	51381
51281	51280
41964	51379
41965	51266
41966	51267
41967	51263
41968	51243
41969	51268
41970	51264
41971	51256
41972	51265
41973	42002
41975	51269
43142	43177
43157	41991
43155	41571
43144	51244
51246	43155
51246	43165
51247	41571
51247	43155
51249	43178
51255	43155
43170	43155
43170	43165
51250	43142
51250	43177
43171	43170
51251	43143
51271	51246
51271	51247
41964	51258
41973	43154
41974	51248
43147	41755
46945	46943
46946	46945
46947	46946
52255	52221
52255	52256
52261	52236
52261	52253
52257	52221
52257	52256
52233	52236
52233	52253
47744	47745
47752	52189
47759	47740
47774	47767
47761	47767
\.


--
-- Data for Name: matrizes_curriculares; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.matrizes_curriculares (id, curso_id, inicio_vigencia, fim_vigencia) FROM stdin;
1	1	2025-01-01	2025-12-31
2	2	2025-01-01	2025-12-31
3	3	2025-01-01	2025-12-31
4	4	2025-01-01	2025-12-31
5	5	2025-01-01	2025-12-31
6	6	2025-01-01	2025-12-31
7	7	2025-01-01	2025-12-31
8	8	2025-01-01	2025-12-31
9	9	2025-01-01	2025-12-31
10	10	2025-01-01	2025-12-31
11	11	2025-01-01	2025-12-31
12	12	2025-01-01	2025-12-31
13	13	2025-01-01	2025-12-31
14	14	2025-01-01	2025-12-31
15	15	2025-01-01	2025-12-31
16	16	2025-01-01	2025-12-31
17	17	2025-01-01	2025-12-31
18	18	2025-01-01	2025-12-31
19	19	2025-01-01	2025-12-31
20	20	2025-01-01	2025-12-31
21	21	2025-01-01	2025-12-31
22	22	2025-01-01	2025-12-31
23	23	2025-01-01	2025-12-31
24	24	2025-01-01	2025-12-31
25	25	2025-01-01	2025-12-31
26	26	2025-01-01	2025-12-31
27	27	2025-01-01	2025-12-31
28	28	2025-01-01	2025-12-31
29	29	2025-01-01	2025-12-31
30	30	2025-01-01	2025-12-31
31	31	2025-01-01	2025-12-31
32	32	2025-01-01	2025-12-31
33	33	2025-01-01	2025-12-31
34	34	2025-01-01	2025-12-31
35	35	2025-01-01	2025-12-31
36	36	2025-01-01	2025-12-31
37	37	2025-01-01	2025-12-31
38	38	2025-01-01	2025-12-31
39	39	2025-01-01	2025-12-31
40	40	2025-01-01	2025-12-31
41	41	2025-01-01	2025-12-31
42	42	2025-01-01	2025-12-31
43	43	2025-01-01	2025-12-31
44	44	2025-01-01	2025-12-31
45	45	2025-01-01	2025-12-31
46	46	2025-01-01	2025-12-31
47	47	2025-01-01	2025-12-31
48	48	2025-01-01	2025-12-31
49	49	2025-01-01	2025-12-31
50	50	2025-01-01	2025-12-31
51	51	2025-01-01	2025-12-31
52	52	2025-01-01	2025-12-31
53	53	2025-01-01	2025-12-31
54	54	2025-01-01	2025-12-31
55	55	2025-01-01	2025-12-31
56	56	2025-01-01	2025-12-31
57	57	2025-01-01	2025-12-31
58	58	2025-01-01	2025-12-31
59	59	2025-01-01	2025-12-31
60	60	2025-01-01	2025-12-31
61	61	2025-01-01	2025-12-31
62	62	2025-01-01	2025-12-31
63	63	2025-01-01	2025-12-31
64	64	2025-01-01	2025-12-31
65	65	2025-01-01	2025-12-31
66	66	2025-01-01	2025-12-31
67	67	2025-01-01	2025-12-31
68	68	2025-01-01	2025-12-31
69	69	2025-01-01	2025-12-31
70	70	2025-01-01	2025-12-31
71	71	2025-01-01	2025-12-31
72	72	2025-01-01	2025-12-31
73	73	2025-01-01	2025-12-31
74	74	2025-01-01	2025-12-31
75	75	2025-01-01	2025-12-31
76	76	2025-01-01	2025-12-31
77	77	2025-01-01	2025-12-31
78	78	2025-01-01	2025-12-31
79	79	2025-01-01	2025-12-31
80	80	2025-01-01	2025-12-31
81	81	2025-01-01	2025-12-31
82	82	2025-01-01	2025-12-31
83	83	2025-01-01	2025-12-31
84	84	2025-01-01	2025-12-31
85	85	2025-01-01	2025-12-31
86	86	2025-01-01	2025-12-31
87	87	2025-01-01	2025-12-31
88	88	2025-01-01	2025-12-31
89	89	2025-01-01	2025-12-31
90	90	2025-01-01	2025-12-31
91	91	2025-01-01	2025-12-31
92	92	2025-01-01	2025-12-31
93	93	2025-01-01	2025-12-31
94	94	2025-01-01	2025-12-31
95	95	2025-01-01	2025-12-31
96	96	2025-01-01	2025-12-31
97	97	2025-01-01	2025-12-31
98	98	2025-01-01	2025-12-31
99	99	2025-01-01	2025-12-31
100	100	2025-01-01	2025-12-31
101	101	2025-01-01	2025-12-31
102	102	2025-01-01	2025-12-31
103	103	2025-01-01	2025-12-31
104	104	2025-01-01	2025-12-31
105	105	2025-01-01	2025-12-31
106	106	2025-01-01	2025-12-31
107	107	2025-01-01	2025-12-31
108	108	2025-01-01	2025-12-31
109	109	2025-01-01	2025-12-31
110	110	2025-01-01	2025-12-31
111	111	2025-01-01	2025-12-31
112	112	2025-01-01	2025-12-31
113	113	2025-01-01	2025-12-31
114	114	2025-01-01	2025-12-31
115	115	2025-01-01	2025-12-31
116	116	2025-01-01	2025-12-31
117	117	2025-01-01	2025-12-31
118	118	2025-01-01	2025-12-31
119	119	2025-01-01	2025-12-31
120	120	2025-01-01	2025-12-31
121	121	2025-01-01	2025-12-31
122	122	2025-01-01	2025-12-31
123	123	2025-01-01	2025-12-31
124	124	2025-01-01	2025-12-31
125	125	2025-01-01	2025-12-31
126	126	2025-01-01	2025-12-31
127	127	2025-01-01	2025-12-31
128	128	2025-01-01	2025-12-31
129	129	2025-01-01	2025-12-31
130	130	2025-01-01	2025-12-31
131	131	2025-01-01	2025-12-31
132	132	2025-01-01	2025-12-31
133	133	2025-01-01	2025-12-31
134	134	2025-01-01	2025-12-31
135	135	2025-01-01	2025-12-31
136	136	2025-01-01	2025-12-31
137	137	2025-01-01	2025-12-31
138	138	2025-01-01	2025-12-31
139	139	2025-01-01	2025-12-31
140	140	2025-01-01	2025-12-31
141	141	2025-01-01	2025-12-31
142	142	2025-01-01	2025-12-31
143	143	2025-01-01	2025-12-31
144	144	2025-01-01	2025-12-31
145	145	2025-01-01	2025-12-31
146	146	2025-01-01	2025-12-31
147	147	2025-01-01	2025-12-31
148	148	2025-01-01	2025-12-31
149	149	2025-01-01	2025-12-31
\.


--
-- Data for Name: matrizes_disciplinas; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.matrizes_disciplinas (id, matriz_curricular_id, disciplina_id, semestre, tipo) FROM stdin;
1	1	43279	1	OBR
2	1	48275	1	OBR
3	1	48281	1	OBR
4	1	43698	1	OBR
5	1	48260	1	OBR
6	1	48252	1	OBR
7	1	48273	2	OBR
8	1	48177	2	OBR
9	1	48274	2	OBR
10	1	48282	2	OBR
11	1	48251	2	OBR
12	1	43710	2	OBR
13	1	43750	3	OBR
14	1	48245	3	OBR
15	1	48249	3	OBR
16	1	48222	3	OBR
17	1	48221	3	OBR
18	1	48218	3	OBR
19	1	48279	3	OBR
20	1	48213	4	OBR
21	1	48256	4	OBR
22	1	48266	4	OBR
23	1	48250	4	OBR
24	1	48278	4	OBR
25	1	43278	4	OBR
26	1	48214	4	OBR
27	1	48240	5	OBR
28	1	48234	5	OBR
29	1	34755	5	OBR
30	1	48231	5	OBR
31	1	48267	5	OBR
32	1	48254	5	OBR
33	1	48265	5	OBR
34	1	48233	5	OBR
35	1	21921	6	OBR
36	1	48241	6	OBR
37	1	48216	6	OBR
38	1	48225	6	OBR
39	1	48289	6	OBR
40	1	48215	6	OBR
41	1	48220	6	OBR
42	1	48229	6	OBR
43	1	48244	7	OBR
44	1	48224	7	OBR
45	1	48276	7	OBR
46	1	48219	7	OBR
47	1	48228	7	OBR
48	1	48283	7	OBR
49	1	48217	7	OBR
50	1	48243	7	OBR
51	1	48242	8	OBR
52	1	48232	8	OBR
53	1	48277	8	OBR
54	1	48227	8	OBR
55	1	48230	8	OBR
56	1	48226	8	OBR
57	1	43755	99	OPT
58	1	43691	99	OPT
59	1	43692	99	OPT
60	1	43723	99	OPT
61	1	43326	99	OPT
62	1	48270	99	OPT
63	1	37350	99	OPT
64	1	48259	99	OPT
65	1	43690	99	OPT
66	1	48271	99	OPT
67	1	43720	99	OPT
68	1	43754	99	OPT
69	1	48288	99	OPT
70	1	48262	99	OPT
71	1	48235	99	OPT
72	1	48236	99	OPT
73	1	43743	99	OPT
74	1	43715	99	OPT
75	1	43704	99	OPT
76	1	48253	99	OPT
77	1	43738	99	OPT
78	1	43748	99	OPT
79	1	43716	99	OPT
80	1	48257	99	OPT
81	1	48258	99	OPT
82	1	43717	99	OPT
83	1	48223	99	OPT
84	1	48280	99	OPT
85	1	48268	99	OPT
86	1	43696	99	OPT
87	1	43718	99	OPT
88	1	48272	99	OPT
89	1	48255	99	OPT
90	1	48285	99	OPT
91	1	43721	99	OPT
92	1	48286	99	OPT
93	1	43724	99	OPT
94	1	43725	99	OPT
95	1	43726	99	OPT
96	1	43728	99	OPT
97	1	43727	99	OPT
98	1	43729	99	OPT
99	1	48284	99	OPT
100	1	48211	99	OPT
101	1	43733	99	OPT
102	1	43730	99	OPT
103	1	48212	99	OPT
104	1	48246	99	OPT
105	1	48238	99	OPT
106	1	48269	99	OPT
107	1	43731	99	OPT
108	1	43732	99	OPT
109	1	48239	99	OPT
110	1	43714	99	OPT
111	1	48264	99	OPT
112	1	48237	99	OPT
113	1	43734	99	OPT
114	1	43735	99	OPT
115	1	43751	99	OPT
116	1	43286	99	OPT
117	1	43266	99	OPT
118	1	48248	99	OPT
119	1	48261	99	OPT
120	1	48247	99	OPT
121	1	43739	99	OPT
122	1	43736	99	OPT
123	1	43737	99	OPT
124	1	43742	99	OPT
125	1	48263	99	OPT
126	1	43741	99	OPT
127	1	43740	99	OPT
128	1	48287	99	OPT
129	2	43279	1	OBR
130	2	48275	1	OBR
131	2	48295	1	OBR
132	2	43698	1	OBR
133	2	48260	1	OBR
134	2	48252	1	OBR
135	2	48273	2	OBR
136	2	48177	2	OBR
137	2	48307	2	OBR
138	2	48282	2	OBR
139	2	48251	2	OBR
140	2	43710	2	OBR
141	2	43750	3	OBR
142	2	48245	3	OBR
143	2	48302	3	OBR
144	2	48222	3	OBR
145	2	48221	3	OBR
146	2	48218	3	OBR
147	2	48279	3	OBR
148	2	48297	4	OBR
149	2	48256	4	OBR
150	2	48266	4	OBR
151	2	48250	4	OBR
152	2	48278	4	OBR
153	2	43278	4	OBR
154	2	48214	4	OBR
155	2	48300	5	OBR
156	2	48234	5	OBR
157	2	34755	5	OBR
158	2	48306	5	OBR
159	2	48267	5	OBR
160	2	48296	5	OBR
161	2	48303	5	OBR
162	2	48233	5	OBR
163	2	21921	6	OBR
164	2	48301	6	OBR
165	2	48216	6	OBR
166	2	48291	6	OBR
167	2	48289	6	OBR
168	2	48299	6	OBR
169	2	48298	6	OBR
170	2	48229	6	OBR
171	2	48292	7	OBR
172	2	48224	7	OBR
173	2	48310	7	OBR
174	2	48219	7	OBR
175	2	48305	7	OBR
176	2	48283	7	OBR
177	2	48304	7	OBR
178	2	48243	7	OBR
179	2	48308	8	OBR
180	2	48232	8	OBR
181	2	48311	8	OBR
182	2	48227	8	OBR
183	2	48309	8	OBR
184	2	48290	8	OBR
185	2	43755	99	OPT
186	2	43691	99	OPT
187	2	43692	99	OPT
188	2	43723	99	OPT
189	2	43326	99	OPT
190	2	48270	99	OPT
191	2	37350	99	OPT
192	2	48259	99	OPT
193	2	43690	99	OPT
194	2	48271	99	OPT
195	2	43720	99	OPT
196	2	43754	99	OPT
197	2	48288	99	OPT
198	2	48262	99	OPT
199	2	48235	99	OPT
200	2	48236	99	OPT
201	2	43743	99	OPT
202	2	43715	99	OPT
203	2	43704	99	OPT
204	2	48253	99	OPT
205	2	43738	99	OPT
206	2	43748	99	OPT
207	2	43716	99	OPT
208	2	48257	99	OPT
209	2	48258	99	OPT
210	2	43717	99	OPT
211	2	48223	99	OPT
212	2	48280	99	OPT
213	2	48268	99	OPT
214	2	43696	99	OPT
215	2	43718	99	OPT
216	2	48285	99	OPT
217	2	43721	99	OPT
218	2	48286	99	OPT
219	2	48293	99	OPT
220	2	48294	99	OPT
221	2	43724	99	OPT
222	2	43725	99	OPT
223	2	43756	99	OPT
224	2	43726	99	OPT
225	2	43728	99	OPT
226	2	43727	99	OPT
227	2	43729	99	OPT
228	2	48284	99	OPT
229	2	48211	99	OPT
230	2	43733	99	OPT
231	2	43730	99	OPT
232	2	48212	99	OPT
233	2	48246	99	OPT
234	2	48238	99	OPT
235	2	48269	99	OPT
236	2	43731	99	OPT
237	2	43732	99	OPT
238	2	48239	99	OPT
239	2	43714	99	OPT
240	2	48264	99	OPT
241	2	48237	99	OPT
242	2	43734	99	OPT
243	2	43735	99	OPT
244	2	43751	99	OPT
245	2	43286	99	OPT
246	2	43266	99	OPT
247	2	48248	99	OPT
248	2	48261	99	OPT
249	2	48247	99	OPT
250	2	43739	99	OPT
251	2	43736	99	OPT
252	2	43737	99	OPT
253	2	43742	99	OPT
254	2	48263	99	OPT
255	2	43741	99	OPT
256	2	43740	99	OPT
257	2	48287	99	OPT
258	3	48171	1	OBR
259	3	48152	1	OBR
260	3	34727	1	OBR
261	3	43264	1	OBR
262	3	48148	1	OBR
263	3	48150	2	OBR
264	3	48153	2	OBR
265	3	48169	2	OBR
266	3	48151	2	OBR
267	3	48154	2	OBR
268	3	48149	3	OBR
269	3	34737	3	OBR
270	3	48155	3	OBR
271	3	48158	3	OBR
272	3	48161	3	OBR
273	3	48170	4	OBR
274	3	48173	4	OBR
275	3	48160	4	OBR
276	3	48177	4	OBR
277	3	48164	5	OBR
278	3	34755	5	OBR
279	3	48174	5	OBR
280	3	48162	5	OBR
281	3	34746	5	OBR
282	3	48167	6	OBR
283	3	34748	6	OBR
284	3	48163	6	OBR
285	3	34751	6	OBR
286	3	48165	6	OBR
287	3	21921	7	OBR
288	3	48172	7	OBR
289	3	48166	7	OBR
290	3	48175	7	OBR
291	3	48176	8	OBR
292	3	33873	8	OBR
293	3	48168	8	OBR
294	3	34764	8	OBR
295	3	43278	8	OBR
296	3	34768	99	OPT
297	3	43280	99	OPT
298	3	43326	99	OPT
299	3	43686	99	OPT
300	3	34769	99	OPT
301	3	34770	99	OPT
302	3	34725	99	OPT
303	3	34771	99	OPT
304	3	43328	99	OPT
305	3	34772	99	OPT
306	3	34773	99	OPT
307	3	34774	99	OPT
308	3	34775	99	OPT
309	3	34776	99	OPT
310	3	43327	99	OPT
311	3	34777	99	OPT
312	3	34778	99	OPT
313	3	34779	99	OPT
314	3	34739	99	OPT
315	3	34745	99	OPT
316	3	34780	99	OPT
317	3	48156	99	OPT
318	3	34781	99	OPT
319	3	34782	99	OPT
320	3	43265	99	OPT
321	3	34783	99	OPT
322	3	43329	99	OPT
323	3	43266	99	OPT
324	3	43330	99	OPT
325	3	48159	99	OPT
326	3	48157	99	OPT
327	3	34784	99	OPT
328	3	34785	99	OPT
329	3	34786	99	OPT
330	3	34787	99	OPT
331	3	34788	99	OPT
332	3	34789	99	OPT
333	3	34790	99	OPT
334	3	34791	99	OPT
335	3	34792	99	OPT
336	4	49291	1	OBR
337	4	49318	1	OBR
338	4	49316	1	OBR
339	4	49294	1	OBR
340	4	49315	1	OBR
341	4	49292	1	OBR
342	4	49297	2	OBR
343	4	49290	2	OBR
344	4	48177	2	OBR
345	4	49317	2	OBR
346	4	49313	2	OBR
347	4	49300	3	OBR
348	4	33873	3	OBR
349	4	49296	3	OBR
350	4	49314	3	OBR
351	4	43278	3	OBR
352	4	43452	4	OBR
353	4	43457	4	OBR
354	4	49287	4	OBR
355	4	49301	4	OBR
356	4	49311	4	OBR
357	4	49323	4	OBR
358	4	49293	5	OBR
359	4	49306	5	OBR
360	4	34755	5	OBR
361	4	49303	5	OBR
362	4	49289	5	OBR
363	4	49310	5	OBR
364	4	49307	6	OBR
365	4	49305	6	OBR
366	4	49320	6	OBR
367	4	49312	6	OBR
368	4	49324	6	OBR
369	4	49302	6	OBR
370	4	49295	7	OBR
371	4	49299	7	OBR
372	4	49308	7	OBR
373	4	43465	7	OBR
374	4	49319	7	OBR
375	4	21921	8	OBR
376	4	49309	8	OBR
377	4	49321	8	OBR
378	4	49304	8	OBR
379	4	43450	8	OBR
380	4	43440	99	OPT
381	4	39358	99	OPT
382	4	39359	99	OPT
383	4	43280	99	OPT
384	4	49286	99	OPT
385	4	43279	99	OPT
386	4	39360	99	OPT
387	4	43458	99	OPT
388	4	34863	99	OPT
389	4	43473	99	OPT
390	4	49322	99	OPT
391	4	49288	99	OPT
392	4	43451	99	OPT
393	4	43441	99	OPT
394	4	39363	99	OPT
395	4	39364	99	OPT
396	4	34819	99	OPT
397	4	43442	99	OPT
398	4	39366	99	OPT
399	4	34845	99	OPT
400	4	39367	99	OPT
401	4	39368	99	OPT
402	4	49298	99	OPT
403	4	39369	99	OPT
404	4	43467	99	OPT
405	4	39370	99	OPT
406	4	39371	99	OPT
407	4	34977	99	OPT
408	4	39372	99	OPT
409	4	39291	99	OPT
410	4	39373	99	OPT
411	4	39374	99	OPT
412	4	34979	99	OPT
413	4	39375	99	OPT
414	4	39376	99	OPT
415	4	39377	99	OPT
416	4	43265	99	OPT
417	4	34877	99	OPT
418	4	34876	99	OPT
419	4	39378	99	OPT
420	4	43447	99	OPT
421	4	43437	99	OPT
422	4	39383	99	OPT
423	4	39325	99	OPT
424	4	43266	99	OPT
425	4	39384	99	OPT
426	4	43461	99	OPT
427	4	39387	99	OPT
428	4	39390	99	OPT
429	4	47785	99	OPT
430	4	39473	99	OPT
431	4	43469	99	OPT
432	5	50983	1	OBR
433	5	51012	1	OBR
434	5	50978	1	OBR
435	5	50988	1	OBR
436	5	51008	1	OBR
437	5	50991	1	OBR
438	5	43278	1	OBR
439	5	50981	2	OBR
440	5	51006	2	OBR
441	5	50987	2	OBR
442	5	48283	2	OBR
443	5	50998	2	OBR
444	5	50974	3	OBR
445	5	34755	3	OBR
446	5	50980	3	OBR
447	5	43516	3	OBR
448	5	51000	3	OBR
449	5	50992	3	OBR
450	5	50982	4	OBR
451	5	50996	4	OBR
452	5	21921	4	OBR
453	5	51016	4	OBR
454	5	51002	4	OBR
455	5	50995	4	OBR
456	5	43512	5	OBR
457	5	50986	5	OBR
458	5	50997	5	OBR
459	5	51027	5	OBR
460	5	43502	5	OBR
461	5	43509	5	OBR
462	5	51004	5	OBR
463	5	51001	6	OBR
464	5	50984	6	OBR
465	5	50994	6	OBR
466	5	50989	6	OBR
467	5	51015	6	OBR
468	5	51005	6	OBR
469	5	51003	7	OBR
470	5	51013	7	OBR
471	5	51007	7	OBR
472	5	51014	7	OBR
473	5	51009	7	OBR
474	5	50993	7	OBR
475	5	50990	8	OBR
476	5	50999	8	OBR
477	5	33873	8	OBR
478	5	43517	8	OBR
479	5	43508	8	OBR
480	5	43515	8	OBR
481	5	34947	99	OPT
482	5	50979	99	OPT
483	5	43533	99	OPT
484	5	51022	99	OPT
485	5	50976	99	OPT
486	5	51018	99	OPT
487	5	51026	99	OPT
488	5	45964	99	OPT
489	5	43495	99	OPT
490	5	51021	99	OPT
491	5	45954	99	OPT
492	5	45965	99	OPT
493	5	45966	99	OPT
494	5	45967	99	OPT
495	5	51023	99	OPT
496	5	50985	99	OPT
497	5	50973	99	OPT
498	5	45958	99	OPT
499	5	45951	99	OPT
500	5	51019	99	OPT
501	5	51024	99	OPT
502	5	51020	99	OPT
503	5	51017	99	OPT
504	5	34979	99	OPT
505	5	45959	99	OPT
506	5	45960	99	OPT
507	5	50977	99	OPT
508	5	51011	99	OPT
509	5	51028	99	OPT
510	5	51010	99	OPT
511	5	51025	99	OPT
512	5	50975	99	OPT
513	5	43521	99	OPT
514	5	43499	99	OPT
515	5	45962	99	OPT
516	5	45956	99	OPT
517	5	43527	99	OPT
518	5	43528	99	OPT
519	6	50288	1	OBR
520	6	34755	1	OBR
521	6	50287	1	OBR
522	6	50302	1	OBR
523	6	50318	1	OBR
524	6	50289	2	OBR
525	6	50293	2	OBR
526	6	50304	2	OBR
527	6	50317	2	OBR
528	6	43264	2	OBR
529	6	50310	2	OBR
530	6	50290	3	OBR
531	6	50316	3	OBR
532	6	50286	3	OBR
533	6	50303	3	OBR
534	6	50311	3	OBR
535	6	50300	3	OBR
536	6	50295	4	OBR
537	6	50319	4	OBR
538	6	50309	4	OBR
539	6	50312	4	OBR
540	6	50305	4	OBR
541	6	36308	4	OBR
542	6	50306	5	OBR
543	6	50296	5	OBR
544	6	50294	5	OBR
545	6	33873	5	OBR
546	6	50313	5	OBR
547	6	36313	5	OBR
548	6	36314	6	OBR
549	6	36320	6	OBR
550	6	21921	6	OBR
551	6	50297	6	OBR
552	6	36316	6	OBR
553	6	50292	6	OBR
554	6	36324	7	OBR
555	6	50298	7	OBR
556	6	36319	7	OBR
557	6	50291	7	OBR
558	6	50308	7	OBR
559	6	50314	7	OBR
560	6	50307	8	OBR
561	6	50301	8	OBR
562	6	36326	8	OBR
563	6	50299	8	OBR
564	6	50315	8	OBR
565	6	43278	8	OBR
566	6	36332	99	OPT
567	6	43277	99	OPT
568	6	36279	99	OPT
569	6	43280	99	OPT
570	6	34965	99	OPT
571	6	43279	99	OPT
572	6	36280	99	OPT
573	6	36334	99	OPT
574	6	43267	99	OPT
575	6	36283	99	OPT
576	6	36285	99	OPT
577	6	36286	99	OPT
578	6	36287	99	OPT
579	6	43269	99	OPT
580	6	36290	99	OPT
581	6	36291	99	OPT
582	6	36292	99	OPT
583	6	43270	99	OPT
584	6	36295	99	OPT
585	6	43266	99	OPT
586	6	43271	99	OPT
587	6	43272	99	OPT
588	6	43273	99	OPT
589	6	43274	99	OPT
590	6	43275	99	OPT
591	6	43276	99	OPT
592	6	46051	99	OPT
593	6	46053	99	OPT
594	6	36299	99	OPT
595	6	36300	99	OPT
596	7	48868	1	OBR
597	7	48880	1	OBR
598	7	48857	1	OBR
599	7	40968	1	OBR
600	7	48871	1	OBR
601	7	48869	2	OBR
602	7	48848	2	OBR
603	7	48872	2	OBR
604	7	48851	2	OBR
605	7	48865	2	OBR
606	7	48870	3	OBR
607	7	48855	3	OBR
608	7	48862	3	OBR
609	7	40964	3	OBR
610	7	48854	3	OBR
611	7	48852	4	OBR
612	7	48860	4	OBR
613	7	48882	4	OBR
614	7	48866	4	OBR
615	7	48856	4	OBR
616	7	48849	5	OBR
617	7	48863	5	OBR
618	7	48881	5	OBR
619	7	48861	5	OBR
620	7	48867	5	OBR
621	7	48858	6	OBR
622	7	48864	6	OBR
623	7	48884	6	OBR
624	7	48883	6	OBR
625	7	48859	6	OBR
626	7	47303	7	OBR
627	7	27904	7	OBR
628	7	40973	7	OBR
629	7	48853	7	OBR
630	7	47305	7	OBR
631	7	48875	8	OBR
632	7	48850	8	OBR
633	7	48876	99	OPT
634	7	34763	99	OPT
635	7	48877	99	OPT
636	7	48878	99	OPT
637	7	48879	99	OPT
638	7	47309	99	OPT
639	7	47310	99	OPT
640	7	47311	99	OPT
641	7	47291	99	OPT
642	7	47292	99	OPT
643	7	47293	99	OPT
644	7	47294	99	OPT
645	7	47295	99	OPT
646	7	47296	99	OPT
647	7	47297	99	OPT
648	7	48873	99	OPT
649	7	48874	99	OPT
650	8	49180	1	OBR
651	8	49177	1	OBR
652	8	49186	1	OBR
653	8	49187	1	OBR
654	8	49184	1	OBR
655	8	49164	2	OBR
656	8	49175	2	OBR
657	8	49158	2	OBR
658	8	49179	2	OBR
659	8	49173	2	OBR
660	8	49188	3	OBR
661	8	49202	3	OBR
662	8	49174	3	OBR
663	8	49165	3	OBR
664	8	49166	3	OBR
665	8	49178	3	OBR
666	8	49176	4	OBR
667	8	49197	4	OBR
668	8	49189	4	OBR
669	8	49206	4	OBR
670	8	49171	4	OBR
671	8	49162	5	OBR
672	8	49181	5	OBR
673	8	49195	5	OBR
674	8	49172	5	OBR
675	8	49194	5	OBR
676	8	49161	5	OBR
677	8	49191	6	OBR
678	8	49183	6	OBR
679	8	49167	6	OBR
680	8	49198	6	OBR
681	8	49163	6	OBR
682	8	49192	7	OBR
683	8	49160	7	OBR
684	8	49193	7	OBR
685	8	49199	7	OBR
686	8	49200	7	OBR
687	8	49185	8	OBR
688	8	49168	8	OBR
689	8	49201	8	OBR
690	8	49190	8	OBR
691	8	49170	8	OBR
692	8	49159	99	OPT
693	8	49169	99	OPT
694	8	43318	99	OPT
695	8	43320	99	OPT
696	8	49182	99	OPT
697	8	43285	99	OPT
698	8	43286	99	OPT
699	8	39880	99	OPT
700	8	49203	99	OPT
701	8	49196	99	OPT
702	8	49204	99	OPT
703	8	49205	99	OPT
704	9	43279	1	OBR
705	9	21921	1	OBR
706	9	51881	1	OBR
707	9	44861	1	OBR
708	9	51857	1	OBR
709	9	33873	2	OBR
710	9	34755	2	OBR
711	9	44840	2	OBR
712	9	44844	2	OBR
713	9	51858	2	OBR
714	9	44857	2	OBR
715	9	44875	3	OBR
716	9	44842	3	OBR
717	9	44848	3	OBR
718	9	44836	3	OBR
719	9	48283	3	OBR
720	9	51868	3	OBR
721	9	44878	3	OBR
722	9	51859	4	OBR
723	9	51864	4	OBR
724	9	51882	4	OBR
725	9	51883	4	OBR
726	9	51870	4	OBR
727	9	51873	4	OBR
728	9	51860	4	OBR
729	9	51867	5	OBR
730	9	51852	5	OBR
731	9	51861	5	OBR
732	9	51853	5	OBR
733	9	51874	5	OBR
734	9	51869	5	OBR
735	9	51876	5	OBR
736	9	51856	6	OBR
737	9	51865	6	OBR
738	9	51863	6	OBR
739	9	51855	6	OBR
740	9	51877	6	OBR
741	9	51878	6	OBR
742	9	51862	7	OBR
743	9	51884	7	OBR
744	9	51854	7	OBR
745	9	51871	7	OBR
746	9	51872	7	OBR
747	9	51885	7	OBR
748	9	51866	8	OBR
749	9	51875	8	OBR
750	9	51851	8	OBR
751	9	51879	8	OBR
752	9	51880	8	OBR
753	9	44866	99	OPT
754	9	44855	99	OPT
755	9	44860	99	OPT
756	9	44833	99	OPT
757	9	44864	99	OPT
758	9	44873	99	OPT
759	9	44829	99	OPT
760	9	44849	99	OPT
761	9	44839	99	OPT
762	10	49291	1	OBR
763	10	49318	1	OBR
764	10	45940	1	OBR
765	10	33882	1	OBR
766	10	49292	1	OBR
767	10	49401	1	OBR
768	10	49297	2	OBR
769	10	49290	2	OBR
770	10	49416	2	OBR
771	10	49404	2	OBR
772	10	34873	2	OBR
773	10	49300	3	OBR
774	10	49296	3	OBR
775	10	49400	3	OBR
776	10	49408	3	OBR
777	10	33895	3	OBR
778	10	43452	4	OBR
779	10	43457	4	OBR
780	10	49287	4	OBR
781	10	49301	4	OBR
782	10	45933	4	OBR
783	10	49413	4	OBR
784	10	49293	5	OBR
785	10	49409	5	OBR
786	10	49303	5	OBR
787	10	49411	5	OBR
788	10	49405	6	OBR
789	10	43463	6	OBR
790	10	49320	6	OBR
791	10	49312	6	OBR
792	10	49302	6	OBR
793	10	49295	7	OBR
794	10	49403	7	OBR
795	10	49410	7	OBR
796	10	49406	7	OBR
797	10	43465	7	OBR
798	10	49414	7	OBR
799	10	49402	7	OBR
800	10	49407	8	OBR
801	10	49321	8	OBR
802	10	49304	8	OBR
803	10	43450	8	OBR
804	10	45935	99	OPT
805	10	45944	99	OPT
806	10	45945	99	OPT
807	10	49415	99	OPT
808	10	45946	99	OPT
809	10	39358	99	OPT
810	10	33877	99	OPT
811	10	29968	99	OPT
812	10	45950	99	OPT
813	10	43280	99	OPT
814	10	49286	99	OPT
815	10	33880	99	OPT
816	10	43279	99	OPT
817	10	39360	99	OPT
818	10	49316	99	OPT
819	10	33873	99	OPT
820	10	34863	99	OPT
821	10	43473	99	OPT
822	10	45934	99	OPT
823	10	43451	99	OPT
824	10	43441	99	OPT
825	10	39364	99	OPT
826	10	43442	99	OPT
827	10	39366	99	OPT
828	10	34845	99	OPT
829	10	39367	99	OPT
830	10	39368	99	OPT
831	10	30408	99	OPT
832	10	39369	99	OPT
833	10	49412	99	OPT
834	10	30409	99	OPT
835	10	26277	99	OPT
836	10	43333	99	OPT
837	10	39372	99	OPT
838	10	39373	99	OPT
839	10	30653	99	OPT
840	10	45942	99	OPT
841	10	30148	99	OPT
842	10	30149	99	OPT
843	10	30412	99	OPT
844	10	45941	99	OPT
845	10	39375	99	OPT
846	10	30655	99	OPT
847	10	39377	99	OPT
848	10	34877	99	OPT
849	10	39378	99	OPT
850	10	39383	99	OPT
851	10	45949	99	OPT
852	10	33904	99	OPT
853	10	27559	99	OPT
854	10	39390	99	OPT
855	10	47784	99	OPT
856	10	47785	99	OPT
857	10	45939	99	OPT
858	10	45943	99	OPT
859	10	45947	99	OPT
860	10	45948	99	OPT
861	11	43279	1	OBR
862	11	21921	1	OBR
863	11	44852	1	OBR
864	11	44861	1	OBR
865	11	44862	1	OBR
866	11	33873	2	OBR
867	11	34755	2	OBR
868	11	44840	2	OBR
869	11	44844	2	OBR
870	11	51830	2	OBR
871	11	44857	2	OBR
872	11	44875	3	OBR
873	11	44842	3	OBR
874	11	51850	3	OBR
875	11	44848	3	OBR
876	11	44836	3	OBR
877	11	43264	3	OBR
878	11	51831	3	OBR
879	11	44878	3	OBR
880	11	51842	4	OBR
881	11	51843	4	OBR
882	11	51821	4	OBR
883	11	51841	4	OBR
884	11	51835	4	OBR
885	11	51836	4	OBR
886	11	51837	4	OBR
887	11	51824	5	OBR
888	11	51847	5	OBR
889	11	51822	5	OBR
890	11	51823	5	OBR
891	11	51825	5	OBR
892	11	51838	5	OBR
893	11	51826	6	OBR
894	11	51839	6	OBR
895	11	51828	6	OBR
896	11	51848	6	OBR
897	11	51845	6	OBR
898	11	51834	6	OBR
899	11	51846	7	OBR
900	11	51840	7	OBR
901	11	51833	7	OBR
902	11	51829	7	OBR
903	11	51849	8	OBR
904	11	51827	8	OBR
905	11	51844	8	OBR
906	11	51832	8	OBR
907	11	44866	99	OPT
908	11	44864	99	OPT
909	11	44873	99	OPT
910	11	44829	99	OPT
911	11	44849	99	OPT
912	11	44839	99	OPT
913	13	44193	1	OBR
914	13	50646	1	OBR
915	13	50644	1	OBR
916	13	50708	1	OBR
917	13	50687	1	OBR
918	13	50670	1	OBR
919	13	43554	1	OBR
920	13	50641	1	OBR
921	13	35335	2	OBR
922	13	50651	2	OBR
923	13	50707	2	OBR
924	13	50639	2	OBR
925	13	50673	2	OBR
926	13	50677	2	OBR
927	13	43556	2	OBR
928	13	50675	2	OBR
929	13	35329	3	OBR
930	13	50700	3	OBR
931	13	50701	3	OBR
932	13	44156	3	OBR
933	13	50674	3	OBR
934	13	50658	3	OBR
935	13	50678	3	OBR
936	13	50682	3	OBR
937	13	50627	4	OBR
938	13	50706	4	OBR
939	13	50660	4	OBR
940	13	50642	4	OBR
941	13	50696	4	OBR
942	13	50652	4	OBR
943	13	50680	4	OBR
944	13	50704	5	OBR
945	13	50643	5	OBR
946	13	50699	5	OBR
947	13	50698	5	OBR
948	13	44188	5	OBR
949	13	50640	5	OBR
950	13	50655	5	OBR
951	13	50647	5	OBR
952	13	50659	5	OBR
953	13	50702	6	OBR
954	13	50650	6	OBR
955	13	50672	6	OBR
956	13	50705	6	OBR
957	13	44164	6	OBR
958	13	50664	6	OBR
959	13	50649	6	OBR
960	13	50695	6	OBR
961	13	50703	7	OBR
962	13	50653	7	OBR
963	13	43573	7	OBR
964	13	50710	7	OBR
965	13	44181	7	OBR
966	13	50676	7	OBR
967	13	50709	7	OBR
968	13	50656	7	OBR
969	13	50666	7	OBR
970	13	50697	8	OBR
971	13	50662	8	OBR
972	13	50711	8	OBR
973	13	50713	8	OBR
974	13	44182	8	OBR
975	13	50661	8	OBR
976	13	50712	8	OBR
977	13	50669	8	OBR
978	13	50667	8	OBR
979	13	50689	8	OBR
980	13	35797	99	OPT
981	13	35798	99	OPT
982	13	35305	99	OPT
983	13	43686	99	OPT
984	13	50648	99	OPT
985	13	44145	99	OPT
986	13	44186	99	OPT
987	13	44173	99	OPT
988	13	35313	99	OPT
989	13	50637	99	OPT
990	13	50693	99	OPT
991	13	44192	99	OPT
992	13	35800	99	OPT
993	13	50671	99	OPT
994	13	50645	99	OPT
995	13	50681	99	OPT
996	13	39609	99	OPT
997	13	50654	99	OPT
998	13	44183	99	OPT
999	13	16948	99	OPT
1000	13	35805	99	OPT
1001	13	39567	99	OPT
1002	13	50663	99	OPT
1003	13	43823	99	OPT
1004	13	50668	99	OPT
1005	13	50692	99	OPT
1006	13	43824	99	OPT
1007	13	39568	99	OPT
1008	13	50694	99	OPT
1009	13	39611	99	OPT
1010	13	39337	99	OPT
1011	13	50690	99	OPT
1012	13	50691	99	OPT
1013	13	35818	99	OPT
1014	13	44170	99	OPT
1015	13	39612	99	OPT
1016	13	44191	99	OPT
1017	14	44193	1	OBR
1018	14	50646	1	OBR
1019	14	50644	1	OBR
1020	14	50686	1	OBR
1021	14	50687	1	OBR
1022	14	50670	1	OBR
1023	14	43554	1	OBR
1024	14	50641	1	OBR
1025	14	35335	2	OBR
1026	14	50651	2	OBR
1027	14	50629	2	OBR
1028	14	50639	2	OBR
1029	14	50673	2	OBR
1030	14	50677	2	OBR
1031	14	43556	2	OBR
1032	14	50675	2	OBR
1033	14	35329	3	OBR
1034	14	50635	3	OBR
1035	14	50684	3	OBR
1036	14	44156	3	OBR
1037	14	50674	3	OBR
1038	14	50658	3	OBR
1039	14	50678	3	OBR
1040	14	50682	3	OBR
1041	14	50627	4	OBR
1042	14	50630	4	OBR
1043	14	50660	4	OBR
1044	14	50642	4	OBR
1045	14	50636	4	OBR
1046	14	50652	4	OBR
1047	14	50680	4	OBR
1048	14	50632	5	OBR
1049	14	50643	5	OBR
1050	14	50628	5	OBR
1051	14	50631	5	OBR
1052	14	44188	5	OBR
1053	14	50640	5	OBR
1054	14	50655	5	OBR
1055	14	50647	5	OBR
1056	14	50659	5	OBR
1057	14	50683	6	OBR
1058	14	50650	6	OBR
1059	14	50672	6	OBR
1060	14	50638	6	OBR
1061	14	44164	6	OBR
1062	14	50664	6	OBR
1063	14	50649	6	OBR
1064	14	50695	6	OBR
1065	14	50665	7	OBR
1066	14	50653	7	OBR
1067	14	43573	7	OBR
1068	14	50688	7	OBR
1069	14	44181	7	OBR
1070	14	50676	7	OBR
1071	14	50657	7	OBR
1072	14	50656	7	OBR
1073	14	50666	7	OBR
1074	14	50634	8	OBR
1075	14	50662	8	OBR
1076	14	50685	8	OBR
1077	14	50679	8	OBR
1078	14	44182	8	OBR
1079	14	50661	8	OBR
1080	14	50633	8	OBR
1081	14	50669	8	OBR
1082	14	50667	8	OBR
1083	14	50689	8	OBR
1084	14	35797	99	OPT
1085	14	35798	99	OPT
1086	14	35305	99	OPT
1087	14	43686	99	OPT
1088	14	51754	99	OPT
1089	14	50648	99	OPT
1090	14	44145	99	OPT
1091	14	44186	99	OPT
1092	14	44173	99	OPT
1093	14	35313	99	OPT
1094	14	50637	99	OPT
1095	14	50693	99	OPT
1096	14	44192	99	OPT
1097	14	35800	99	OPT
1098	14	52013	99	OPT
1099	14	50671	99	OPT
1100	14	50645	99	OPT
1101	14	50681	99	OPT
1102	14	50654	99	OPT
1103	14	39565	99	OPT
1104	14	16948	99	OPT
1105	14	35805	99	OPT
1106	14	35808	99	OPT
1107	14	39567	99	OPT
1108	14	50663	99	OPT
1109	14	43823	99	OPT
1110	14	50668	99	OPT
1111	14	50692	99	OPT
1112	14	45038	99	OPT
1113	14	43824	99	OPT
1114	14	52220	99	OPT
1115	14	50694	99	OPT
1116	14	39611	99	OPT
1117	14	35811	99	OPT
1118	14	50690	99	OPT
1119	14	50691	99	OPT
1120	14	35818	99	OPT
1121	14	44170	99	OPT
1122	14	39570	99	OPT
1123	14	44191	99	OPT
1124	15	48340	1	OBR
1125	15	48342	1	OBR
1126	15	48378	1	OBR
1127	15	36646	1	OBR
1128	15	48386	1	OBR
1129	15	48373	1	OBR
1130	15	48393	2	OBR
1131	15	48379	2	OBR
1132	15	48357	2	OBR
1133	15	48349	2	OBR
1134	15	46577	2	OBR
1135	15	48374	2	OBR
1136	15	48377	2	OBR
1137	15	48387	3	OBR
1138	15	48372	3	OBR
1139	15	36663	3	OBR
1140	15	48365	3	OBR
1141	15	48344	3	OBR
1142	15	48388	4	OBR
1143	15	36675	4	OBR
1144	15	46580	4	OBR
1145	15	48366	4	OBR
1146	15	48375	4	OBR
1147	15	48368	5	OBR
1148	15	48376	5	OBR
1149	15	48358	5	OBR
1150	15	48371	5	OBR
1151	15	48343	5	OBR
1152	15	48347	5	OBR
1153	15	48363	6	OBR
1154	15	48394	6	OBR
1155	15	48364	6	OBR
1156	15	48350	6	OBR
1157	15	48359	6	OBR
1158	15	48389	7	OBR
1159	15	48390	7	OBR
1160	15	48360	7	OBR
1161	15	48381	7	OBR
1162	15	48395	7	OBR
1163	15	48351	7	OBR
1164	15	48361	7	OBR
1165	15	48362	8	OBR
1166	15	48380	8	OBR
1167	15	48352	8	OBR
1168	15	48369	8	OBR
1169	15	48353	8	OBR
1170	15	48370	9	OBR
1171	15	48392	9	OBR
1172	15	48354	9	OBR
1173	15	48382	9	OBR
1174	15	48367	9	OBR
1175	15	46605	10	OBR
1176	15	46594	10	OBR
1177	15	48383	10	OBR
1178	15	48391	10	OBR
1179	15	48355	99	OPT
1180	15	46578	99	OPT
1181	15	48341	99	OPT
1182	15	36617	99	OPT
1183	15	46606	99	OPT
1184	15	46596	99	OPT
1185	15	46609	99	OPT
1186	15	48384	99	OPT
1187	15	46568	99	OPT
1188	15	36619	99	OPT
1189	15	36620	99	OPT
1190	15	36686	99	OPT
1191	15	46570	99	OPT
1192	15	48385	99	OPT
1193	15	46585	99	OPT
1194	15	46600	99	OPT
1195	15	36623	99	OPT
1196	15	46574	99	OPT
1197	15	36624	99	OPT
1198	15	36626	99	OPT
1199	15	36627	99	OPT
1200	15	46575	99	OPT
1201	15	46573	99	OPT
1202	15	48346	99	OPT
1203	15	36628	99	OPT
1204	15	48348	99	OPT
1205	15	46601	99	OPT
1206	15	43686	99	OPT
1207	15	46582	99	OPT
1208	15	46592	99	OPT
1209	15	46563	99	OPT
1210	15	46593	99	OPT
1211	15	35352	99	OPT
1212	15	46590	99	OPT
1213	15	46591	99	OPT
1214	15	46602	99	OPT
1215	15	36633	99	OPT
1216	15	36634	99	OPT
1217	15	46583	99	OPT
1218	15	48356	99	OPT
1219	15	46610	99	OPT
1220	15	46603	99	OPT
1221	15	46611	99	OPT
1222	15	46597	99	OPT
1223	15	46562	99	OPT
1224	15	46587	99	OPT
1225	15	46576	99	OPT
1226	15	46564	99	OPT
1227	15	48345	99	OPT
1228	16	50879	1	OBR
1229	16	50877	1	OBR
1230	16	50878	1	OBR
1231	16	50883	1	OBR
1232	16	46561	1	OBR
1233	16	50889	2	OBR
1234	16	50876	2	OBR
1235	16	50888	2	OBR
1236	16	50907	2	OBR
1237	16	50887	2	OBR
1238	16	50892	3	OBR
1239	16	50898	3	OBR
1240	16	50881	3	OBR
1241	16	50890	3	OBR
1242	16	46560	3	OBR
1243	16	50893	4	OBR
1244	16	50908	4	OBR
1245	16	50868	4	OBR
1246	16	50906	4	OBR
1247	16	50874	4	OBR
1248	16	50891	5	OBR
1249	16	50895	5	OBR
1250	16	50897	5	OBR
1251	16	50896	5	OBR
1252	16	50894	5	OBR
1253	16	50900	6	OBR
1254	16	50899	6	OBR
1255	16	46547	6	OBR
1256	16	50872	6	OBR
1257	16	50901	6	OBR
1258	16	50884	7	OBR
1259	16	50866	7	OBR
1260	16	37043	7	OBR
1261	16	50886	7	OBR
1262	16	50905	8	OBR
1263	16	50902	8	OBR
1264	16	50863	8	OBR
1265	16	50864	99	OPT
1266	16	46548	99	OPT
1267	16	46550	99	OPT
1268	16	35794	99	OPT
1269	16	37006	99	OPT
1270	16	46541	99	OPT
1271	16	50880	99	OPT
1272	16	50875	99	OPT
1273	16	46537	99	OPT
1274	16	50885	99	OPT
1275	16	46557	99	OPT
1276	16	46542	99	OPT
1277	16	46554	99	OPT
1278	16	50909	99	OPT
1279	16	46539	99	OPT
1280	16	50873	99	OPT
1281	16	50882	99	OPT
1282	16	46543	99	OPT
1283	16	46558	99	OPT
1284	16	50869	99	OPT
1285	16	46544	99	OPT
1286	16	50867	99	OPT
1287	16	36178	99	OPT
1288	16	46538	99	OPT
1289	16	35886	99	OPT
1290	16	35887	99	OPT
1291	16	35888	99	OPT
1292	16	37007	99	OPT
1293	16	37008	99	OPT
1294	16	37009	99	OPT
1295	16	37010	99	OPT
1296	16	37011	99	OPT
1297	16	37012	99	OPT
1298	16	35896	99	OPT
1299	16	35895	99	OPT
1300	16	37013	99	OPT
1301	16	35899	99	OPT
1302	16	35900	99	OPT
1303	16	35901	99	OPT
1304	16	37016	99	OPT
1305	16	37017	99	OPT
1306	16	50862	99	OPT
1307	16	37018	99	OPT
1308	16	50904	99	OPT
1309	16	37019	99	OPT
1310	16	37020	99	OPT
1311	16	37021	99	OPT
1312	16	37023	99	OPT
1313	16	37024	99	OPT
1314	16	37025	99	OPT
1315	16	37026	99	OPT
1316	16	37031	99	OPT
1317	16	37027	99	OPT
1318	16	37039	99	OPT
1319	16	50870	99	OPT
1320	16	37022	99	OPT
1321	16	46545	99	OPT
1322	16	37028	99	OPT
1323	16	37029	99	OPT
1324	16	37030	99	OPT
1325	16	50903	99	OPT
1326	16	37040	99	OPT
1327	16	37032	99	OPT
1328	16	37033	99	OPT
1329	16	37034	99	OPT
1330	16	37035	99	OPT
1331	16	37036	99	OPT
1332	16	37037	99	OPT
1333	16	37038	99	OPT
1334	16	37041	99	OPT
1335	16	35885	99	OPT
1336	16	50865	99	OPT
1337	16	50871	99	OPT
1338	16	46555	99	OPT
1339	16	46549	99	OPT
1340	16	37042	99	OPT
1341	17	47533	1	OBR
1342	17	48680	1	OBR
1343	17	48703	1	OBR
1344	17	48697	1	OBR
1345	17	47525	2	OBR
1346	17	48693	2	OBR
1347	17	47540	2	OBR
1348	17	48705	2	OBR
1349	17	48696	2	OBR
1350	17	48695	3	OBR
1351	17	48683	3	OBR
1352	17	46556	3	OBR
1353	17	48685	3	OBR
1354	17	47500	3	OBR
1355	17	48706	4	OBR
1356	17	48694	4	OBR
1357	17	48692	4	OBR
1358	17	48700	4	OBR
1359	17	48699	4	OBR
1360	17	48707	5	OBR
1361	17	48687	5	OBR
1362	17	48701	5	OBR
1363	17	48684	5	OBR
1364	17	48686	6	OBR
1365	17	48689	6	OBR
1366	17	47534	6	OBR
1367	17	47503	6	OBR
1368	17	47504	6	OBR
1369	17	48704	7	OBR
1370	17	48681	7	OBR
1371	17	48688	7	OBR
1372	17	48702	7	OBR
1373	17	47532	8	OBR
1374	17	43686	8	OBR
1375	17	48708	8	OBR
1376	17	48698	8	OBR
1377	17	47528	99	OPT
1378	17	47529	99	OPT
1379	17	36971	99	OPT
1380	17	47530	99	OPT
1381	17	47516	99	OPT
1382	17	47518	99	OPT
1383	17	47520	99	OPT
1384	17	47535	99	OPT
1385	17	45088	99	OPT
1386	17	43573	99	OPT
1387	17	47544	99	OPT
1388	17	47545	99	OPT
1389	17	47546	99	OPT
1390	17	47490	99	OPT
1391	17	44169	99	OPT
1392	17	47499	99	OPT
1393	17	48682	99	OPT
1394	17	47506	99	OPT
1395	17	47507	99	OPT
1396	17	47508	99	OPT
1397	17	47509	99	OPT
1398	17	47510	99	OPT
1399	17	47511	99	OPT
1400	17	47512	99	OPT
1401	17	48711	99	OPT
1402	17	48691	99	OPT
1403	17	48709	99	OPT
1404	17	37032	99	OPT
1405	17	47513	99	OPT
1406	17	47522	99	OPT
1407	17	47523	99	OPT
1408	17	48710	99	OPT
1409	17	48712	99	OPT
1410	17	48690	99	OPT
1411	17	47524	99	OPT
1412	18	49764	1	OBR
1413	18	49748	1	OBR
1414	18	49788	1	OBR
1415	18	49786	1	OBR
1416	18	49779	1	OBR
1417	18	49781	2	OBR
1418	18	49782	2	OBR
1419	18	49787	2	OBR
1420	18	43556	2	OBR
1421	18	49755	2	OBR
1422	18	43570	3	OBR
1423	18	43569	3	OBR
1424	18	49780	3	OBR
1425	18	49746	3	OBR
1426	18	49753	3	OBR
1427	18	35333	4	OBR
1428	18	49760	4	OBR
1429	18	43573	4	OBR
1430	18	49769	4	OBR
1431	18	49763	4	OBR
1432	18	49745	4	OBR
1433	18	49762	5	OBR
1434	18	49765	5	OBR
1435	18	49747	5	OBR
1436	18	49766	5	OBR
1437	18	49761	5	OBR
1438	18	49767	6	OBR
1439	18	49768	6	OBR
1440	18	49777	6	OBR
1441	18	38633	6	OBR
1442	18	43554	6	OBR
1443	18	49744	7	OBR
1444	18	49751	7	OBR
1445	18	49790	7	OBR
1446	18	49784	7	OBR
1447	18	49752	7	OBR
1448	18	49750	8	OBR
1449	18	49797	8	OBR
1450	18	49789	8	OBR
1451	18	49743	8	OBR
1452	18	43824	8	OBR
1453	18	49774	99	OPT
1454	18	51911	99	OPT
1455	18	49775	99	OPT
1456	18	49749	99	OPT
1457	18	49794	99	OPT
1458	18	49795	99	OPT
1459	18	49770	99	OPT
1460	18	49783	99	OPT
1461	18	49791	99	OPT
1462	18	49772	99	OPT
1463	18	49771	99	OPT
1464	18	49792	99	OPT
1465	18	49798	99	OPT
1466	18	49773	99	OPT
1467	18	43823	99	OPT
1468	18	35733	99	OPT
1469	18	49793	99	OPT
1470	18	38631	99	OPT
1471	18	49776	99	OPT
1472	18	43550	99	OPT
1473	18	49759	99	OPT
1474	18	49796	99	OPT
1475	18	49785	99	OPT
1476	18	49756	99	OPT
1477	18	49778	99	OPT
1478	18	49757	99	OPT
1479	18	49758	99	OPT
1480	19	43570	1	OBR
1481	19	43569	1	OBR
1482	19	51157	1	OBR
1483	19	43556	1	OBR
1484	19	51164	1	OBR
1485	19	43549	2	OBR
1486	19	51156	2	OBR
1487	19	43573	2	OBR
1488	19	51158	2	OBR
1489	19	43554	2	OBR
1490	19	35928	2	OBR
1491	19	51175	3	OBR
1492	19	36724	3	OBR
1493	19	51154	3	OBR
1494	19	51160	3	OBR
1495	19	43820	3	OBR
1496	19	51152	3	OBR
1497	19	51161	4	OBR
1498	19	36730	4	OBR
1499	19	36738	4	OBR
1500	19	51142	4	OBR
1501	19	51159	4	OBR
1502	19	51146	4	OBR
1503	19	51168	5	OBR
1504	19	36752	5	OBR
1505	19	51179	5	OBR
1506	19	51171	5	OBR
1507	19	51143	5	OBR
1508	19	51153	5	OBR
1509	19	51170	6	OBR
1510	19	51177	6	OBR
1511	19	51155	6	OBR
1512	19	51162	6	OBR
1513	19	51163	6	OBR
1514	19	51173	6	OBR
1515	19	51151	7	OBR
1516	19	51166	7	OBR
1517	19	51144	7	OBR
1518	19	51178	7	OBR
1519	19	35716	7	OBR
1520	19	51172	7	OBR
1521	19	51174	8	OBR
1522	19	51167	8	OBR
1523	19	51145	8	OBR
1524	19	51176	8	OBR
1525	19	51150	8	OBR
1526	19	51165	8	OBR
1527	19	43564	99	OPT
1528	19	35305	99	OPT
1529	19	35313	99	OPT
1530	19	45899	99	OPT
1531	19	45892	99	OPT
1532	19	51149	99	OPT
1533	19	45889	99	OPT
1534	19	45894	99	OPT
1535	19	45891	99	OPT
1536	19	43565	99	OPT
1537	19	43568	99	OPT
1538	19	43823	99	OPT
1539	19	51169	99	OPT
1540	19	51148	99	OPT
1541	19	51147	99	OPT
1542	19	43816	99	OPT
1543	19	43550	99	OPT
1544	19	43824	99	OPT
1545	19	43831	99	OPT
1546	19	45897	99	OPT
1547	19	45898	99	OPT
1548	19	45900	99	OPT
1549	19	45901	99	OPT
1550	19	43837	99	OPT
1551	19	43828	99	OPT
1552	19	45895	99	OPT
1553	19	45893	99	OPT
1554	19	45890	99	OPT
1555	19	45888	99	OPT
1556	19	45896	99	OPT
1557	19	43832	99	OPT
1558	20	50719	1	OBR
1559	20	50717	1	OBR
1560	20	50716	1	OBR
1561	20	50741	1	OBR
1562	20	50715	1	OBR
1563	20	43556	1	OBR
1564	20	50720	2	OBR
1565	20	50721	2	OBR
1566	20	50722	2	OBR
1567	20	50736	2	OBR
1568	20	50714	2	OBR
1569	20	50748	2	OBR
1570	20	43554	2	OBR
1571	20	50726	3	OBR
1572	20	35549	3	OBR
1573	20	50723	3	OBR
1574	20	50724	3	OBR
1575	20	50742	3	OBR
1576	20	50749	3	OBR
1577	20	50735	4	OBR
1578	20	50737	4	OBR
1579	20	35555	4	OBR
1580	20	50750	4	OBR
1581	20	50740	4	OBR
1582	20	50738	4	OBR
1583	20	50753	5	OBR
1584	20	35559	5	OBR
1585	20	50728	5	OBR
1586	20	35567	5	OBR
1587	20	50746	5	OBR
1588	20	43569	5	OBR
1589	20	50754	5	OBR
1590	20	50725	5	OBR
1591	20	35564	6	OBR
1592	20	50729	6	OBR
1593	20	35570	6	OBR
1594	20	43570	6	OBR
1595	20	50747	6	OBR
1596	20	50718	6	OBR
1597	20	50751	6	OBR
1598	20	50727	6	OBR
1599	20	50734	7	OBR
1600	20	50739	7	OBR
1601	20	50730	7	OBR
1602	20	50743	7	OBR
1603	20	50744	7	OBR
1604	20	43573	7	OBR
1605	20	50731	7	OBR
1606	20	43575	7	OBR
1607	20	50732	8	OBR
1608	20	50733	8	OBR
1609	20	50745	8	OBR
1610	20	35583	8	OBR
1611	20	35554	8	OBR
1612	20	50752	8	OBR
1613	20	35521	99	OPT
1614	20	35522	99	OPT
1615	20	35523	99	OPT
1616	20	35524	99	OPT
1617	20	35526	99	OPT
1618	20	35525	99	OPT
1619	20	35527	99	OPT
1620	20	35528	99	OPT
1621	20	43572	99	OPT
1622	20	35529	99	OPT
1623	20	35530	99	OPT
1624	20	35531	99	OPT
1625	20	43549	99	OPT
1626	20	35305	99	OPT
1627	20	43686	99	OPT
1628	20	35533	99	OPT
1629	20	35534	99	OPT
1630	20	43566	99	OPT
1631	20	35535	99	OPT
1632	20	43562	99	OPT
1633	20	43567	99	OPT
1634	20	35536	99	OPT
1635	20	35537	99	OPT
1636	20	35538	99	OPT
1637	20	35539	99	OPT
1638	20	43565	99	OPT
1639	20	43568	99	OPT
1640	20	35540	99	OPT
1641	20	50755	99	OPT
1642	20	35541	99	OPT
1643	20	35542	99	OPT
1644	20	43550	99	OPT
1645	20	50756	99	OPT
1646	20	35544	99	OPT
1647	20	35545	99	OPT
1648	20	43571	99	OPT
1649	20	47481	99	OPT
1650	20	47480	99	OPT
1651	20	47479	99	OPT
1652	20	47478	99	OPT
1653	20	35546	99	OPT
1654	21	49980	1	OBR
1655	21	49972	1	OBR
1656	21	49978	1	OBR
1657	21	36195	1	OBR
1658	21	43554	1	OBR
1659	21	49966	1	OBR
1660	21	49979	2	OBR
1661	21	43570	2	OBR
1662	21	43573	2	OBR
1663	21	49973	2	OBR
1664	21	49967	2	OBR
1665	21	36199	2	OBR
1666	21	49970	3	OBR
1667	21	49975	3	OBR
1668	21	49958	3	OBR
1669	21	49955	3	OBR
1670	21	49954	3	OBR
1671	21	49959	3	OBR
1672	21	36207	4	OBR
1673	21	49961	4	OBR
1674	21	43569	4	OBR
1675	21	45878	4	OBR
1676	21	49956	4	OBR
1677	21	49957	5	OBR
1678	21	36209	5	OBR
1679	21	36210	5	OBR
1680	21	49963	5	OBR
1681	21	49960	5	OBR
1682	21	45869	5	OBR
1683	21	49976	6	OBR
1684	21	45868	6	OBR
1685	21	49964	6	OBR
1686	21	36216	6	OBR
1687	21	45880	6	OBR
1688	21	49971	6	OBR
1689	21	49962	7	OBR
1690	21	36220	7	OBR
1691	21	49977	7	OBR
1692	21	49968	7	OBR
1693	21	45875	7	OBR
1694	21	43556	7	OBR
1695	21	45877	8	OBR
1696	21	45881	8	OBR
1697	21	49974	8	OBR
1698	21	36225	8	OBR
1699	21	49969	8	OBR
1700	21	49965	8	OBR
1701	21	36157	99	OPT
1702	21	36158	99	OPT
1703	21	36159	99	OPT
1704	21	36160	99	OPT
1705	21	35671	99	OPT
1706	21	44505	99	OPT
1707	21	36162	99	OPT
1708	21	38550	99	OPT
1709	21	36163	99	OPT
1710	21	36164	99	OPT
1711	21	36165	99	OPT
1712	21	44498	99	OPT
1713	21	43549	99	OPT
1714	21	35305	99	OPT
1715	21	43686	99	OPT
1716	21	36166	99	OPT
1717	21	44508	99	OPT
1718	21	36167	99	OPT
1719	21	36168	99	OPT
1720	21	36169	99	OPT
1721	21	35745	99	OPT
1722	21	35313	99	OPT
1723	21	36170	99	OPT
1724	21	36171	99	OPT
1725	21	36172	99	OPT
1726	21	36173	99	OPT
1727	21	43077	99	OPT
1728	21	44494	99	OPT
1729	21	36174	99	OPT
1730	21	44509	99	OPT
1731	21	43565	99	OPT
1732	21	43568	99	OPT
1733	21	35769	99	OPT
1734	21	35695	99	OPT
1735	21	44499	99	OPT
1736	21	44496	99	OPT
1737	21	36176	99	OPT
1738	21	44493	99	OPT
1739	21	45867	99	OPT
1740	21	44489	99	OPT
1741	21	36178	99	OPT
1742	21	36179	99	OPT
1743	21	43550	99	OPT
1744	21	43824	99	OPT
1745	21	35551	99	OPT
1746	21	35557	99	OPT
1747	21	36180	99	OPT
1748	21	36181	99	OPT
1749	21	36182	99	OPT
1750	21	36183	99	OPT
1751	21	44504	99	OPT
1752	21	45884	99	OPT
1753	21	44495	99	OPT
1754	21	44490	99	OPT
1755	21	44497	99	OPT
1756	21	44507	99	OPT
1757	21	45887	99	OPT
1758	21	36184	99	OPT
1759	21	36185	99	OPT
1760	21	36186	99	OPT
1761	21	36187	99	OPT
1762	21	36188	99	OPT
1763	21	44501	99	OPT
1764	21	45874	99	OPT
1765	21	44500	99	OPT
1766	21	44502	99	OPT
1767	21	44503	99	OPT
1768	21	44510	99	OPT
1769	21	45871	99	OPT
1770	21	43079	99	OPT
1771	21	36189	99	OPT
1772	21	36192	99	OPT
1773	22	50223	1	OBR
1774	22	50213	1	OBR
1775	22	50210	1	OBR
1776	22	50214	1	OBR
1777	22	50219	1	OBR
1778	22	50211	1	OBR
1779	22	50212	2	OBR
1780	22	50200	2	OBR
1781	22	50218	2	OBR
1782	22	50197	2	OBR
1783	22	50204	2	OBR
1784	22	50222	2	OBR
1785	22	50216	3	OBR
1786	22	50178	3	OBR
1787	22	50177	3	OBR
1788	22	50215	3	OBR
1789	22	50196	3	OBR
1790	22	50207	3	OBR
1791	22	35947	3	OBR
1792	22	50221	4	OBR
1793	22	50217	4	OBR
1794	22	50181	4	OBR
1795	22	50176	4	OBR
1796	22	50220	4	OBR
1797	22	50189	4	OBR
1798	22	35953	5	OBR
1799	22	50229	5	OBR
1800	22	50179	5	OBR
1801	22	50230	5	OBR
1802	22	50186	5	OBR
1803	22	50227	5	OBR
1804	22	50194	6	OBR
1805	22	50183	6	OBR
1806	22	35959	6	OBR
1807	22	50228	6	OBR
1808	22	50201	6	OBR
1809	22	50226	6	OBR
1810	22	50184	6	OBR
1811	22	50224	7	OBR
1812	22	35966	7	OBR
1813	22	50180	7	OBR
1814	22	50182	7	OBR
1815	22	50187	7	OBR
1816	22	50188	7	OBR
1817	22	35973	8	OBR
1818	22	50225	8	OBR
1819	22	50195	8	OBR
1820	22	35972	8	OBR
1821	22	50199	8	OBR
1822	22	50198	8	OBR
1823	22	50185	8	OBR
1824	22	50202	9	NAP
1825	22	50205	9	NAP
1826	22	50203	10	NAP
1827	22	50206	10	NAP
1828	22	43549	99	OPT
1829	22	50192	99	OPT
1830	22	35352	99	OPT
1831	22	50193	99	OPT
1832	22	35923	99	OPT
1833	22	35921	99	OPT
1834	22	35922	99	OPT
1835	22	50208	99	OPT
1836	22	35919	99	OPT
1837	22	35917	99	OPT
1838	22	50190	99	OPT
1839	22	50209	99	OPT
1840	22	46864	99	OPT
1841	22	46861	99	OPT
1842	22	46870	99	OPT
1843	22	46860	99	OPT
1844	22	46862	99	OPT
1845	22	46863	99	OPT
1846	22	46865	99	OPT
1847	22	50191	99	OPT
1848	23	49093	1	OBR
1849	23	49094	1	OBR
1850	23	49089	1	OBR
1851	23	49111	1	OBR
1852	23	49079	1	OBR
1853	23	49105	1	OBR
1854	23	49090	2	OBR
1855	23	49122	2	OBR
1856	23	49100	2	OBR
1857	23	49101	2	OBR
1858	23	49075	2	OBR
1859	23	49103	2	OBR
1860	23	49087	3	OBR
1861	23	49109	3	OBR
1862	23	49110	3	OBR
1863	23	49151	3	OBR
1864	23	49095	3	OBR
1865	23	49088	3	OBR
1866	23	49086	4	OBR
1867	23	49108	4	OBR
1868	23	49098	4	OBR
1869	23	49113	4	OBR
1870	23	49128	4	OBR
1871	23	49104	4	OBR
1872	23	49076	5	OBR
1873	23	49102	5	OBR
1874	23	49124	5	OBR
1875	23	49125	5	OBR
1876	23	49080	5	OBR
1877	23	49127	5	OBR
1878	23	49078	6	OBR
1879	23	49123	6	OBR
1880	23	49126	6	OBR
1881	23	49129	6	OBR
1882	23	49096	6	OBR
1883	23	49106	6	OBR
1884	23	49118	7	OBR
1885	23	49119	7	OBR
1886	23	49091	7	OBR
1887	23	49150	7	OBR
1888	23	49107	7	OBR
1889	23	49116	8	OBR
1890	23	49099	8	OBR
1891	23	49130	8	OBR
1892	23	49147	8	OBR
1893	23	49155	8	OBR
1894	23	49143	99	OPT
1895	23	49081	99	OPT
1896	23	49082	99	OPT
1897	23	49145	99	OPT
1898	23	49097	99	OPT
1899	23	49152	99	OPT
1900	23	49115	99	OPT
1901	23	49154	99	OPT
1902	23	49144	99	OPT
1903	23	49142	99	OPT
1904	23	49117	99	OPT
1905	23	49157	99	OPT
1906	23	49153	99	OPT
1907	23	49136	99	OPT
1908	23	49131	99	OPT
1909	23	49139	99	OPT
1910	23	49112	99	OPT
1911	23	49114	99	OPT
1912	23	49084	99	OPT
1913	23	49146	99	OPT
1914	23	49140	99	OPT
1915	23	49083	99	NAP
1916	23	49120	99	NAP
1917	23	49121	99	NAP
1918	23	49138	99	OPT
1919	23	49133	99	OPT
1920	23	49148	99	OPT
1921	23	49149	99	OPT
1922	23	49132	99	OPT
1923	23	49137	99	OPT
1924	23	49156	99	OPT
1925	23	49077	99	OPT
1926	23	49134	99	OPT
1927	23	49092	99	OPT
1928	23	49141	99	OPT
1929	23	49085	99	OPT
1930	23	49135	99	OPT
1931	24	51406	1	OBR
1932	24	51411	1	OBR
1933	24	51394	1	OBR
1934	24	51395	1	OBR
1935	24	51409	1	OBR
1936	24	43556	1	OBR
1937	24	43554	1	OBR
1938	24	43570	2	OBR
1939	24	43569	2	OBR
1940	24	45162	2	OBR
1941	24	45136	2	OBR
1942	24	51396	2	OBR
1943	24	51408	2	OBR
1944	24	51399	3	OBR
1945	24	51384	3	OBR
1946	24	51392	3	OBR
1947	24	45167	3	OBR
1948	24	51398	3	OBR
1949	24	51391	3	OBR
1950	24	51404	3	OBR
1951	24	51400	4	OBR
1952	24	51414	4	OBR
1953	24	51385	4	OBR
1954	24	45159	4	OBR
1955	24	51397	4	OBR
1956	24	51410	4	OBR
1957	24	51405	4	OBR
1958	24	45129	5	OBR
1959	24	51401	5	OBR
1960	24	51386	5	OBR
1961	24	51403	5	OBR
1962	24	24634	5	OBR
1963	24	30453	5	OBR
1964	24	51390	6	OBR
1965	24	51389	6	OBR
1966	24	51393	6	OBR
1967	24	24641	6	OBR
1968	24	45138	6	OBR
1969	24	34187	6	OBR
1970	24	51412	6	OBR
1971	24	34178	7	OBR
1972	24	51402	7	OBR
1973	24	51388	7	OBR
1974	24	43573	7	OBR
1975	24	51413	7	OBR
1976	24	51407	8	OBR
1977	24	51387	8	OBR
1978	24	34194	8	OBR
1979	24	51382	8	OBR
1980	24	45168	8	OBR
1981	24	45163	99	OPT
1982	24	45150	99	OPT
1983	24	43549	99	OPT
1984	24	45132	99	OPT
1985	24	45155	99	OPT
1986	24	45153	99	OPT
1987	24	45145	99	OPT
1988	24	51383	99	OPT
1989	24	45135	99	OPT
1990	24	45165	99	OPT
1991	24	43823	99	OPT
1992	24	43550	99	OPT
1993	24	43824	99	OPT
1994	24	45141	99	OPT
1995	24	45131	99	OPT
1996	24	45161	99	OPT
1997	24	45142	99	OPT
1998	24	45143	99	OPT
1999	24	45157	99	OPT
2000	24	45128	99	OPT
2001	25	36158	1	OBR
2002	25	50325	1	OBR
2003	25	50329	1	OBR
2004	25	50338	1	OBR
2005	25	50336	1	OBR
2006	25	50322	2	OBR
2007	25	43069	2	OBR
2008	25	50337	2	OBR
2009	25	50335	2	OBR
2010	25	50340	2	OBR
2011	25	43084	3	OBR
2012	25	50323	3	OBR
2013	25	43686	3	OBR
2014	25	50326	3	OBR
2015	25	50320	3	OBR
2016	25	50327	4	OBR
2017	25	50344	4	OBR
2018	25	50330	4	OBR
2019	25	50347	4	OBR
2020	25	50350	4	OBR
2021	25	37085	5	OBR
2022	25	50331	5	OBR
2023	25	50332	5	OBR
2024	25	50351	5	OBR
2025	25	50321	5	OBR
2026	25	50349	6	OBR
2027	25	50343	6	OBR
2028	25	37093	6	OBR
2029	25	50348	6	OBR
2030	25	50341	6	OBR
2031	25	50345	7	OBR
2032	25	50346	7	OBR
2033	25	50334	7	OBR
2034	25	50328	7	OBR
2035	25	50342	7	OBR
2036	25	50324	8	OBR
2037	25	50339	8	OBR
2038	25	50333	8	OBR
2039	25	37105	99	OPT
2040	25	37107	99	OPT
2041	25	37111	99	OPT
2042	25	37113	99	OPT
2043	25	43092	99	OPT
2044	25	43080	99	OPT
2045	25	43082	99	OPT
2046	25	36220	99	OPT
2047	25	37118	99	OPT
2048	25	37120	99	OPT
2049	25	37122	99	OPT
2050	25	43065	99	OPT
2051	25	37125	99	OPT
2052	25	37126	99	OPT
2053	25	43095	99	OPT
2054	25	37128	99	OPT
2055	25	37130	99	OPT
2056	25	35352	99	OPT
2057	25	37133	99	OPT
2058	25	43096	99	OPT
2059	25	43089	99	OPT
2060	25	37140	99	OPT
2061	25	37141	99	OPT
2062	25	37144	99	OPT
2063	25	43097	99	OPT
2064	25	43093	99	OPT
2065	25	43101	99	OPT
2066	25	43102	99	OPT
2067	25	43066	99	OPT
2068	25	43074	99	OPT
2069	25	43072	99	OPT
2070	25	43098	99	OPT
2071	25	43100	99	OPT
2072	25	43068	99	OPT
2073	25	43067	99	OPT
2074	25	43079	99	OPT
2075	25	40950	99	OPT
2076	25	40951	99	OPT
2077	25	43078	99	OPT
2078	25	43099	99	OPT
2079	25	43094	99	OPT
2080	25	40949	99	OPT
2081	25	43064	99	OPT
2082	25	43075	99	OPT
2083	25	37146	99	OPT
2084	25	43071	99	OPT
2085	25	43070	99	OPT
2086	26	36158	1	OBR
2087	26	50325	1	OBR
2088	26	50329	1	OBR
2089	26	50338	1	OBR
2090	26	50336	1	OBR
2091	26	50322	2	OBR
2092	26	43069	2	OBR
2093	26	50337	2	OBR
2094	26	50335	2	OBR
2095	26	50340	2	OBR
2096	26	43084	3	OBR
2097	26	50323	3	OBR
2098	26	43686	3	OBR
2099	26	50326	3	OBR
2100	26	50320	3	OBR
2101	26	50327	4	OBR
2102	26	50344	4	OBR
2103	26	50330	4	OBR
2104	26	50347	4	OBR
2105	26	50350	4	OBR
2106	26	37085	5	OBR
2107	26	50331	5	OBR
2108	26	50332	5	OBR
2109	26	50351	5	OBR
2110	26	50321	5	OBR
2111	26	50349	6	OBR
2112	26	50343	6	OBR
2113	26	37093	6	OBR
2114	26	50348	6	OBR
2115	26	50341	6	OBR
2116	26	50345	7	OBR
2117	26	50346	7	OBR
2118	26	50334	7	OBR
2119	26	50328	7	OBR
2120	26	50342	7	OBR
2121	26	50324	8	OBR
2122	26	50339	8	OBR
2123	26	50333	8	OBR
2124	26	37105	99	OPT
2125	26	37107	99	OPT
2126	26	37111	99	OPT
2127	26	37113	99	OPT
2128	26	43092	99	OPT
2129	26	43080	99	OPT
2130	26	43082	99	OPT
2131	26	36220	99	OPT
2132	26	37118	99	OPT
2133	26	37120	99	OPT
2134	26	37122	99	OPT
2135	26	43065	99	OPT
2136	26	37125	99	OPT
2137	26	37126	99	OPT
2138	26	43095	99	OPT
2139	26	37128	99	OPT
2140	26	37130	99	OPT
2141	26	35352	99	OPT
2142	26	37133	99	OPT
2143	26	43096	99	OPT
2144	26	43089	99	OPT
2145	26	37140	99	OPT
2146	26	37141	99	OPT
2147	26	37144	99	OPT
2148	26	43097	99	OPT
2149	26	43093	99	OPT
2150	26	43101	99	OPT
2151	26	43102	99	OPT
2152	26	43066	99	OPT
2153	26	43074	99	OPT
2154	26	43072	99	OPT
2155	26	43098	99	OPT
2156	26	43100	99	OPT
2157	26	43068	99	OPT
2158	26	43067	99	OPT
2159	26	43079	99	OPT
2160	26	40950	99	OPT
2161	26	40951	99	OPT
2162	26	43078	99	OPT
2163	26	43099	99	OPT
2164	26	43094	99	OPT
2165	26	40949	99	OPT
2166	26	43064	99	OPT
2167	26	43075	99	OPT
2168	26	37146	99	OPT
2169	26	43071	99	OPT
2170	26	43070	99	OPT
2171	27	49093	1	OBR
2172	27	49094	1	OBR
2173	27	49089	1	OBR
2174	27	49111	1	OBR
2175	27	49079	1	OBR
2176	27	49105	1	OBR
2177	27	49090	2	OBR
2178	27	49122	2	OBR
2179	27	49100	2	OBR
2180	27	49101	2	OBR
2181	27	49075	2	OBR
2182	27	49103	2	OBR
2183	27	49087	3	OBR
2184	27	49109	3	OBR
2185	27	49110	3	OBR
2186	27	49151	3	OBR
2187	27	49095	3	OBR
2188	27	49088	3	OBR
2189	27	49086	4	OBR
2190	27	49108	4	OBR
2191	27	49098	4	OBR
2192	27	49113	4	OBR
2193	27	49128	4	OBR
2194	27	49104	4	OBR
2195	27	49076	5	OBR
2196	27	49102	5	OBR
2197	27	49124	5	OBR
2198	27	49125	5	OBR
2199	27	49080	5	OBR
2200	27	49127	5	OBR
2201	27	49078	6	OBR
2202	27	49123	6	OBR
2203	27	49126	6	OBR
2204	27	49129	6	OBR
2205	27	49096	6	OBR
2206	27	49106	6	OBR
2207	27	49118	7	OBR
2208	27	49119	7	OBR
2209	27	49091	7	OBR
2210	27	49150	7	OBR
2211	27	49107	7	OBR
2212	27	49116	8	OBR
2213	27	49099	8	OBR
2214	27	49130	8	OBR
2215	27	49147	8	OBR
2216	27	49155	8	OBR
2217	27	49143	99	OPT
2218	27	49081	99	OPT
2219	27	49082	99	OPT
2220	27	49145	99	OPT
2221	27	49097	99	OPT
2222	27	49152	99	OPT
2223	27	49115	99	OPT
2224	27	49154	99	OPT
2225	27	49144	99	OPT
2226	27	49142	99	OPT
2227	27	49117	99	OPT
2228	27	49157	99	OPT
2229	27	49153	99	OPT
2230	27	49136	99	OPT
2231	27	49131	99	OPT
2232	27	49139	99	OPT
2233	27	49112	99	OPT
2234	27	49114	99	OPT
2235	27	49084	99	OPT
2236	27	49146	99	OPT
2237	27	49140	99	OPT
2238	27	49083	99	NAP
2239	27	49120	99	NAP
2240	27	49121	99	NAP
2241	27	49138	99	OPT
2242	27	49133	99	OPT
2243	27	49148	99	OPT
2244	27	49149	99	OPT
2245	27	49132	99	OPT
2246	27	49137	99	OPT
2247	27	49156	99	OPT
2248	27	49077	99	OPT
2249	27	49134	99	OPT
2250	27	49092	99	OPT
2251	27	49141	99	OPT
2252	27	49085	99	OPT
2253	27	49135	99	OPT
2254	28	50518	1	OBR
2255	28	50607	1	OBR
2256	28	50521	1	OBR
2257	28	50606	2	OBR
2258	28	50622	2	OBR
2259	28	50509	3	OBR
2260	28	50516	3	OBR
2261	28	50614	3	OBR
2262	28	50608	3	OBR
2263	28	44958	4	OBR
2264	28	50523	4	OBR
2265	28	50626	4	OBR
2266	28	50514	4	OBR
2267	28	50613	5	OBR
2268	28	47388	5	OBR
2269	28	47397	5	OBR
2270	28	50508	5	OBR
2271	28	50617	5	OBR
2272	28	50619	6	OBR
2273	28	50611	6	OBR
2274	28	50615	6	OBR
2275	28	50623	6	OBR
2276	28	50618	7	OBR
2277	28	47391	7	OBR
2278	28	50625	7	OBR
2279	28	44968	7	OBR
2280	28	50616	8	OBR
2281	28	50620	8	OBR
2282	28	50601	8	OBR
2283	28	47386	99	OPT
2284	28	47196	99	OPT
2285	28	47381	99	OPT
2286	28	34565	99	OPT
2287	28	47389	99	OPT
2288	28	44950	99	OPT
2289	28	47197	99	OPT
2290	28	47392	99	OPT
2291	28	44992	99	OPT
2292	28	47393	99	OPT
2293	28	47384	99	OPT
2294	28	44964	99	OPT
2295	28	44970	99	OPT
2296	28	44951	99	OPT
2297	28	47400	99	OPT
2298	28	47399	99	OPT
2299	28	44974	99	OPT
2300	28	50605	99	OPT
2301	28	50603	99	OPT
2302	28	44986	99	OPT
2303	28	44990	99	OPT
2304	28	50604	99	OPT
2305	28	44939	99	OPT
2306	28	44975	99	OPT
2307	28	44976	99	OPT
2308	28	45370	99	OPT
2309	29	47141	1	OBR
2310	29	38984	1	OBR
2311	29	47160	1	OBR
2312	29	38986	1	OBR
2313	29	47170	1	OBR
2314	29	47190	1	OBR
2315	29	47165	1	OBR
2316	29	44451	1	OBR
2317	29	38992	1	OBR
2318	29	47193	2	OBR
2319	29	38994	2	OBR
2320	29	38995	2	OBR
2321	29	38996	2	OBR
2322	29	47191	2	OBR
2323	29	44475	2	OBR
2324	29	47156	2	OBR
2325	29	47180	2	OBR
2326	29	39055	3	OBR
2327	29	47169	3	OBR
2328	29	47162	3	OBR
2329	29	44469	3	OBR
2330	29	47166	3	OBR
2331	29	39051	3	OBR
2332	29	39058	3	OBR
2333	29	39059	3	OBR
2334	29	39056	4	OBR
2335	29	47134	4	OBR
2336	29	47161	4	OBR
2337	29	44470	4	OBR
2338	29	47171	4	OBR
2339	29	47118	4	OBR
2340	29	39065	4	OBR
2341	29	47147	4	OBR
2342	29	47133	5	OBR
2343	29	39068	5	OBR
2344	29	47148	5	OBR
2345	29	39081	5	OBR
2346	29	47183	5	OBR
2347	29	47144	5	OBR
2348	29	47146	5	OBR
2349	29	47121	5	OBR
2350	29	47135	5	OBR
2351	29	47194	6	OBR
2352	29	47167	6	OBR
2353	29	47181	6	OBR
2354	29	47120	6	OBR
2355	29	47158	6	OBR
2356	29	47184	6	OBR
2357	29	47189	6	OBR
2358	29	47138	6	OBR
2359	29	47130	7	OBR
2360	29	47177	7	OBR
2361	29	47124	7	OBR
2362	29	47188	7	OBR
2363	29	47192	8	OBR
2364	29	47126	99	OPT
2365	29	47143	99	OPT
2366	29	47178	99	OPT
2367	29	47163	99	OPT
2368	29	47159	99	OPT
2369	29	47119	99	OPT
2370	29	44468	99	OPT
2371	29	47103	99	OPT
2372	29	47104	99	OPT
2373	29	47105	99	OPT
2374	29	47157	99	OPT
2375	29	47152	99	OPT
2376	29	47139	99	OPT
2377	29	47140	99	OPT
2378	29	47185	99	OPT
2379	29	47110	99	OPT
2380	29	47128	99	OPT
2381	29	47179	99	OPT
2382	29	47123	99	OPT
2383	29	47127	99	OPT
2384	29	47168	99	OPT
2385	29	39105	99	OPT
2386	29	44455	99	OPT
2387	29	47116	99	OPT
2388	29	47125	99	OPT
2389	29	34565	99	OPT
2390	29	47137	99	OPT
2391	29	44464	99	OPT
2392	29	44463	99	OPT
2393	29	47132	99	OPT
2394	29	47151	99	OPT
2395	29	47195	99	OPT
2396	29	47115	99	OPT
2397	29	47182	99	OPT
2398	29	47108	99	OPT
2399	29	47107	99	OPT
2400	29	47129	99	OPT
2401	29	47109	99	OPT
2402	29	47106	99	OPT
2403	29	47136	99	OPT
2404	29	44476	99	OPT
2405	29	47172	99	OPT
2406	29	47174	99	OPT
2407	29	39112	99	OPT
2408	29	47175	99	OPT
2409	29	47176	99	OPT
2410	29	39114	99	OPT
2411	29	47101	99	OPT
2412	29	47145	99	OPT
2413	29	47154	99	OPT
2414	29	47186	99	OPT
2415	29	47102	99	OPT
2416	29	47122	99	OPT
2417	29	39115	99	OPT
2418	29	39116	99	OPT
2419	29	47187	99	OPT
2420	29	47173	99	OPT
2421	29	47117	99	OPT
2422	29	47114	99	OPT
2423	29	47111	99	OPT
2424	29	47112	99	OPT
2425	29	47164	99	OPT
2426	29	44995	99	OPT
2427	29	44968	99	OPT
2428	29	47094	99	OPT
2429	29	47150	99	OPT
2430	29	47153	99	OPT
2431	29	47113	99	OPT
2432	29	47142	99	OPT
2433	29	44456	99	OPT
2434	29	44453	99	OPT
2435	29	44459	99	OPT
2436	29	47131	99	OPT
2437	29	47155	99	OPT
2438	29	47149	99	OPT
2439	30	50014	1	OBR
2440	30	50004	1	OBR
2441	30	49988	1	OBR
2442	30	39194	1	OBR
2443	30	50024	1	OBR
2444	30	49986	1	OBR
2445	30	50019	1	OBR
2446	30	35182	2	OBR
2447	30	50030	2	OBR
2448	30	49989	2	OBR
2449	30	43788	2	OBR
2450	30	50008	2	OBR
2451	30	50006	2	OBR
2452	30	50022	2	OBR
2453	30	50020	3	OBR
2454	30	50007	3	OBR
2455	30	49999	3	OBR
2456	30	49987	3	OBR
2457	30	50021	3	OBR
2458	30	43783	3	OBR
2459	30	50023	3	OBR
2460	30	34565	4	OBR
2461	30	50032	4	OBR
2462	30	49990	4	OBR
2463	30	49981	4	OBR
2464	30	50025	4	OBR
2465	30	50027	4	OBR
2466	30	50028	4	OBR
2467	30	50031	5	OBR
2468	30	49984	5	OBR
2469	30	35198	5	OBR
2470	30	50009	5	OBR
2471	30	49997	5	OBR
2472	30	50005	5	OBR
2473	30	49983	5	OBR
2474	30	50000	6	OBR
2475	30	50012	6	OBR
2476	30	50010	6	OBR
2477	30	50011	6	OBR
2478	30	49991	6	OBR
2479	30	50017	6	OBR
2480	30	50002	6	OBR
2481	30	43775	7	OBR
2482	30	50033	7	OBR
2483	30	49982	7	OBR
2484	30	50026	7	OBR
2485	30	50001	7	OBR
2486	30	49985	7	OBR
2487	30	50016	7	OBR
2488	30	50003	8	OBR
2489	30	50013	8	OBR
2490	30	50029	8	OBR
2491	30	49998	8	OBR
2492	30	50018	8	OBR
2493	30	49992	8	OBR
2494	30	50015	8	OBR
2495	30	37807	99	OPT
2496	30	37808	99	OPT
2497	30	37809	99	OPT
2498	30	37810	99	OPT
2499	30	37811	99	OPT
2500	30	37812	99	OPT
2501	30	37813	99	OPT
2502	30	37814	99	OPT
2503	30	37815	99	OPT
2504	30	37816	99	OPT
2505	30	37817	99	OPT
2506	30	49993	99	OPT
2507	30	37818	99	OPT
2508	30	37819	99	OPT
2509	30	37820	99	OPT
2510	30	43789	99	OPT
2511	30	37821	99	OPT
2512	30	37822	99	OPT
2513	30	37823	99	OPT
2514	30	37824	99	OPT
2515	30	37825	99	OPT
2516	30	37826	99	OPT
2517	30	43778	99	OPT
2518	30	37888	99	OPT
2519	30	37827	99	OPT
2520	30	37828	99	OPT
2521	30	37829	99	OPT
2522	30	37830	99	OPT
2523	30	37831	99	OPT
2524	30	37833	99	OPT
2525	30	37834	99	OPT
2526	30	37835	99	OPT
2527	30	37836	99	OPT
2528	30	49994	99	OPT
2529	30	37838	99	OPT
2530	30	37839	99	OPT
2531	30	37840	99	OPT
2532	30	43777	99	OPT
2533	30	37842	99	OPT
2534	30	37843	99	OPT
2535	30	43779	99	OPT
2536	30	43787	99	OPT
2537	30	37844	99	OPT
2538	30	37845	99	OPT
2539	30	49995	99	OPT
2540	30	37846	99	OPT
2541	30	49996	99	OPT
2542	31	49352	1	OBR
2543	31	49348	1	OBR
2544	31	49349	1	OBR
2545	31	49350	1	OBR
2546	31	49354	1	OBR
2547	31	49353	2	OBR
2548	31	49355	2	OBR
2549	31	49395	2	OBR
2550	31	49378	2	OBR
2551	31	49396	2	OBR
2552	31	49399	2	OBR
2553	31	49366	3	OBR
2554	31	49351	3	OBR
2555	31	49356	3	OBR
2556	31	49360	3	OBR
2557	31	49391	3	OBR
2558	31	49358	3	OBR
2559	31	49365	4	OBR
2560	31	49388	4	OBR
2561	31	49328	4	OBR
2562	31	49389	4	OBR
2563	31	49364	4	OBR
2564	31	49392	4	OBR
2565	31	49325	5	OBR
2566	31	49367	5	OBR
2567	31	49326	5	OBR
2568	31	49374	5	OBR
2569	31	49357	5	OBR
2570	31	49368	5	OBR
2571	31	49363	6	OBR
2572	31	49393	6	OBR
2573	31	49397	6	OBR
2574	31	49370	6	OBR
2575	31	49361	6	OBR
2576	31	49362	6	OBR
2577	31	49359	7	OBR
2578	31	49390	7	OBR
2579	31	49372	7	OBR
2580	31	47241	7	OBR
2581	31	49327	7	OBR
2582	31	49373	7	OBR
2583	31	49375	7	OBR
2584	31	49329	8	OBR
2585	31	49376	8	OBR
2586	31	49398	8	OBR
2587	31	49379	8	OBR
2588	31	47242	8	OBR
2589	31	49371	8	OBR
2590	31	49330	99	OPT
2591	31	49394	99	OPT
2592	31	49339	99	OPT
2593	31	49332	99	OPT
2594	31	44999	99	NAP
2595	31	49340	99	OPT
2596	31	45009	99	OPT
2597	31	49380	99	OPT
2598	31	45010	99	OPT
2599	31	49369	99	OPT
2600	31	49346	99	OPT
2601	31	49331	99	OPT
2602	31	45000	99	NAP
2603	31	45002	99	NAP
2604	31	49334	99	OPT
2605	31	49337	99	OPT
2606	31	49344	99	OPT
2607	31	49347	99	OPT
2608	31	49341	99	OPT
2609	31	49345	99	OPT
2610	31	49377	99	OPT
2611	31	49342	99	OPT
2612	31	45020	99	OPT
2613	31	45015	99	OPT
2614	31	49381	99	OPT
2615	31	49336	99	OPT
2616	31	49384	99	OPT
2617	31	49333	99	OPT
2618	31	49338	99	OPT
2619	31	45001	99	NAP
2620	31	51817	99	OPT
2621	31	51818	99	OPT
2622	31	51819	99	OPT
2623	31	49387	99	OPT
2624	31	49386	99	OPT
2625	31	49385	99	OPT
2626	31	49382	99	OPT
2627	31	49383	99	OPT
2628	31	49343	99	OPT
2629	31	49335	99	OPT
2630	31	45024	99	OPT
2631	32	51427	1	OBR
2632	32	51436	1	OBR
2633	32	51429	1	OBR
2634	32	51445	1	OBR
2635	32	47042	1	OBR
2636	32	51426	1	OBR
2637	32	51420	2	OBR
2638	32	51428	2	OBR
2639	32	51418	2	OBR
2640	32	51452	2	OBR
2641	32	51454	2	OBR
2642	32	34491	2	OBR
2643	32	47051	2	OBR
2644	32	47036	3	OBR
2645	32	51467	3	OBR
2646	32	51424	3	OBR
2647	32	34545	3	OBR
2648	32	51466	3	OBR
2649	32	47075	3	OBR
2650	32	52155	4	OBR
2651	32	51463	4	OBR
2652	32	51457	4	OBR
2653	32	52157	4	OBR
2654	32	51450	4	OBR
2655	32	51458	5	OBR
2656	32	51455	5	OBR
2657	32	51444	5	OBR
2658	32	47072	5	OBR
2659	32	51421	5	OBR
2660	32	51433	6	OBR
2661	32	51437	6	OBR
2662	32	52156	6	OBR
2663	32	46996	6	OBR
2664	32	51422	6	OBR
2665	32	51464	7	OBR
2666	32	46993	7	OBR
2667	32	51417	7	OBR
2668	32	51423	7	OBR
2669	32	52150	7	OBR
2670	32	46990	7	OBR
2671	32	47078	7	OBR
2672	32	51443	7	OBR
2673	32	51438	8	OBR
2674	32	51461	8	OBR
2675	32	34540	8	OBR
2676	32	51419	8	OBR
2677	32	52149	8	OBR
2678	32	52148	8	OBR
2679	32	51449	8	OBR
2680	32	51442	9	OBR
2681	32	51440	9	OBR
2682	32	51462	9	OBR
2683	32	51425	9	OBR
2684	32	34544	9	OBR
2685	32	34548	9	OBR
2686	32	51416	9	OBR
2687	32	52151	9	OBR
2688	32	52147	10	OBR
2689	32	51439	10	OBR
2690	32	51459	10	OBR
2691	32	51451	10	OBR
2692	32	51446	10	OBR
2693	32	51453	10	OBR
2694	32	52152	10	OBR
2695	32	51441	10	OBR
2696	32	47003	99	OPT
2697	32	47000	99	OPT
2698	32	51435	99	OPT
2699	32	47065	99	OPT
2700	32	47004	99	OPT
2701	32	34553	99	OPT
2702	32	47082	99	OPT
2703	32	47079	99	OPT
2704	32	46995	99	OPT
2705	32	47086	99	OPT
2706	32	34555	99	OPT
2707	32	47026	99	OPT
2708	32	34556	99	OPT
2709	32	47057	99	OPT
2710	32	51415	99	OPT
2711	32	47009	99	OPT
2712	32	47022	99	OPT
2713	32	34557	99	OPT
2714	32	47088	99	OPT
2715	32	47017	99	OPT
2716	32	47012	99	OPT
2717	32	34558	99	OPT
2718	32	47005	99	OPT
2719	32	47019	99	OPT
2720	32	47016	99	OPT
2721	32	34559	99	OPT
2722	32	47063	99	OPT
2723	32	47030	99	OPT
2724	32	47032	99	OPT
2725	32	47033	99	OPT
2726	32	52153	99	OPT
2727	32	47038	99	OPT
2728	32	47041	99	OPT
2729	32	51460	99	OPT
2730	32	47044	99	OPT
2731	32	52154	99	OPT
2732	32	47084	99	OPT
2733	32	47001	99	OPT
2734	32	47011	99	OPT
2735	32	34563	99	OPT
2736	32	47013	99	OPT
2737	32	47018	99	OPT
2738	32	47081	99	OPT
2739	32	47073	99	OPT
2740	32	47040	99	OPT
2741	32	47052	99	OPT
2742	32	43686	99	OPT
2743	32	47045	99	OPT
2744	32	25678	99	OPT
2745	32	47014	99	OPT
2746	32	47089	99	OPT
2747	32	47020	99	OPT
2748	32	47083	99	OPT
2749	32	51456	99	OPT
2750	32	47031	99	OPT
2751	32	47029	99	OPT
2752	32	46989	99	OPT
2753	32	46975	99	OPT
2754	32	51448	99	OPT
2755	32	34569	99	OPT
2756	32	34570	99	OPT
2757	32	46980	99	OPT
2758	32	47066	99	OPT
2759	32	46992	99	OPT
2760	32	47061	99	OPT
2761	32	46976	99	OPT
2762	32	47067	99	OPT
2763	32	46977	99	OPT
2764	32	34572	99	OPT
2765	32	47076	99	OPT
2766	32	47090	99	OPT
2767	32	34573	99	OPT
2768	32	47054	99	OPT
2769	32	46983	99	OPT
2770	32	46991	99	OPT
2771	32	34574	99	OPT
2772	32	47046	99	OPT
2773	32	46985	99	OPT
2774	32	46984	99	OPT
2775	32	46978	99	OPT
2776	32	46987	99	OPT
2777	32	46986	99	OPT
2778	32	34576	99	OPT
2779	32	47043	99	OPT
2780	32	47021	99	OPT
2781	32	47025	99	OPT
2782	32	46998	99	OPT
2783	32	47068	99	OPT
2784	32	47074	99	OPT
2785	32	47071	99	OPT
2786	32	47087	99	OPT
2787	32	46981	99	OPT
2788	32	47023	99	OPT
2789	32	47024	99	OPT
2790	32	46979	99	OPT
2791	32	47069	99	OPT
2792	32	47070	99	OPT
2793	32	51434	99	OPT
2794	33	50077	1	OBR
2795	33	50014	1	OBR
2796	33	49988	1	OBR
2797	33	39194	1	OBR
2798	33	50024	1	OBR
2799	33	49986	1	OBR
2800	33	50019	1	OBR
2801	33	35182	2	OBR
2802	33	50030	2	OBR
2803	33	50078	2	OBR
2804	33	43788	2	OBR
2805	33	50008	2	OBR
2806	33	50006	2	OBR
2807	33	50022	2	OBR
2808	33	50079	3	OBR
2809	33	50020	3	OBR
2810	33	50007	3	OBR
2811	33	49987	3	OBR
2812	33	50021	3	OBR
2813	33	43783	3	OBR
2814	33	50023	3	OBR
2815	33	34565	4	OBR
2816	33	50032	4	OBR
2817	33	49981	4	OBR
2818	33	50025	4	OBR
2819	33	50027	4	OBR
2820	33	50028	4	OBR
2821	33	50080	4	OBR
2822	33	49984	5	OBR
2823	33	50088	5	OBR
2824	33	50081	5	OBR
2825	33	35198	5	OBR
2826	33	49997	5	OBR
2827	33	50005	5	OBR
2828	33	49983	5	OBR
2829	33	50012	6	OBR
2830	33	50083	6	OBR
2831	33	50010	6	OBR
2832	33	50011	6	OBR
2833	33	50017	6	OBR
2834	33	50002	6	OBR
2835	33	50082	6	OBR
2836	33	43775	7	OBR
2837	33	49982	7	OBR
2838	33	50001	7	OBR
2839	33	50084	7	OBR
2840	33	50016	7	OBR
2841	33	50087	7	OBR
2842	33	50013	8	OBR
2843	33	49998	8	OBR
2844	33	50018	8	OBR
2845	33	50085	8	OBR
2846	33	49992	8	OBR
2847	33	50086	8	OBR
2848	33	37807	99	OPT
2849	33	37808	99	OPT
2850	33	37809	99	OPT
2851	33	37810	99	OPT
2852	33	37811	99	OPT
2853	33	37812	99	OPT
2854	33	37813	99	OPT
2855	33	37814	99	OPT
2856	33	37815	99	OPT
2857	33	37816	99	OPT
2858	33	37817	99	OPT
2859	33	49993	99	OPT
2860	33	37818	99	OPT
2861	33	39904	99	OPT
2862	33	37820	99	OPT
2863	33	37821	99	OPT
2864	33	37822	99	OPT
2865	33	37823	99	OPT
2866	33	37824	99	OPT
2867	33	37825	99	OPT
2868	33	37826	99	OPT
2869	33	43778	99	OPT
2870	33	37888	99	OPT
2871	33	37827	99	OPT
2872	33	37828	99	OPT
2873	33	37829	99	OPT
2874	33	37830	99	OPT
2875	33	37831	99	OPT
2876	33	37833	99	OPT
2877	33	37834	99	OPT
2878	33	37835	99	OPT
2879	33	37836	99	OPT
2880	33	49994	99	OPT
2881	33	37839	99	OPT
2882	33	39905	99	OPT
2883	33	43777	99	OPT
2884	33	37842	99	OPT
2885	33	37843	99	OPT
2886	33	43779	99	OPT
2887	33	43043	99	OPT
2888	33	37844	99	OPT
2889	33	37845	99	OPT
2890	33	49995	99	OPT
2891	33	37846	99	OPT
2892	33	49996	99	OPT
2893	34	49517	1	OBR
2894	34	35278	1	OBR
2895	34	49513	1	OBR
2896	34	50585	1	OBR
2897	34	49491	1	OBR
2898	34	35275	2	OBR
2899	34	49504	2	OBR
2900	34	50914	2	OBR
2901	34	35274	2	OBR
2902	34	49514	2	OBR
2903	34	49486	3	OBR
2904	34	35284	3	OBR
2905	34	49500	3	OBR
2906	34	35273	3	OBR
2907	34	49503	3	OBR
2908	34	49501	4	OBR
2909	34	35276	4	OBR
2910	34	49497	4	OBR
2911	34	49519	4	OBR
2912	34	49518	4	OBR
2913	34	49496	5	OBR
2914	34	49505	5	OBR
2915	34	49494	5	OBR
2916	34	35282	5	OBR
2917	34	49485	6	OBR
2918	34	35289	6	OBR
2919	34	49490	6	OBR
2920	34	49499	6	OBR
2921	34	50929	7	OBR
2922	34	49492	7	OBR
2923	34	49507	7	OBR
2924	34	49502	7	OBR
2925	34	35363	8	OBR
2926	34	43686	8	OBR
2927	34	49488	8	OBR
2928	34	49495	8	OBR
2929	34	35367	99	OPT
2930	34	35368	99	OPT
2931	34	35369	99	OPT
2932	34	35371	99	OPT
2933	34	35372	99	OPT
2934	34	49489	99	OPT
2935	34	35374	99	OPT
2936	34	50581	99	OPT
2937	34	35375	99	OPT
2938	34	35376	99	OPT
2939	34	47281	99	OPT
2940	34	35377	99	OPT
2941	34	50916	99	OPT
2942	34	35261	99	OPT
2943	34	35378	99	OPT
2944	34	35110	99	OPT
2945	34	34522	99	OPT
2946	34	49487	99	OPT
2947	34	35392	99	OPT
2948	34	35393	99	OPT
2949	34	35395	99	OPT
2950	34	49639	99	OPT
2951	34	35399	99	OPT
2952	34	35400	99	OPT
2953	34	35401	99	OPT
2954	34	52162	99	OPT
2955	34	37831	99	OPT
2956	34	49640	99	OPT
2957	34	35404	99	OPT
2958	34	47269	99	OPT
2959	34	35407	99	OPT
2960	34	35111	99	OPT
2961	34	35409	99	OPT
2962	34	35412	99	OPT
2963	34	35413	99	OPT
2964	34	35414	99	OPT
2965	34	35415	99	OPT
2966	34	35416	99	OPT
2967	34	35417	99	OPT
2968	34	35418	99	OPT
2969	34	35419	99	OPT
2970	34	49508	99	OPT
2971	34	49509	99	OPT
2972	34	49510	99	OPT
2973	34	49511	99	OPT
2974	34	49512	99	OPT
2975	34	35420	99	OPT
2976	34	51817	99	OPT
2977	34	51818	99	OPT
2978	34	52158	99	OPT
2979	34	52159	99	OPT
2980	34	52160	99	OPT
2981	34	52161	99	OPT
2982	35	51562	1	OBR
2983	35	43675	1	OBR
2984	35	43614	1	OBR
2985	35	43630	1	OBR
2986	35	51563	2	OBR
2987	35	43628	2	OBR
2988	35	43582	2	OBR
2989	35	43631	2	OBR
2990	35	43649	3	OBR
2991	35	43625	3	OBR
2992	35	43583	3	OBR
2993	35	43632	3	OBR
2994	35	51561	3	OBR
2995	35	43674	4	OBR
2996	35	43676	4	OBR
2997	35	43584	4	OBR
2998	35	43636	4	OBR
2999	35	43602	5	OBR
3000	35	43677	5	OBR
3001	35	43586	5	OBR
3002	35	43633	5	OBR
3003	35	51567	5	OBR
3004	35	43650	6	OBR
3005	35	43678	6	OBR
3006	35	51559	6	OBR
3007	35	43587	6	OBR
3008	35	43634	6	OBR
3009	35	43651	7	OBR
3010	35	43621	7	OBR
3011	35	51570	7	OBR
3012	35	43616	7	OBR
3013	35	43646	7	OBR
3014	35	51564	7	OBR
3015	35	51566	8	OBR
3016	35	43679	8	OBR
3017	35	51560	8	OBR
3018	35	43661	8	OBR
3019	35	43637	8	OBR
3020	35	51558	8	OBR
3021	35	51555	9	OBR
3022	35	51556	9	OBR
3023	35	51553	9	OBR
3024	35	51552	9	OBR
3025	35	51568	10	OBR
3026	35	51548	10	OBR
3027	35	51557	10	OBR
3028	35	51569	10	OBR
3029	35	51543	11	OBR
3030	35	51549	11	OBR
3031	35	51550	11	OBR
3032	35	51565	12	OBR
3033	35	51551	12	OBR
3034	35	51554	12	OBR
3035	35	43673	99	OPT
3036	35	39062	99	OPT
3037	35	43595	99	OPT
3038	35	46087	99	OPT
3039	35	46073	99	OPT
3040	35	46095	99	OPT
3041	35	46083	99	OPT
3042	35	43609	99	OPT
3043	35	43611	99	OPT
3044	35	43592	99	OPT
3045	35	46085	99	OPT
3046	35	43680	99	OPT
3047	35	35261	99	OPT
3048	35	43593	99	OPT
3049	35	43686	99	OPT
3050	35	34565	99	OPT
3051	35	43597	99	OPT
3052	35	43660	99	OPT
3053	35	43594	99	OPT
3054	35	43596	99	OPT
3055	35	46092	99	OPT
3056	35	43598	99	OPT
3057	35	43664	99	OPT
3058	35	43662	99	OPT
3059	35	43652	99	OPT
3060	35	46094	99	OPT
3061	35	46097	99	OPT
3062	35	43588	99	OPT
3063	35	40105	99	OPT
3064	35	43608	99	OPT
3065	35	46093	99	OPT
3066	35	51545	99	OPT
3067	35	46078	99	OPT
3068	35	43613	99	OPT
3069	35	43603	99	OPT
3070	35	37831	99	OPT
3071	35	43667	99	OPT
3072	35	43615	99	OPT
3073	35	46086	99	OPT
3074	35	43668	99	OPT
3075	35	43682	99	OPT
3076	35	43601	99	OPT
3077	35	40113	99	OPT
3078	35	43617	99	OPT
3079	35	43618	99	OPT
3080	35	46067	99	OPT
3081	35	46072	99	OPT
3082	35	46068	99	OPT
3083	35	43669	99	OPT
3084	35	46166	99	OPT
3085	35	46186	99	OPT
3086	35	46069	99	OPT
3087	35	43619	99	OPT
3088	35	46066	99	OPT
3089	35	46070	99	OPT
3090	35	46063	99	OPT
3091	35	46178	99	OPT
3092	35	43624	99	OPT
3093	35	46065	99	OPT
3094	35	46088	99	OPT
3095	35	46172	99	OPT
3096	35	46177	99	OPT
3097	35	43670	99	OPT
3098	35	46169	99	OPT
3099	35	46064	99	OPT
3100	35	46082	99	OPT
3101	35	51546	99	OPT
3102	35	51544	99	OPT
3103	35	46089	99	OPT
3104	35	46061	99	OPT
3105	35	46084	99	OPT
3106	35	46090	99	OPT
3107	35	46170	99	OPT
3108	35	51547	99	OPT
3109	35	46174	99	OPT
3110	35	46179	99	OPT
3111	35	46182	99	OPT
3112	35	46176	99	OPT
3113	35	46062	99	OPT
3114	35	43620	99	OPT
3115	35	43672	99	OPT
3116	36	50014	1	OBR
3117	36	50092	1	OBR
3118	36	49988	1	OBR
3119	36	39194	1	OBR
3120	36	50024	1	OBR
3121	36	49986	1	OBR
3122	36	50019	1	OBR
3123	36	35182	2	OBR
3124	36	50030	2	OBR
3125	36	50093	2	OBR
3126	36	43788	2	OBR
3127	36	50008	2	OBR
3128	36	50006	2	OBR
3129	36	50022	2	OBR
3130	36	50020	3	OBR
3131	36	50007	3	OBR
3132	36	50094	3	OBR
3133	36	49987	3	OBR
3134	36	50021	3	OBR
3135	36	43783	3	OBR
3136	36	50023	3	OBR
3137	36	34565	4	OBR
3138	36	50032	4	OBR
3139	36	50102	4	OBR
3140	36	49981	4	OBR
3141	36	50025	4	OBR
3142	36	50027	4	OBR
3143	36	50028	4	OBR
3144	36	50095	5	OBR
3145	36	49984	5	OBR
3146	36	35198	5	OBR
3147	36	50096	5	OBR
3148	36	49997	5	OBR
3149	36	50005	5	OBR
3150	36	49983	5	OBR
3151	36	50100	6	OBR
3152	36	50012	6	OBR
3153	36	50010	6	OBR
3154	36	50011	6	OBR
3155	36	50089	6	OBR
3156	36	50017	6	OBR
3157	36	50002	6	OBR
3158	36	43775	7	OBR
3159	36	50099	7	OBR
3160	36	49982	7	OBR
3161	36	50090	7	OBR
3162	36	50001	7	OBR
3163	36	50097	7	OBR
3164	36	50016	7	OBR
3165	36	50101	8	OBR
3166	36	50013	8	OBR
3167	36	50091	8	OBR
3168	36	49998	8	OBR
3169	36	50018	8	OBR
3170	36	49992	8	OBR
3171	36	50098	8	OBR
3172	36	37807	99	OPT
3173	36	37808	99	OPT
3174	36	37809	99	OPT
3175	36	37810	99	OPT
3176	36	37811	99	OPT
3177	36	37812	99	OPT
3178	36	37813	99	OPT
3179	36	37814	99	OPT
3180	36	37815	99	OPT
3181	36	37816	99	OPT
3182	36	37817	99	OPT
3183	36	49993	99	OPT
3184	36	37818	99	OPT
3185	36	37819	99	OPT
3186	36	37820	99	OPT
3187	36	43789	99	OPT
3188	36	37821	99	OPT
3189	36	37822	99	OPT
3190	36	37823	99	OPT
3191	36	37824	99	OPT
3192	36	37825	99	OPT
3193	36	37826	99	OPT
3194	36	43778	99	OPT
3195	36	37888	99	OPT
3196	36	37827	99	OPT
3197	36	37828	99	OPT
3198	36	37829	99	OPT
3199	36	37830	99	OPT
3200	36	37831	99	OPT
3201	36	37833	99	OPT
3202	36	37834	99	OPT
3203	36	37835	99	OPT
3204	36	37836	99	OPT
3205	36	49994	99	OPT
3206	36	37838	99	OPT
3207	36	37839	99	OPT
3208	36	37840	99	OPT
3209	36	37841	99	OPT
3210	36	43777	99	OPT
3211	36	37842	99	OPT
3212	36	37843	99	OPT
3213	36	43779	99	OPT
3214	36	43787	99	OPT
3215	36	37844	99	OPT
3216	36	37845	99	OPT
3217	36	49995	99	OPT
3218	36	37846	99	OPT
3219	36	49996	99	OPT
3220	37	51427	1	OBR
3221	37	51436	1	OBR
3222	37	51429	1	OBR
3223	37	51445	1	OBR
3224	37	47042	1	OBR
3225	37	51426	1	OBR
3226	37	51420	2	OBR
3227	37	51428	2	OBR
3228	37	51418	2	OBR
3229	37	51452	2	OBR
3230	37	51454	2	OBR
3231	37	34491	2	OBR
3232	37	47051	2	OBR
3233	37	47036	3	OBR
3234	37	51467	3	OBR
3235	37	51424	3	OBR
3236	37	34545	3	OBR
3237	37	51466	3	OBR
3238	37	47075	3	OBR
3239	37	52155	4	OBR
3240	37	51463	4	OBR
3241	37	51457	4	OBR
3242	37	52157	4	OBR
3243	37	51450	4	OBR
3244	37	51458	5	OBR
3245	37	51455	5	OBR
3246	37	51444	5	OBR
3247	37	47072	5	OBR
3248	37	51421	5	OBR
3249	37	51433	6	OBR
3250	37	51437	6	OBR
3251	37	52156	6	OBR
3252	37	46996	6	OBR
3253	37	51422	6	OBR
3254	37	51464	7	OBR
3255	37	46993	7	OBR
3256	37	51417	7	OBR
3257	37	51423	7	OBR
3258	37	52150	7	OBR
3259	37	46990	7	OBR
3260	37	47078	7	OBR
3261	37	51443	7	OBR
3262	37	51438	8	OBR
3263	37	51461	8	OBR
3264	37	34540	8	OBR
3265	37	51419	8	OBR
3266	37	52149	8	OBR
3267	37	52148	8	OBR
3268	37	51449	8	OBR
3269	37	51442	9	OBR
3270	37	51440	9	OBR
3271	37	51462	9	OBR
3272	37	51425	9	OBR
3273	37	34544	9	OBR
3274	37	34548	9	OBR
3275	37	51416	9	OBR
3276	37	52151	9	OBR
3277	37	52147	10	OBR
3278	37	51439	10	OBR
3279	37	51459	10	OBR
3280	37	51451	10	OBR
3281	37	51446	10	OBR
3282	37	51453	10	OBR
3283	37	52152	10	OBR
3284	37	51441	10	OBR
3285	37	47003	99	OPT
3286	37	47000	99	OPT
3287	37	51435	99	OPT
3288	37	47065	99	OPT
3289	37	47004	99	OPT
3290	37	34553	99	OPT
3291	37	47082	99	OPT
3292	37	47079	99	OPT
3293	37	46995	99	OPT
3294	37	47086	99	OPT
3295	37	34555	99	OPT
3296	37	47026	99	OPT
3297	37	34556	99	OPT
3298	37	47057	99	OPT
3299	37	51415	99	OPT
3300	37	47009	99	OPT
3301	37	47022	99	OPT
3302	37	34557	99	OPT
3303	37	47088	99	OPT
3304	37	47017	99	OPT
3305	37	47012	99	OPT
3306	37	34558	99	OPT
3307	37	47005	99	OPT
3308	37	47019	99	OPT
3309	37	47016	99	OPT
3310	37	34559	99	OPT
3311	37	47063	99	OPT
3312	37	47030	99	OPT
3313	37	47032	99	OPT
3314	37	47033	99	OPT
3315	37	52153	99	OPT
3316	37	47038	99	OPT
3317	37	47041	99	OPT
3318	37	51460	99	OPT
3319	37	47044	99	OPT
3320	37	52154	99	OPT
3321	37	47084	99	OPT
3322	37	47001	99	OPT
3323	37	47011	99	OPT
3324	37	34563	99	OPT
3325	37	47013	99	OPT
3326	37	47018	99	OPT
3327	37	47081	99	OPT
3328	37	47073	99	OPT
3329	37	47040	99	OPT
3330	37	47052	99	OPT
3331	37	43686	99	OPT
3332	37	47045	99	OPT
3333	37	25678	99	OPT
3334	37	47014	99	OPT
3335	37	47089	99	OPT
3336	37	47020	99	OPT
3337	37	47083	99	OPT
3338	37	51456	99	OPT
3339	37	47031	99	OPT
3340	37	47029	99	OPT
3341	37	46989	99	OPT
3342	37	46975	99	OPT
3343	37	51448	99	OPT
3344	37	34569	99	OPT
3345	37	34570	99	OPT
3346	37	46980	99	OPT
3347	37	47066	99	OPT
3348	37	46992	99	OPT
3349	37	47061	99	OPT
3350	37	46976	99	OPT
3351	37	47067	99	OPT
3352	37	46977	99	OPT
3353	37	34572	99	OPT
3354	37	47076	99	OPT
3355	37	47090	99	OPT
3356	37	34573	99	OPT
3357	37	47054	99	OPT
3358	37	46983	99	OPT
3359	37	46991	99	OPT
3360	37	34574	99	OPT
3361	37	47046	99	OPT
3362	37	46985	99	OPT
3363	37	46984	99	OPT
3364	37	46978	99	OPT
3365	37	46987	99	OPT
3366	37	46986	99	OPT
3367	37	34576	99	OPT
3368	37	47043	99	OPT
3369	37	47021	99	OPT
3370	37	47025	99	OPT
3371	37	46998	99	OPT
3372	37	47068	99	OPT
3373	37	47074	99	OPT
3374	37	47071	99	OPT
3375	37	47087	99	OPT
3376	37	46981	99	OPT
3377	37	47023	99	OPT
3378	37	47024	99	OPT
3379	37	46979	99	OPT
3380	37	47069	99	OPT
3381	37	47070	99	OPT
3382	37	51434	99	OPT
3383	38	49250	1	OBR
3384	38	36213	1	OBR
3385	38	36226	1	OBR
3386	38	36229	1	OBR
3387	38	49257	1	OBR
3388	38	36235	2	OBR
3389	38	49264	2	OBR
3390	38	36233	2	OBR
3391	38	36234	2	OBR
3392	38	35182	3	OBR
3393	38	35198	3	OBR
3394	38	49265	3	OBR
3395	38	49251	3	OBR
3396	38	49262	4	OBR
3397	38	49255	4	OBR
3398	38	36240	4	OBR
3399	38	49281	4	OBR
3400	38	39194	4	OBR
3401	38	43775	5	OBR
3402	38	49253	5	OBR
3403	38	49285	5	OBR
3404	38	49282	5	OBR
3405	38	49284	5	OBR
3406	38	49256	6	OBR
3407	38	49283	6	OBR
3408	38	36247	6	OBR
3409	38	49273	6	OBR
3410	38	43783	6	OBR
3411	38	49249	6	OBR
3412	38	49258	7	OBR
3413	38	34565	7	OBR
3414	38	49266	7	OBR
3415	38	36252	7	OBR
3416	38	49272	7	OBR
3417	38	49267	8	OBR
3418	38	36254	8	OBR
3419	38	49275	8	OBR
3420	38	49278	8	OBR
3421	38	49252	99	OPT
3422	38	39496	99	OPT
3423	38	34520	99	OPT
3424	38	49279	99	OPT
3425	38	49270	99	OPT
3426	38	43960	99	OPT
3427	38	49254	99	OPT
3428	38	49260	99	OPT
3429	38	49280	99	OPT
3430	38	39497	99	OPT
3431	38	43966	99	OPT
3432	38	49261	99	OPT
3433	38	36130	99	OPT
3434	38	39498	99	OPT
3435	38	39499	99	OPT
3436	38	43968	99	OPT
3437	38	49269	99	OPT
3438	38	39500	99	OPT
3439	38	39507	99	OPT
3440	38	43961	99	OPT
3441	38	39508	99	OPT
3442	38	39509	99	OPT
3443	38	43974	99	OPT
3444	38	43964	99	OPT
3445	38	39510	99	OPT
3446	38	43969	99	OPT
3447	38	43965	99	OPT
3448	38	49276	99	OPT
3449	38	49263	99	OPT
3450	38	39511	99	OPT
3451	38	43971	99	OPT
3452	38	49268	99	OPT
3453	38	43963	99	OPT
3454	38	43970	99	OPT
3455	38	39512	99	OPT
3456	38	39513	99	OPT
3457	38	39514	99	OPT
3458	38	43967	99	OPT
3459	38	39515	99	OPT
3460	38	39516	99	OPT
3461	38	49274	99	OPT
3462	38	39517	99	OPT
3463	38	39519	99	OPT
3464	38	43975	99	OPT
3465	38	39518	99	OPT
3466	38	49277	99	OPT
3467	38	43973	99	OPT
3468	38	39520	99	OPT
3469	38	39521	99	OPT
3470	38	43972	99	OPT
3471	38	39522	99	OPT
3472	38	39523	99	OPT
3473	38	39524	99	OPT
3474	38	39525	99	OPT
3475	38	39526	99	OPT
3476	38	43788	99	OPT
3477	38	49271	99	OPT
3478	38	49259	99	OPT
3479	39	50105	1	OBR
3480	39	50106	1	OBR
3481	39	50126	1	OBR
3482	39	50127	1	OBR
3483	39	50108	1	OBR
3484	39	50104	1	OBR
3485	39	50122	1	OBR
3486	39	47251	2	OBR
3487	39	50109	2	OBR
3488	39	50135	2	OBR
3489	39	38990	2	OBR
3490	39	44475	2	OBR
3491	39	50110	2	OBR
3492	39	50121	2	OBR
3493	39	50124	2	OBR
3494	39	43783	2	OBR
3495	39	39055	3	OBR
3496	39	50111	3	OBR
3497	39	47160	3	OBR
3498	39	44469	3	OBR
3499	39	50130	3	OBR
3500	39	39051	3	OBR
3501	39	50103	3	OBR
3502	39	50107	3	OBR
3503	39	39059	3	OBR
3504	39	44481	4	OBR
3505	39	39056	4	OBR
3506	39	47191	4	OBR
3507	39	44470	4	OBR
3508	39	47118	4	OBR
3509	39	35198	4	OBR
3510	39	50123	4	OBR
3511	39	50129	4	OBR
3512	39	39068	5	OBR
3513	39	50132	5	OBR
3514	39	50125	5	OBR
3515	39	35182	5	OBR
3516	39	50119	5	OBR
3517	39	39071	5	OBR
3518	39	50115	5	OBR
3519	39	47194	6	OBR
3520	39	50112	6	OBR
3521	39	50120	6	OBR
3522	39	39077	6	OBR
3523	39	50131	6	OBR
3524	39	50128	6	OBR
3525	39	50114	6	OBR
3526	39	47162	7	OBR
3527	39	39081	7	OBR
3528	39	50116	7	OBR
3529	39	47144	7	OBR
3530	39	47121	7	OBR
3531	39	47135	7	OBR
3532	39	50117	7	OBR
3533	39	50113	8	OBR
3534	39	47161	8	OBR
3535	39	39089	8	OBR
3536	39	50118	8	OBR
3537	39	47171	8	OBR
3538	39	44478	8	OBR
3539	39	47250	99	OPT
3540	39	47130	99	OPT
3541	39	47244	99	OPT
3542	39	47124	99	OPT
3543	39	47091	99	OPT
3544	39	47140	99	OPT
3545	39	39104	99	OPT
3546	39	50136	99	OPT
3547	39	44484	99	OPT
3548	39	44485	99	OPT
3549	39	39105	99	OPT
3550	39	44455	99	OPT
3551	39	47252	99	OPT
3552	39	36551	99	OPT
3553	39	43775	99	OPT
3554	39	47096	99	OPT
3555	39	47095	99	OPT
3556	39	44472	99	OPT
3557	39	47245	99	OPT
3558	39	47783	99	OPT
3559	39	47247	99	OPT
3560	39	39107	99	OPT
3561	39	47137	99	OPT
3562	39	51757	99	OPT
3563	39	44463	99	OPT
3564	39	44462	99	OPT
3565	39	47151	99	OPT
3566	39	50134	99	OPT
3567	39	47184	99	OPT
3568	39	44486	99	OPT
3569	39	44476	99	OPT
3570	39	39111	99	OPT
3571	39	36238	99	OPT
3572	39	44473	99	OPT
3573	39	39112	99	OPT
3574	39	39113	99	OPT
3575	39	39114	99	OPT
3576	39	47248	99	OPT
3577	39	50133	99	OPT
3578	39	39115	99	OPT
3579	39	39116	99	OPT
3580	39	39117	99	OPT
3581	39	43788	99	OPT
3582	39	44465	99	OPT
3583	39	51770	99	OPT
3584	39	51765	99	OPT
3585	39	51766	99	OPT
3586	39	51767	99	OPT
3587	39	51763	99	OPT
3588	39	51764	99	OPT
3589	39	51768	99	OPT
3590	39	51769	99	OPT
3591	39	51759	99	OPT
3592	39	51760	99	OPT
3593	39	51761	99	OPT
3594	39	51762	99	OPT
3595	39	50137	99	OPT
3596	39	47093	99	OPT
3597	39	43777	99	OPT
3598	39	44460	99	OPT
3599	39	47094	99	OPT
3600	39	51758	99	OPT
3601	39	44480	99	OPT
3602	39	39121	99	OPT
3603	39	44482	99	OPT
3604	39	44456	99	OPT
3605	39	44453	99	OPT
3606	39	44459	99	OPT
3607	39	47092	99	OPT
3608	40	35182	1	OBR
3609	40	50534	1	OBR
3610	40	50130	1	OBR
3611	40	50547	1	OBR
3612	40	50546	1	OBR
3613	40	50533	2	OBR
3614	40	35198	2	OBR
3615	40	50551	2	OBR
3616	40	50549	2	OBR
3617	40	50543	2	OBR
3618	40	50539	3	OBR
3619	40	50550	3	OBR
3620	40	50535	3	OBR
3621	40	50555	3	OBR
3622	40	39194	3	OBR
3623	40	35195	3	OBR
3624	40	35197	4	OBR
3625	40	50538	4	OBR
3626	40	50553	4	OBR
3627	40	50527	4	OBR
3628	40	50554	4	OBR
3629	40	35200	4	OBR
3630	40	35201	5	OBR
3631	40	35202	5	OBR
3632	40	50529	5	OBR
3633	40	35214	5	OBR
3634	40	35204	5	OBR
3635	40	50542	5	OBR
3636	40	35208	6	OBR
3637	40	50556	6	OBR
3638	40	35220	6	OBR
3639	40	50545	6	OBR
3640	40	50544	6	OBR
3641	40	50541	6	OBR
3642	40	43783	6	OBR
3643	40	35218	7	OBR
3644	40	50536	7	OBR
3645	40	50540	7	OBR
3646	40	50528	7	OBR
3647	40	50531	7	OBR
3648	40	35203	8	OBR
3649	40	50552	8	OBR
3650	40	50530	8	OBR
3651	40	44068	8	OBR
3652	40	50537	8	OBR
3653	40	50532	8	OBR
3654	40	35207	99	OPT
3655	40	44060	99	OPT
3656	40	44061	99	OPT
3657	40	44062	99	OPT
3658	40	36551	99	OPT
3659	40	47783	99	OPT
3660	40	44059	99	OPT
3661	40	50548	99	OPT
3662	40	24402	99	OPT
3663	40	25684	99	OPT
3664	40	44058	99	OPT
3665	40	44065	99	OPT
3666	40	44052	99	OPT
3667	40	44064	99	OPT
3668	40	35212	99	OPT
3669	40	44069	99	OPT
3670	40	35217	99	OPT
3671	40	35221	99	OPT
3672	40	44049	99	OPT
3673	40	35205	99	OPT
3674	40	44055	99	OPT
3675	40	43777	99	OPT
3676	40	44056	99	OPT
3677	40	44050	99	OPT
3678	40	44054	99	OPT
3679	40	35193	99	OPT
3680	40	44053	99	OPT
3681	41	50925	1	OBR
3682	41	50927	1	OBR
3683	41	50923	1	OBR
3684	41	50931	1	OBR
3685	41	50917	1	OBR
3686	41	50918	2	OBR
3687	41	50914	2	OBR
3688	41	35130	2	OBR
3689	41	35111	2	OBR
3690	41	35230	2	OBR
3691	41	50915	3	OBR
3692	41	50916	3	OBR
3693	41	50920	3	OBR
3694	41	50919	3	OBR
3695	41	50924	3	OBR
3696	41	50935	3	OBR
3697	41	50921	4	OBR
3698	41	50911	4	OBR
3699	41	50913	4	OBR
3700	41	50930	4	OBR
3701	41	50933	4	OBR
3702	41	50928	5	OBR
3703	41	50932	5	OBR
3704	41	50910	5	OBR
3705	41	50929	5	OBR
3706	41	40927	5	OBR
3707	41	35248	6	OBR
3708	41	46753	6	OBR
3709	41	50912	6	OBR
3710	41	34069	6	OBR
3711	41	50922	6	OBR
3712	41	35257	7	OBR
3713	41	46789	7	OBR
3714	41	46759	7	OBR
3715	41	46755	7	OBR
3716	41	46791	7	OBR
3717	41	50934	8	OBR
3718	41	50926	8	OBR
3719	41	46783	8	OBR
3720	41	35253	8	OBR
3721	41	46792	8	OBR
3722	41	46786	8	OBR
3723	41	46761	99	OPT
3724	41	35259	99	OPT
3725	41	46760	99	OPT
3726	41	46776	99	OPT
3727	41	46762	99	OPT
3728	41	46768	99	OPT
3729	41	46771	99	OPT
3730	41	46757	99	OPT
3731	41	40921	99	OPT
3732	41	35260	99	OPT
3733	41	46766	99	OPT
3734	41	35261	99	OPT
3735	41	46785	99	OPT
3736	41	46769	99	OPT
3737	41	35120	99	OPT
3738	41	40923	99	OPT
3739	41	46772	99	OPT
3740	41	46773	99	OPT
3741	41	34719	99	OPT
3742	41	40924	99	OPT
3743	41	46765	99	OPT
3744	41	46774	99	OPT
3745	41	46782	99	OPT
3746	41	46756	99	OPT
3747	41	46758	99	OPT
3748	41	46764	99	OPT
3749	41	46777	99	OPT
3750	41	46763	99	OPT
3751	41	46784	99	OPT
3752	41	40925	99	OPT
3753	41	40926	99	OPT
3754	41	40928	99	OPT
3755	41	46778	99	OPT
3756	41	46779	99	OPT
3757	41	46775	99	OPT
3758	41	35267	99	OPT
3759	41	46770	99	OPT
3760	41	46780	99	OPT
3761	41	46790	99	OPT
3762	41	46781	99	OPT
3763	41	46767	99	OPT
3764	41	46752	99	OPT
3765	41	35270	99	OPT
3766	42	35129	1	OBR
3767	42	47278	1	OBR
3768	42	47279	1	OBR
3769	42	49635	1	OBR
3770	42	49639	1	OBR
3771	42	49640	1	OBR
3772	42	47281	2	OBR
3773	42	35133	2	OBR
3774	42	49648	2	OBR
3775	42	49638	2	OBR
3776	42	49636	2	OBR
3777	42	47270	3	OBR
3778	42	47272	3	OBR
3779	42	35154	3	OBR
3780	42	49642	3	OBR
3781	42	47273	3	OBR
3782	42	49633	4	OBR
3783	42	47274	4	OBR
3784	42	47275	4	OBR
3785	42	49652	4	OBR
3786	42	35141	4	OBR
3787	42	49644	5	OBR
3788	42	49645	5	OBR
3789	42	47276	5	OBR
3790	42	49641	5	OBR
3791	42	35144	5	OBR
3792	42	49647	6	OBR
3793	42	49632	6	OBR
3794	42	49651	6	OBR
3795	42	49649	6	OBR
3796	42	49646	6	OBR
3797	42	35152	7	OBR
3798	42	49634	7	OBR
3799	42	35158	7	OBR
3800	42	49654	7	OBR
3801	42	49643	7	OBR
3802	42	49637	8	OBR
3803	42	49653	8	OBR
3804	42	49655	8	OBR
3805	42	49650	8	OBR
3806	42	47254	99	OPT
3807	42	49631	99	OPT
3808	42	35107	99	OPT
3809	42	47255	99	OPT
3810	42	35103	99	OPT
3811	42	35096	99	OPT
3812	42	47256	99	OPT
3813	42	47257	99	OPT
3814	42	47258	99	OPT
3815	42	47259	99	OPT
3816	42	47260	99	OPT
3817	42	43686	99	OPT
3818	42	35120	99	OPT
3819	42	47261	99	OPT
3820	42	47262	99	OPT
3821	42	35110	99	OPT
3822	42	35233	99	OPT
3823	42	35105	99	OPT
3824	42	47267	99	OPT
3825	42	47268	99	OPT
3826	42	35394	99	OPT
3827	42	35249	99	OPT
3828	42	47263	99	OPT
3829	42	47264	99	OPT
3830	42	47265	99	OPT
3831	42	47266	99	OPT
3832	42	47269	99	OPT
3833	42	35111	99	OPT
3834	42	47282	99	OPT
3835	42	47283	99	OPT
3836	42	47284	99	OPT
3837	42	47285	99	OPT
3838	42	47286	99	OPT
3839	42	47287	99	OPT
3840	42	47288	99	OPT
3841	42	35113	99	OPT
3842	42	35114	99	OPT
3843	42	47289	99	OPT
3844	42	35116	99	OPT
3845	43	50518	1	OBR
3846	43	35198	1	OBR
3847	43	50607	1	OBR
3848	43	50521	1	OBR
3849	43	43783	1	OBR
3850	43	50606	2	OBR
3851	43	35182	2	OBR
3852	43	50500	2	OBR
3853	43	39194	2	OBR
3854	43	50509	3	OBR
3855	43	50516	3	OBR
3856	43	50499	3	OBR
3857	43	50608	3	OBR
3858	43	47383	3	OBR
3859	43	44958	4	OBR
3860	43	50523	4	OBR
3861	43	47384	4	OBR
3862	43	47380	4	OBR
3863	43	50501	5	OBR
3864	43	47397	5	OBR
3865	43	50508	5	OBR
3866	43	44935	5	OBR
3867	43	50617	5	OBR
3868	43	50502	6	OBR
3869	43	50611	6	OBR
3870	43	50615	6	OBR
3871	43	50510	6	OBR
3872	43	50520	6	OBR
3873	43	50525	7	OBR
3874	43	34565	7	OBR
3875	43	47391	7	OBR
3876	43	50625	7	OBR
3877	43	44973	7	OBR
3878	43	50616	8	OBR
3879	43	50503	8	OBR
3880	43	50511	8	OBR
3881	43	50613	99	OPT
3882	43	44940	99	OPT
3883	43	47386	99	OPT
3884	43	47196	99	OPT
3885	43	47381	99	OPT
3886	43	43775	99	OPT
3887	43	47388	99	OPT
3888	43	47389	99	OPT
3889	43	44950	99	OPT
3890	43	47197	99	OPT
3891	43	44957	99	OPT
3892	43	47392	99	OPT
3893	43	44992	99	OPT
3894	43	47393	99	OPT
3895	43	44964	99	OPT
3896	43	44970	99	OPT
3897	43	44951	99	OPT
3898	43	47400	99	OPT
3899	43	47399	99	OPT
3900	43	44947	99	OPT
3901	43	44974	99	OPT
3902	43	50512	99	OPT
3903	43	44955	99	OPT
3904	43	50626	99	OPT
3905	43	50505	99	OPT
3906	43	43788	99	OPT
3907	43	44956	99	OPT
3908	43	44986	99	OPT
3909	43	47398	99	OPT
3910	43	44987	99	OPT
3911	43	47401	99	OPT
3912	43	50514	99	OPT
3913	43	44981	99	OPT
3914	43	43777	99	OPT
3915	43	44990	99	OPT
3916	43	50507	99	OPT
3917	43	44968	99	OPT
3918	43	44939	99	OPT
3919	43	44975	99	OPT
3920	43	44976	99	OPT
3921	43	44962	99	OPT
3922	44	40726	1	OBR
3923	44	49229	1	OBR
3924	44	34668	1	OBR
3925	44	49231	1	OBR
3926	44	40728	1	OBR
3927	44	49235	1	OBR
3928	44	40729	1	OBR
3929	44	49217	1	OBR
3930	44	40731	2	OBR
3931	44	49246	2	OBR
3932	44	49232	2	OBR
3933	44	45531	2	OBR
3934	44	49237	2	OBR
3935	44	49243	2	OBR
3936	44	49239	2	OBR
3937	44	49242	2	OBR
3938	44	49248	3	OBR
3939	44	49233	3	OBR
3940	44	49214	3	OBR
3941	44	49240	3	OBR
3942	44	49241	3	OBR
3943	44	45323	3	OBR
3944	44	49228	4	OBR
3945	44	49234	4	OBR
3946	44	49247	4	OBR
3947	44	49236	4	OBR
3948	44	49238	4	OBR
3949	44	45321	4	OBR
3950	44	49230	5	OBR
3951	44	49209	5	OBR
3952	44	49227	5	OBR
3953	44	52116	5	OBR
3954	44	34696	5	OBR
3955	44	52118	6	OBR
3956	44	49211	6	OBR
3957	44	49215	6	OBR
3958	44	49212	6	OBR
3959	44	52119	6	OBR
3960	44	49210	7	OBR
3961	44	40754	7	OBR
3962	44	45336	7	OBR
3963	44	49213	7	OBR
3964	44	49218	7	OBR
3965	44	49244	7	OBR
3966	44	52117	8	OBR
3967	44	49216	8	OBR
3968	44	34708	8	OBR
3969	44	34710	8	OBR
3970	44	34711	8	OBR
3971	44	49207	9	OBR
3972	44	49245	9	OBR
3973	44	49208	10	OBR
3974	44	45529	99	OPT
3975	44	51904	99	OPT
3976	44	49225	99	OPT
3977	44	40715	99	OPT
3978	44	40716	99	OPT
3979	44	45528	99	OPT
3980	44	49223	99	OPT
3981	44	43686	99	OPT
3982	44	45345	99	OPT
3983	44	45331	99	OPT
3984	44	49219	99	OPT
3985	44	49220	99	OPT
3986	44	45332	99	OPT
3987	44	40717	99	OPT
3988	44	45530	99	OPT
3989	44	45338	99	OPT
3990	44	45339	99	OPT
3991	44	35110	99	OPT
3992	44	45316	99	OPT
3993	44	45337	99	OPT
3994	44	45533	99	OPT
3995	44	40718	99	OPT
3996	44	45330	99	OPT
3997	44	40719	99	OPT
3998	44	45347	99	OPT
3999	44	49221	99	OPT
4000	44	40720	99	OPT
4001	44	49224	99	OPT
4002	44	45319	99	OPT
4003	44	45349	99	OPT
4004	44	49222	99	OPT
4005	44	34722	99	OPT
4006	44	45318	99	OPT
4007	44	45532	99	OPT
4008	44	40722	99	OPT
4009	44	40723	99	OPT
4010	44	45317	99	OPT
4011	44	40724	99	OPT
4012	44	40725	99	OPT
4013	44	45320	99	OPT
4014	44	45342	99	OPT
4015	45	50572	1	OBR
4016	45	27460	1	OBR
4017	45	50557	1	OBR
4018	45	25535	1	OBR
4019	45	50585	1	OBR
4020	45	25536	1	OBR
4021	45	50558	1	OBR
4022	45	50584	2	OBR
4023	45	50581	2	OBR
4024	45	25679	2	OBR
4025	45	50597	2	OBR
4026	45	50596	2	OBR
4027	45	50560	2	OBR
4028	45	25541	2	OBR
4029	45	50595	2	OBR
4030	45	50587	2	OBR
4031	45	50582	3	OBR
4032	45	50559	3	OBR
4033	45	50580	3	OBR
4034	45	25680	3	OBR
4035	45	50586	3	OBR
4036	45	50589	3	OBR
4037	45	50583	4	OBR
4038	45	50598	4	OBR
4039	45	50574	4	OBR
4040	45	50571	4	OBR
4041	45	25686	4	OBR
4042	45	34047	4	OBR
4043	45	50573	4	OBR
4044	45	25687	4	OBR
4045	45	25690	5	OBR
4046	45	50562	5	OBR
4047	45	50569	5	OBR
4048	45	50590	5	OBR
4049	45	25693	5	OBR
4050	45	50576	5	OBR
4051	45	25696	6	OBR
4052	45	50600	6	OBR
4053	45	25698	6	OBR
4054	45	50575	6	OBR
4055	45	50577	6	OBR
4056	45	50588	6	OBR
4057	45	50599	6	OBR
4058	45	34050	6	OBR
4059	45	25702	7	OBR
4060	45	50565	7	OBR
4061	45	50594	7	OBR
4062	45	34052	7	OBR
4063	45	25705	7	OBR
4064	45	50561	7	OBR
4065	45	50578	7	OBR
4066	45	25707	7	OBR
4067	45	34054	8	OBR
4068	45	43686	8	OBR
4069	45	25712	8	OBR
4070	45	50579	8	OBR
4071	45	50592	8	OBR
4072	45	26089	8	OBR
4073	45	34056	8	OBR
4074	45	50566	9	OBR
4075	45	50593	9	OBR
4076	45	50591	9	OBR
4077	45	50563	9	OBR
4078	45	50564	9	OBR
4079	45	50567	10	OBR
4080	45	34062	99	OPT
4081	45	50568	99	OPT
4082	45	25678	99	OPT
4083	45	50570	99	OPT
4084	45	34063	99	OPT
4085	45	25704	99	OPT
4086	45	25544	99	OPT
4087	45	34064	99	OPT
4088	45	34065	99	OPT
4089	45	34066	99	OPT
4090	45	34067	99	OPT
4091	45	25543	99	OPT
4092	45	34068	99	OPT
4093	45	34069	99	OPT
4094	45	34071	99	OPT
4095	45	34074	99	OPT
4096	45	34072	99	OPT
4097	46	49528	1	OBR
4098	46	49556	1	OBR
4099	46	34299	1	OBR
4100	46	49549	1	OBR
4101	46	49526	2	OBR
4102	46	49527	2	OBR
4103	46	49562	2	OBR
4104	46	49563	3	OBR
4105	46	49524	3	OBR
4106	46	49542	3	OBR
4107	46	49550	3	OBR
4108	46	49522	4	OBR
4109	46	43686	4	OBR
4110	46	49568	4	OBR
4111	46	25977	4	OBR
4112	46	49540	4	OBR
4113	46	49529	5	OBR
4114	46	49535	5	OBR
4115	46	25969	5	OBR
4116	46	49541	5	OBR
4117	46	49523	5	OBR
4118	46	49561	6	OBR
4119	46	49558	6	OBR
4120	46	49543	6	OBR
4121	46	49521	6	OBR
4122	46	34305	7	OBR
4123	46	49538	7	OBR
4124	46	49534	7	OBR
4125	46	49557	7	OBR
4126	46	34304	8	OBR
4127	46	49570	8	OBR
4128	46	25934	8	OBR
4129	46	30085	99	OPT
4130	46	49559	99	OPT
4131	46	25548	99	OPT
4132	46	25913	99	OPT
4133	46	25914	99	OPT
4134	46	25915	99	OPT
4135	46	25916	99	OPT
4136	46	44487	99	OPT
4137	46	25980	99	OPT
4138	46	31405	99	OPT
4139	46	25919	99	OPT
4140	46	25920	99	OPT
4141	46	25921	99	OPT
4142	46	30088	99	OPT
4143	46	25923	99	OPT
4144	46	49545	99	OPT
4145	46	25489	99	OPT
4146	46	25924	99	OPT
4147	46	49551	99	OPT
4148	46	49554	99	OPT
4149	46	25925	99	OPT
4150	46	34282	99	OPT
4151	46	25927	99	OPT
4152	46	49531	99	OPT
4153	46	34284	99	OPT
4154	46	34298	99	OPT
4155	46	49560	99	OPT
4156	46	30083	99	OPT
4157	46	49569	99	OPT
4158	46	25930	99	OPT
4159	46	25931	99	OPT
4160	46	49564	99	OPT
4161	46	44627	99	OPT
4162	46	49580	99	OPT
4163	46	49581	99	OPT
4164	46	49577	99	OPT
4165	46	49578	99	OPT
4166	46	49553	99	OPT
4167	46	49552	99	OPT
4168	46	49520	99	OPT
4169	46	49533	99	OPT
4170	46	49555	99	OPT
4171	46	25937	99	OPT
4172	46	49579	99	OPT
4173	46	49576	99	OPT
4174	46	25938	99	OPT
4175	46	25939	99	OPT
4176	46	49575	99	OPT
4177	46	49546	99	OPT
4178	46	49530	99	OPT
4179	46	49548	99	OPT
4180	46	49532	99	OPT
4181	46	25940	99	OPT
4182	46	49574	99	OPT
4183	46	49525	99	OPT
4184	46	25941	99	OPT
4185	46	49547	99	OPT
4186	46	49544	99	OPT
4187	46	34294	99	OPT
4188	46	49573	99	OPT
4189	46	49567	99	OPT
4190	46	49536	99	OPT
4191	46	34295	99	OPT
4192	46	49572	99	OPT
4193	46	49566	99	OPT
4194	46	49539	99	OPT
4195	46	34297	99	OPT
4196	46	49565	99	OPT
4197	46	49537	99	OPT
4198	46	34296	99	OPT
4199	46	49571	99	OPT
4200	46	46046	99	OPT
4201	47	47414	1	OBR
4202	47	50236	1	OBR
4203	47	47473	1	OBR
4204	47	50240	1	OBR
4205	47	47411	1	OBR
4206	47	50231	1	OBR
4207	47	50253	1	OBR
4208	47	47412	1	OBR
4209	47	47434	2	OBR
4210	47	50249	2	OBR
4211	47	50246	2	OBR
4212	47	47416	2	OBR
4213	47	50250	2	OBR
4214	47	50251	2	OBR
4215	47	47470	2	OBR
4216	47	50239	3	OBR
4217	47	47462	3	OBR
4218	47	47463	3	OBR
4219	47	50237	3	OBR
4220	47	50241	3	OBR
4221	47	50242	3	OBR
4222	47	50245	4	OBR
4223	47	50234	4	OBR
4224	47	50243	4	OBR
4225	47	50244	4	OBR
4226	47	47468	4	OBR
4227	47	47441	5	OBR
4228	47	47442	5	OBR
4229	47	50238	5	OBR
4230	47	47443	5	OBR
4231	47	47437	5	OBR
4232	47	47445	6	OBR
4233	47	47446	6	OBR
4234	47	50232	6	OBR
4235	47	47421	6	OBR
4236	47	47477	7	OBR
4237	47	47429	7	OBR
4238	47	47448	7	OBR
4239	47	50235	7	OBR
4240	47	50252	7	OBR
4241	47	47449	8	OBR
4242	47	47439	8	OBR
4243	47	47475	8	OBR
4244	47	50233	8	OBR
4245	47	50247	9	OBR
4246	47	50248	10	OBR
4247	47	47459	99	OPT
4248	47	47417	99	OPT
4249	47	47450	99	OPT
4250	47	47438	99	OPT
4251	47	47460	99	OPT
4252	47	47453	99	OPT
4253	47	47454	99	OPT
4254	47	47455	99	OPT
4255	47	47456	99	OPT
4256	47	47424	99	OPT
4257	47	40874	99	OPT
4258	47	30070	99	OPT
4259	47	25487	99	OPT
4260	47	33938	99	OPT
4261	47	25489	99	OPT
4262	47	47431	99	OPT
4263	47	47425	99	OPT
4264	47	47472	99	OPT
4265	47	25494	99	OPT
4266	47	38998	99	OPT
4267	47	47422	99	OPT
4268	47	47419	99	OPT
4269	47	47430	99	OPT
4270	47	33939	99	OPT
4271	47	40878	99	OPT
4272	47	47474	99	OPT
4273	47	47426	99	OPT
4274	47	47420	99	OPT
4275	47	47458	99	OPT
4276	47	47457	99	OPT
4277	47	47418	99	OPT
4278	48	24472	1	OBR
4279	48	36609	1	OBR
4280	48	24501	1	OBR
4281	48	44230	1	OBR
4282	48	36610	1	OBR
4283	48	36771	2	OBR
4284	48	36773	2	OBR
4285	48	36772	2	OBR
4286	48	34584	2	OBR
4287	48	36774	2	OBR
4288	48	44225	2	OBR
4289	48	33925	3	OBR
4290	48	36778	3	OBR
4291	48	36775	3	OBR
4292	48	44226	3	OBR
4293	48	36777	3	OBR
4294	48	36776	3	OBR
4295	48	24495	4	OBR
4296	48	26376	4	OBR
4297	48	44229	4	OBR
4298	48	36780	4	OBR
4299	48	44227	4	OBR
4300	48	36779	4	OBR
4301	48	44231	5	OBR
4302	48	44221	5	OBR
4303	48	44217	5	OBR
4304	48	36784	5	OBR
4305	48	44224	5	OBR
4306	48	36783	5	OBR
4307	48	36789	6	OBR
4308	48	44218	6	OBR
4309	48	36788	6	OBR
4310	48	44232	6	OBR
4311	48	36791	6	OBR
4312	48	44214	7	OBR
4313	48	44215	7	OBR
4314	48	36795	7	OBR
4315	48	44228	7	OBR
4316	48	44222	8	OBR
4317	48	44223	8	OBR
4318	48	24559	8	OBR
4319	48	36799	8	OBR
4320	48	24567	99	OPT
4321	48	36761	99	OPT
4322	48	36793	99	OPT
4323	48	24556	99	OPT
4324	48	36762	99	OPT
4325	48	24557	99	OPT
4326	48	36763	99	OPT
4327	48	24565	99	OPT
4328	48	36764	99	OPT
4329	48	36765	99	OPT
4330	48	44216	99	OPT
4331	48	24566	99	OPT
4332	48	24563	99	OPT
4333	48	24560	99	OPT
4334	48	44220	99	OPT
4335	48	36767	99	OPT
4336	48	44219	99	OPT
4337	48	24562	99	OPT
4338	48	24564	99	OPT
4339	48	36768	99	OPT
4340	48	36769	99	OPT
4341	48	36770	99	OPT
4342	49	48923	1	OBR
4343	49	48935	1	OBR
4344	49	48940	1	OBR
4345	49	48931	1	OBR
4346	49	48968	1	OBR
4347	49	48909	2	OBR
4348	49	48973	2	OBR
4349	49	48927	2	OBR
4350	49	48947	2	OBR
4351	49	48891	2	OBR
4352	49	48913	2	OBR
4353	49	48896	3	OBR
4354	49	48894	3	OBR
4355	49	48972	3	OBR
4356	49	48952	3	OBR
4357	49	48887	3	OBR
4358	49	48969	4	OBR
4359	49	48963	4	OBR
4360	49	48903	4	OBR
4361	49	48953	4	OBR
4362	49	48924	4	OBR
4363	49	48961	5	OBR
4364	49	48956	5	OBR
4365	49	48900	5	OBR
4366	49	48966	5	OBR
4367	49	48941	5	OBR
4368	49	48932	5	OBR
4369	49	48898	6	OBR
4370	49	48922	6	OBR
4371	49	48967	6	OBR
4372	49	48890	6	OBR
4373	49	48893	6	OBR
4374	49	48930	6	OBR
4375	49	48895	7	OBR
4376	49	48916	7	OBR
4377	49	48933	7	OBR
4378	49	48942	7	OBR
4379	49	48960	7	OBR
4380	49	48928	7	OBR
4381	49	48955	8	OBR
4382	49	48917	8	OBR
4383	49	48937	8	OBR
4384	49	48946	8	OBR
4385	49	48934	8	OBR
4386	49	48901	8	OBR
4387	49	48902	9	OBR
4388	49	48921	9	OBR
4389	49	48938	9	OBR
4390	49	48888	9	OBR
4391	49	48939	9	OBR
4392	49	48964	9	OBR
4393	49	48911	10	OBR
4394	49	48970	10	OBR
4395	49	48899	10	OBR
4396	49	48925	10	OBR
4397	49	48943	10	OBR
4398	49	48907	99	OPT
4399	49	48897	99	OPT
4400	49	48957	99	OPT
4401	49	48908	99	OPT
4402	49	46006	99	OPT
4403	49	48904	99	OPT
4404	49	48959	99	OPT
4405	49	46028	99	OPT
4406	49	46018	99	OPT
4407	49	46031	99	OPT
4408	49	48958	99	OPT
4409	49	48914	99	OPT
4410	49	48918	99	OPT
4411	49	48919	99	OPT
4412	49	48936	99	OPT
4413	49	43686	99	OPT
4414	49	46039	99	OPT
4415	49	48971	99	OPT
4416	49	48944	99	OPT
4417	49	48892	99	OPT
4418	49	48889	99	OPT
4419	49	48885	99	OPT
4420	49	48886	99	OPT
4421	49	46041	99	OPT
4422	49	46025	99	OPT
4423	49	46026	99	OPT
4424	49	46047	99	OPT
4425	49	46048	99	OPT
4426	49	48951	99	OPT
4427	49	48949	99	OPT
4428	49	48950	99	OPT
4429	49	48948	99	OPT
4430	49	46022	99	OPT
4431	49	48945	99	OPT
4432	49	48912	99	OPT
4433	49	46046	99	OPT
4434	49	48920	99	OPT
4435	49	46023	99	OPT
4436	49	46045	99	OPT
4437	49	48929	99	OPT
4438	49	48926	99	OPT
4439	49	48915	99	OPT
4440	49	48905	99	OPT
4441	49	46044	99	OPT
4442	49	48906	99	OPT
4443	49	48910	99	OPT
4444	49	48962	99	OPT
4445	49	48965	99	OPT
4446	49	48954	99	OPT
4447	50	49031	1	OBR
4448	50	49060	1	OBR
4449	50	49028	1	OBR
4450	50	49057	1	OBR
4451	50	49038	1	OBR
4452	50	49035	2	OBR
4453	50	49051	2	OBR
4454	50	49045	2	OBR
4455	50	49013	2	OBR
4456	50	49063	2	OBR
4457	50	49065	3	OBR
4458	50	49046	3	OBR
4459	50	49058	3	OBR
4460	50	49012	3	OBR
4461	50	49022	3	OBR
4462	50	49042	4	OBR
4463	50	49037	4	OBR
4464	50	49073	4	OBR
4465	50	49016	4	OBR
4466	50	44319	4	OBR
4467	50	49021	5	OBR
4468	50	49067	5	OBR
4469	50	49032	5	OBR
4470	50	49033	5	OBR
4471	50	49055	5	OBR
4472	50	49056	6	OBR
4473	50	49040	6	OBR
4474	50	49014	6	OBR
4475	50	49015	6	OBR
4476	50	49064	6	OBR
4477	50	44334	7	OBR
4478	50	49029	7	OBR
4479	50	49020	7	OBR
4480	50	49041	7	OBR
4481	50	49024	8	OBR
4482	50	49030	8	OBR
4483	50	44286	8	OBR
4484	50	49048	8	OBR
4485	50	49017	99	OPT
4486	50	49070	99	OPT
4487	50	49069	99	OPT
4488	50	49066	99	OPT
4489	50	46712	99	OPT
4490	50	46683	99	OPT
4491	50	49023	99	OPT
4492	50	44310	99	OPT
4493	50	46670	99	OPT
4494	50	46716	99	OPT
4495	50	46697	99	OPT
4496	50	49039	99	OPT
4497	50	42994	99	OPT
4498	50	44340	99	OPT
4499	50	49071	99	OPT
4500	50	49059	99	OPT
4501	50	49061	99	OPT
4502	50	49072	99	OPT
4503	50	49034	99	OPT
4504	50	49062	99	OPT
4505	50	49026	99	OPT
4506	50	49036	99	OPT
4507	50	49068	99	OPT
4508	50	49043	99	OPT
4509	50	44305	99	OPT
4510	50	49074	99	OPT
4511	50	49047	99	OPT
4512	50	44337	99	OPT
4513	50	49025	99	OPT
4514	50	49018	99	OPT
4515	50	49019	99	OPT
4516	50	49027	99	OPT
4517	50	44324	99	OPT
4518	50	44339	99	OPT
4519	50	44342	99	OPT
4520	50	44317	99	OPT
4521	50	49050	99	OPT
4522	50	49049	99	OPT
4523	50	49054	99	OPT
4524	50	49052	99	OPT
4525	50	49053	99	OPT
4526	50	49044	99	OPT
4527	51	48103	1	OBR
4528	51	48104	1	OBR
4529	51	48101	1	OBR
4530	51	48141	1	OBR
4531	51	48122	1	OBR
4532	51	48105	1	OBR
4533	51	48096	1	OBR
4534	51	48118	2	OBR
4535	51	48113	2	OBR
4536	51	48106	2	OBR
4537	51	48107	2	OBR
4538	51	48121	2	OBR
4539	51	48095	2	OBR
4540	51	48085	2	OBR
4541	51	34593	3	OBR
4542	51	48142	3	OBR
4543	51	48087	3	OBR
4544	51	48088	3	OBR
4545	51	48119	3	OBR
4546	51	48112	3	OBR
4547	51	48086	3	OBR
4548	51	48108	4	OBR
4549	51	48123	4	OBR
4550	51	48111	4	OBR
4551	51	48109	4	OBR
4552	51	48120	4	OBR
4553	51	48110	4	OBR
4554	51	48146	4	OBR
4555	51	48098	5	OBR
4556	51	48116	5	OBR
4557	51	48125	5	OBR
4558	51	48117	5	OBR
4559	51	48124	5	OBR
4560	51	48147	5	OBR
4561	51	48102	6	OBR
4562	51	48127	6	OBR
4563	51	48100	6	OBR
4564	51	48114	6	OBR
4565	51	48126	6	OBR
4566	51	48131	6	OBR
4567	51	48128	7	OBR
4568	51	48099	7	NAP
4569	51	48129	7	NAP
4570	51	48115	7	OBR
4571	51	48133	7	OBR
4572	51	48093	8	OBR
4573	51	48134	8	NAP
4574	51	48144	8	NAP
4575	51	48132	9	NAP
4576	51	48130	9	NAP
4577	51	48143	10	NAP
4578	51	48145	10	NAP
4579	51	48089	99	OPT
4580	51	42995	99	OPT
4581	51	42994	99	OPT
4582	51	34638	99	OPT
4583	51	34640	99	OPT
4584	51	34641	99	OPT
4585	51	34644	99	OPT
4586	51	48136	99	OPT
4587	51	34650	99	OPT
4588	51	34655	99	OPT
4589	51	34656	99	OPT
4590	51	48139	99	OPT
4591	51	48092	99	OPT
4592	51	48140	99	OPT
4593	51	48091	99	OPT
4594	51	48097	99	OPT
4595	51	48138	99	OPT
4596	51	48135	99	OPT
4597	51	48094	99	OPT
4598	51	48137	99	OPT
4599	51	48090	99	OPT
4600	52	49598	1	OBR
4601	52	49625	1	OBR
4602	52	43232	1	OBR
4603	52	49623	1	OBR
4604	52	49624	1	OBR
4605	52	49592	2	OBR
4606	52	49621	2	OBR
4607	52	38323	2	OBR
4608	52	49620	2	OBR
4609	52	49599	2	OBR
4610	52	49593	3	OBR
4611	52	49608	3	OBR
4612	52	49588	3	OBR
4613	52	49615	3	OBR
4614	52	43253	3	OBR
4615	52	49626	4	OBR
4616	52	43240	4	OBR
4617	52	43243	4	OBR
4618	52	43244	4	OBR
4619	52	49627	4	OBR
4620	52	49590	5	OBR
4621	52	49607	5	OBR
4622	52	49619	5	OBR
4623	52	49609	5	OBR
4624	52	49610	5	OBR
4625	52	49606	5	OBR
4626	52	49583	6	OBR
4627	52	49613	6	OBR
4628	52	49614	6	OBR
4629	52	49618	6	OBR
4630	52	38348	6	OBR
4631	52	49612	6	OBR
4632	52	49591	7	OBR
4633	52	49630	7	OBR
4634	52	49611	7	OBR
4635	52	49587	7	OBR
4636	52	49617	7	OBR
4637	52	49589	7	OBR
4638	52	43254	7	OBR
4639	52	49604	8	OBR
4640	52	43225	8	OBR
4641	52	49594	8	OBR
4642	52	49600	8	OBR
4643	52	49622	8	OBR
4644	52	49595	8	OBR
4645	52	43261	99	OPT
4646	52	43262	99	OPT
4647	52	49597	99	OPT
4648	52	43239	99	OPT
4649	52	43213	99	OPT
4650	52	43223	99	OPT
4651	52	44340	99	OPT
4652	52	43263	99	OPT
4653	52	43224	99	OPT
4654	52	43228	99	OPT
4655	52	49628	99	OPT
4656	52	38329	99	OPT
4657	52	38324	99	OPT
4658	52	38325	99	OPT
4659	52	38330	99	OPT
4660	52	43216	99	OPT
4661	52	43217	99	OPT
4662	52	43256	99	OPT
4663	52	49585	99	OPT
4664	52	43258	99	OPT
4665	52	43259	99	OPT
4666	52	43218	99	OPT
4667	52	49586	99	OPT
4668	52	49596	99	OPT
4669	52	43219	99	OPT
4670	52	43220	99	OPT
4671	52	43230	99	OPT
4672	52	43221	99	OPT
4673	52	49584	99	OPT
4674	52	49601	99	OPT
4675	52	49603	99	OPT
4676	52	49602	99	OPT
4677	52	49605	99	OPT
4678	52	49616	99	OPT
4679	52	49629	99	OPT
4680	53	47878	1	OBR
4681	53	47901	1	OBR
4682	53	47993	1	OBR
4683	53	47933	1	OBR
4684	53	47902	1	OBR
4685	53	47962	1	OBR
4686	53	47894	2	OBR
4687	53	47904	2	OBR
4688	53	47903	2	OBR
4689	53	47916	2	OBR
4690	53	47905	2	OBR
4691	53	47889	2	OBR
4692	53	47997	3	OBR
4693	53	47928	3	OBR
4694	53	47880	3	OBR
4695	53	47925	3	OBR
4696	53	47996	3	OBR
4697	53	47877	3	OBR
4698	53	47922	3	OBR
4699	53	47935	4	OBR
4700	53	47888	4	OBR
4701	53	47890	4	OBR
4702	53	47967	4	OBR
4703	53	47891	4	OBR
4704	53	47936	4	OBR
4705	53	47947	4	OBR
4706	53	47893	4	OBR
4707	53	47887	4	OBR
4708	53	47961	5	OBR
4709	53	47875	5	OBR
4710	53	47919	5	OBR
4711	53	47930	5	OBR
4712	53	47938	5	OBR
4713	53	47874	5	OBR
4714	53	47920	6	OBR
4715	53	47956	6	OBR
4716	53	47906	6	OBR
4717	53	47942	6	OBR
4718	53	47907	6	OBR
4719	53	47876	6	OBR
4720	53	47991	6	OBR
4721	53	47886	7	OBR
4722	53	47921	7	OBR
4723	53	47968	7	OBR
4724	53	47931	7	OBR
4725	53	47950	7	OBR
4726	53	47895	7	OBR
4727	53	47908	8	OBR
4728	53	47910	8	OBR
4729	53	47932	8	OBR
4730	53	47943	8	OBR
4731	53	47957	8	OBR
4732	53	47884	8	OBR
4733	53	47911	9	OBR
4734	53	47998	9	OBR
4735	53	47900	9	OBR
4736	53	47945	9	OBR
4737	53	47958	9	OBR
4738	53	47964	9	OBR
4739	53	47969	9	OBR
4740	53	47974	9	OBR
4741	53	47976	9	OBR
4742	53	47951	9	OBR
4743	53	47927	10	OBR
4744	53	47941	99	OPT
4745	53	47912	99	OPT
4746	53	47882	99	OPT
4747	53	47934	99	OPT
4748	53	47929	99	OPT
4749	53	47994	99	OPT
4750	53	47995	99	OPT
4751	53	47879	99	OPT
4752	53	47915	99	OPT
4753	53	47918	99	OPT
4754	53	47944	99	OPT
4755	53	48000	99	OPT
4756	53	47953	99	OPT
4757	53	47970	99	OPT
4758	53	47954	99	OPT
4759	53	47965	99	OPT
4760	53	47973	99	OPT
4761	53	47977	99	OPT
4762	53	47984	99	OPT
4763	53	43686	99	OPT
4764	53	47981	99	OPT
4765	53	47986	99	OPT
4766	53	47982	99	OPT
4767	53	47988	99	OPT
4768	53	47909	99	OPT
4769	53	47892	99	OPT
4770	53	47917	99	OPT
4771	53	47926	99	OPT
4772	53	48001	99	OPT
4773	53	47940	99	OPT
4774	53	47952	99	OPT
4775	53	47955	99	OPT
4776	53	47960	99	OPT
4777	53	47971	99	OPT
4778	53	47979	99	OPT
4779	53	48003	99	OPT
4780	53	47975	99	OPT
4781	53	48004	99	OPT
4782	53	47897	99	OPT
4783	53	47959	99	OPT
4784	53	47972	99	OPT
4785	53	47999	99	OPT
4786	53	47992	99	OPT
4787	53	47949	99	OPT
4788	53	47899	99	OPT
4789	53	47883	99	OPT
4790	53	48002	99	OPT
4791	53	47913	99	OPT
4792	53	47885	99	OPT
4793	53	47924	99	OPT
4794	53	47896	99	OPT
4795	53	47946	99	OPT
4796	53	47939	99	OPT
4797	53	47937	99	OPT
4798	53	47923	99	OPT
4799	53	47914	99	OPT
4800	53	47948	99	OPT
4801	53	47898	99	OPT
4802	53	47963	99	OPT
4803	53	47966	99	OPT
4804	53	47881	99	OPT
4805	53	47978	99	OPT
4806	53	47985	99	OPT
4807	53	47987	99	OPT
4808	53	47989	99	OPT
4809	53	47990	99	OPT
4810	53	48005	99	OPT
4811	53	48006	99	OPT
4812	53	47980	99	OPT
4813	53	47983	99	OPT
4814	53	48007	99	OPT
4815	54	51489	1	OBR
4816	54	51469	1	OBR
4817	54	51542	1	OBR
4818	54	51541	1	OBR
4819	54	52284	1	OBR
4820	54	51516	2	OBR
4821	54	51470	2	OBR
4822	54	51530	2	OBR
4823	54	51529	2	OBR
4824	54	51527	2	OBR
4825	54	51498	3	OBR
4826	54	51532	3	OBR
4827	54	51537	3	OBR
4828	54	51533	3	OBR
4829	54	51536	3	OBR
4830	54	51534	4	OBR
4831	54	51538	4	OBR
4832	54	51540	4	OBR
4833	54	51535	4	OBR
4834	54	51512	4	OBR
4835	54	51494	5	OBR
4836	54	51490	5	OBR
4837	54	51515	5	OBR
4838	54	51511	5	OBR
4839	54	51539	5	OBR
4840	54	51514	5	OBR
4841	54	51513	5	OBR
4842	54	51495	6	OBR
4843	54	51510	6	OBR
4844	54	51509	6	OBR
4845	54	51504	6	OBR
4846	54	51505	6	OBR
4847	54	51508	6	OBR
4848	54	51506	6	OBR
4849	54	51496	7	OBR
4850	54	51526	7	OBR
4851	54	51473	7	OBR
4852	54	51499	7	OBR
4853	54	51518	7	OBR
4854	54	51524	7	OBR
4855	54	51522	7	OBR
4856	54	51497	8	OBR
4857	54	51479	8	OBR
4858	54	51521	8	OBR
4859	54	51517	8	OBR
4860	54	51520	8	OBR
4861	54	51519	8	OBR
4862	54	51531	8	OBR
4863	54	51492	9	OBR
4864	54	51487	9	OBR
4865	54	51523	9	OBR
4866	54	51476	9	OBR
4867	54	51493	9	OBR
4868	54	51485	10	OBR
4869	54	51507	10	OBR
4870	54	51525	10	OBR
4871	54	51474	10	OBR
4872	54	51486	10	OBR
4873	54	51503	11	OBR
4874	54	51500	11	OBR
4875	54	51481	11	OBR
4876	54	51484	11	OBR
4877	54	51482	12	OBR
4878	54	51483	12	OBR
4879	54	51475	12	OBR
4880	54	38587	99	OPT
4881	54	51491	99	OPT
4882	54	31586	99	OPT
4883	54	38590	99	OPT
4884	54	41760	99	OPT
4885	54	41585	99	OPT
4886	54	43686	99	OPT
4887	54	41756	99	OPT
4888	54	51468	99	OPT
4889	54	41586	99	OPT
4890	54	51471	99	OPT
4891	54	38595	99	OPT
4892	54	41587	99	OPT
4893	54	44746	99	OPT
4894	54	41226	99	OPT
4895	54	40713	99	OPT
4896	54	38603	99	OPT
4897	54	38604	99	OPT
4898	54	38605	99	OPT
4899	54	44799	99	OPT
4900	54	41589	99	OPT
4901	54	51480	99	OPT
4902	54	41590	99	OPT
4903	54	51477	99	OPT
4904	54	51501	99	OPT
4905	54	51488	99	OPT
4906	54	51502	99	OPT
4907	54	51478	99	OPT
4908	54	45372	99	OPT
4909	54	45373	99	OPT
4910	54	45374	99	OPT
4911	54	45375	99	OPT
4912	54	45376	99	OPT
4913	54	45377	99	OPT
4914	54	45378	99	OPT
4915	54	45379	99	OPT
4916	54	51528	99	OPT
4917	55	41610	1	OBR
4918	55	45283	1	OBR
4919	55	41627	1	OBR
4920	55	41635	1	OBR
4921	55	51790	1	OBR
4922	55	51778	1	OBR
4923	55	41614	2	OBR
4924	55	41628	2	OBR
4925	55	41617	2	OBR
4926	55	45288	2	OBR
4927	55	45300	2	OBR
4928	55	51791	2	OBR
4929	55	45198	2	OBR
4930	55	41612	3	OBR
4931	55	45860	3	OBR
4932	55	45862	3	OBR
4933	55	45271	3	OBR
4934	55	51787	3	OBR
4935	55	41620	3	OBR
4936	55	42899	3	OBR
4937	55	51799	4	OBR
4938	55	37695	4	OBR
4939	55	51795	4	OBR
4940	55	51792	4	OBR
4941	55	51783	4	OBR
4942	55	51781	4	OBR
4943	55	51779	4	OBR
4944	55	45294	5	OBR
4945	55	51786	5	OBR
4946	55	51793	5	OBR
4947	55	51798	5	OBR
4948	55	45297	5	OBR
4949	55	51784	5	OBR
4950	55	51794	5	OBR
4951	55	51796	5	OBR
4952	55	51797	5	OBR
4953	55	51803	6	OBR
4954	55	51804	6	OBR
4955	55	37713	6	OBR
4956	55	51809	7	OBR
4957	55	51806	7	OBR
4958	55	51807	7	OBR
4959	55	39409	7	OBR
4960	55	51814	8	OBR
4961	55	51801	8	OBR
4962	55	51800	8	OBR
4963	55	45298	9	OBR
4964	55	51810	9	OBR
4965	55	51805	9	OBR
4966	55	51782	9	OBR
4967	55	45281	10	OBR
4968	55	51789	10	OBR
4969	55	51811	10	OBR
4970	55	51802	10	OBR
4971	55	51785	10	OBR
4972	55	51780	99	OPT
4973	55	41623	99	OPT
4974	55	31586	99	OPT
4975	55	51813	99	OPT
4976	55	51812	99	OPT
4977	55	51808	99	OPT
4978	55	41760	99	OPT
4979	55	45293	99	OPT
4980	55	41624	99	OPT
4981	55	45292	99	OPT
4982	55	45279	99	OPT
4983	55	42895	99	OPT
4984	55	45861	99	OPT
4985	55	40956	99	OPT
4986	55	51788	99	OPT
4987	55	45301	99	OPT
4988	55	45859	99	OPT
4989	55	45863	99	OPT
4990	55	45865	99	OPT
4991	56	41632	1	OBR
4992	56	41633	1	OBR
4993	56	47858	1	OBR
4994	56	36843	1	OBR
4995	56	47838	1	OBR
4996	56	47817	1	OBR
4997	56	41636	2	OBR
4998	56	47818	2	OBR
4999	56	41637	2	OBR
5000	56	47841	2	OBR
5001	56	47862	2	OBR
5002	56	47816	2	OBR
5003	56	36884	3	OBR
5004	56	47815	3	OBR
5005	56	41643	3	OBR
5006	56	47829	3	OBR
5007	56	47830	3	OBR
5008	56	47847	3	OBR
5009	56	47846	3	OBR
5010	56	36858	4	OBR
5011	56	36853	4	OBR
5012	56	36868	4	OBR
5013	56	36870	4	OBR
5014	56	41644	4	OBR
5015	56	47811	4	OBR
5016	56	47814	4	OBR
5017	56	36422	4	OBR
5018	56	36423	4	OBR
5019	56	36866	5	OBR
5020	56	47801	5	OBR
5021	56	47863	5	OBR
5022	56	47852	5	OBR
5023	56	47833	5	OBR
5024	56	36863	5	OBR
5025	56	36860	6	OBR
5026	56	36867	6	OBR
5027	56	47864	6	OBR
5028	56	47789	6	OBR
5029	56	47851	6	OBR
5030	56	47813	6	OBR
5031	56	36871	6	OBR
5032	56	36872	7	OBR
5033	56	47853	7	OBR
5034	56	47854	7	OBR
5035	56	47794	7	OBR
5036	56	47827	7	OBR
5037	56	47855	7	OBR
5038	56	47845	8	OBR
5039	56	47831	8	OBR
5040	56	47857	8	OBR
5041	56	47786	8	OBR
5042	56	47832	8	OBR
5043	56	36885	8	OBR
5044	56	47843	9	OBR
5045	56	47820	9	OBR
5046	56	47822	9	OBR
5047	56	47824	9	OBR
5048	56	47797	9	OBR
5049	56	47798	9	OBR
5050	56	47799	9	OBR
5051	56	47800	9	OBR
5052	56	47834	9	OBR
5053	56	47826	9	OBR
5054	56	47812	10	OBR
5055	56	41629	99	OPT
5056	56	47790	99	OPT
5057	56	47860	99	OPT
5058	56	36337	99	OPT
5059	56	31970	99	OPT
5060	56	47806	99	OPT
5061	56	41178	99	OPT
5062	56	47809	99	OPT
5063	56	47808	99	OPT
5064	56	36343	99	OPT
5065	56	36344	99	OPT
5066	56	36809	99	OPT
5067	56	41527	99	OPT
5068	56	47819	99	OPT
5069	56	36810	99	OPT
5070	56	36811	99	OPT
5071	56	47850	99	OPT
5072	56	41760	99	OPT
5073	56	47802	99	OPT
5074	56	36437	99	OPT
5075	56	35081	99	OPT
5076	56	41756	99	OPT
5077	56	41470	99	OPT
5078	56	41524	99	OPT
5079	56	34343	99	OPT
5080	56	32013	99	OPT
5081	56	47796	99	OPT
5082	56	47842	99	OPT
5083	56	47791	99	OPT
5084	56	45516	99	OPT
5085	56	47792	99	OPT
5086	56	47805	99	OPT
5087	56	47840	99	OPT
5088	56	44523	99	OPT
5089	56	47839	99	OPT
5090	56	36816	99	OPT
5091	56	47859	99	OPT
5092	56	47849	99	OPT
5093	56	47793	99	OPT
5094	56	47861	99	OPT
5095	56	36434	99	OPT
5096	56	47844	99	OPT
5097	56	36427	99	OPT
5098	56	47825	99	OPT
5099	56	41488	99	OPT
5100	56	47807	99	OPT
5101	56	47828	99	OPT
5102	56	36827	99	OPT
5103	56	47856	99	OPT
5104	56	36829	99	OPT
5105	56	47823	99	OPT
5106	56	32040	99	OPT
5107	56	32000	99	OPT
5108	56	36830	99	OPT
5109	56	36831	99	OPT
5110	56	47836	99	OPT
5111	56	41531	99	OPT
5112	56	47835	99	OPT
5113	56	47804	99	OPT
5114	56	47795	99	OPT
5115	56	47848	99	OPT
5116	56	36836	99	OPT
5117	56	36837	99	OPT
5118	56	47788	99	OPT
5119	56	47810	99	OPT
5120	56	47821	99	OPT
5121	56	47837	99	OPT
5122	56	36838	99	OPT
5123	56	47803	99	OPT
5124	56	47787	99	OPT
5125	57	51969	1	OBR
5126	57	51970	1	OBR
5127	57	51968	1	OBR
5128	57	36389	1	OBR
5129	57	51999	1	OBR
5130	57	50156	1	OBR
5131	57	50837	1	OBR
5132	57	50829	1	OBR
5133	57	51972	1	OBR
5134	57	36394	2	OBR
5135	57	41445	2	OBR
5136	57	41654	2	OBR
5137	57	51973	2	OBR
5138	57	36399	2	OBR
5139	57	41656	2	OBR
5140	57	51772	2	OBR
5141	57	36407	2	OBR
5142	57	36402	3	OBR
5143	57	41658	3	OBR
5144	57	51971	3	OBR
5145	57	51977	3	OBR
5146	57	36398	3	OBR
5147	57	52006	3	OBR
5148	57	36406	3	OBR
5149	57	51997	3	OBR
5150	57	51989	3	OBR
5151	57	51975	4	OBR
5152	57	52005	4	OBR
5153	57	36411	4	OBR
5154	57	36414	4	OBR
5155	57	36412	4	OBR
5156	57	36413	4	OBR
5157	57	36415	4	OBR
5158	57	51982	5	OBR
5159	57	36418	5	OBR
5160	57	36419	5	OBR
5161	57	36420	5	OBR
5162	57	36421	5	OBR
5163	57	36422	5	OBR
5164	57	36423	5	OBR
5165	57	36424	6	OBR
5166	57	36425	6	OBR
5167	57	36426	6	OBR
5168	57	51979	6	OBR
5169	57	36428	6	OBR
5170	57	36429	6	OBR
5171	57	51978	7	OBR
5172	57	36431	7	OBR
5173	57	52000	7	OBR
5174	57	51995	7	OBR
5175	57	36433	7	OBR
5176	57	52001	7	OBR
5177	57	36430	8	OBR
5178	57	36437	8	OBR
5179	57	36439	8	OBR
5180	57	51980	8	OBR
5181	57	51996	8	OBR
5182	57	52002	9	OBR
5183	57	52003	9	OBR
5184	57	36443	9	OBR
5185	57	51998	99	OPT
5186	57	36337	99	OPT
5187	57	36338	99	OPT
5188	57	36339	99	OPT
5189	57	36340	99	OPT
5190	57	36341	99	OPT
5191	57	36342	99	OPT
5192	57	36343	99	OPT
5193	57	36344	99	OPT
5194	57	36345	99	OPT
5195	57	51988	99	OPT
5196	57	36346	99	OPT
5197	57	36347	99	OPT
5198	57	36348	99	OPT
5199	57	51994	99	OPT
5200	57	36349	99	OPT
5201	57	36810	99	OPT
5202	57	51985	99	OPT
5203	57	41760	99	OPT
5204	57	51991	99	OPT
5205	57	51990	99	OPT
5206	57	51773	99	OPT
5207	57	51992	99	OPT
5208	57	36352	99	OPT
5209	57	51993	99	OPT
5210	57	51983	99	OPT
5211	57	36353	99	OPT
5212	57	52004	99	OPT
5213	57	51984	99	OPT
5214	57	36354	99	OPT
5215	57	36361	99	OPT
5216	57	36355	99	OPT
5217	57	36816	99	OPT
5218	57	36357	99	OPT
5219	57	47849	99	OPT
5220	57	36358	99	OPT
5221	57	36359	99	OPT
5222	57	51986	99	OPT
5223	57	36434	99	OPT
5224	57	51976	99	OPT
5225	57	41648	99	OPT
5226	57	36364	99	OPT
5227	57	36365	99	OPT
5228	57	36366	99	OPT
5229	57	36367	99	OPT
5230	57	36368	99	OPT
5231	57	51974	99	OPT
5232	57	36369	99	OPT
5233	57	51981	99	OPT
5234	57	36370	99	OPT
5235	57	36371	99	OPT
5236	57	41649	99	OPT
5237	57	36373	99	OPT
5238	57	36374	99	OPT
5239	57	36375	99	OPT
5240	57	36376	99	OPT
5241	57	36377	99	OPT
5242	57	36378	99	OPT
5243	57	51987	99	OPT
5244	57	36379	99	OPT
5245	57	36380	99	OPT
5246	57	36381	99	OPT
5247	57	36382	99	OPT
5248	57	36383	99	OPT
5249	57	36384	99	OPT
5250	57	36385	99	OPT
5251	58	51939	1	OBR
5252	58	51938	1	OBR
5253	58	37436	1	OBR
5254	58	51931	1	OBR
5255	58	51928	1	OBR
5256	58	51940	1	OBR
5257	58	37431	1	OBR
5258	58	51930	1	OBR
5259	58	37460	2	OBR
5260	58	37433	2	OBR
5261	58	51933	2	OBR
5262	58	51935	2	OBR
5263	58	51941	2	OBR
5264	58	37590	2	OBR
5265	58	51943	3	OBR
5266	58	51936	3	OBR
5267	58	51929	3	OBR
5268	58	51937	3	OBR
5269	58	51948	3	OBR
5270	58	37450	3	OBR
5271	58	51957	3	OBR
5272	58	51917	4	OBR
5273	58	51932	4	OBR
5274	58	37441	4	OBR
5275	58	37444	4	OBR
5276	58	37543	4	OBR
5277	58	51956	4	OBR
5278	58	37445	4	OBR
5279	58	37446	5	OBR
5280	58	37447	5	OBR
5281	58	37602	5	OBR
5282	58	51945	5	OBR
5283	58	51950	5	OBR
5284	58	37449	5	OBR
5285	58	51944	5	OBR
5286	58	51951	6	OBR
5287	58	51918	6	OBR
5288	58	37458	6	OBR
5289	58	51942	6	OBR
5290	58	51920	6	OBR
5291	58	37606	6	OBR
5292	58	51921	6	OBR
5293	58	51919	7	OBR
5294	58	37525	7	OBR
5295	58	51953	7	OBR
5296	58	37475	7	OBR
5297	58	37603	7	OBR
5298	58	37549	7	OBR
5299	58	51922	7	OBR
5300	58	37617	8	OBR
5301	58	51954	8	OBR
5302	58	51923	8	OBR
5303	58	51924	8	OBR
5304	58	51912	8	OBR
5305	58	37548	8	OBR
5306	58	37625	8	OBR
5307	58	51955	9	OBR
5308	58	37435	9	OBR
5309	58	51916	9	OBR
5310	58	51959	9	OBR
5311	58	51960	9	OBR
5312	58	51958	9	OBR
5313	58	51963	9	OBR
5314	58	37512	99	OPT
5315	58	37513	99	OPT
5316	58	37648	99	OPT
5317	58	51946	99	OPT
5318	58	46533	99	OPT
5319	58	51926	99	OPT
5320	58	37649	99	OPT
5321	58	51927	99	OPT
5322	58	37651	99	OPT
5323	58	46517	99	OPT
5324	58	46523	99	OPT
5325	58	37652	99	OPT
5326	58	46520	99	OPT
5327	58	37519	99	OPT
5328	58	46515	99	OPT
5329	58	37556	99	OPT
5330	58	37537	99	OPT
5331	58	37653	99	OPT
5332	58	37473	99	OPT
5333	58	37486	99	OPT
5334	58	37522	99	OPT
5335	58	37654	99	OPT
5336	58	37655	99	OPT
5337	58	46524	99	OPT
5338	58	51947	99	OPT
5339	58	51961	99	OPT
5340	58	46521	99	OPT
5341	58	46522	99	OPT
5342	58	37657	99	OPT
5343	58	51934	99	OPT
5344	58	37542	99	OPT
5345	58	46532	99	OPT
5346	58	46518	99	OPT
5347	58	37658	99	OPT
5348	58	46519	99	OPT
5349	58	51925	99	OPT
5350	58	37659	99	OPT
5351	58	37550	99	OPT
5352	58	37551	99	OPT
5353	58	37660	99	OPT
5354	58	51914	99	OPT
5355	58	51949	99	OPT
5356	58	51913	99	OPT
5357	58	51952	99	OPT
5358	58	51915	99	OPT
5359	58	51962	99	OPT
5360	58	46529	99	OPT
5361	58	46531	99	OPT
5362	59	37427	1	OBR
5363	59	37428	1	OBR
5364	59	37429	1	OBR
5365	59	37430	1	OBR
5366	59	37431	1	OBR
5367	59	37432	1	OBR
5368	59	37433	2	OBR
5369	59	37434	2	OBR
5370	59	37435	2	OBR
5371	59	37436	2	OBR
5372	59	37437	2	OBR
5373	59	37438	2	OBR
5374	59	37439	2	OBR
5375	59	37440	3	OBR
5376	59	37441	3	OBR
5377	59	37442	3	OBR
5378	59	37443	3	OBR
5379	59	37444	3	OBR
5380	59	37445	3	OBR
5381	59	37446	4	OBR
5382	59	37447	4	OBR
5383	59	37448	4	OBR
5384	59	37449	4	OBR
5385	59	37450	4	OBR
5386	59	37451	4	OBR
5387	59	37452	4	OBR
5388	59	37453	5	OBR
5389	59	37454	5	OBR
5390	59	37455	5	OBR
5391	59	37456	5	OBR
5392	59	37457	5	OBR
5393	59	37458	5	OBR
5394	59	37459	5	OBR
5395	59	37460	6	OBR
5396	59	37461	6	OBR
5397	59	37463	6	OBR
5398	59	37464	6	OBR
5399	59	37466	6	OBR
5400	59	37468	6	OBR
5401	59	37483	7	OBR
5402	59	37470	7	OBR
5403	59	37472	7	OBR
5404	59	37473	7	OBR
5405	59	37475	7	OBR
5406	59	37476	7	OBR
5407	59	37478	7	OBR
5408	59	37497	8	OBR
5409	59	37486	8	OBR
5410	59	37489	8	OBR
5411	59	37481	8	OBR
5412	59	37491	8	OBR
5413	59	37493	8	OBR
5414	59	37495	9	OBR
5415	59	37485	9	OBR
5416	59	37499	9	OBR
5417	59	37500	9	OBR
5418	59	37504	9	OBR
5419	59	37505	9	OBR
5420	59	37512	99	OPT
5421	59	37513	99	OPT
5422	59	37516	99	OPT
5423	59	37517	99	OPT
5424	59	46517	99	OPT
5425	59	37518	99	OPT
5426	59	46523	99	OPT
5427	59	46520	99	OPT
5428	59	37519	99	OPT
5429	59	46515	99	OPT
5430	59	37556	99	OPT
5431	59	37521	99	OPT
5432	59	37537	99	OPT
5433	59	37522	99	OPT
5434	59	37523	99	OPT
5435	59	37524	99	OPT
5436	59	37525	99	OPT
5437	59	37526	99	OPT
5438	59	46524	99	OPT
5439	59	37535	99	OPT
5440	59	46521	99	OPT
5441	59	46522	99	OPT
5442	59	37538	99	OPT
5443	59	37542	99	OPT
5444	59	37543	99	OPT
5445	59	37548	99	OPT
5446	59	46518	99	OPT
5447	59	46519	99	OPT
5448	59	51820	99	OPT
5449	59	37549	99	OPT
5450	59	37550	99	OPT
5451	59	46516	99	OPT
5452	59	37551	99	OPT
5453	59	37552	99	OPT
5454	59	37553	99	OPT
5455	60	49713	1	OBR
5456	60	49699	1	OBR
5457	60	49711	1	OBR
5458	60	49712	1	OBR
5459	60	49709	1	OBR
5460	60	49692	2	OBR
5461	60	49740	2	OBR
5462	60	49714	2	OBR
5463	60	49723	2	OBR
5464	60	49715	2	OBR
5465	60	49724	3	OBR
5466	60	49694	3	OBR
5467	60	49703	3	OBR
5468	60	49728	3	OBR
5469	60	49725	3	OBR
5470	60	49707	4	OBR
5471	60	49729	4	OBR
5472	60	49716	4	OBR
5473	60	49700	4	OBR
5474	60	49698	4	OBR
5475	60	49717	5	OBR
5476	60	49722	5	OBR
5477	60	49695	5	OBR
5478	60	49730	5	OBR
5479	60	49726	5	OBR
5480	60	49727	6	OBR
5481	60	49697	6	OBR
5482	60	49708	6	OBR
5483	60	49696	6	OBR
5484	60	49693	6	OBR
5485	60	49718	7	OBR
5486	60	49721	7	OBR
5487	60	49719	7	OBR
5488	60	49720	8	OBR
5489	60	49686	8	OBR
5490	60	49710	8	OBR
5491	60	43104	99	OPT
5492	60	43136	99	OPT
5493	60	49706	99	OPT
5494	60	43686	99	OPT
5495	60	49688	99	OPT
5496	60	49691	99	OPT
5497	60	49687	99	OPT
5498	60	49737	99	OPT
5499	60	49731	99	OPT
5500	60	49732	99	OPT
5501	60	49738	99	OPT
5502	60	49690	99	OPT
5503	60	49733	99	OPT
5504	60	49739	99	OPT
5505	60	49701	99	OPT
5506	60	49734	99	OPT
5507	60	49741	99	OPT
5508	60	49704	99	OPT
5509	60	49735	99	OPT
5510	60	49742	99	OPT
5511	60	49689	99	OPT
5512	60	49736	99	OPT
5513	60	49685	99	OPT
5514	60	49705	99	OPT
5515	60	49702	99	OPT
5516	61	51939	1	OBR
5517	61	51938	1	OBR
5518	61	37436	1	OBR
5519	61	51931	1	OBR
5520	61	51928	1	OBR
5521	61	51940	1	OBR
5522	61	37431	1	OBR
5523	61	51930	1	OBR
5524	61	37460	2	OBR
5525	61	37433	2	OBR
5526	61	51933	2	OBR
5527	61	51935	2	OBR
5528	61	51941	2	OBR
5529	61	37590	2	OBR
5530	61	51943	3	OBR
5531	61	51936	3	OBR
5532	61	51929	3	OBR
5533	61	51937	3	OBR
5534	61	51948	3	OBR
5535	61	37450	3	OBR
5536	61	51957	3	OBR
5537	61	51917	4	OBR
5538	61	51932	4	OBR
5539	61	37441	4	OBR
5540	61	37444	4	OBR
5541	61	37543	4	OBR
5542	61	51956	4	OBR
5543	61	37445	4	OBR
5544	61	37446	5	OBR
5545	61	37447	5	OBR
5546	61	37602	5	OBR
5547	61	51945	5	OBR
5548	61	51950	5	OBR
5549	61	37449	5	OBR
5550	61	51944	5	OBR
5551	61	51951	6	OBR
5552	61	51918	6	OBR
5553	61	37458	6	OBR
5554	61	51942	6	OBR
5555	61	51920	6	OBR
5556	61	37606	6	OBR
5557	61	51921	6	OBR
5558	61	51919	7	OBR
5559	61	37525	7	OBR
5560	61	51953	7	OBR
5561	61	37475	7	OBR
5562	61	37603	7	OBR
5563	61	37549	7	OBR
5564	61	51922	7	OBR
5565	61	37617	8	OBR
5566	61	51954	8	OBR
5567	61	51923	8	OBR
5568	61	51924	8	OBR
5569	61	51912	8	OBR
5570	61	37548	8	OBR
5571	61	37625	8	OBR
5572	61	51955	9	OBR
5573	61	37435	9	OBR
5574	61	51916	9	OBR
5575	61	51959	9	OBR
5576	61	51960	9	OBR
5577	61	51958	9	OBR
5578	61	51963	9	OBR
5579	61	37512	99	OPT
5580	61	37513	99	OPT
5581	61	37648	99	OPT
5582	61	51946	99	OPT
5583	61	46533	99	OPT
5584	61	51926	99	OPT
5585	61	37649	99	OPT
5586	61	51927	99	OPT
5587	61	37651	99	OPT
5588	61	46517	99	OPT
5589	61	46523	99	OPT
5590	61	37652	99	OPT
5591	61	46520	99	OPT
5592	61	37519	99	OPT
5593	61	46515	99	OPT
5594	61	37556	99	OPT
5595	61	37537	99	OPT
5596	61	37653	99	OPT
5597	61	37473	99	OPT
5598	61	37486	99	OPT
5599	61	37522	99	OPT
5600	61	37654	99	OPT
5601	61	37655	99	OPT
5602	61	46524	99	OPT
5603	61	51947	99	OPT
5604	61	51961	99	OPT
5605	61	46521	99	OPT
5606	61	46522	99	OPT
5607	61	37657	99	OPT
5608	61	51934	99	OPT
5609	61	37542	99	OPT
5610	61	46532	99	OPT
5611	61	46518	99	OPT
5612	61	37658	99	OPT
5613	61	46519	99	OPT
5614	61	51925	99	OPT
5615	61	37659	99	OPT
5616	61	37550	99	OPT
5617	61	37551	99	OPT
5618	61	37660	99	OPT
5619	61	51914	99	OPT
5620	61	51949	99	OPT
5621	61	51913	99	OPT
5622	61	51952	99	OPT
5623	61	51915	99	OPT
5624	61	51962	99	OPT
5625	61	46529	99	OPT
5626	61	46531	99	OPT
5627	63	48062	1	OBR
5628	63	43799	1	OBR
5629	63	48056	1	OBR
5630	63	48060	1	OBR
5631	63	48073	1	OBR
5632	63	48051	2	OBR
5633	63	48055	2	OBR
5634	63	48050	2	OBR
5635	63	48064	2	OBR
5636	63	48077	2	OBR
5637	63	48059	3	OBR
5638	63	48065	3	OBR
5639	63	48066	3	OBR
5640	63	48081	3	OBR
5641	63	48080	3	OBR
5642	63	48068	4	OBR
5643	63	48078	4	OBR
5644	63	43798	4	OBR
5645	63	48072	4	OBR
5646	63	48074	4	OBR
5647	63	48054	5	OBR
5648	63	48067	5	OBR
5649	63	48075	5	OBR
5650	63	48076	5	OBR
5651	63	43804	5	OBR
5652	63	48079	5	OBR
5653	63	43815	6	OBR
5654	63	48058	6	OBR
5655	63	48069	6	OBR
5656	63	48071	6	OBR
5657	63	48082	6	OBR
5658	63	48052	7	OBR
5659	63	43812	7	OBR
5660	63	48053	7	OBR
5661	63	48070	7	OBR
5662	63	48083	7	OBR
5663	63	43797	8	OBR
5664	63	48057	8	OBR
5665	63	48063	8	OBR
5666	63	48061	8	OBR
5667	63	48049	8	OBR
5668	63	38255	99	OPT
5669	63	38256	99	OPT
5670	63	38257	99	OPT
5671	63	38258	99	OPT
5672	63	48084	99	OPT
5673	63	43793	99	OPT
5674	63	38259	99	OPT
5675	63	38260	99	OPT
5676	63	38261	99	OPT
5677	63	38186	99	OPT
5678	63	38263	99	OPT
5679	63	38264	99	OPT
5680	63	43795	99	OPT
5681	63	38265	99	OPT
5682	63	38266	99	OPT
5683	63	38267	99	OPT
5684	63	38268	99	OPT
5685	63	38269	99	OPT
5686	63	38270	99	OPT
5687	63	38271	99	OPT
5688	63	43805	99	OPT
5689	63	38272	99	OPT
5690	63	38301	99	OPT
5691	63	38275	99	OPT
5692	63	38276	99	OPT
5693	63	43796	99	OPT
5694	63	43801	99	OPT
5695	63	43802	99	OPT
5696	63	38278	99	OPT
5697	63	38277	99	OPT
5698	63	38280	99	OPT
5699	63	43810	99	OPT
5700	63	38281	99	OPT
5701	63	38282	99	OPT
5702	63	38283	99	OPT
5703	63	38285	99	OPT
5704	63	38286	99	OPT
5705	63	38287	99	OPT
5706	63	38288	99	OPT
5707	63	38289	99	OPT
5708	63	43809	99	OPT
5709	63	38294	99	OPT
5710	63	38290	99	OPT
5711	63	38291	99	OPT
5712	63	38292	99	OPT
5713	63	38293	99	OPT
5714	63	38295	99	OPT
5715	63	38296	99	OPT
5716	63	43807	99	OPT
5717	63	38302	99	OPT
5718	63	38298	99	OPT
5719	63	38299	99	OPT
5720	63	43800	99	OPT
5721	63	38300	99	OPT
5722	64	48765	1	OBR
5723	64	48758	1	OBR
5724	64	48747	1	OBR
5725	64	48764	1	OBR
5726	64	48767	2	OBR
5727	64	48763	2	OBR
5728	64	48789	2	OBR
5729	64	48768	2	OBR
5730	64	48766	2	OBR
5731	64	48771	3	OBR
5732	64	48785	3	OBR
5733	64	48770	3	OBR
5734	64	48773	3	OBR
5735	64	48743	3	OBR
5736	64	48790	4	OBR
5737	64	48740	4	OBR
5738	64	48781	4	OBR
5739	64	48782	4	OBR
5740	64	48750	4	OBR
5741	64	48751	5	OBR
5742	64	48753	5	OBR
5743	64	48788	5	OBR
5744	64	48744	5	OBR
5745	64	48774	6	OBR
5746	64	48759	6	OBR
5747	64	48754	6	OBR
5748	64	48749	6	OBR
5749	64	48757	6	OBR
5750	64	48777	7	OBR
5751	64	43686	7	OBR
5752	64	48776	7	OBR
5753	64	48783	8	OBR
5754	64	48760	8	OBR
5755	64	48784	99	OPT
5756	64	48755	99	OPT
5757	64	48745	99	OPT
5758	64	48775	99	OPT
5759	64	48741	99	OPT
5760	64	48772	99	OPT
5761	64	48752	99	OPT
5762	64	48756	99	OPT
5763	64	48769	99	OPT
5764	64	38242	99	OPT
5765	64	48787	99	OPT
5766	64	48746	99	OPT
5767	64	48786	99	OPT
5768	64	48742	99	OPT
5769	64	48748	99	OPT
5770	64	48779	99	OPT
5771	64	48761	99	OPT
5772	64	48778	99	OPT
5773	64	48780	99	OPT
5774	64	48762	99	OPT
5775	65	48641	1	OBR
5776	65	48649	1	OBR
5777	65	48634	1	OBR
5778	65	48626	1	OBR
5779	65	48644	1	OBR
5780	65	48646	2	OBR
5781	65	43686	2	OBR
5782	65	48608	2	OBR
5783	65	48632	2	OBR
5784	65	48635	2	OBR
5785	65	48651	3	OBR
5786	65	48648	3	OBR
5787	65	48642	3	OBR
5788	65	48610	3	OBR
5789	65	48607	3	OBR
5790	65	48647	4	OBR
5791	65	48654	4	OBR
5792	65	48614	4	OBR
5793	65	43018	4	OBR
5794	65	48643	4	OBR
5795	65	48613	5	OBR
5796	65	48652	5	OBR
5797	65	48650	5	OBR
5798	65	48612	5	OBR
5799	65	48616	6	OBR
5800	65	48618	6	OBR
5801	65	48615	6	OBR
5802	65	48609	6	OBR
5803	65	48617	7	OBR
5804	65	48653	7	OBR
5805	65	48622	7	OBR
5806	65	48645	7	OBR
5807	65	48623	8	OBR
5808	65	48621	8	OBR
5809	65	48628	8	OBR
5810	65	48636	99	OPT
5811	65	39502	99	OPT
5812	65	48637	99	OPT
5813	65	43031	99	OPT
5814	65	48611	99	OPT
5815	65	48619	99	OPT
5816	65	43032	99	OPT
5817	65	48631	99	OPT
5818	65	43033	99	OPT
5819	65	48639	99	OPT
5820	65	43010	99	OPT
5821	65	48620	99	OPT
5822	65	48625	99	OPT
5823	65	48629	99	OPT
5824	65	33459	99	OPT
5825	65	48638	99	OPT
5826	65	46534	99	OPT
5827	65	39535	99	OPT
5828	65	48633	99	OPT
5829	65	43040	99	OPT
5830	65	48640	99	OPT
5831	65	48627	99	OPT
5832	65	48630	99	OPT
5833	65	48624	99	OPT
5834	66	48533	1	OBR
5835	66	48482	1	OBR
5836	66	48468	1	OBR
5837	66	48485	1	OBR
5838	66	48540	1	OBR
5839	66	48529	2	OBR
5840	66	48530	2	OBR
5841	66	48528	2	OBR
5842	66	48546	2	OBR
5843	66	48547	2	OBR
5844	66	48475	2	OBR
5845	66	48526	3	OBR
5846	66	48531	3	OBR
5847	66	48525	3	OBR
5848	66	48545	3	OBR
5849	66	48549	3	OBR
5850	66	48479	3	OBR
5851	66	48532	4	OBR
5852	66	48527	4	OBR
5853	66	48541	4	OBR
5854	66	48473	4	OBR
5855	66	48480	4	OBR
5856	66	48535	5	OBR
5857	66	48538	5	OBR
5858	66	48483	5	OBR
5859	66	48523	5	OBR
5860	66	48469	5	OBR
5861	66	48524	6	OBR
5862	66	48470	6	OBR
5863	66	48550	6	OBR
5864	66	48478	6	OBR
5865	66	48548	6	OBR
5866	66	48534	7	OBR
5867	66	48542	7	OBR
5868	66	48484	7	OBR
5869	66	48481	7	OBR
5870	66	48477	7	OBR
5871	66	48519	8	OBR
5872	66	48536	8	OBR
5873	66	48537	8	OBR
5874	66	48522	8	OBR
5875	66	48472	8	OBR
5876	66	48476	8	OBR
5877	66	43686	9	OBR
5878	66	48543	9	OBR
5879	66	48539	9	OBR
5880	66	48474	9	OBR
5881	66	48471	9	OBR
5882	66	48544	10	OBR
5883	66	48491	99	OPT
5884	66	48489	99	OPT
5885	66	48488	99	OPT
5886	66	48518	99	OPT
5887	66	48517	99	OPT
5888	66	48490	99	OPT
5889	66	48492	99	OPT
5890	66	48495	99	OPT
5891	66	48496	99	OPT
5892	66	48520	99	OPT
5893	66	48497	99	OPT
5894	66	48498	99	OPT
5895	66	48499	99	OPT
5896	66	48500	99	OPT
5897	66	48501	99	OPT
5898	66	48502	99	OPT
5899	66	48503	99	OPT
5900	66	48504	99	OPT
5901	66	48516	99	OPT
5902	66	48505	99	OPT
5903	66	48493	99	OPT
5904	66	48486	99	OPT
5905	66	48512	99	OPT
5906	66	48515	99	OPT
5907	66	48514	99	OPT
5908	66	48513	99	OPT
5909	66	48506	99	OPT
5910	66	48507	99	OPT
5911	66	48508	99	OPT
5912	66	48521	99	OPT
5913	66	48494	99	OPT
5914	66	48509	99	OPT
5915	66	48510	99	OPT
5916	66	48487	99	OPT
5917	66	48511	99	OPT
5918	67	48533	1	OBR
5919	67	48482	1	OBR
5920	67	48468	1	OBR
5921	67	48485	1	OBR
5922	67	48540	1	OBR
5923	67	48529	2	OBR
5924	67	48530	2	OBR
5925	67	48528	2	OBR
5926	67	48546	2	OBR
5927	67	48547	2	OBR
5928	67	48475	2	OBR
5929	67	48526	3	OBR
5930	67	48531	3	OBR
5931	67	48525	3	OBR
5932	67	48545	3	OBR
5933	67	48549	3	OBR
5934	67	48479	3	OBR
5935	67	48532	4	OBR
5936	67	48527	4	OBR
5937	67	48541	4	OBR
5938	67	48473	4	OBR
5939	67	48480	4	OBR
5940	67	48535	5	OBR
5941	67	48538	5	OBR
5942	67	48483	5	OBR
5943	67	48523	5	OBR
5944	67	48469	5	OBR
5945	67	48524	6	OBR
5946	67	48470	6	OBR
5947	67	48550	6	OBR
5948	67	48478	6	OBR
5949	67	48548	6	OBR
5950	67	48534	7	OBR
5951	67	48542	7	OBR
5952	67	48484	7	OBR
5953	67	48481	7	OBR
5954	67	48477	7	OBR
5955	67	48519	8	OBR
5956	67	48536	8	OBR
5957	67	48537	8	OBR
5958	67	48522	8	OBR
5959	67	48472	8	OBR
5960	67	48476	8	OBR
5961	67	43686	9	OBR
5962	67	48543	9	OBR
5963	67	48539	9	OBR
5964	67	48474	9	OBR
5965	67	48471	9	OBR
5966	67	48544	10	OBR
5967	67	48491	99	OPT
5968	67	48489	99	OPT
5969	67	48488	99	OPT
5970	67	48518	99	OPT
5971	67	48517	99	OPT
5972	67	48490	99	OPT
5973	67	48492	99	OPT
5974	67	48495	99	OPT
5975	67	48496	99	OPT
5976	67	48520	99	OPT
5977	67	48497	99	OPT
5978	67	48498	99	OPT
5979	67	48499	99	OPT
5980	67	48500	99	OPT
5981	67	48501	99	OPT
5982	67	48502	99	OPT
5983	67	48503	99	OPT
5984	67	48504	99	OPT
5985	67	48516	99	OPT
5986	67	48505	99	OPT
5987	67	48493	99	OPT
5988	67	48486	99	OPT
5989	67	48512	99	OPT
5990	67	48515	99	OPT
5991	67	48514	99	OPT
5992	67	48513	99	OPT
5993	67	48506	99	OPT
5994	67	48507	99	OPT
5995	67	48508	99	OPT
5996	67	48521	99	OPT
5997	67	48494	99	OPT
5998	67	48509	99	OPT
5999	67	48510	99	OPT
6000	67	48487	99	OPT
6001	67	48511	99	OPT
6002	68	45576	1	OBR
6003	68	45582	1	OBR
6004	68	45577	1	OBR
6005	68	39704	1	OBR
6006	68	45581	1	OBR
6007	68	39791	2	OBR
6008	68	39707	2	OBR
6009	68	45580	2	OBR
6010	68	39710	2	OBR
6011	68	45584	2	OBR
6012	68	45585	3	OBR
6013	68	44198	3	OBR
6014	68	39715	3	OBR
6015	68	39716	3	OBR
6016	68	39717	3	OBR
6017	68	44206	4	OBR
6018	68	44200	4	OBR
6019	68	39720	4	OBR
6020	68	39721	4	OBR
6021	68	39722	4	OBR
6022	68	39723	5	OBR
6023	68	39724	5	OBR
6024	68	45575	5	OBR
6025	68	45579	5	OBR
6026	68	45583	6	OBR
6027	68	39727	6	OBR
6028	68	45578	6	OBR
6029	68	39730	6	OBR
6030	68	39731	6	OBR
6031	68	44204	7	OBR
6032	68	39734	7	OBR
6033	68	39732	7	OBR
6034	68	44209	7	OBR
6035	68	39736	7	OBR
6036	68	44205	8	OBR
6037	68	39738	8	OBR
6038	68	44207	8	OBR
6039	68	39741	99	OPT
6040	68	39742	99	OPT
6041	68	39743	99	OPT
6042	68	39745	99	OPT
6043	68	39746	99	OPT
6044	68	39747	99	OPT
6045	68	39748	99	OPT
6046	68	39749	99	OPT
6047	68	39750	99	OPT
6048	68	39751	99	OPT
6049	68	39752	99	OPT
6050	68	44202	99	OPT
6051	68	39753	99	OPT
6052	68	39754	99	OPT
6053	68	39757	99	OPT
6054	68	39755	99	OPT
6055	68	39756	99	OPT
6056	68	39758	99	OPT
6057	68	44201	99	OPT
6058	68	44210	99	OPT
6059	68	39759	99	OPT
6060	68	44197	99	OPT
6061	68	44203	99	OPT
6062	68	44208	99	OPT
6063	68	39760	99	OPT
6064	68	44199	99	OPT
6065	68	39761	99	OPT
6066	68	39764	99	OPT
6067	68	39762	99	OPT
6068	68	39763	99	OPT
6069	69	49934	1	OBR
6070	69	49932	1	OBR
6071	69	49939	1	OBR
6072	69	49938	1	OBR
6073	69	49940	1	OBR
6074	69	49935	2	OBR
6075	69	49923	2	OBR
6076	69	49933	2	OBR
6077	69	49937	2	OBR
6078	69	49936	2	OBR
6079	69	49916	3	OBR
6080	69	49929	3	OBR
6081	69	49919	3	OBR
6082	69	49915	3	OBR
6083	69	49917	3	OBR
6084	69	49920	4	OBR
6085	69	49925	4	OBR
6086	69	49912	4	OBR
6087	69	49944	4	OBR
6088	69	49926	4	OBR
6089	69	49924	5	OBR
6090	69	49918	5	OBR
6091	69	49945	5	OBR
6092	69	49922	5	OBR
6093	69	49921	5	OBR
6094	69	49927	5	OBR
6095	69	49949	6	OBR
6096	69	49947	6	OBR
6097	69	49950	6	OBR
6098	69	49911	6	OBR
6099	69	49951	6	OBR
6100	69	49928	7	OBR
6101	69	49946	7	OBR
6102	69	49948	7	OBR
6103	69	49914	7	OBR
6104	69	49941	7	OBR
6105	69	49943	8	OBR
6106	69	49942	8	OBR
6107	69	49913	8	OBR
6108	69	49953	8	OBR
6109	69	49952	8	OBR
6110	69	39767	99	OPT
6111	69	39768	99	OPT
6112	69	44212	99	OPT
6113	69	39771	99	OPT
6114	69	39772	99	OPT
6115	69	39781	99	OPT
6116	69	49931	99	OPT
6117	69	49930	99	OPT
6118	69	39786	99	OPT
6119	69	39788	99	OPT
6120	70	51082	1	OBR
6121	70	51066	1	OBR
6122	70	51088	1	OBR
6123	70	51080	1	OBR
6124	70	51084	1	OBR
6125	70	51075	2	OBR
6126	70	51072	2	OBR
6127	70	51092	2	OBR
6128	70	51093	2	OBR
6129	70	51067	2	OBR
6130	70	51079	2	OBR
6131	70	51063	3	OBR
6132	70	51073	3	OBR
6133	70	51071	3	OBR
6134	70	51078	3	OBR
6135	70	51081	3	OBR
6136	70	45480	4	OBR
6137	70	51077	4	OBR
6138	70	45456	4	OBR
6139	70	51070	4	OBR
6140	70	51089	4	OBR
6141	70	51086	5	OBR
6142	70	45462	5	OBR
6143	70	51064	5	OBR
6144	70	51083	5	OBR
6145	70	51065	5	OBR
6146	70	45463	6	OBR
6147	70	51074	6	OBR
6148	70	51069	6	OBR
6149	70	51094	6	OBR
6150	70	51087	7	OBR
6151	70	41022	7	OBR
6152	70	51085	7	OBR
6153	70	45464	7	OBR
6154	70	51076	8	OBR
6155	70	51096	8	OBR
6156	70	51068	8	OBR
6157	70	51090	8	OBR
6158	70	51091	99	OPT
6159	70	51095	99	OPT
6160	70	45439	99	OPT
6161	70	45469	99	OPT
6162	70	45446	99	OPT
6163	70	45452	99	OPT
6164	70	39752	99	OPT
6165	70	45475	99	OPT
6166	70	45438	99	OPT
6167	70	45448	99	OPT
6168	70	44209	99	OPT
6169	70	45473	99	OPT
6170	70	41032	99	OPT
6171	70	45453	99	OPT
6172	70	45457	99	OPT
6173	70	45459	99	OPT
6174	70	45479	99	OPT
6175	70	45455	99	OPT
6176	70	45436	99	OPT
6177	70	45445	99	OPT
6178	70	45450	99	OPT
6179	70	41047	99	OPT
6180	70	45451	99	OPT
6181	70	45461	99	OPT
6182	70	45476	99	OPT
6183	70	45447	99	OPT
6184	70	45437	99	OPT
6185	70	45440	99	OPT
6186	70	45434	99	OPT
6187	70	45443	99	OPT
6188	70	45433	99	OPT
6189	71	52086	1	OBR
6190	71	47372	1	OBR
6191	71	50057	1	OBR
6192	71	50049	1	OBR
6193	71	50048	1	OBR
6194	71	50069	1	OBR
6195	71	50044	1	OBR
6196	71	52082	2	OBR
6197	71	52087	2	OBR
6198	71	52090	2	OBR
6199	71	50076	2	OBR
6200	71	50034	2	OBR
6201	71	50070	2	OBR
6202	71	52097	2	OBR
6203	71	52102	2	OBR
6204	71	52098	2	OBR
6205	71	52079	3	OBR
6206	71	52091	3	OBR
6207	71	50064	3	OBR
6208	71	50052	3	OBR
6209	71	50073	3	OBR
6210	71	50063	3	OBR
6211	71	50068	3	OBR
6212	71	50060	4	OBR
6213	71	52077	4	OBR
6214	71	50065	4	OBR
6215	71	50053	4	OBR
6216	71	50072	4	OBR
6217	71	50046	4	OBR
6218	71	50059	5	OBR
6219	71	52084	5	OBR
6220	71	50061	5	OBR
6221	71	50071	5	OBR
6222	71	50066	5	OBR
6223	71	50067	5	OBR
6224	71	50038	5	OBR
6225	71	52092	5	OBR
6226	71	52080	6	OBR
6227	71	52088	6	OBR
6228	71	50054	6	OBR
6229	71	50062	6	OBR
6230	71	50035	6	OBR
6231	71	52093	6	OBR
6232	71	52096	6	OBR
6233	71	52083	7	OBR
6234	71	50055	7	OBR
6235	71	52099	7	OBR
6236	71	52100	7	OBR
6237	71	52094	7	OBR
6238	71	52078	8	OBR
6239	71	52081	8	OBR
6240	71	52095	8	OBR
6241	71	50056	8	OBR
6242	71	52085	8	OBR
6243	71	52089	8	OBR
6244	71	50058	9	OBR
6245	71	52101	9	OBR
6246	71	50075	9	OBR
6247	71	46149	99	OPT
6248	71	46148	99	OPT
6249	71	39752	99	OPT
6250	71	43686	99	OPT
6251	71	46115	99	OPT
6252	71	46125	99	OPT
6253	71	46127	99	OPT
6254	71	46128	99	OPT
6255	71	46157	99	OPT
6256	71	45440	99	OPT
6257	71	45434	99	OPT
6258	71	45443	99	OPT
6259	71	47350	99	OPT
6260	71	47351	99	OPT
6261	71	47352	99	OPT
6262	71	47355	99	OPT
6263	71	47356	99	OPT
6264	71	47346	99	OPT
6265	71	47347	99	OPT
6266	71	47348	99	OPT
6267	71	47357	99	OPT
6268	71	47349	99	OPT
6269	71	47353	99	OPT
6270	71	47354	99	OPT
6271	72	48554	1	OBR
6272	72	44040	1	OBR
6273	72	48572	1	OBR
6274	72	48575	1	OBR
6275	72	44041	1	OBR
6276	72	48551	1	OBR
6277	72	48565	2	OBR
6278	72	48560	2	OBR
6279	72	44038	2	OBR
6280	72	48573	2	OBR
6281	72	48555	2	OBR
6282	72	48558	2	OBR
6283	72	44043	2	OBR
6284	72	48576	3	OBR
6285	72	44039	3	OBR
6286	72	37487	3	OBR
6287	72	48579	3	OBR
6288	72	48561	3	OBR
6289	72	48566	3	OBR
6290	72	48553	4	OBR
6291	72	38921	4	OBR
6292	72	38900	4	OBR
6293	72	48571	4	OBR
6294	72	48568	4	OBR
6295	72	38961	4	OBR
6296	72	38912	5	OBR
6297	72	48570	5	OBR
6298	72	48574	5	OBR
6299	72	38913	5	OBR
6300	72	48563	5	OBR
6301	72	37479	5	OBR
6302	72	38915	6	OBR
6303	72	38918	6	OBR
6304	72	48569	6	OBR
6305	72	48578	6	OBR
6306	72	48562	6	OBR
6307	72	48552	7	OBR
6308	72	48567	7	OBR
6309	72	38382	7	OBR
6310	72	48564	7	OBR
6311	72	48556	7	OBR
6312	72	48557	8	OBR
6313	72	48559	8	OBR
6314	72	48577	8	OBR
6315	72	38937	99	OPT
6316	72	38938	99	OPT
6317	72	38939	99	OPT
6318	72	37494	99	OPT
6319	72	38940	99	OPT
6320	72	33580	99	OPT
6321	72	44042	99	OPT
6322	72	33567	99	OPT
6323	72	44045	99	OPT
6324	72	43686	99	OPT
6325	72	33582	99	OPT
6326	72	33584	99	OPT
6327	72	38941	99	OPT
6328	72	37571	99	OPT
6329	72	38942	99	OPT
6330	72	38943	99	OPT
6331	72	38890	99	OPT
6332	72	44048	99	OPT
6333	72	44032	99	OPT
6334	72	33549	99	OPT
6335	72	33534	99	OPT
6336	72	33587	99	OPT
6337	72	38945	99	OPT
6338	72	44035	99	OPT
6339	72	38947	99	OPT
6340	72	30796	99	OPT
6341	72	37467	99	OPT
6342	72	38949	99	OPT
6343	72	33555	99	OPT
6344	72	33599	99	OPT
6345	72	33559	99	OPT
6346	72	37488	99	OPT
6347	72	44046	99	OPT
6348	72	44031	99	OPT
6349	72	44034	99	OPT
6350	72	44030	99	OPT
6351	72	33550	99	OPT
6352	72	38951	99	OPT
6353	72	38953	99	OPT
6354	72	44033	99	OPT
6355	72	44044	99	OPT
6356	72	44036	99	OPT
6357	73	48670	1	OBR
6358	73	48663	1	OBR
6359	73	48669	1	OBR
6360	73	37465	1	OBR
6361	73	48674	1	OBR
6362	73	48673	2	OBR
6363	73	48656	2	OBR
6364	73	37469	2	OBR
6365	73	37477	2	OBR
6366	73	37480	3	OBR
6367	73	48662	3	OBR
6368	73	37484	3	OBR
6369	73	48668	3	OBR
6370	73	48678	4	OBR
6371	73	43686	4	OBR
6372	73	48655	4	OBR
6373	73	48659	4	OBR
6374	73	48661	4	OBR
6375	73	48675	5	OBR
6376	73	48660	5	OBR
6377	73	48672	5	OBR
6378	73	37528	5	OBR
6379	73	48679	6	OBR
6380	73	48676	6	OBR
6381	73	48677	6	OBR
6382	73	48664	6	OBR
6383	73	48666	6	OBR
6384	73	38369	7	OBR
6385	73	48657	7	OBR
6386	73	48658	7	OBR
6387	73	48665	7	OBR
6388	73	48671	8	OBR
6389	73	38372	8	OBR
6390	73	48667	8	OBR
6391	73	37557	99	OPT
6392	73	37482	99	OPT
6393	73	37501	99	OPT
6394	73	38376	99	OPT
6395	73	37498	99	OPT
6396	73	38377	99	OPT
6397	73	37547	99	OPT
6398	73	37562	99	OPT
6399	73	38378	99	OPT
6400	73	37662	99	OPT
6401	73	37565	99	OPT
6402	73	38379	99	OPT
6403	73	33580	99	OPT
6404	73	37569	99	OPT
6405	73	37570	99	OPT
6406	73	38380	99	OPT
6407	73	37574	99	OPT
6408	73	38381	99	OPT
6409	73	37575	99	OPT
6410	73	37576	99	OPT
6411	73	33545	99	OPT
6412	73	37583	99	OPT
6413	73	38383	99	OPT
6414	73	38384	99	OPT
6415	73	37587	99	OPT
6416	73	37507	99	OPT
6417	73	38385	99	OPT
6418	73	37588	99	OPT
6419	73	38386	99	OPT
6420	73	37614	99	OPT
6421	73	37613	99	OPT
6422	73	37506	99	OPT
6423	73	38387	99	OPT
6424	73	37616	99	OPT
6425	73	37664	99	OPT
6426	73	37621	99	OPT
6427	73	37623	99	OPT
6428	73	37624	99	OPT
6429	73	37628	99	OPT
6430	73	37629	99	OPT
6431	73	37631	99	OPT
6432	73	37633	99	OPT
6433	73	37635	99	OPT
6434	73	37637	99	OPT
6435	73	37638	99	OPT
6436	73	38390	99	OPT
6437	73	37639	99	OPT
6438	73	38393	99	OPT
6439	73	37641	99	OPT
6440	73	37642	99	OPT
6441	73	37643	99	OPT
6442	73	37644	99	OPT
6443	73	37645	99	OPT
6444	73	37479	99	OPT
6445	74	49864	1	OBR
6446	74	49845	1	OBR
6447	74	49861	1	OBR
6448	74	52113	1	OBR
6449	74	49867	1	OBR
6450	74	49859	1	OBR
6451	74	49865	2	OBR
6452	74	49860	2	OBR
6453	74	49866	2	OBR
6454	74	49862	2	OBR
6455	74	52105	2	OBR
6456	74	49863	2	OBR
6457	74	49868	3	OBR
6458	74	49879	3	OBR
6459	74	52106	3	OBR
6460	74	49885	3	OBR
6461	74	49873	3	OBR
6462	74	49882	3	OBR
6463	74	49876	4	OBR
6464	74	49869	4	OBR
6465	74	52107	4	OBR
6466	74	49875	4	OBR
6467	74	49907	4	OBR
6468	74	49888	5	OBR
6469	74	49886	5	OBR
6470	74	49881	5	OBR
6471	74	49883	5	OBR
6472	74	49874	5	OBR
6473	74	49877	6	OBR
6474	74	49890	6	OBR
6475	74	49889	6	OBR
6476	74	52115	6	OBR
6477	74	52114	6	OBR
6478	74	49887	7	OBR
6479	74	49870	7	OBR
6480	74	49910	7	OBR
6481	74	49908	7	OBR
6482	74	49905	7	OBR
6483	74	52109	8	OBR
6484	74	49897	8	OBR
6485	74	49896	99	OPT
6486	74	52108	99	OPT
6487	74	49898	99	OPT
6488	74	49891	99	OPT
6489	74	52110	99	NAP
6490	74	44895	99	NAP
6491	74	43686	99	OPT
6492	74	49853	99	OPT
6493	74	49852	99	OPT
6494	74	49856	99	OPT
6495	74	49854	99	OPT
6496	74	49855	99	OPT
6497	74	49858	99	OPT
6498	74	49844	99	OPT
6499	74	49846	99	OPT
6500	74	49851	99	OPT
6501	74	49901	99	OPT
6502	74	49906	99	OPT
6503	74	49893	99	OPT
6504	74	49904	99	OPT
6505	74	49903	99	OPT
6506	74	49899	99	OPT
6507	74	49895	99	OPT
6508	74	49892	99	OPT
6509	74	49900	99	OPT
6510	74	49902	99	OPT
6511	74	52111	99	NAP
6512	74	52112	99	NAP
6513	75	49864	1	OBR
6514	75	49845	1	OBR
6515	75	49861	1	OBR
6516	75	52113	1	OBR
6517	75	49867	1	OBR
6518	75	49859	1	OBR
6519	75	49865	2	OBR
6520	75	49860	2	OBR
6521	75	49866	2	OBR
6522	75	49862	2	OBR
6523	75	52105	2	OBR
6524	75	49863	2	OBR
6525	75	49868	3	OBR
6526	75	49879	3	OBR
6527	75	52106	3	OBR
6528	75	49885	3	OBR
6529	75	49873	3	OBR
6530	75	49882	3	OBR
6531	75	49876	4	OBR
6532	75	49869	4	OBR
6533	75	52107	4	OBR
6534	75	49875	4	OBR
6535	75	49907	4	OBR
6536	75	49888	5	OBR
6537	75	49886	5	OBR
6538	75	49881	5	OBR
6539	75	49883	5	OBR
6540	75	49874	5	OBR
6541	75	49877	6	OBR
6542	75	49890	6	OBR
6543	75	49889	6	OBR
6544	75	52115	6	OBR
6545	75	52114	6	OBR
6546	75	49887	7	OBR
6547	75	49870	7	OBR
6548	75	49910	7	OBR
6549	75	49908	7	OBR
6550	75	49905	7	OBR
6551	75	52109	8	OBR
6552	75	49897	8	OBR
6553	75	49896	99	OPT
6554	75	52108	99	OPT
6555	75	49898	99	OPT
6556	75	49891	99	OPT
6557	75	52110	99	NAP
6558	75	44895	99	NAP
6559	75	43686	99	OPT
6560	75	49853	99	OPT
6561	75	49852	99	OPT
6562	75	49856	99	OPT
6563	75	49854	99	OPT
6564	75	49855	99	OPT
6565	75	49858	99	OPT
6566	75	49844	99	OPT
6567	75	49846	99	OPT
6568	75	49851	99	OPT
6569	75	49901	99	OPT
6570	75	49906	99	OPT
6571	75	49893	99	OPT
6572	75	49904	99	OPT
6573	75	49903	99	OPT
6574	75	49899	99	OPT
6575	75	49895	99	OPT
6576	75	49892	99	OPT
6577	75	49900	99	OPT
6578	75	49902	99	OPT
6579	75	52111	99	NAP
6580	75	52112	99	NAP
6581	77	45398	1	OBR
6582	77	48016	1	OBR
6583	77	45389	1	OBR
6584	77	48585	1	OBR
6585	77	48008	1	OBR
6586	77	45399	2	OBR
6587	77	48017	2	OBR
6588	77	45418	2	OBR
6589	77	48019	2	OBR
6590	77	36270	2	OBR
6591	77	48330	3	OBR
6592	77	48603	3	OBR
6593	77	45412	3	OBR
6594	77	45405	3	OBR
6595	77	35450	3	OBR
6596	77	35498	4	OBR
6597	77	45416	4	OBR
6598	77	48009	4	OBR
6599	77	35503	4	OBR
6600	77	45263	4	OBR
6601	77	35427	5	OBR
6602	77	35430	5	OBR
6603	77	45422	5	OBR
6604	77	48582	5	OBR
6605	77	45417	5	OBR
6606	77	35505	6	OBR
6607	77	35431	6	OBR
6608	77	48581	6	OBR
6609	77	35507	6	OBR
6610	77	45397	7	OBR
6611	77	45411	99	OPT
6612	77	29375	99	OPT
6613	77	35426	99	OPT
6614	77	39974	99	OPT
6615	77	48318	99	OPT
6616	77	31586	99	OPT
6617	77	36156	99	OPT
6618	77	48599	99	OPT
6619	77	45401	99	OPT
6620	77	41084	99	OPT
6621	77	45409	99	OPT
6622	77	35435	99	OPT
6623	77	45388	99	OPT
6624	77	35436	99	OPT
6625	77	24760	99	OPT
6626	77	41760	99	OPT
6627	77	43686	99	OPT
6628	77	45407	99	OPT
6629	77	48606	99	OPT
6630	77	48018	99	OPT
6631	77	41756	99	OPT
6632	77	48596	99	OPT
6633	77	48032	99	OPT
6634	77	48034	99	OPT
6635	77	35440	99	OPT
6636	77	48588	99	OPT
6637	77	37052	99	OPT
6638	77	48594	99	OPT
6639	77	45488	99	OPT
6640	77	45415	99	OPT
6641	77	40188	99	OPT
6642	77	35444	99	OPT
6643	77	36259	99	OPT
6644	77	40185	99	OPT
6645	77	35446	99	OPT
6646	77	42900	99	OPT
6647	77	42901	99	OPT
6648	77	42903	99	OPT
6649	77	42902	99	OPT
6650	77	36261	99	OPT
6651	77	36262	99	OPT
6652	77	45396	99	OPT
6653	77	36263	99	OPT
6654	77	36264	99	OPT
6655	77	41076	99	OPT
6656	77	41077	99	OPT
6657	77	48580	99	OPT
6658	77	45394	99	OPT
6659	77	41083	99	OPT
6660	77	35497	99	OPT
6661	77	35452	99	OPT
6662	77	35453	99	OPT
6663	77	35454	99	OPT
6664	77	45392	99	OPT
6665	77	45408	99	OPT
6666	77	45410	99	OPT
6667	77	35511	99	OPT
6668	77	35460	99	OPT
6669	77	45403	99	OPT
6670	77	45425	99	OPT
6671	77	35518	99	OPT
6672	77	45420	99	OPT
6673	77	45426	99	OPT
6674	77	49831	99	OPT
6675	77	35467	99	OPT
6676	77	48604	99	OPT
6677	77	48586	99	OPT
6678	77	48590	99	OPT
6679	77	48592	99	OPT
6680	77	35469	99	OPT
6681	77	35470	99	OPT
6682	77	35471	99	OPT
6683	77	35472	99	OPT
6684	77	45413	99	OPT
6685	77	45419	99	OPT
6686	77	45406	99	OPT
6687	77	41074	99	OPT
6688	77	37061	99	OPT
6689	77	37062	99	OPT
6690	77	37063	99	OPT
6691	77	48605	99	OPT
6692	77	48587	99	OPT
6693	77	48589	99	OPT
6694	77	48591	99	OPT
6695	77	48593	99	OPT
6696	77	35474	99	OPT
6697	77	35475	99	OPT
6698	77	35476	99	OPT
6699	77	35477	99	OPT
6700	77	35478	99	OPT
6701	77	35479	99	OPT
6702	77	35480	99	OPT
6703	77	35481	99	OPT
6704	77	35482	99	OPT
6705	77	35483	99	OPT
6706	77	35484	99	OPT
6707	77	35485	99	OPT
6708	77	35486	99	OPT
6709	77	35487	99	OPT
6710	77	35488	99	OPT
6711	77	35489	99	OPT
6712	77	45423	99	OPT
6713	77	45400	99	OPT
6714	77	45421	99	OPT
6715	77	45404	99	OPT
6716	77	45395	99	OPT
6717	78	45398	1	OBR
6718	78	48016	1	OBR
6719	78	48585	1	OBR
6720	78	48008	1	OBR
6721	78	45399	2	OBR
6722	78	48017	2	OBR
6723	78	48034	2	OBR
6724	78	45418	2	OBR
6725	78	48723	2	OBR
6726	78	48019	2	OBR
6727	78	48330	3	OBR
6728	78	48318	3	OBR
6729	78	45412	3	OBR
6730	78	48031	3	OBR
6731	78	48812	3	OBR
6732	78	36270	3	OBR
6733	78	35498	4	OBR
6734	78	48018	4	OBR
6735	78	48032	4	OBR
6736	78	45405	4	OBR
6737	78	35450	4	OBR
6738	78	50169	4	OBR
6739	78	29375	5	OBR
6740	78	35427	5	OBR
6741	78	37066	5	OBR
6742	78	34320	5	OBR
6743	78	48009	5	OBR
6744	78	35503	5	OBR
6745	78	48603	6	OBR
6746	78	37068	6	OBR
6747	78	35430	6	OBR
6748	78	37069	6	OBR
6749	78	48582	6	OBR
6750	78	45401	7	OBR
6751	78	42904	7	OBR
6752	78	50254	7	OBR
6753	78	45422	7	OBR
6754	78	37070	7	OBR
6755	78	45417	7	OBR
6756	78	45389	8	OBR
6757	78	36263	8	OBR
6758	78	50156	8	OBR
6759	78	49467	8	OBR
6760	78	35507	8	OBR
6761	78	37071	8	OBR
6762	78	51771	9	OBR
6763	78	45416	9	OBR
6764	78	45220	9	OBR
6765	78	35505	99	OPT
6766	78	39974	99	OPT
6767	78	36156	99	OPT
6768	78	40250	99	OPT
6769	78	45428	99	OPT
6770	78	35431	99	OPT
6771	78	45409	99	OPT
6772	78	45431	99	OPT
6773	78	35435	99	OPT
6774	78	41760	99	OPT
6775	78	43686	99	OPT
6776	78	48606	99	OPT
6777	78	41756	99	OPT
6778	78	35440	99	OPT
6779	78	48588	99	OPT
6780	78	37052	99	OPT
6781	78	48594	99	OPT
6782	78	45427	99	OPT
6783	78	45415	99	OPT
6784	78	35444	99	OPT
6785	78	36259	99	OPT
6786	78	35446	99	OPT
6787	78	36261	99	OPT
6788	78	36262	99	OPT
6789	78	45396	99	OPT
6790	78	36264	99	OPT
6791	78	41077	99	OPT
6792	78	48580	99	OPT
6793	78	45394	99	OPT
6794	78	41083	99	OPT
6795	78	35497	99	OPT
6796	78	35452	99	OPT
6797	78	35453	99	OPT
6798	78	35454	99	OPT
6799	78	45392	99	OPT
6800	78	48581	99	OPT
6801	78	45408	99	OPT
6802	78	45410	99	OPT
6803	78	35458	99	OPT
6804	78	35511	99	OPT
6805	78	45403	99	OPT
6806	78	45420	99	OPT
6807	78	45397	99	OPT
6808	78	37059	99	OPT
6809	78	45426	99	OPT
6810	78	45263	99	OPT
6811	78	35467	99	OPT
6812	78	48604	99	OPT
6813	78	48586	99	OPT
6814	78	48590	99	OPT
6815	78	48592	99	OPT
6816	78	35469	99	OPT
6817	78	35470	99	OPT
6818	78	35471	99	OPT
6819	78	35472	99	OPT
6820	78	45413	99	OPT
6821	78	45419	99	OPT
6822	78	45406	99	OPT
6823	78	37061	99	OPT
6824	78	37062	99	OPT
6825	78	37063	99	OPT
6826	78	48605	99	OPT
6827	78	48587	99	OPT
6828	78	48589	99	OPT
6829	78	48591	99	OPT
6830	78	48593	99	OPT
6831	78	35474	99	OPT
6832	78	35475	99	OPT
6833	78	35476	99	OPT
6834	78	35477	99	OPT
6835	78	35478	99	OPT
6836	78	35479	99	OPT
6837	78	35480	99	OPT
6838	78	35484	99	OPT
6839	78	35485	99	OPT
6840	78	35486	99	OPT
6841	78	35487	99	OPT
6842	78	35488	99	OPT
6843	78	35489	99	OPT
6844	78	45395	99	OPT
6845	79	45398	1	OBR
6846	79	48583	1	OBR
6847	79	48596	1	OBR
6848	79	45430	1	OBR
6849	79	48585	1	OBR
6850	79	48584	1	OBR
6851	79	45399	2	OBR
6852	79	48603	2	OBR
6853	79	45415	2	OBR
6854	79	45405	2	OBR
6855	79	35497	2	OBR
6856	79	35505	3	OBR
6857	79	45407	3	OBR
6858	79	45412	3	OBR
6859	79	37052	3	OBR
6860	79	45402	3	OBR
6861	79	39974	4	OBR
6862	79	45427	4	OBR
6863	79	45484	4	OBR
6864	79	45396	4	OBR
6865	79	48580	4	OBR
6866	79	45410	4	OBR
6867	79	45486	5	OBR
6868	79	48588	5	OBR
6869	79	41077	5	OBR
6870	79	45392	5	OBR
6871	79	45395	5	OBR
6872	79	45428	6	OBR
6873	79	48606	6	OBR
6874	79	45422	6	OBR
6875	79	41076	6	OBR
6876	79	45426	6	OBR
6877	79	45389	7	OBR
6878	79	48598	7	OBR
6879	79	43686	8	OBR
6880	79	48595	8	OBR
6881	79	45411	99	OPT
6882	79	48330	99	OPT
6883	79	35426	99	OPT
6884	79	35498	99	OPT
6885	79	35427	99	OPT
6886	79	48016	99	OPT
6887	79	48017	99	OPT
6888	79	48318	99	OPT
6889	79	31586	99	OPT
6890	79	35430	99	OPT
6891	79	36156	99	OPT
6892	79	48599	99	OPT
6893	79	35431	99	OPT
6894	79	45401	99	OPT
6895	79	41084	99	OPT
6896	79	45409	99	OPT
6897	79	35435	99	OPT
6898	79	45388	99	OPT
6899	79	35436	99	OPT
6900	79	32044	99	OPT
6901	79	48602	99	OPT
6902	79	24594	99	OPT
6903	79	24596	99	OPT
6904	79	48600	99	OPT
6905	79	41760	99	OPT
6906	79	51115	99	OPT
6907	79	41756	99	OPT
6908	79	45418	99	OPT
6909	79	35440	99	OPT
6910	79	45485	99	OPT
6911	79	34343	99	OPT
6912	79	50144	99	OPT
6913	79	46486	99	OPT
6914	79	48597	99	OPT
6915	79	46490	99	OPT
6916	79	48594	99	OPT
6917	79	45488	99	OPT
6918	79	35444	99	OPT
6919	79	36259	99	OPT
6920	79	40185	99	OPT
6921	79	35446	99	OPT
6922	79	42900	99	OPT
6923	79	42901	99	OPT
6924	79	48601	99	OPT
6925	79	42903	99	OPT
6926	79	42902	99	OPT
6927	79	36261	99	OPT
6928	79	36262	99	OPT
6929	79	36263	99	OPT
6930	79	36264	99	OPT
6931	79	35450	99	OPT
6932	79	48331	99	OPT
6933	79	51138	99	OPT
6934	79	42623	99	OPT
6935	79	45394	99	OPT
6936	79	46475	99	OPT
6937	79	41083	99	OPT
6938	79	48582	99	OPT
6939	79	35452	99	OPT
6940	79	51120	99	OPT
6941	79	48009	99	OPT
6942	79	35453	99	OPT
6943	79	35454	99	OPT
6944	79	48581	99	OPT
6945	79	45408	99	OPT
6946	79	35503	99	OPT
6947	79	35458	99	OPT
6948	79	35507	99	OPT
6949	79	35460	99	OPT
6950	79	45403	99	OPT
6951	79	45425	99	OPT
6952	79	35518	99	OPT
6953	79	48019	99	OPT
6954	79	45420	99	OPT
6955	79	36270	99	OPT
6956	79	45397	99	OPT
6957	79	45417	99	OPT
6958	79	44085	99	OPT
6959	79	45263	99	OPT
6960	79	40251	99	OPT
6961	79	35467	99	OPT
6962	79	35468	99	OPT
6963	79	48604	99	OPT
6964	79	48586	99	OPT
6965	79	48590	99	OPT
6966	79	48592	99	OPT
6967	79	35469	99	OPT
6968	79	35470	99	OPT
6969	79	35471	99	OPT
6970	79	35472	99	OPT
6971	79	45413	99	OPT
6972	79	45419	99	OPT
6973	79	45406	99	OPT
6974	79	41074	99	OPT
6975	79	37061	99	OPT
6976	79	37062	99	OPT
6977	79	37063	99	OPT
6978	79	35473	99	OPT
6979	79	48605	99	OPT
6980	79	48587	99	OPT
6981	79	48589	99	OPT
6982	79	48591	99	OPT
6983	79	48593	99	OPT
6984	79	35474	99	OPT
6985	79	35475	99	OPT
6986	79	35476	99	OPT
6987	79	35477	99	OPT
6988	79	35478	99	OPT
6989	79	35479	99	OPT
6990	79	35480	99	OPT
6991	79	35481	99	OPT
6992	79	35482	99	OPT
6993	79	35483	99	OPT
6994	79	35484	99	OPT
6995	79	35485	99	OPT
6996	79	35486	99	OPT
6997	79	35487	99	OPT
6998	79	35488	99	OPT
6999	79	35489	99	OPT
7000	79	45423	99	OPT
7001	79	48008	99	OPT
7002	80	45398	1	OBR
7003	80	48596	1	OBR
7004	80	45430	1	OBR
7005	80	48585	1	OBR
7006	80	35497	1	OBR
7007	80	45399	2	OBR
7008	80	48603	2	OBR
7009	80	48599	2	OBR
7010	80	48331	2	OBR
7011	80	45416	3	OBR
7012	80	48583	3	OBR
7013	80	48594	3	OBR
7014	80	45405	3	OBR
7015	80	45402	3	OBR
7016	80	43686	4	OBR
7017	80	45412	4	OBR
7018	80	37052	4	OBR
7019	80	45484	4	OBR
7020	80	45396	4	OBR
7021	80	35505	5	OBR
7022	80	45486	5	OBR
7023	80	45422	5	OBR
7024	80	45410	5	OBR
7025	80	45428	6	OBR
7026	80	45389	6	OBR
7027	80	35511	6	OBR
7028	80	45426	6	OBR
7029	80	45488	7	OBR
7030	80	45420	7	OBR
7031	80	45485	8	OBR
7032	80	45415	8	OBR
7033	80	35518	8	OBR
7034	80	45411	99	OPT
7035	80	35426	99	OPT
7036	80	39974	99	OPT
7037	80	31586	99	OPT
7038	80	45401	99	OPT
7039	80	41084	99	OPT
7040	80	45409	99	OPT
7041	80	35435	99	OPT
7042	80	45388	99	OPT
7043	80	35436	99	OPT
7044	80	48602	99	OPT
7045	80	41760	99	OPT
7046	80	34020	99	OPT
7047	80	45407	99	OPT
7048	80	48606	99	OPT
7049	80	41756	99	OPT
7050	80	45418	99	OPT
7051	80	48588	99	OPT
7052	80	45427	99	OPT
7053	80	35444	99	OPT
7054	80	40185	99	OPT
7055	80	35446	99	OPT
7056	80	42900	99	OPT
7057	80	35447	99	OPT
7058	80	42901	99	OPT
7059	80	42903	99	OPT
7060	80	35496	99	OPT
7061	80	41076	99	OPT
7062	80	41077	99	OPT
7063	80	48580	99	OPT
7064	80	42623	99	OPT
7065	80	45394	99	OPT
7066	80	35454	99	OPT
7067	80	45392	99	OPT
7068	80	48581	99	OPT
7069	80	45408	99	OPT
7070	80	35503	99	OPT
7071	80	35460	99	OPT
7072	80	45403	99	OPT
7073	80	45425	99	OPT
7074	80	45397	99	OPT
7075	80	45263	99	OPT
7076	80	35467	99	OPT
7077	80	35468	99	OPT
7078	80	48604	99	OPT
7079	80	48586	99	OPT
7080	80	48590	99	OPT
7081	80	48592	99	OPT
7082	80	49582	99	OPT
7083	80	35469	99	OPT
7084	80	35470	99	OPT
7085	80	35471	99	OPT
7086	80	35472	99	OPT
7087	80	45413	99	OPT
7088	80	45419	99	OPT
7089	80	45406	99	OPT
7090	80	35473	99	OPT
7091	80	48605	99	OPT
7092	80	48587	99	OPT
7093	80	48589	99	OPT
7094	80	48591	99	OPT
7095	80	48593	99	OPT
7096	80	35474	99	OPT
7097	80	35475	99	OPT
7098	80	35476	99	OPT
7099	80	35477	99	OPT
7100	80	35478	99	OPT
7101	80	35479	99	OPT
7102	80	35480	99	OPT
7103	80	35481	99	OPT
7104	80	35482	99	OPT
7105	80	35483	99	OPT
7106	80	35484	99	OPT
7107	80	35485	99	OPT
7108	80	35486	99	OPT
7109	80	35487	99	OPT
7110	80	35488	99	OPT
7111	80	35489	99	OPT
7112	80	45423	99	OPT
7113	80	45400	99	OPT
7114	80	45421	99	OPT
7115	80	45404	99	OPT
7116	80	45395	99	OPT
7117	81	46916	1	OBR
7118	81	49427	1	OBR
7119	81	46926	1	OBR
7120	81	46917	1	OBR
7121	81	49430	1	OBR
7122	81	46915	1	OBR
7123	81	49425	2	OBR
7124	81	48602	2	OBR
7125	81	49433	2	OBR
7126	81	49454	2	OBR
7127	81	49450	2	OBR
7128	81	46914	2	OBR
7129	81	49441	3	OBR
7130	81	49432	3	OBR
7131	81	49445	3	OBR
7132	81	49426	3	OBR
7133	81	49417	3	OBR
7134	81	46891	3	OBR
7135	81	46897	4	OBR
7136	81	49451	4	OBR
7137	81	49420	4	OBR
7138	81	49446	4	OBR
7139	81	49452	4	OBR
7140	81	49421	4	OBR
7141	81	49448	5	OBR
7142	81	49424	5	OBR
7143	81	49442	5	OBR
7144	81	49447	5	OBR
7145	81	49453	5	OBR
7146	81	49436	5	OBR
7147	81	49418	6	OBR
7148	81	49444	6	OBR
7149	81	24777	6	OBR
7150	81	49429	6	OBR
7151	81	46929	6	OBR
7152	81	49434	6	OBR
7153	81	49419	7	OBR
7154	81	27248	7	OBR
7155	81	49438	7	OBR
7156	81	22615	7	OBR
7157	81	46930	7	OBR
7158	81	49435	7	OBR
7159	81	49423	8	OBR
7160	81	46893	8	OBR
7161	81	49437	8	OBR
7162	81	49443	8	OBR
7163	81	22620	8	OBR
7164	81	49431	8	OBR
7165	81	49449	9	OBR
7166	81	46888	9	OBR
7167	81	46905	9	OBR
7168	81	46906	9	OBR
7169	81	22622	9	OBR
7170	81	24826	9	OBR
7171	81	46896	9	OBR
7172	81	49428	10	OBR
7173	81	46883	10	OBR
7174	81	46886	10	OBR
7175	81	49440	10	OBR
7176	81	49439	10	OBR
7177	81	27254	10	OBR
7178	81	46932	99	OPT
7179	81	46889	99	OPT
7180	81	46903	99	OPT
7181	81	46900	99	OPT
7182	81	34091	99	OPT
7183	81	46907	99	OPT
7184	81	46882	99	OPT
7185	81	46933	99	OPT
7186	81	34099	99	OPT
7187	81	34101	99	OPT
7188	81	49422	99	OPT
7189	81	46925	99	OPT
7190	81	46874	99	OPT
7191	81	34103	99	OPT
7192	81	46922	99	OPT
7193	81	34104	99	OPT
7194	81	46920	99	OPT
7195	81	46884	99	OPT
7196	81	46919	99	OPT
7197	81	34107	99	OPT
7198	81	46890	99	OPT
7199	81	43686	99	OPT
7200	81	42895	99	OPT
7201	81	46904	99	OPT
7202	81	34115	99	OPT
7203	81	46931	99	OPT
7204	81	34080	99	OPT
7205	81	49455	99	OPT
7206	81	46923	99	OPT
7207	81	34121	99	OPT
7208	81	46918	99	OPT
7209	81	46881	99	OPT
7210	81	46921	99	OPT
7211	82	46916	1	OBR
7212	82	49427	1	OBR
7213	82	46926	1	OBR
7214	82	46917	1	OBR
7215	82	49430	1	OBR
7216	82	46915	1	OBR
7217	82	49425	2	OBR
7218	82	48602	2	OBR
7219	82	49433	2	OBR
7220	82	49454	2	OBR
7221	82	49450	2	OBR
7222	82	46914	2	OBR
7223	82	49441	3	OBR
7224	82	49432	3	OBR
7225	82	49445	3	OBR
7226	82	49426	3	OBR
7227	82	49417	3	OBR
7228	82	46891	3	OBR
7229	82	46897	4	OBR
7230	82	49451	4	OBR
7231	82	49420	4	OBR
7232	82	49446	4	OBR
7233	82	49452	4	OBR
7234	82	49421	4	OBR
7235	82	49448	5	OBR
7236	82	49424	5	OBR
7237	82	49442	5	OBR
7238	82	49447	5	OBR
7239	82	49453	5	OBR
7240	82	49436	5	OBR
7241	82	49418	6	OBR
7242	82	49444	6	OBR
7243	82	24777	6	OBR
7244	82	49429	6	OBR
7245	82	46929	6	OBR
7246	82	49434	6	OBR
7247	82	49419	7	OBR
7248	82	27248	7	OBR
7249	82	49438	7	OBR
7250	82	22615	7	OBR
7251	82	46930	7	OBR
7252	82	49435	7	OBR
7253	82	49423	8	OBR
7254	82	46893	8	OBR
7255	82	49437	8	OBR
7256	82	49443	8	OBR
7257	82	22620	8	OBR
7258	82	49431	8	OBR
7259	82	49449	9	OBR
7260	82	46888	9	OBR
7261	82	46905	9	OBR
7262	82	46906	9	OBR
7263	82	22622	9	OBR
7264	82	24826	9	OBR
7265	82	46896	9	OBR
7266	82	49428	10	OBR
7267	82	46883	10	OBR
7268	82	46886	10	OBR
7269	82	49440	10	OBR
7270	82	49439	10	OBR
7271	82	27254	10	OBR
7272	82	46932	99	OPT
7273	82	46889	99	OPT
7274	82	46903	99	OPT
7275	82	46900	99	OPT
7276	82	34091	99	OPT
7277	82	46907	99	OPT
7278	82	46882	99	OPT
7279	82	46933	99	OPT
7280	82	34099	99	OPT
7281	82	34101	99	OPT
7282	82	49422	99	OPT
7283	82	46925	99	OPT
7284	82	46874	99	OPT
7285	82	34103	99	OPT
7286	82	46922	99	OPT
7287	82	34104	99	OPT
7288	82	46920	99	OPT
7289	82	46884	99	OPT
7290	82	46919	99	OPT
7291	82	34107	99	OPT
7292	82	46890	99	OPT
7293	82	43686	99	OPT
7294	82	42895	99	OPT
7295	82	46904	99	OPT
7296	82	34115	99	OPT
7297	82	46931	99	OPT
7298	82	34080	99	OPT
7299	82	49455	99	OPT
7300	82	46923	99	OPT
7301	82	34121	99	OPT
7302	82	46918	99	OPT
7303	82	46881	99	OPT
7304	82	46921	99	OPT
7305	83	51319	1	OBR
7306	83	51282	1	OBR
7307	83	51285	1	OBR
7308	83	51302	1	OBR
7309	83	51286	1	OBR
7310	83	51320	1	OBR
7311	83	51310	1	OBR
7312	83	38807	1	OBR
7313	83	51304	1	OBR
7314	83	51753	2	OBR
7315	83	38810	2	OBR
7316	83	51288	2	OBR
7317	83	51324	2	OBR
7318	83	51299	2	OBR
7319	83	51321	2	OBR
7320	83	38528	2	OBR
7321	83	51311	2	OBR
7322	83	51305	3	OBR
7323	83	31527	3	OBR
7324	83	51325	3	OBR
7325	83	51300	3	OBR
7326	83	31534	3	OBR
7327	83	40492	3	OBR
7328	83	51294	3	OBR
7329	83	51322	4	OBR
7330	83	51291	4	OBR
7331	83	51290	4	OBR
7332	83	40498	4	OBR
7333	83	51323	4	OBR
7334	83	40496	4	OBR
7335	83	51309	4	OBR
7336	83	51295	4	OBR
7337	83	51296	5	OBR
7338	83	51318	5	OBR
7339	83	40502	5	OBR
7340	83	40503	5	OBR
7341	83	40500	5	OBR
7342	83	51314	5	OBR
7343	83	40501	5	OBR
7344	83	51317	5	OBR
7345	83	51297	6	OBR
7346	83	51292	6	OBR
7347	83	51287	6	OBR
7348	83	51303	6	OBR
7349	83	40507	6	OBR
7350	83	51326	7	OBR
7351	83	51283	7	OBR
7352	83	51289	7	OBR
7353	83	51313	7	OBR
7354	83	38848	7	OBR
7355	83	51327	8	OBR
7356	83	40512	8	OBR
7357	83	51298	8	OBR
7358	83	51307	8	OBR
7359	83	38854	8	OBR
7360	83	51301	9	OBR
7361	83	40473	9	OBR
7362	83	51308	9	OBR
7363	83	38757	99	OPT
7364	83	51312	99	OPT
7365	83	40469	99	OPT
7366	83	51284	99	OPT
7367	83	33950	99	OPT
7368	83	33956	99	OPT
7369	83	33959	99	OPT
7370	83	40470	99	OPT
7371	83	41760	99	OPT
7372	83	33964	99	OPT
7373	83	43686	99	OPT
7374	83	38761	99	OPT
7375	83	38763	99	OPT
7376	83	42895	99	OPT
7377	83	38765	99	OPT
7378	83	40471	99	OPT
7379	83	38768	99	OPT
7380	83	38769	99	OPT
7381	83	51293	99	OPT
7382	83	38770	99	OPT
7383	83	51315	99	OPT
7384	83	40472	99	OPT
7385	83	38772	99	OPT
7386	83	40475	99	OPT
7387	83	40828	99	OPT
7388	83	38774	99	OPT
7389	83	40476	99	OPT
7390	83	40477	99	OPT
7391	83	40478	99	OPT
7392	83	51306	99	OPT
7393	83	40479	99	OPT
7394	83	38783	99	OPT
7395	83	34033	99	OPT
7396	83	51316	99	OPT
7397	83	40480	99	OPT
7398	83	40481	99	OPT
7399	83	34010	99	OPT
7400	84	48791	1	OBR
7401	84	48016	1	OBR
7402	84	48034	1	OBR
7403	84	50151	1	OBR
7404	84	31697	1	OBR
7405	84	48008	1	OBR
7406	84	48330	2	OBR
7407	84	48017	2	OBR
7408	84	31586	2	OBR
7409	84	50139	2	OBR
7410	84	46512	2	OBR
7411	84	48031	2	OBR
7412	84	48723	2	OBR
7413	84	48318	3	OBR
7414	84	50157	3	OBR
7415	84	48009	3	OBR
7416	84	50156	3	OBR
7417	84	49467	3	OBR
7418	84	50173	3	OBR
7419	84	50171	4	OBR
7420	84	50150	4	OBR
7421	84	50164	4	OBR
7422	84	48018	4	OBR
7423	84	31859	4	OBR
7424	84	50160	4	OBR
7425	84	31858	4	OBR
7426	84	50159	5	OBR
7427	84	46511	5	OBR
7428	84	31599	5	OBR
7429	84	31613	5	OBR
7430	84	48582	5	OBR
7431	84	50165	5	OBR
7432	84	50146	6	OBR
7433	84	34023	6	OBR
7434	84	50166	6	OBR
7435	84	50161	6	OBR
7436	84	34024	6	OBR
7437	84	50172	6	OBR
7438	84	31617	6	OBR
7439	84	50167	7	OBR
7440	84	50158	7	OBR
7441	84	34027	7	OBR
7442	84	50168	7	OBR
7443	84	31619	7	OBR
7444	84	31712	7	OBR
7445	84	31539	7	OBR
7446	84	50174	8	OBR
7447	84	50152	8	OBR
7448	84	45266	8	OBR
7449	84	34028	8	OBR
7450	84	46513	8	OBR
7451	84	34033	8	OBR
7452	84	34035	8	OBR
7453	84	50147	9	OBR
7454	84	50148	9	OBR
7455	84	45267	9	OBR
7456	84	50140	9	OBR
7457	84	50138	9	OBR
7458	84	50149	9	OBR
7459	84	50153	9	OBR
7460	84	34030	10	OBR
7461	84	50170	10	OBR
7462	84	50154	10	OBR
7463	84	31638	99	OPT
7464	84	33944	99	OPT
7465	84	31637	99	OPT
7466	84	33945	99	OPT
7467	84	33946	99	OPT
7468	84	33947	99	OPT
7469	84	31698	99	OPT
7470	84	46476	99	OPT
7471	84	50145	99	OPT
7472	84	51755	99	OPT
7473	84	33948	99	OPT
7474	84	46488	99	OPT
7475	84	33949	99	OPT
7476	84	31642	99	OPT
7477	84	31643	99	OPT
7478	84	31889	99	OPT
7479	84	33950	99	OPT
7480	84	46482	99	OPT
7481	84	46483	99	OPT
7482	84	34034	99	OPT
7483	84	33951	99	OPT
7484	84	33952	99	OPT
7485	84	46506	99	OPT
7486	84	33954	99	OPT
7487	84	33955	99	OPT
7488	84	46493	99	OPT
7489	84	42908	99	OPT
7490	84	33956	99	OPT
7491	84	46500	99	OPT
7492	84	33957	99	OPT
7493	84	33958	99	OPT
7494	84	46484	99	OPT
7495	84	33959	99	OPT
7496	84	33960	99	OPT
7497	84	46480	99	OPT
7498	84	46501	99	OPT
7499	84	33962	99	OPT
7500	84	33963	99	OPT
7501	84	31903	99	OPT
7502	84	41760	99	OPT
7503	84	31705	99	OPT
7504	84	33965	99	OPT
7505	84	36922	99	OPT
7506	84	36925	99	OPT
7507	84	46491	99	OPT
7508	84	43686	99	OPT
7509	84	46481	99	OPT
7510	84	31704	99	OPT
7511	84	46510	99	OPT
7512	84	46487	99	OPT
7513	84	33966	99	OPT
7514	84	33967	99	OPT
7515	84	33968	99	OPT
7516	84	33969	99	OPT
7517	84	50143	99	OPT
7518	84	46507	99	OPT
7519	84	33972	99	OPT
7520	84	41756	99	OPT
7521	84	33973	99	OPT
7522	84	33974	99	OPT
7523	84	33975	99	OPT
7524	84	33976	99	OPT
7525	84	33977	99	OPT
7526	84	33979	99	OPT
7527	84	48032	99	OPT
7528	84	51756	99	OPT
7529	84	33980	99	OPT
7530	84	33981	99	OPT
7531	84	33982	99	OPT
7532	84	33983	99	OPT
7533	84	46514	99	OPT
7534	84	33984	99	OPT
7535	84	34343	99	OPT
7536	84	32042	99	OPT
7537	84	50144	99	OPT
7538	84	46497	99	OPT
7539	84	46486	99	OPT
7540	84	46504	99	OPT
7541	84	50142	99	OPT
7542	84	46490	99	OPT
7543	84	34342	99	OPT
7544	84	46489	99	OPT
7545	84	46495	99	OPT
7546	84	45265	99	OPT
7547	84	36936	99	OPT
7548	84	36940	99	OPT
7549	84	50155	99	OPT
7550	84	31949	99	OPT
7551	84	31846	99	OPT
7552	84	33985	99	OPT
7553	84	33986	99	OPT
7554	84	31671	99	OPT
7555	84	48812	99	OPT
7556	84	33987	99	OPT
7557	84	33988	99	OPT
7558	84	31852	99	OPT
7559	84	31673	99	OPT
7560	84	46509	99	OPT
7561	84	50169	99	OPT
7562	84	46492	99	OPT
7563	84	31699	99	OPT
7564	84	31883	99	OPT
7565	84	33989	99	OPT
7566	84	31674	99	OPT
7567	84	33990	99	OPT
7568	84	31675	99	OPT
7569	84	50162	99	OPT
7570	84	33992	99	OPT
7571	84	31996	99	OPT
7572	84	32007	99	OPT
7573	84	33993	99	OPT
7574	84	33994	99	OPT
7575	84	31703	99	OPT
7576	84	33996	99	OPT
7577	84	33997	99	OPT
7578	84	31534	99	OPT
7579	84	31540	99	OPT
7580	84	31709	99	OPT
7581	84	33998	99	OPT
7582	84	33999	99	OPT
7583	84	34000	99	OPT
7584	84	31702	99	OPT
7585	84	31876	99	OPT
7586	84	31874	99	OPT
7587	84	48019	99	OPT
7588	84	34001	99	OPT
7589	84	34002	99	OPT
7590	84	46485	99	OPT
7591	84	50163	99	OPT
7592	84	31684	99	OPT
7593	84	50141	99	OPT
7594	84	34005	99	OPT
7595	84	34006	99	OPT
7596	84	34007	99	OPT
7597	84	46508	99	OPT
7598	84	34009	99	OPT
7599	84	34008	99	OPT
7600	84	31689	99	OPT
7601	84	31911	99	OPT
7602	84	34010	99	OPT
7603	85	48791	1	OBR
7604	85	48016	1	OBR
7605	85	50150	1	OBR
7606	85	48034	1	OBR
7607	85	36913	1	OBR
7608	85	50156	1	OBR
7609	85	49467	1	OBR
7610	85	48008	1	OBR
7611	85	48330	2	OBR
7612	85	48017	2	OBR
7613	85	48809	2	OBR
7614	85	48719	2	OBR
7615	85	50487	2	OBR
7616	85	48723	2	OBR
7617	85	46513	2	OBR
7618	85	48318	3	OBR
7619	85	31586	3	OBR
7620	85	50489	3	OBR
7621	85	48032	3	OBR
7622	85	50488	3	OBR
7623	85	50169	3	OBR
7624	85	36917	3	OBR
7625	85	46475	3	OBR
7626	85	36918	4	OBR
7627	85	48018	4	OBR
7628	85	48812	4	OBR
7629	85	34320	4	OBR
7630	85	48582	4	OBR
7631	85	48009	4	OBR
7632	85	50486	4	OBR
7633	85	36923	5	OBR
7634	85	36920	5	OBR
7635	85	50497	5	OBR
7636	85	50483	5	OBR
7637	85	50493	5	OBR
7638	85	36921	5	OBR
7639	85	36924	5	OBR
7640	85	36931	6	OBR
7641	85	36927	6	OBR
7642	85	50492	6	OBR
7643	85	50495	6	OBR
7644	85	36928	6	OBR
7645	85	50494	6	OBR
7646	85	36930	6	OBR
7647	85	36934	7	OBR
7648	85	36935	7	OBR
7649	85	36936	7	OBR
7650	85	36937	7	OBR
7651	85	36933	7	OBR
7652	85	50490	7	OBR
7653	85	36938	7	OBR
7654	85	36939	8	OBR
7655	85	50147	8	OBR
7656	85	36944	8	OBR
7657	85	36940	8	OBR
7658	85	36941	8	OBR
7659	85	36942	8	OBR
7660	85	36948	9	OBR
7661	85	36946	9	OBR
7662	85	31741	9	OBR
7663	85	40522	9	OBR
7664	85	36951	9	OBR
7665	85	36954	10	OBR
7666	85	46511	10	OBR
7667	85	46512	10	OBR
7668	85	36895	99	OPT
7669	85	42910	99	OPT
7670	85	36896	99	OPT
7671	85	34016	99	OPT
7672	85	42909	99	OPT
7673	85	41760	99	OPT
7674	85	50496	99	OPT
7675	85	40545	99	OPT
7676	85	43686	99	OPT
7677	85	41756	99	OPT
7678	85	40523	99	OPT
7679	85	40524	99	OPT
7680	85	40525	99	OPT
7681	85	36906	99	OPT
7682	85	50491	99	OPT
7683	85	40538	99	OPT
7684	85	42911	99	OPT
7685	85	36890	99	OPT
7686	85	40526	99	OPT
7687	85	40527	99	OPT
7688	85	40547	99	OPT
7689	85	40548	99	OPT
7690	85	40529	99	OPT
7691	85	50485	99	OPT
7692	85	40539	99	OPT
7693	85	50484	99	OPT
7694	85	36900	99	OPT
7695	85	36901	99	OPT
7696	85	40530	99	OPT
7697	85	34033	99	OPT
7698	85	40531	99	OPT
7699	85	37065	99	OPT
7700	85	43548	99	OPT
7701	85	40540	99	OPT
7702	85	40541	99	OPT
7703	85	40532	99	OPT
7704	85	40533	99	OPT
7705	85	40542	99	OPT
7706	85	40543	99	OPT
7707	85	40534	99	OPT
7708	85	40535	99	OPT
7709	85	40536	99	OPT
7710	85	40537	99	OPT
7711	85	31858	99	OPT
7712	86	48791	1	OBR
7713	86	48016	1	OBR
7714	86	48034	1	OBR
7715	86	31866	1	OBR
7716	86	50140	1	OBR
7717	86	35069	1	OBR
7718	86	48008	1	OBR
7719	86	48330	2	OBR
7720	86	48017	2	OBR
7721	86	48809	2	OBR
7722	86	46511	2	OBR
7723	86	48798	2	OBR
7724	86	35070	2	OBR
7725	86	49467	2	OBR
7726	86	51344	3	OBR
7727	86	48318	3	OBR
7728	86	50150	3	OBR
7729	86	50164	3	OBR
7730	86	51339	3	OBR
7731	86	48018	3	OBR
7732	86	31859	3	OBR
7733	86	48723	3	OBR
7734	86	50159	4	OBR
7735	86	51361	4	OBR
7736	86	34024	4	OBR
7737	86	34320	4	OBR
7738	86	35095	4	OBR
7739	86	48582	4	OBR
7740	86	48009	4	OBR
7741	86	31858	4	OBR
7742	86	46512	5	OBR
7743	86	51340	5	OBR
7744	86	50161	5	OBR
7745	86	51352	5	OBR
7746	86	31613	5	OBR
7747	86	31699	5	OBR
7748	86	51329	5	OBR
7749	86	31908	6	OBR
7750	86	35077	6	OBR
7751	86	51360	6	OBR
7752	86	51351	6	OBR
7753	86	51348	6	OBR
7754	86	31617	6	OBR
7755	86	35079	6	OBR
7756	86	31637	7	OBR
7757	86	50147	7	OBR
7758	86	31889	7	OBR
7759	86	51363	7	OBR
7760	86	51331	7	OBR
7761	86	34033	7	OBR
7762	86	51354	7	OBR
7763	86	51353	7	OBR
7764	86	51334	8	OBR
7765	86	51335	8	OBR
7766	86	51362	8	OBR
7767	86	51368	8	OBR
7768	86	51358	8	OBR
7769	86	51345	8	OBR
7770	86	31702	8	OBR
7771	86	51349	8	OBR
7772	86	51347	9	OBR
7773	86	51328	9	OBR
7774	86	51341	9	OBR
7775	86	51350	9	OBR
7776	86	51332	9	OBR
7777	86	51369	9	OBR
7778	86	51342	9	OBR
7779	86	51355	9	OBR
7780	86	35094	10	OBR
7781	86	31860	99	OPT
7782	86	51359	99	OPT
7783	86	51336	99	OPT
7784	86	50148	99	OPT
7785	86	51194	99	OPT
7786	86	31970	99	OPT
7787	86	31642	99	OPT
7788	86	51364	99	OPT
7789	86	34017	99	OPT
7790	86	51330	99	OPT
7791	86	46483	99	OPT
7792	86	34016	99	OPT
7793	86	51333	99	OPT
7794	86	32171	99	OPT
7795	86	46648	99	OPT
7796	86	31705	99	OPT
7797	86	31704	99	OPT
7798	86	34023	99	OPT
7799	86	34027	99	OPT
7800	86	42300	99	OPT
7801	86	31904	99	OPT
7802	86	40523	99	OPT
7803	86	48032	99	OPT
7804	86	51343	99	OPT
7805	86	48719	99	OPT
7806	86	31901	99	OPT
7807	86	31897	99	OPT
7808	86	34330	99	OPT
7809	86	46514	99	OPT
7810	86	51366	99	OPT
7811	86	51365	99	OPT
7812	86	31669	99	OPT
7813	86	31896	99	OPT
7814	86	38076	99	OPT
7815	86	51337	99	OPT
7816	86	48812	99	OPT
7817	86	41350	99	OPT
7818	86	51356	99	OPT
7819	86	34019	99	OPT
7820	86	51183	99	OPT
7821	86	37277	99	OPT
7822	86	51346	99	OPT
7823	86	31899	99	OPT
7824	86	31861	99	OPT
7825	86	32000	99	OPT
7826	86	31900	99	OPT
7827	86	32167	99	OPT
7828	86	48019	99	OPT
7829	86	51367	99	OPT
7830	86	51338	99	OPT
7831	86	51357	99	OPT
7832	87	48016	1	OBR
7833	87	31586	1	OBR
7834	87	48809	1	OBR
7835	87	46511	1	OBR
7836	87	31966	1	OBR
7837	87	50156	1	OBR
7838	87	49467	1	OBR
7839	87	48008	1	OBR
7840	87	48330	2	OBR
7841	87	48791	2	OBR
7842	87	48017	2	OBR
7843	87	50150	2	OBR
7844	87	46512	2	OBR
7845	87	48034	2	OBR
7846	87	34033	2	OBR
7847	87	34314	2	OBR
7848	87	48318	3	OBR
7849	87	51115	3	OBR
7850	87	48798	3	OBR
7851	87	50169	3	OBR
7852	87	51138	3	OBR
7853	87	46475	3	OBR
7854	87	48582	3	OBR
7855	87	34323	3	OBR
7856	87	48032	4	OBR
7857	87	50488	4	OBR
7858	87	51134	4	OBR
7859	87	48723	4	OBR
7860	87	46513	4	OBR
7861	87	34320	4	OBR
7862	87	51131	4	OBR
7863	87	32002	4	OBR
7864	87	50164	5	OBR
7865	87	51132	5	OBR
7866	87	51117	5	OBR
7867	87	51120	5	OBR
7868	87	32006	5	OBR
7869	87	32019	5	OBR
7870	87	51114	5	OBR
7871	87	51116	6	OBR
7872	87	50144	6	OBR
7873	87	34024	6	OBR
7874	87	34340	6	OBR
7875	87	51125	6	OBR
7876	87	32015	6	OBR
7877	87	34332	6	OBR
7878	87	51113	7	OBR
7879	87	51124	7	OBR
7880	87	34327	7	OBR
7881	87	34331	7	OBR
7882	87	50142	7	OBR
7883	87	51121	7	OBR
7884	87	51135	7	OBR
7885	87	34336	7	OBR
7886	87	34333	8	OBR
7887	87	34343	8	OBR
7888	87	34335	8	OBR
7889	87	32039	8	OBR
7890	87	51123	8	OBR
7891	87	50148	9	OBR
7892	87	51118	9	OBR
7893	87	51140	9	OBR
7894	87	34342	9	OBR
7895	87	51133	9	OBR
7896	87	43686	10	OBR
7897	87	51141	10	OBR
7898	87	51122	10	OBR
7899	87	51107	10	OBR
7900	87	51127	99	OPT
7901	87	46476	99	OPT
7902	87	51111	99	OPT
7903	87	32033	99	OPT
7904	87	46482	99	OPT
7905	87	46483	99	OPT
7906	87	32008	99	OPT
7907	87	51129	99	OPT
7908	87	32044	99	OPT
7909	87	46501	99	OPT
7910	87	51128	99	OPT
7911	87	31971	99	OPT
7912	87	46510	99	OPT
7913	87	45383	99	OPT
7914	87	42913	99	OPT
7915	87	31972	99	OPT
7916	87	51119	99	OPT
7917	87	51136	99	OPT
7918	87	48719	99	OPT
7919	87	46514	99	OPT
7920	87	46497	99	OPT
7921	87	46504	99	OPT
7922	87	32020	99	OPT
7923	87	48812	99	OPT
7924	87	31965	99	OPT
7925	87	32499	99	OPT
7926	87	32022	99	OPT
7927	87	32034	99	OPT
7928	87	31973	99	OPT
7929	87	31782	99	OPT
7930	87	32040	99	OPT
7931	87	32041	99	OPT
7932	87	32000	99	OPT
7933	87	32532	99	OPT
7934	87	51130	99	OPT
7935	87	34318	99	OPT
7936	87	46485	99	OPT
7937	87	32021	99	OPT
7938	87	51112	99	OPT
7939	87	51110	99	OPT
7940	87	51109	99	OPT
7941	87	43548	99	OPT
7942	87	31975	99	OPT
7943	87	51139	99	OPT
7944	87	34348	99	OPT
7945	87	34349	99	OPT
7946	87	34346	99	OPT
7947	87	34350	99	OPT
7948	87	34351	99	OPT
7949	87	34352	99	OPT
7950	87	34347	99	OPT
7951	87	51108	99	OPT
7952	87	34353	99	OPT
7953	87	34354	99	OPT
7954	87	51137	99	OPT
7955	87	51126	99	OPT
7956	88	38502	1	OBR
7957	88	38507	1	OBR
7958	88	51200	1	OBR
7959	88	51205	1	OBR
7960	88	51185	1	OBR
7961	88	38508	2	OBR
7962	88	38510	2	OBR
7963	88	38511	2	OBR
7964	88	51204	2	OBR
7965	88	51193	2	OBR
7966	88	48600	3	OBR
7967	88	51207	3	OBR
7968	88	38514	3	OBR
7969	88	38512	3	OBR
7970	88	31858	3	OBR
7971	88	38517	4	OBR
7972	88	38524	4	OBR
7973	88	38531	4	OBR
7974	88	51206	4	OBR
7975	88	51192	5	OBR
7976	88	38522	5	OBR
7977	88	51199	5	OBR
7978	88	51196	5	OBR
7979	88	51186	6	OBR
7980	88	51201	6	OBR
7981	88	51202	6	OBR
7982	88	51197	6	OBR
7983	88	38525	6	OBR
7984	88	51198	7	OBR
7985	88	51195	7	OBR
7986	88	38533	7	OBR
7987	88	38536	7	OBR
7988	88	51180	8	OBR
7989	88	51184	8	OBR
7990	88	38054	8	OBR
7991	88	51188	99	OPT
7992	88	51194	99	OPT
7993	88	38028	99	OPT
7994	88	38029	99	OPT
7995	88	38031	99	OPT
7996	88	38032	99	OPT
7997	88	38035	99	OPT
7998	88	41760	99	OPT
7999	88	38041	99	OPT
8000	88	41755	99	OPT
8001	88	43686	99	OPT
8002	88	35081	99	OPT
8003	88	51189	99	OPT
8004	88	38045	99	OPT
8005	88	41756	99	OPT
8006	88	38046	99	OPT
8007	88	38047	99	OPT
8008	88	38048	99	OPT
8009	88	41761	99	OPT
8010	88	42915	99	OPT
8011	88	38051	99	OPT
8012	88	38052	99	OPT
8013	88	51181	99	OPT
8014	88	38053	99	OPT
8015	88	38055	99	OPT
8016	88	38056	99	OPT
8017	88	38057	99	OPT
8018	88	38058	99	OPT
8019	88	32193	99	OPT
8020	88	38063	99	OPT
8021	88	38064	99	OPT
8022	88	38519	99	OPT
8023	88	38069	99	OPT
8024	88	38071	99	OPT
8025	88	38074	99	OPT
8026	88	42916	99	OPT
8027	88	38076	99	OPT
8028	88	51182	99	OPT
8029	88	38079	99	OPT
8030	88	51190	99	OPT
8031	88	51183	99	OPT
8032	88	51191	99	OPT
8033	88	51187	99	OPT
8034	88	51203	99	OPT
8035	88	31861	99	OPT
8036	88	41759	99	OPT
8037	88	38086	99	OPT
8038	88	38087	99	OPT
8039	88	41758	99	OPT
8040	88	38088	99	OPT
8041	88	42684	99	OPT
8042	88	38097	99	OPT
8043	88	38098	99	OPT
8044	89	48791	1	OBR
8045	89	48016	1	OBR
8046	89	48034	1	OBR
8047	89	50151	1	OBR
8048	89	31697	1	OBR
8049	89	48008	1	OBR
8050	89	48330	2	OBR
8051	89	48017	2	OBR
8052	89	31586	2	OBR
8053	89	50139	2	OBR
8054	89	46512	2	OBR
8055	89	48031	2	OBR
8056	89	48723	2	OBR
8057	89	48318	3	OBR
8058	89	50157	3	OBR
8059	89	48009	3	OBR
8060	89	50156	3	OBR
8061	89	49467	3	OBR
8062	89	50173	3	OBR
8063	89	50171	4	OBR
8064	89	50150	4	OBR
8065	89	50164	4	OBR
8066	89	48018	4	OBR
8067	89	31859	4	OBR
8068	89	50160	4	OBR
8069	89	31858	4	OBR
8070	89	50159	5	OBR
8071	89	46511	5	OBR
8072	89	31599	5	OBR
8073	89	31613	5	OBR
8074	89	48582	5	OBR
8075	89	50165	5	OBR
8076	89	50146	6	OBR
8077	89	34023	6	OBR
8078	89	50166	6	OBR
8079	89	50161	6	OBR
8080	89	34024	6	OBR
8081	89	50172	6	OBR
8082	89	31617	6	OBR
8083	89	50167	7	OBR
8084	89	50158	7	OBR
8085	89	34027	7	OBR
8086	89	50168	7	OBR
8087	89	31619	7	OBR
8088	89	31712	7	OBR
8089	89	31539	7	OBR
8090	89	50174	8	OBR
8091	89	50152	8	OBR
8092	89	45266	8	OBR
8093	89	34028	8	OBR
8094	89	46513	8	OBR
8095	89	34033	8	OBR
8096	89	34035	8	OBR
8097	89	50147	9	OBR
8098	89	50148	9	OBR
8099	89	45267	9	OBR
8100	89	50140	9	OBR
8101	89	50138	9	OBR
8102	89	50149	9	OBR
8103	89	50153	9	OBR
8104	89	34030	10	OBR
8105	89	50170	10	OBR
8106	89	50154	10	OBR
8107	89	31638	99	OPT
8108	89	33944	99	OPT
8109	89	31637	99	OPT
8110	89	33945	99	OPT
8111	89	33946	99	OPT
8112	89	33947	99	OPT
8113	89	31698	99	OPT
8114	89	46476	99	OPT
8115	89	50145	99	OPT
8116	89	51755	99	OPT
8117	89	33948	99	OPT
8118	89	46488	99	OPT
8119	89	33949	99	OPT
8120	89	31642	99	OPT
8121	89	31643	99	OPT
8122	89	31889	99	OPT
8123	89	33950	99	OPT
8124	89	46482	99	OPT
8125	89	46483	99	OPT
8126	89	34034	99	OPT
8127	89	33951	99	OPT
8128	89	33952	99	OPT
8129	89	46506	99	OPT
8130	89	33954	99	OPT
8131	89	33955	99	OPT
8132	89	46493	99	OPT
8133	89	42908	99	OPT
8134	89	33956	99	OPT
8135	89	46500	99	OPT
8136	89	33957	99	OPT
8137	89	33958	99	OPT
8138	89	46484	99	OPT
8139	89	33959	99	OPT
8140	89	33960	99	OPT
8141	89	46480	99	OPT
8142	89	46501	99	OPT
8143	89	33962	99	OPT
8144	89	33963	99	OPT
8145	89	31903	99	OPT
8146	89	41760	99	OPT
8147	89	31705	99	OPT
8148	89	33965	99	OPT
8149	89	36922	99	OPT
8150	89	36925	99	OPT
8151	89	46491	99	OPT
8152	89	43686	99	OPT
8153	89	46481	99	OPT
8154	89	31704	99	OPT
8155	89	46510	99	OPT
8156	89	46487	99	OPT
8157	89	33966	99	OPT
8158	89	33967	99	OPT
8159	89	33968	99	OPT
8160	89	33969	99	OPT
8161	89	50143	99	OPT
8162	89	46507	99	OPT
8163	89	33972	99	OPT
8164	89	41756	99	OPT
8165	89	33973	99	OPT
8166	89	33974	99	OPT
8167	89	33975	99	OPT
8168	89	33976	99	OPT
8169	89	33977	99	OPT
8170	89	33979	99	OPT
8171	89	48032	99	OPT
8172	89	51756	99	OPT
8173	89	33980	99	OPT
8174	89	33981	99	OPT
8175	89	33982	99	OPT
8176	89	33983	99	OPT
8177	89	46514	99	OPT
8178	89	33984	99	OPT
8179	89	34343	99	OPT
8180	89	32042	99	OPT
8181	89	50144	99	OPT
8182	89	46497	99	OPT
8183	89	46486	99	OPT
8184	89	46504	99	OPT
8185	89	50142	99	OPT
8186	89	46490	99	OPT
8187	89	34342	99	OPT
8188	89	46489	99	OPT
8189	89	46495	99	OPT
8190	89	45265	99	OPT
8191	89	36936	99	OPT
8192	89	36940	99	OPT
8193	89	50155	99	OPT
8194	89	31949	99	OPT
8195	89	31846	99	OPT
8196	89	33985	99	OPT
8197	89	33986	99	OPT
8198	89	31671	99	OPT
8199	89	48812	99	OPT
8200	89	33987	99	OPT
8201	89	33988	99	OPT
8202	89	31852	99	OPT
8203	89	31673	99	OPT
8204	89	46509	99	OPT
8205	89	50169	99	OPT
8206	89	46492	99	OPT
8207	89	31699	99	OPT
8208	89	31883	99	OPT
8209	89	33989	99	OPT
8210	89	31674	99	OPT
8211	89	33990	99	OPT
8212	89	31675	99	OPT
8213	89	50162	99	OPT
8214	89	33992	99	OPT
8215	89	31996	99	OPT
8216	89	32007	99	OPT
8217	89	33993	99	OPT
8218	89	33994	99	OPT
8219	89	31703	99	OPT
8220	89	33996	99	OPT
8221	89	33997	99	OPT
8222	89	31534	99	OPT
8223	89	31540	99	OPT
8224	89	31709	99	OPT
8225	89	33998	99	OPT
8226	89	33999	99	OPT
8227	89	34000	99	OPT
8228	89	31702	99	OPT
8229	89	31876	99	OPT
8230	89	31874	99	OPT
8231	89	48019	99	OPT
8232	89	34001	99	OPT
8233	89	34002	99	OPT
8234	89	46485	99	OPT
8235	89	50163	99	OPT
8236	89	31684	99	OPT
8237	89	50141	99	OPT
8238	89	34005	99	OPT
8239	89	34006	99	OPT
8240	89	34007	99	OPT
8241	89	46508	99	OPT
8242	89	34009	99	OPT
8243	89	34008	99	OPT
8244	89	31689	99	OPT
8245	89	31911	99	OPT
8246	89	34010	99	OPT
8247	90	50939	1	OBR
8248	90	50964	1	OBR
8249	90	50951	1	OBR
8250	90	41758	1	OBR
8251	90	50940	1	OBR
8252	90	50966	2	OBR
8253	90	41761	2	OBR
8254	90	50963	2	OBR
8255	90	50938	2	OBR
8256	90	41759	2	OBR
8257	90	50952	2	OBR
8258	90	50971	3	OBR
8259	90	50957	3	OBR
8260	90	41755	3	OBR
8261	90	50955	3	OBR
8262	90	50953	3	OBR
8263	90	50956	3	OBR
8264	90	48016	4	OBR
8265	90	50959	4	OBR
8266	90	50936	4	OBR
8267	90	50960	4	OBR
8268	90	50967	4	OBR
8269	90	48008	4	OBR
8270	90	48330	5	OBR
8271	90	48017	5	OBR
8272	90	50946	5	OBR
8273	90	50958	5	OBR
8274	90	50937	5	OBR
8275	90	50961	5	OBR
8276	90	48019	5	OBR
8277	90	48318	6	OBR
8278	90	50954	6	OBR
8279	90	50970	6	OBR
8280	90	48582	6	OBR
8281	90	50962	6	OBR
8282	90	48009	6	OBR
8283	90	48018	7	OBR
8284	90	50972	7	OBR
8285	90	48034	7	OBR
8286	90	50948	7	OBR
8287	90	50943	7	OBR
8288	90	50950	7	OBR
8289	90	50968	8	OBR
8290	90	50969	8	OBR
8291	90	50965	8	OBR
8292	90	50947	8	OBR
8293	90	41756	8	OBR
8294	90	48031	8	OBR
8295	90	50944	8	OBR
8296	90	50949	8	OBR
8297	90	32253	99	OPT
8298	90	42295	99	OPT
8299	90	42909	99	OPT
8300	90	43686	99	OPT
8301	90	32254	99	OPT
8302	90	48583	99	OPT
8303	90	38876	99	OPT
8304	90	32255	99	OPT
8305	90	48331	99	OPT
8306	90	38877	99	OPT
8307	90	43476	99	OPT
8308	90	43487	99	OPT
8309	90	50942	99	OPT
8310	90	50945	99	OPT
8311	90	50941	99	OPT
8312	90	32259	99	OPT
8313	91	50939	1	OBR
8314	91	50964	1	OBR
8315	91	50951	1	OBR
8316	91	41758	1	OBR
8317	91	50940	1	OBR
8318	91	50966	2	OBR
8319	91	41761	2	OBR
8320	91	50963	2	OBR
8321	91	50938	2	OBR
8322	91	41759	2	OBR
8323	91	50952	2	OBR
8324	91	50971	3	OBR
8325	91	50957	3	OBR
8326	91	41755	3	OBR
8327	91	50955	3	OBR
8328	91	50953	3	OBR
8329	91	50956	3	OBR
8330	91	48016	4	OBR
8331	91	50959	4	OBR
8332	91	50936	4	OBR
8333	91	50960	4	OBR
8334	91	50967	4	OBR
8335	91	48008	4	OBR
8336	91	48330	5	OBR
8337	91	48017	5	OBR
8338	91	50946	5	OBR
8339	91	50958	5	OBR
8340	91	50937	5	OBR
8341	91	50961	5	OBR
8342	91	48019	5	OBR
8343	91	48318	6	OBR
8344	91	50954	6	OBR
8345	91	50970	6	OBR
8346	91	48582	6	OBR
8347	91	50962	6	OBR
8348	91	48009	6	OBR
8349	91	48018	7	OBR
8350	91	50972	7	OBR
8351	91	48034	7	OBR
8352	91	50948	7	OBR
8353	91	50943	7	OBR
8354	91	50950	7	OBR
8355	91	50968	8	OBR
8356	91	50969	8	OBR
8357	91	50965	8	OBR
8358	91	50947	8	OBR
8359	91	41756	8	OBR
8360	91	48031	8	OBR
8361	91	50944	8	OBR
8362	91	50949	8	OBR
8363	91	32253	99	OPT
8364	91	42295	99	OPT
8365	91	42909	99	OPT
8366	91	43686	99	OPT
8367	91	32254	99	OPT
8368	91	48583	99	OPT
8369	91	38876	99	OPT
8370	91	32255	99	OPT
8371	91	48331	99	OPT
8372	91	38877	99	OPT
8373	91	43476	99	OPT
8374	91	43487	99	OPT
8375	91	50942	99	OPT
8376	91	50945	99	OPT
8377	91	50941	99	OPT
8378	91	32259	99	OPT
8379	92	50957	1	OBR
8380	92	52141	1	OBR
8381	92	50959	1	OBR
8382	92	50955	1	OBR
8383	92	48331	1	OBR
8384	92	45836	2	OBR
8385	92	48016	2	OBR
8386	92	50958	2	OBR
8387	92	48008	2	OBR
8388	92	48330	3	OBR
8389	92	45839	3	OBR
8390	92	48017	3	OBR
8391	92	45853	3	OBR
8392	92	48019	3	OBR
8393	92	52144	4	OBR
8394	92	48318	4	OBR
8395	92	45842	4	OBR
8396	92	48018	4	OBR
8397	92	45846	4	OBR
8398	92	38906	5	OBR
8399	92	45840	5	OBR
8400	92	48582	5	OBR
8401	92	52143	5	OBR
8402	92	38908	6	OBR
8403	92	45833	6	OBR
8404	92	45841	6	OBR
8405	92	45850	6	OBR
8406	92	45843	7	OBR
8407	92	48034	7	OBR
8408	92	45849	7	OBR
8409	92	52142	7	OBR
8410	92	41760	8	OBR
8411	92	48031	8	OBR
8412	92	45845	8	OBR
8413	92	45834	99	OPT
8414	92	42295	99	OPT
8415	92	45838	99	OPT
8416	92	41756	99	OPT
8417	92	48032	99	OPT
8418	92	45847	99	OPT
8419	92	45848	99	OPT
8420	92	45851	99	OPT
8421	92	45852	99	OPT
8422	92	45854	99	OPT
8423	92	45263	99	OPT
8424	92	45856	99	OPT
8425	92	45832	99	OPT
8426	92	45855	99	OPT
8427	93	48726	1	OBR
8428	93	48727	1	OBR
8429	93	48011	1	OBR
8430	93	48718	1	OBR
8431	93	48331	1	OBR
8432	93	41758	1	OBR
8433	93	48016	2	OBR
8434	93	48034	2	OBR
8435	93	48736	2	OBR
8436	93	48022	2	OBR
8437	93	48041	2	OBR
8438	93	48017	3	OBR
8439	93	48719	3	OBR
8440	93	48739	3	OBR
8441	93	41759	3	OBR
8442	93	36058	3	OBR
8443	93	48046	3	OBR
8444	93	48012	3	OBR
8445	93	48018	4	OBR
8446	93	45236	4	OBR
8447	93	41761	4	OBR
8448	93	48714	4	OBR
8449	93	48045	4	OBR
8450	93	36060	4	OBR
8451	93	48013	4	OBR
8452	93	48027	5	OBR
8453	93	36063	5	OBR
8454	93	48716	5	OBR
8455	93	48026	5	OBR
8456	93	36064	5	OBR
8457	93	48024	5	OBR
8458	93	48019	5	OBR
8459	93	41755	6	OBR
8460	93	36069	6	OBR
8461	93	48723	6	OBR
8462	93	48728	6	OBR
8463	93	48048	6	OBR
8464	93	48023	6	OBR
8465	93	51906	7	OBR
8466	93	41756	7	OBR
8467	93	36074	7	OBR
8468	93	48725	7	OBR
8469	93	48044	7	OBR
8470	93	48735	7	OBR
8471	93	51907	8	OBR
8472	93	48028	8	OBR
8473	93	48047	8	OBR
8474	93	48010	8	OBR
8475	93	48042	8	OBR
8476	93	36077	8	OBR
8477	93	51908	9	OBR
8478	93	36084	9	OBR
8479	93	48721	9	OBR
8480	93	48039	9	OBR
8481	93	48717	9	OBR
8482	93	51905	10	OBR
8483	93	36089	10	OBR
8484	93	48720	10	OBR
8485	93	48015	99	OPT
8486	93	24594	99	OPT
8487	93	24596	99	OPT
8488	93	48729	99	OPT
8489	93	43181	99	OPT
8490	93	36029	99	OPT
8491	93	43686	99	OPT
8492	93	36030	99	OPT
8493	93	43863	99	OPT
8494	93	36033	99	OPT
8495	93	36034	99	OPT
8496	93	36035	99	OPT
8497	93	36036	99	OPT
8498	93	36037	99	OPT
8499	93	48713	99	OPT
8500	93	48043	99	OPT
8501	93	44010	99	OPT
8502	93	41088	99	OPT
8503	93	41089	99	OPT
8504	93	41090	99	OPT
8505	93	36104	99	OPT
8506	93	48014	99	OPT
8507	93	36041	99	OPT
8508	93	43183	99	OPT
8509	93	36094	99	OPT
8510	93	36042	99	OPT
8511	93	36043	99	OPT
8512	93	36044	99	OPT
8513	93	36103	99	OPT
8514	93	36045	99	OPT
8515	93	48035	99	OPT
8516	93	48734	99	OPT
8517	93	48731	99	OPT
8518	93	36046	99	OPT
8519	93	36047	99	OPT
8520	93	43926	99	OPT
8521	93	43890	99	OPT
8522	93	43950	99	OPT
8523	93	48737	99	OPT
8524	93	48715	99	OPT
8525	93	48738	99	OPT
8526	93	36050	99	OPT
8527	93	48730	99	OPT
8528	94	48016	1	OBR
8529	94	48034	1	OBR
8530	94	48011	1	OBR
8531	94	42900	1	OBR
8532	94	48040	1	OBR
8533	94	48008	1	OBR
8534	94	48017	2	OBR
8535	94	48031	2	OBR
8536	94	48045	2	OBR
8537	94	36060	2	OBR
8538	94	48022	2	OBR
8539	94	48041	2	OBR
8540	94	48018	3	OBR
8541	94	48027	3	OBR
8542	94	48032	3	OBR
8543	94	48723	3	OBR
8544	94	48009	3	OBR
8545	94	36058	3	OBR
8546	94	48046	3	OBR
8547	94	48012	3	OBR
8548	94	48019	3	OBR
8549	94	48021	4	OBR
8550	94	36102	4	OBR
8551	94	36069	4	OBR
8552	94	36101	4	OBR
8553	94	48048	4	OBR
8554	94	48023	4	OBR
8555	94	48024	4	OBR
8556	94	48013	4	OBR
8557	94	36074	5	OBR
8558	94	48025	5	OBR
8559	94	36063	5	OBR
8560	94	48044	5	OBR
8561	94	48026	5	OBR
8562	94	36064	5	OBR
8563	94	36103	5	OBR
8564	94	48028	6	OBR
8565	94	36105	6	OBR
8566	94	36106	6	OBR
8567	94	48047	6	OBR
8568	94	48010	6	OBR
8569	94	48042	6	OBR
8570	94	36077	6	OBR
8571	94	36089	7	OBR
8572	94	36084	7	OBR
8573	94	48043	7	OBR
8574	94	48039	7	OBR
8575	94	36107	7	OBR
8576	94	48020	7	OBR
8577	94	36108	7	OBR
8578	94	36113	8	OBR
8579	94	48014	8	OBR
8580	94	36027	99	OPT
8581	94	48038	99	OPT
8582	94	48015	99	OPT
8583	94	24594	99	OPT
8584	94	24596	99	OPT
8585	94	41760	99	OPT
8586	94	36029	99	OPT
8587	94	48796	99	OPT
8588	94	36030	99	OPT
8589	94	41756	99	OPT
8590	94	36033	99	OPT
8591	94	36034	99	OPT
8592	94	36035	99	OPT
8593	94	36036	99	OPT
8594	94	48037	99	OPT
8595	94	36040	99	OPT
8596	94	36041	99	OPT
8597	94	36094	99	OPT
8598	94	36080	99	OPT
8599	94	36042	99	OPT
8600	94	36043	99	OPT
8601	94	36044	99	OPT
8602	94	36045	99	OPT
8603	94	48035	99	OPT
8604	94	48036	99	OPT
8605	94	36046	99	OPT
8606	94	36047	99	OPT
8607	94	36095	99	OPT
8608	94	36096	99	OPT
8609	95	48016	1	OBR
8610	95	48796	1	OBR
8611	95	48034	1	OBR
8612	95	48011	1	OBR
8613	95	48800	1	OBR
8614	95	34025	1	OBR
8615	95	48040	1	OBR
8616	95	48008	1	OBR
8617	95	48017	2	OBR
8618	95	48809	2	OBR
8619	95	45236	2	OBR
8620	95	48798	2	OBR
8621	95	46468	2	OBR
8622	95	36060	2	OBR
8623	95	48022	2	OBR
8624	95	48041	2	OBR
8625	95	48318	3	OBR
8626	95	48018	3	OBR
8627	95	48027	3	OBR
8628	95	48799	3	OBR
8629	95	48812	3	OBR
8630	95	48046	3	OBR
8631	95	48012	3	OBR
8632	95	48019	3	OBR
8633	95	44652	4	OBR
8634	95	36069	4	OBR
8635	95	48723	4	OBR
8636	95	48582	4	OBR
8637	95	48048	4	OBR
8638	95	48023	4	OBR
8639	95	48024	4	OBR
8640	95	48013	4	OBR
8641	95	48038	5	OBR
8642	95	44653	5	OBR
8643	95	36074	5	OBR
8644	95	48801	5	OBR
8645	95	48009	5	OBR
8646	95	48044	5	OBR
8647	95	36064	5	OBR
8648	95	48821	5	OBR
8649	95	48791	6	OBR
8650	95	44659	6	OBR
8651	95	34312	6	OBR
8652	95	46456	6	OBR
8653	95	48813	6	OBR
8654	95	36106	6	OBR
8655	95	48010	6	OBR
8656	95	48823	6	OBR
8657	95	48797	7	OBR
8658	95	48806	7	OBR
8659	95	34481	7	OBR
8660	95	44643	7	OBR
8661	95	44636	7	OBR
8662	95	48039	7	OBR
8663	95	48820	7	OBR
8664	95	48020	7	OBR
8665	95	48794	8	OBR
8666	95	48817	8	OBR
8667	95	36101	8	OBR
8668	95	34319	8	OBR
8669	95	48811	8	OBR
8670	95	48807	8	OBR
8671	95	48792	8	OBR
8672	95	48795	9	OBR
8673	95	48015	9	OBR
8674	95	48808	9	OBR
8675	95	44637	9	OBR
8676	95	48805	9	OBR
8677	95	48793	9	OBR
8678	95	44647	9	OBR
8679	95	31958	99	OPT
8680	95	48814	99	OPT
8681	95	41383	99	OPT
8682	95	48818	99	OPT
8683	95	48602	99	OPT
8684	95	24594	99	OPT
8685	95	24596	99	OPT
8686	95	36029	99	OPT
8687	95	31817	99	OPT
8688	95	41756	99	OPT
8689	95	34317	99	OPT
8690	95	32419	99	OPT
8691	95	48803	99	OPT
8692	95	36110	99	OPT
8693	95	36082	99	OPT
8694	95	36042	99	OPT
8695	95	48804	99	OPT
8696	95	48822	99	OPT
8697	95	48819	99	OPT
8698	95	48816	99	OPT
8699	95	48815	99	OPT
8700	95	46457	99	OPT
8701	95	46459	99	OPT
8702	95	46458	99	OPT
8703	95	48802	99	OPT
8704	96	48339	1	OBR
8705	96	37185	1	OBR
8706	96	48331	1	OBR
8707	96	45363	1	OBR
8708	96	48333	1	OBR
8709	96	45398	2	OBR
8710	96	48016	2	OBR
8711	96	48313	2	OBR
8712	96	48008	2	OBR
8713	96	48330	3	OBR
8714	96	48017	3	OBR
8715	96	48312	3	OBR
8716	96	48324	3	OBR
8717	96	37188	3	OBR
8718	96	48318	4	OBR
8719	96	48321	4	OBR
8720	96	37192	4	OBR
8721	96	48334	4	OBR
8722	96	48019	4	OBR
8723	96	48320	5	OBR
8724	96	48319	5	OBR
8725	96	48326	5	OBR
8726	96	37196	5	OBR
8727	96	48327	5	OBR
8728	96	48325	6	OBR
8729	96	48314	6	OBR
8730	96	48329	6	OBR
8731	96	48322	6	OBR
8732	96	37201	6	OBR
8733	96	48336	7	OBR
8734	96	37203	7	OBR
8735	96	48315	7	OBR
8736	96	48009	7	OBR
8737	96	48337	8	OBR
8738	96	48332	8	OBR
8739	96	48323	8	OBR
8740	96	37145	99	OPT
8741	96	31586	99	OPT
8742	96	43181	99	OPT
8743	96	37148	99	OPT
8744	96	37149	99	OPT
8745	96	41755	99	OPT
8746	96	48338	99	OPT
8747	96	43686	99	OPT
8748	96	41756	99	OPT
8749	96	44450	99	OPT
8750	96	37153	99	OPT
8751	96	37154	99	OPT
8752	96	37155	99	OPT
8753	96	48335	99	OPT
8754	96	37158	99	OPT
8755	96	37162	99	OPT
8756	96	37163	99	OPT
8757	96	37164	99	OPT
8758	96	37165	99	OPT
8759	96	37166	99	OPT
8760	96	37167	99	OPT
8761	96	51887	99	OPT
8762	96	37168	99	OPT
8763	96	41091	99	OPT
8764	96	44448	99	OPT
8765	96	37170	99	OPT
8766	96	37171	99	OPT
8767	96	48040	99	OPT
8768	96	37177	99	OPT
8769	96	37178	99	OPT
8770	96	37179	99	OPT
8771	96	37180	99	OPT
8772	96	48328	99	OPT
8773	96	48317	99	OPT
8774	96	48316	99	OPT
8775	97	48339	1	OBR
8776	97	49478	1	OBR
8777	97	37185	1	OBR
8778	97	44439	1	OBR
8779	97	44441	1	OBR
8780	97	41758	1	OBR
8781	97	48016	2	OBR
8782	97	48313	2	OBR
8783	97	49473	2	OBR
8784	97	41761	2	OBR
8785	97	48008	2	OBR
8786	97	48017	3	OBR
8787	97	43181	3	OBR
8788	97	48324	3	OBR
8789	97	37188	3	OBR
8790	97	51892	3	OBR
8791	97	48318	4	OBR
8792	97	41755	4	OBR
8793	97	48321	4	OBR
8794	97	49474	4	OBR
8795	97	37192	4	OBR
8796	97	51893	4	OBR
8797	97	49480	5	OBR
8798	97	48319	5	OBR
8799	97	37196	5	OBR
8800	97	41759	5	OBR
8801	97	51894	5	OBR
8802	97	48334	5	OBR
8803	97	49481	6	OBR
8804	97	49472	6	OBR
8805	97	49470	6	OBR
8806	97	37169	6	OBR
8807	97	48329	6	OBR
8808	97	49482	7	OBR
8809	97	41756	7	OBR
8810	97	51891	7	OBR
8811	97	49471	7	OBR
8812	97	51895	7	OBR
8813	97	49476	8	OBR
8814	97	49483	8	OBR
8815	97	49475	8	OBR
8816	97	37203	8	OBR
8817	97	51896	8	OBR
8818	97	51888	8	OBR
8819	97	44447	99	OPT
8820	97	42295	99	OPT
8821	97	41686	99	OPT
8822	97	37148	99	OPT
8823	97	37149	99	OPT
8824	97	43686	99	OPT
8825	97	37181	99	OPT
8826	97	37186	99	OPT
8827	97	44442	99	OPT
8828	97	43188	99	OPT
8829	97	43186	99	OPT
8830	97	43187	99	OPT
8831	97	37157	99	OPT
8832	97	37159	99	OPT
8833	97	37162	99	OPT
8834	97	37165	99	OPT
8835	97	37166	99	OPT
8836	97	37195	99	OPT
8837	97	44448	99	OPT
8838	97	43185	99	OPT
8839	97	43184	99	OPT
8840	97	43189	99	OPT
8841	97	43183	99	OPT
8842	97	38615	99	OPT
8843	97	37178	99	OPT
8844	97	37179	99	OPT
8845	97	37180	99	OPT
8846	97	51890	99	OPT
8847	97	51889	99	OPT
8848	98	31586	1	OBR
8849	98	32049	1	OBR
8850	98	45355	1	OBR
8851	98	37185	1	OBR
8852	98	51886	1	OBR
8853	98	48331	1	OBR
8854	98	45363	1	OBR
8855	98	48016	2	OBR
8856	98	43181	2	OBR
8857	98	48313	2	OBR
8858	98	47705	2	OBR
8859	98	48008	2	OBR
8860	98	48330	3	OBR
8861	98	45398	3	OBR
8862	98	48017	3	OBR
8863	98	48324	3	OBR
8864	98	37188	3	OBR
8865	98	48318	4	OBR
8866	98	48312	4	OBR
8867	98	48321	4	OBR
8868	98	37192	4	OBR
8869	98	48009	4	OBR
8870	98	48019	4	OBR
8871	98	50493	5	OBR
8872	98	48320	5	OBR
8873	98	48319	5	OBR
8874	98	48326	5	OBR
8875	98	37196	5	OBR
8876	98	48327	5	OBR
8877	98	50489	6	OBR
8878	98	50492	6	OBR
8879	98	48325	6	OBR
8880	98	48329	6	OBR
8881	98	46456	6	OBR
8882	98	37201	6	OBR
8883	98	36920	7	OBR
8884	98	48336	7	OBR
8885	98	45353	7	OBR
8886	98	34024	7	OBR
8887	98	48315	7	OBR
8888	98	47722	8	OBR
8889	98	37163	8	OBR
8890	98	37164	8	OBR
8891	98	37203	8	OBR
8892	98	48334	8	OBR
8893	98	45364	9	OBR
8894	98	51887	9	OBR
8895	98	36933	9	OBR
8896	98	48040	9	OBR
8897	98	45358	9	OBR
8898	98	46613	10	OBR
8899	98	45399	99	OPT
8900	98	37145	99	OPT
8901	98	42908	99	OPT
8902	98	45352	99	OPT
8903	98	24594	99	OPT
8904	98	24596	99	OPT
8905	98	48337	99	OPT
8906	98	48338	99	OPT
8907	98	45354	99	OPT
8908	98	43686	99	OPT
8909	98	41756	99	OPT
8910	98	48339	99	OPT
8911	98	37153	99	OPT
8912	98	37155	99	OPT
8913	98	48314	99	OPT
8914	98	48335	99	OPT
8915	98	45422	99	OPT
8916	98	37166	99	OPT
8917	98	37168	99	OPT
8918	98	40538	99	OPT
8919	98	45361	99	OPT
8920	98	44439	99	OPT
8921	98	48322	99	OPT
8922	98	48332	99	OPT
8923	98	48323	99	OPT
8924	98	32322	99	OPT
8925	98	45362	99	OPT
8926	98	43185	99	OPT
8927	98	37171	99	OPT
8928	98	36060	99	OPT
8929	98	36070	99	OPT
8930	98	48047	99	OPT
8931	98	36073	99	OPT
8932	98	36081	99	OPT
8933	98	36054	99	OPT
8934	98	36059	99	OPT
8935	98	48333	99	OPT
8936	98	36270	99	OPT
8937	98	37177	99	OPT
8938	98	45360	99	OPT
8939	98	45359	99	OPT
8940	98	45365	99	OPT
8941	98	37178	99	OPT
8942	98	37179	99	OPT
8943	98	37180	99	OPT
8944	98	48328	99	OPT
8945	98	48317	99	OPT
8946	98	48316	99	OPT
8947	99	49804	1	OBR
8948	99	49838	1	OBR
8949	99	49799	1	OBR
8950	99	48596	1	OBR
8951	99	48331	1	OBR
8952	99	49800	2	OBR
8953	99	49801	2	OBR
8954	99	49842	2	OBR
8955	99	49822	2	OBR
8956	99	49831	2	OBR
8957	99	49802	3	OBR
8958	99	49835	3	OBR
8959	99	49823	3	OBR
8960	99	49834	3	OBR
8961	99	49839	4	OBR
8962	99	49832	4	OBR
8963	99	48594	4	OBR
8964	99	49840	4	OBR
8965	99	49837	4	OBR
8966	99	49803	5	OBR
8967	99	49828	5	OBR
8968	99	49841	5	OBR
8969	99	49833	5	OBR
8970	99	48599	6	OBR
8971	99	49829	6	OBR
8972	99	48597	6	OBR
8973	99	49819	6	OBR
8974	99	49824	6	OBR
8975	99	49827	6	OBR
8976	99	49820	7	OBR
8977	99	40268	7	OBR
8978	99	49821	7	OBR
8979	99	49830	7	OBR
8980	99	49843	8	OBR
8981	99	49826	99	OPT
8982	99	42920	99	OPT
8983	99	43686	99	OPT
8984	99	42300	99	OPT
8985	99	49825	99	OPT
8986	99	49836	99	OPT
8987	99	49805	99	OPT
8988	99	49806	99	OPT
8989	99	49807	99	OPT
8990	99	49808	99	OPT
8991	99	49815	99	OPT
8992	99	49809	99	OPT
8993	99	49810	99	OPT
8994	99	49811	99	OPT
8995	99	49814	99	OPT
8996	99	49817	99	OPT
8997	99	49812	99	OPT
8998	99	49816	99	OPT
8999	99	49818	99	OPT
9000	99	49813	99	OPT
9001	99	40208	99	OPT
9002	99	40209	99	OPT
9003	99	40210	99	OPT
9004	99	40211	99	OPT
9005	99	40212	99	OPT
9006	99	40213	99	OPT
9007	99	40215	99	OPT
9008	99	40214	99	OPT
9009	100	49804	1	OBR
9010	100	49838	1	OBR
9011	100	49799	1	OBR
9012	100	48596	1	OBR
9013	100	48331	1	OBR
9014	100	49800	2	OBR
9015	100	49801	2	OBR
9016	100	49842	2	OBR
9017	100	49822	2	OBR
9018	100	49831	2	OBR
9019	100	49802	3	OBR
9020	100	49835	3	OBR
9021	100	49823	3	OBR
9022	100	49834	3	OBR
9023	100	49839	4	OBR
9024	100	49832	4	OBR
9025	100	48594	4	OBR
9026	100	49840	4	OBR
9027	100	49837	4	OBR
9028	100	49803	5	OBR
9029	100	49828	5	OBR
9030	100	49841	5	OBR
9031	100	49833	5	OBR
9032	100	49829	6	OBR
9033	100	48597	6	OBR
9034	100	49819	6	OBR
9035	100	49824	6	OBR
9036	100	49827	6	OBR
9037	100	49820	7	OBR
9038	100	48599	7	OBR
9039	100	40268	7	OBR
9040	100	49821	7	OBR
9041	100	49830	7	OBR
9042	100	49843	8	OBR
9043	100	49826	99	OPT
9044	100	42920	99	OPT
9045	100	43686	99	OPT
9046	100	42300	99	OPT
9047	100	49825	99	OPT
9048	100	49836	99	OPT
9049	100	49805	99	OPT
9050	100	49806	99	OPT
9051	100	49807	99	OPT
9052	100	49808	99	OPT
9053	100	49815	99	OPT
9054	100	49809	99	OPT
9055	100	49810	99	OPT
9056	100	49811	99	OPT
9057	100	49814	99	OPT
9058	100	49817	99	OPT
9059	100	49812	99	OPT
9060	100	49816	99	OPT
9061	100	49818	99	OPT
9062	100	49813	99	OPT
9063	100	40208	99	OPT
9064	100	40209	99	OPT
9065	100	40210	99	OPT
9066	100	40211	99	OPT
9067	100	40212	99	OPT
9068	100	40213	99	OPT
9069	100	40215	99	OPT
9070	100	40214	99	OPT
9071	101	51237	1	OBR
9072	101	48596	1	OBR
9073	101	51222	1	OBR
9074	101	40184	1	OBR
9075	101	51225	1	OBR
9076	101	40231	2	OBR
9077	101	48594	2	OBR
9078	101	51223	2	OBR
9079	101	40232	2	OBR
9080	101	51238	2	OBR
9081	101	51224	3	OBR
9082	101	49839	3	OBR
9083	101	40235	3	OBR
9084	101	51220	3	OBR
9085	101	51221	3	OBR
9086	101	51217	4	OBR
9087	101	51216	4	OBR
9088	101	51219	4	OBR
9089	101	40233	4	OBR
9090	101	51215	4	OBR
9091	101	51226	4	OBR
9092	101	51218	5	OBR
9093	101	40234	5	OBR
9094	101	51239	5	OBR
9095	101	40236	5	OBR
9096	101	51210	5	OBR
9097	101	51214	6	OBR
9098	101	40278	6	OBR
9099	101	51211	6	OBR
9100	101	51213	6	OBR
9101	101	40240	6	OBR
9102	101	51208	7	OBR
9103	101	51209	7	OBR
9104	101	51235	7	OBR
9105	101	51233	99	OPT
9106	101	51230	99	OPT
9107	101	51232	99	OPT
9108	101	51234	99	OPT
9109	101	51231	99	OPT
9110	101	42920	99	OPT
9111	101	43686	99	OPT
9112	101	51227	99	OPT
9113	101	42300	99	OPT
9114	101	51228	99	OPT
9115	101	51229	99	OPT
9116	101	51212	99	OPT
9117	101	51240	99	OPT
9118	101	51236	99	OPT
9119	102	46655	1	OBR
9120	102	46639	1	OBR
9121	102	49670	1	OBR
9122	102	49674	1	OBR
9123	102	49656	1	OBR
9124	102	46656	2	OBR
9125	102	49658	2	OBR
9126	102	49659	2	OBR
9127	102	46635	2	OBR
9128	102	49678	2	OBR
9129	102	49673	2	OBR
9130	102	46636	2	OBR
9131	102	49675	3	OBR
9132	102	49660	3	OBR
9133	102	46657	3	OBR
9134	102	49672	3	OBR
9135	102	49680	3	OBR
9136	102	49668	4	OBR
9137	102	46644	4	OBR
9138	102	49661	4	OBR
9139	102	49657	4	OBR
9140	102	46662	4	OBR
9141	102	49667	5	OBR
9142	102	49679	5	OBR
9143	102	49662	5	OBR
9144	102	49682	5	OBR
9145	102	46649	5	OBR
9146	102	49676	6	OBR
9147	102	49671	6	OBR
9148	102	49664	6	OBR
9149	102	49677	6	OBR
9150	102	46651	6	OBR
9151	102	49665	7	OBR
9152	102	49669	7	OBR
9153	102	49683	7	OBR
9154	102	49684	7	OBR
9155	102	49666	7	OBR
9156	102	49663	8	OBR
9157	102	46641	8	OBR
9158	102	49681	8	OBR
9159	102	46630	99	OPT
9160	102	46620	99	OPT
9161	102	46653	99	OPT
9162	102	46617	99	OPT
9163	102	46614	99	OPT
9164	102	46627	99	OPT
9165	102	46628	99	OPT
9166	102	42920	99	OPT
9167	102	46648	99	OPT
9168	102	43686	99	OPT
9169	102	46623	99	OPT
9170	102	42300	99	OPT
9171	102	46622	99	OPT
9172	102	46629	99	OPT
9173	102	46632	99	OPT
9174	102	46619	99	OPT
9175	102	42152	99	OPT
9176	102	46631	99	OPT
9177	102	46646	99	OPT
9178	102	46634	99	OPT
9179	102	46659	99	OPT
9180	102	46616	99	OPT
9181	102	46660	99	OPT
9182	102	46661	99	OPT
9183	102	46633	99	OPT
9184	102	46647	99	OPT
9185	102	46624	99	OPT
9186	102	46625	99	OPT
9187	103	48596	1	OBR
9188	103	40276	1	OBR
9189	103	48594	1	OBR
9190	103	40271	1	OBR
9191	103	48331	1	OBR
9192	103	49835	2	OBR
9193	103	40272	2	OBR
9194	103	49830	2	OBR
9195	103	49834	2	OBR
9196	103	48599	3	OBR
9197	103	49828	3	OBR
9198	103	40278	3	OBR
9199	103	40273	3	OBR
9200	103	40275	4	OBR
9201	103	40279	4	OBR
9202	103	40274	4	OBR
9203	103	49827	4	OBR
9204	103	42923	99	OPT
9205	103	42300	99	OPT
9206	103	40208	99	OPT
9207	103	40209	99	OPT
9208	103	40210	99	OPT
9209	103	40211	99	OPT
9210	103	40216	99	OPT
9211	103	40212	99	OPT
9212	103	40213	99	OPT
9213	103	40215	99	OPT
9214	103	40214	99	OPT
9215	103	40217	99	OPT
9216	103	50175	99	OPT
9217	104	40186	1	OBR
9218	104	42935	1	OBR
9219	104	50278	1	OBR
9220	104	50276	1	OBR
9221	104	50275	1	OBR
9222	104	50255	1	OBR
9223	104	42937	2	OBR
9224	104	50256	2	OBR
9225	104	40252	2	OBR
9226	104	50274	2	OBR
9227	104	42938	2	OBR
9228	104	50279	3	OBR
9229	104	50273	3	OBR
9230	104	42940	3	OBR
9231	104	51897	3	OBR
9232	104	42943	3	OBR
9233	104	42955	4	OBR
9234	104	42946	4	OBR
9235	104	51899	4	OBR
9236	104	51900	4	OBR
9237	104	51898	4	OBR
9238	104	42948	4	OBR
9239	104	42958	5	OBR
9240	104	42963	5	OBR
9241	104	50280	5	OBR
9242	104	42949	5	OBR
9243	104	51901	5	OBR
9244	104	42951	5	OBR
9245	104	42957	6	OBR
9246	104	42960	6	OBR
9247	104	42953	6	OBR
9248	104	42954	6	OBR
9249	104	50283	6	OBR
9250	104	51903	6	OBR
9251	104	50266	7	OBR
9252	104	50285	7	OBR
9253	104	50259	7	OBR
9254	104	50284	7	OBR
9255	104	51902	7	OBR
9256	104	50257	8	OBR
9257	104	50269	99	OPT
9258	104	42950	99	OPT
9259	104	41756	99	OPT
9260	104	50277	99	OPT
9261	104	50271	99	OPT
9262	104	50265	99	OPT
9263	104	50262	99	OPT
9264	104	50263	99	OPT
9265	104	50261	99	OPT
9266	104	50260	99	OPT
9267	104	50270	99	OPT
9268	104	50264	99	OPT
9269	104	42928	99	OPT
9270	104	42930	99	OPT
9271	104	42931	99	OPT
9272	104	50272	99	OPT
9273	104	42933	99	OPT
9274	104	42934	99	OPT
9275	106	41095	1	OBR
9276	106	45760	1	OBR
9277	106	41635	1	OBR
9278	106	41247	1	OBR
9279	106	45778	1	OBR
9280	106	49467	1	OBR
9281	106	45757	1	OBR
9282	106	45795	2	OBR
9283	106	45789	2	OBR
9284	106	41251	2	OBR
9285	106	49457	2	OBR
9286	106	48041	2	OBR
9287	106	38436	2	OBR
9288	106	45753	3	OBR
9289	106	49465	3	OBR
9290	106	41254	3	OBR
9291	106	41255	3	OBR
9292	106	45742	3	OBR
9293	106	36060	3	OBR
9294	106	38442	3	OBR
9295	106	38443	3	OBR
9296	106	45796	4	OBR
9297	106	41145	4	OBR
9298	106	45776	4	OBR
9299	106	41250	4	OBR
9300	106	45766	4	OBR
9301	106	41264	4	OBR
9302	106	45755	4	OBR
9303	106	48023	4	OBR
9304	106	45774	5	OBR
9305	106	41263	5	OBR
9306	106	45743	5	OBR
9307	106	41289	5	OBR
9308	106	41268	5	OBR
9309	106	41620	5	OBR
9310	106	41265	5	OBR
9311	106	41261	6	OBR
9312	106	45750	6	OBR
9313	106	45748	6	OBR
9314	106	41267	6	OBR
9315	106	49460	6	OBR
9316	106	41288	6	OBR
9317	106	41271	6	OBR
9318	106	41272	7	OBR
9319	106	45790	7	OBR
9320	106	45784	7	OBR
9321	106	45794	7	OBR
9322	106	41275	7	OBR
9323	106	45759	7	OBR
9324	106	41276	7	OBR
9325	106	41278	8	OBR
9326	106	45783	8	OBR
9327	106	45791	8	OBR
9328	106	45773	8	OBR
9329	106	41283	8	OBR
9330	106	45785	8	OBR
9331	106	41285	9	OBR
9332	106	45752	9	OBR
9333	106	47548	9	OBR
9334	106	45751	9	OBR
9335	106	49456	9	OBR
9336	106	45771	9	OBR
9337	106	41287	9	OBR
9338	106	49466	10	OBR
9339	106	45786	10	OBR
9340	106	45777	10	OBR
9341	106	45772	10	OBR
9342	106	45758	99	OPT
9343	106	45238	99	OPT
9344	106	45764	99	OPT
9345	106	41421	99	OPT
9346	106	41309	99	OPT
9347	106	41296	99	OPT
9348	106	45745	99	OPT
9349	106	42622	99	OPT
9350	106	43686	99	OPT
9351	106	41392	99	OPT
9352	106	45756	99	OPT
9353	106	41756	99	OPT
9354	106	41230	99	OPT
9355	106	45749	99	OPT
9356	106	41761	99	OPT
9357	106	41232	99	OPT
9358	106	45781	99	OPT
9359	106	45762	99	OPT
9360	106	49459	99	OPT
9361	106	45744	99	OPT
9362	106	41299	99	OPT
9363	106	45195	99	OPT
9364	106	41344	99	OPT
9365	106	49458	99	OPT
9366	106	45779	99	OPT
9367	106	41099	99	OPT
9368	106	41100	99	OPT
9369	106	43953	99	OPT
9370	106	46746	99	OPT
9371	106	45780	99	OPT
9372	106	45787	99	OPT
9373	106	45769	99	OPT
9374	106	45782	99	OPT
9375	106	49464	99	OPT
9376	106	45747	99	OPT
9377	106	49461	99	OPT
9378	106	49462	99	OPT
9379	106	49463	99	OPT
9380	106	45767	99	OPT
9381	106	41311	99	OPT
9382	106	45765	99	OPT
9383	107	41095	1	OBR
9384	107	41103	1	OBR
9385	107	45795	1	OBR
9386	107	41097	1	OBR
9387	107	47547	1	OBR
9388	107	43049	1	OBR
9389	107	45929	1	OBR
9390	107	45928	1	OBR
9391	107	41143	1	OBR
9392	107	45753	2	OBR
9393	107	45919	2	OBR
9394	107	41094	2	OBR
9395	107	43047	2	OBR
9396	107	42981	2	OBR
9397	107	45924	2	OBR
9398	107	45920	2	OBR
9399	107	45926	2	OBR
9400	107	41108	2	OBR
9401	107	41115	2	OBR
9402	107	41109	3	OBR
9403	107	41145	3	OBR
9404	107	41111	3	OBR
9405	107	41146	3	OBR
9406	107	41102	3	OBR
9407	107	41147	3	OBR
9408	107	45911	3	OBR
9409	107	41114	3	OBR
9410	107	41148	4	OBR
9411	107	41113	4	OBR
9412	107	41421	4	OBR
9413	107	45921	4	OBR
9414	107	47555	4	OBR
9415	107	41119	4	OBR
9416	107	45922	4	OBR
9417	107	43046	4	OBR
9418	107	45914	4	OBR
9419	107	43044	5	OBR
9420	107	45927	5	OBR
9421	107	41150	5	OBR
9422	107	45915	5	OBR
9423	107	45912	5	OBR
9424	107	45908	5	OBR
9425	107	45923	5	OBR
9426	107	47556	6	OBR
9427	107	41122	6	OBR
9428	107	45917	6	OBR
9429	107	45918	6	OBR
9430	107	41159	6	OBR
9431	107	43045	6	OBR
9432	107	41154	6	OBR
9433	107	45925	6	OBR
9434	107	45904	7	OBR
9435	107	45916	7	OBR
9436	107	45903	8	OBR
9437	107	45931	8	OBR
9438	107	41125	99	OPT
9439	107	43059	99	OPT
9440	107	45906	99	OPT
9441	107	45902	99	OPT
9442	107	43055	99	OPT
9443	107	41138	99	OPT
9444	107	42980	99	OPT
9445	107	41663	99	OPT
9446	107	43056	99	OPT
9447	107	43057	99	OPT
9448	107	43053	99	OPT
9449	107	45761	99	OPT
9450	107	45910	99	OPT
9451	107	41117	99	OPT
9452	107	43051	99	OPT
9453	107	41135	99	OPT
9454	107	41136	99	OPT
9455	107	41167	99	OPT
9456	107	47551	99	OPT
9457	107	41123	99	OPT
9458	107	41129	99	OPT
9459	107	45905	99	OPT
9460	107	41168	99	OPT
9461	107	42978	99	OPT
9462	107	41169	99	OPT
9463	107	41131	99	OPT
9464	107	42979	99	OPT
9465	107	42968	99	OPT
9466	107	42969	99	OPT
9467	107	42972	99	OPT
9468	107	42973	99	OPT
9469	107	45909	99	OPT
9470	107	41170	99	OPT
9471	107	45930	99	OPT
9472	107	41139	99	OPT
9473	107	41140	99	OPT
9474	107	41141	99	OPT
9475	107	41142	99	OPT
9476	107	42976	99	OPT
9477	107	41099	99	OPT
9478	107	41100	99	OPT
9479	107	46746	99	OPT
9480	107	42977	99	OPT
9481	107	47554	99	OPT
9482	107	45932	99	OPT
9483	107	47553	99	OPT
9484	107	47549	99	OPT
9485	107	47552	99	OPT
9486	107	47550	99	OPT
9487	108	50382	1	OBR
9488	108	48331	1	OBR
9489	108	45198	1	OBR
9490	108	37193	1	OBR
9491	108	45245	1	OBR
9492	108	50352	1	OBR
9493	108	50363	1	OBR
9494	108	48016	2	OBR
9495	108	48809	2	OBR
9496	108	50354	2	OBR
9497	108	46735	2	OBR
9498	108	50353	2	OBR
9499	108	48041	2	OBR
9500	108	48008	2	OBR
9501	108	50398	3	OBR
9502	108	45219	3	OBR
9503	108	48017	3	OBR
9504	108	48034	3	OBR
9505	108	46730	3	OBR
9506	108	50373	3	OBR
9507	108	48791	4	OBR
9508	108	50357	4	OBR
9509	108	50379	4	OBR
9510	108	48318	4	OBR
9511	108	46723	4	OBR
9512	108	48798	4	OBR
9513	108	50369	4	OBR
9514	108	46751	5	OBR
9515	108	45236	5	OBR
9516	108	49460	5	OBR
9517	108	48723	5	OBR
9518	108	50386	5	OBR
9519	108	48009	5	OBR
9520	108	46747	5	OBR
9521	108	45244	6	OBR
9522	108	50359	6	OBR
9523	108	50362	6	OBR
9524	108	50358	6	OBR
9525	108	50372	6	OBR
9526	108	45194	6	OBR
9527	108	50355	6	OBR
9528	108	45251	7	OBR
9529	108	46725	7	OBR
9530	108	50387	7	OBR
9531	108	42904	7	OBR
9532	108	46738	7	OBR
9533	108	50367	7	OBR
9534	108	50389	8	OBR
9535	108	50364	8	OBR
9536	108	50397	8	OBR
9537	108	50393	8	OBR
9538	108	50360	8	OBR
9539	108	46733	8	OBR
9540	108	50370	8	OBR
9541	108	50385	9	OBR
9542	108	45214	9	OBR
9543	108	45220	9	OBR
9544	108	50391	9	OBR
9545	108	46734	9	OBR
9546	108	50371	9	OBR
9547	108	46742	10	OBR
9548	108	45197	99	OPT
9549	108	45242	99	OPT
9550	108	45202	99	OPT
9551	108	45246	99	OPT
9552	108	50388	99	OPT
9553	108	45256	99	OPT
9554	108	45206	99	OPT
9555	108	45258	99	OPT
9556	108	45261	99	OPT
9557	108	46722	99	OPT
9558	108	44548	99	OPT
9559	108	45207	99	OPT
9560	108	50378	99	OPT
9561	108	50380	99	OPT
9562	108	50399	99	OPT
9563	108	50366	99	OPT
9564	108	37153	99	OPT
9565	108	50356	99	OPT
9566	108	44651	99	OPT
9567	108	46497	99	OPT
9568	108	46741	99	OPT
9569	108	50361	99	OPT
9570	108	45217	99	OPT
9571	108	31636	99	OPT
9572	108	46732	99	OPT
9573	108	45211	99	OPT
9574	108	45225	99	OPT
9575	108	45218	99	OPT
9576	108	50377	99	OPT
9577	108	50368	99	OPT
9578	108	45200	99	OPT
9579	108	34325	99	OPT
9580	108	45223	99	OPT
9581	108	43953	99	OPT
9582	108	43952	99	OPT
9583	108	45201	99	OPT
9584	108	50394	99	OPT
9585	108	45208	99	OPT
9586	108	45228	99	OPT
9587	108	46740	99	OPT
9588	108	50395	99	OPT
9589	108	50375	99	OPT
9590	108	50381	99	OPT
9591	108	50390	99	OPT
9592	108	45259	99	OPT
9593	108	50392	99	OPT
9594	108	50376	99	OPT
9595	108	50383	99	OPT
9596	108	50396	99	OPT
9597	108	50365	99	OPT
9598	108	50374	99	OPT
9599	108	50384	99	OPT
9600	108	45226	99	OPT
9601	109	41499	1	OBR
9602	109	41500	1	OBR
9603	109	41177	1	OBR
9604	109	37772	1	OBR
9605	109	41501	1	OBR
9606	109	41502	1	OBR
9607	109	50156	1	OBR
9608	109	41503	2	OBR
9609	109	41504	2	OBR
9610	109	41387	2	OBR
9611	109	49801	2	OBR
9612	109	41505	2	OBR
9613	109	37786	2	OBR
9614	109	50837	2	OBR
9615	109	50829	2	OBR
9616	109	41506	3	OBR
9617	109	41445	3	OBR
9618	109	41507	3	OBR
9619	109	41508	3	OBR
9620	109	41182	3	OBR
9621	109	41509	3	OBR
9622	109	48739	3	OBR
9623	109	41187	4	OBR
9624	109	41510	4	OBR
9625	109	41511	4	OBR
9626	109	41512	4	OBR
9627	109	41513	4	OBR
9628	109	41514	4	OBR
9629	109	41515	4	OBR
9630	109	41516	5	OBR
9631	109	41517	5	OBR
9632	109	41519	5	OBR
9633	109	50783	5	OBR
9634	109	50818	5	OBR
9635	109	41520	5	OBR
9636	109	41521	6	OBR
9637	109	41522	6	OBR
9638	109	41523	6	OBR
9639	109	41205	6	OBR
9640	109	41524	6	OBR
9641	109	41232	6	OBR
9642	109	41525	6	OBR
9643	109	41526	7	OBR
9644	109	50761	7	OBR
9645	109	41527	7	OBR
9646	109	41528	7	OBR
9647	109	41529	7	OBR
9648	109	49821	7	OBR
9649	109	50859	7	OBR
9650	109	41531	7	OBR
9651	109	50808	8	OBR
9652	109	41446	99	OPT
9653	109	50851	99	OPT
9654	109	41175	99	OPT
9655	109	50802	99	OPT
9656	109	50844	99	OPT
9657	109	50817	99	OPT
9658	109	50845	99	OPT
9659	109	50819	99	OPT
9660	109	50834	99	OPT
9661	109	41447	99	OPT
9662	109	41448	99	OPT
9663	109	50841	99	OPT
9664	109	50840	99	OPT
9665	109	50820	99	OPT
9666	109	50830	99	OPT
9667	109	41449	99	OPT
9668	109	50821	99	OPT
9669	109	50843	99	OPT
9670	109	41450	99	OPT
9671	109	50839	99	OPT
9672	109	41451	99	OPT
9673	109	50842	99	OPT
9674	109	50846	99	OPT
9675	109	50822	99	OPT
9676	109	50815	99	OPT
9677	109	50823	99	OPT
9678	109	47205	99	OPT
9679	109	50853	99	OPT
9680	109	50824	99	OPT
9681	109	41456	99	OPT
9682	109	50854	99	OPT
9683	109	50847	99	OPT
9684	109	50825	99	OPT
9685	109	41457	99	OPT
9686	109	48729	99	OPT
9687	109	41760	99	OPT
9688	109	43686	99	OPT
9689	109	50836	99	OPT
9690	109	50833	99	OPT
9691	109	50816	99	OPT
9692	109	41459	99	OPT
9693	109	50832	99	OPT
9694	109	41460	99	OPT
9695	109	41461	99	OPT
9696	109	41462	99	OPT
9697	109	41756	99	OPT
9698	109	50806	99	OPT
9699	109	50849	99	OPT
9700	109	50807	99	OPT
9701	109	41463	99	OPT
9702	109	41464	99	OPT
9703	109	41465	99	OPT
9704	109	50784	99	OPT
9705	109	50794	99	OPT
9706	109	50826	99	OPT
9707	109	41467	99	OPT
9708	109	50827	99	OPT
9709	109	41470	99	OPT
9710	109	41469	99	OPT
9711	109	41471	99	OPT
9712	109	41472	99	OPT
9713	109	50858	99	OPT
9714	109	41473	99	OPT
9715	109	50835	99	OPT
9716	109	50852	99	OPT
9717	109	50850	99	OPT
9718	109	41474	99	OPT
9719	109	41475	99	OPT
9720	109	50855	99	OPT
9721	109	41476	99	OPT
9722	109	41478	99	OPT
9723	109	41479	99	OPT
9724	109	41480	99	OPT
9725	109	41482	99	OPT
9726	109	50799	99	OPT
9727	109	41483	99	OPT
9728	109	41535	99	OPT
9729	109	41484	99	OPT
9730	109	41485	99	OPT
9731	109	41486	99	OPT
9732	109	50812	99	OPT
9733	109	50856	99	OPT
9734	109	50804	99	OPT
9735	109	50810	99	OPT
9736	109	50800	99	OPT
9737	109	50857	99	OPT
9738	109	50805	99	OPT
9739	109	41207	99	OPT
9740	109	41487	99	OPT
9741	109	36427	99	OPT
9742	109	41488	99	OPT
9743	109	41489	99	OPT
9744	109	50811	99	OPT
9745	109	50861	99	OPT
9746	109	41490	99	OPT
9747	109	41491	99	OPT
9748	109	50809	99	OPT
9749	109	41492	99	OPT
9750	109	50813	99	OPT
9751	109	50831	99	OPT
9752	109	50814	99	OPT
9753	109	50828	99	OPT
9754	109	41493	99	OPT
9755	109	41494	99	OPT
9756	109	41495	99	OPT
9757	109	41496	99	OPT
9758	109	41497	99	OPT
9759	109	41498	99	OPT
9760	109	50838	99	OPT
9761	109	50848	99	OPT
9762	109	50860	99	OPT
9763	109	50803	99	OPT
9764	109	50801	99	OPT
9765	109	50798	99	OPT
9766	109	50797	99	OPT
9767	110	41175	1	OBR
9768	110	48726	1	OBR
9769	110	50768	1	OBR
9770	110	41177	1	OBR
9771	110	50795	1	OBR
9772	110	50762	1	OBR
9773	110	50776	1	OBR
9774	110	41759	1	OBR
9775	110	50765	2	OBR
9776	110	41506	2	OBR
9777	110	50763	2	OBR
9778	110	41178	2	OBR
9779	110	41173	2	OBR
9780	110	50778	2	OBR
9781	110	50766	2	OBR
9782	110	41758	2	OBR
9783	110	50796	3	OBR
9784	110	50770	3	OBR
9785	110	41761	3	OBR
9786	110	50781	3	OBR
9787	110	50782	3	OBR
9788	110	50793	3	OBR
9789	110	50769	3	OBR
9790	110	50787	3	OBR
9791	110	50785	4	OBR
9792	110	50764	4	OBR
9793	110	41755	4	OBR
9794	110	44530	4	OBR
9795	110	37772	4	OBR
9796	110	50779	4	OBR
9797	110	50757	4	OBR
9798	110	41445	5	OBR
9799	110	50773	5	OBR
9800	110	50780	5	OBR
9801	110	37786	5	OBR
9802	110	50767	5	OBR
9803	110	50758	5	OBR
9804	110	50791	6	OBR
9805	110	50759	6	OBR
9806	110	50774	6	OBR
9807	110	50783	6	OBR
9808	110	50788	6	OBR
9809	110	41193	6	OBR
9810	110	50760	7	OBR
9811	110	44517	7	OBR
9812	110	50771	7	OBR
9813	110	41756	7	OBR
9814	110	50792	7	OBR
9815	110	50786	7	OBR
9816	110	50761	8	OBR
9817	110	50789	8	OBR
9818	110	50775	8	OBR
9819	110	50790	8	OBR
9820	110	48729	8	OBR
9821	110	50772	8	OBR
9822	110	41207	8	OBR
9823	110	44518	99	OPT
9824	110	44521	99	OPT
9825	110	41218	99	OPT
9826	110	41219	99	OPT
9827	110	41220	99	OPT
9828	110	44532	99	OPT
9829	110	47205	99	OPT
9830	110	44527	99	OPT
9831	110	44519	99	OPT
9832	110	43181	99	OPT
9833	110	44528	99	OPT
9834	110	43686	99	OPT
9835	110	41221	99	OPT
9836	110	44522	99	OPT
9837	110	41222	99	OPT
9838	110	50784	99	OPT
9839	110	50794	99	OPT
9840	110	44520	99	OPT
9841	110	41223	99	OPT
9842	110	41224	99	OPT
9843	110	41225	99	OPT
9844	110	47202	99	OPT
9845	110	44526	99	OPT
9846	110	47203	99	OPT
9847	110	44531	99	OPT
9848	110	44523	99	OPT
9849	110	44524	99	OPT
9850	110	47204	99	OPT
9851	110	41226	99	OPT
9852	110	44536	99	OPT
9853	110	44538	99	OPT
9854	110	44525	99	OPT
9855	110	44534	99	OPT
9856	110	50777	99	OPT
9857	110	44537	99	OPT
9858	110	47200	99	OPT
9859	110	47201	99	OPT
9860	111	41095	1	OBR
9861	111	48189	1	OBR
9862	111	48204	1	OBR
9863	111	48191	1	OBR
9864	111	48190	1	OBR
9865	111	48196	1	OBR
9866	111	52104	1	OBR
9867	111	48193	1	OBR
9868	111	45515	2	OBR
9869	111	48198	2	OBR
9870	111	45489	2	OBR
9871	111	48194	2	OBR
9872	111	48203	2	OBR
9873	111	48201	2	OBR
9874	111	48195	2	OBR
9875	111	45514	2	OBR
9876	111	45522	3	OBR
9877	111	41392	3	OBR
9878	111	48202	3	OBR
9879	111	48205	3	OBR
9880	111	48199	3	OBR
9881	111	48200	3	OBR
9882	111	45520	3	OBR
9883	111	48192	4	OBR
9884	111	48208	4	OBR
9885	111	48207	4	OBR
9886	111	48206	4	OBR
9887	111	48197	4	OBR
9888	111	45504	4	OBR
9889	111	45505	5	OBR
9890	111	48209	5	OBR
9891	111	45508	5	OBR
9892	111	45509	6	OBR
9893	111	48183	6	OBR
9894	111	48184	6	OBR
9895	111	48188	6	OBR
9896	111	48187	7	OBR
9897	111	48180	7	OBR
9898	111	48178	7	OBR
9899	111	48179	7	OBR
9900	111	45494	8	OBR
9901	111	48210	8	OBR
9902	111	48185	9	OBR
9903	111	48182	9	OBR
9904	111	48186	10	OBR
9905	111	41437	99	OPT
9906	111	45519	99	OPT
9907	111	24594	99	OPT
9908	111	24596	99	OPT
9909	111	41215	99	OPT
9910	111	41439	99	OPT
9911	111	41760	99	OPT
9912	111	41756	99	OPT
9913	111	45516	99	OPT
9914	111	41234	99	OPT
9915	111	52103	99	OPT
9916	111	42972	99	OPT
9917	111	44687	99	OPT
9918	111	45524	99	OPT
9919	111	48181	99	OPT
9920	111	45517	99	OPT
9921	112	41384	1	OBR
9922	112	41385	1	OBR
9923	112	41386	1	OBR
9924	112	41387	1	OBR
9925	112	41388	1	OBR
9926	112	41442	1	OBR
9927	112	48398	1	OBR
9928	112	41390	2	OBR
9929	112	41383	2	OBR
9930	112	48411	2	OBR
9931	112	41393	2	OBR
9932	112	41394	2	OBR
9933	112	41395	2	OBR
9934	112	41396	2	OBR
9935	112	48413	2	OBR
9936	112	48401	3	OBR
9937	112	41399	3	OBR
9938	112	48410	3	OBR
9939	112	48402	3	OBR
9940	112	41402	3	OBR
9941	112	41228	3	OBR
9942	112	48399	3	OBR
9943	112	41404	4	OBR
9944	112	41405	4	OBR
9945	112	44022	4	OBR
9946	112	41407	4	OBR
9947	112	41408	4	OBR
9948	112	41409	4	OBR
9949	112	48400	4	OBR
9950	112	48406	5	OBR
9951	112	41412	5	OBR
9952	112	41413	5	OBR
9953	112	41414	5	OBR
9954	112	48404	5	OBR
9955	112	48405	6	OBR
9956	112	48403	6	OBR
9957	112	41417	6	OBR
9958	112	41418	6	OBR
9959	112	48407	6	OBR
9960	112	48396	6	OBR
9961	112	41421	7	OBR
9962	112	44029	7	OBR
9963	112	41436	7	OBR
9964	112	41423	7	OBR
9965	112	48397	7	OBR
9966	112	44024	7	OBR
9967	112	41426	8	OBR
9968	112	42992	8	OBR
9969	112	41427	8	OBR
9970	112	41428	8	OBR
9971	112	48408	8	OBR
9972	112	44027	8	OBR
9973	112	48412	9	OBR
9974	112	44021	9	OBR
9975	112	44023	10	OBR
9976	112	44019	10	OBR
9977	112	41437	99	OPT
9978	112	41438	99	OPT
9979	112	24594	99	OPT
9980	112	41439	99	OPT
9981	112	43181	99	OPT
9982	112	44018	99	OPT
9983	112	41756	99	OPT
9984	112	41440	99	OPT
9985	112	44028	99	OPT
9986	112	48409	99	OPT
9987	112	41441	99	OPT
9988	112	41443	99	OPT
9989	112	41444	99	OPT
9990	112	44026	99	OPT
9991	112	44020	99	OPT
9992	113	44089	1	OBR
9993	113	44078	1	OBR
9994	113	44084	1	OBR
9995	113	44075	1	OBR
9996	113	44124	1	OBR
9997	113	44104	1	OBR
9998	113	41816	1	OBR
9999	113	44116	2	OBR
10000	113	44121	2	OBR
10001	113	44076	2	OBR
10002	113	41761	2	OBR
10003	113	44125	2	OBR
10004	113	44085	2	OBR
10005	113	44073	2	OBR
10006	113	41797	3	OBR
10007	113	44079	3	OBR
10008	113	44090	3	OBR
10009	113	44091	3	OBR
10010	113	42733	3	OBR
10011	113	44131	3	OBR
10012	113	41803	3	OBR
10013	113	44113	4	OBR
10014	113	41804	4	OBR
10015	113	44074	4	OBR
10016	113	44141	4	OBR
10017	113	44138	4	OBR
10018	113	44092	4	OBR
10019	113	44107	4	OBR
10020	113	41757	4	OBR
10021	113	44102	5	OBR
10022	113	44136	5	OBR
10023	113	44118	5	OBR
10024	113	44094	5	OBR
10025	113	44109	5	OBR
10026	113	41758	5	OBR
10027	113	44143	5	OBR
10028	113	44120	6	OBR
10029	113	43181	6	OBR
10030	113	44142	6	OBR
10031	113	44139	6	OBR
10032	113	44119	6	OBR
10033	113	44132	6	OBR
10034	113	41755	7	OBR
10035	113	44140	7	OBR
10036	113	44115	7	OBR
10037	113	41759	7	OBR
10038	113	41756	8	OBR
10039	113	44144	8	OBR
10040	113	44123	99	OPT
10041	113	44096	99	OPT
10042	113	44082	99	OPT
10043	113	44098	99	OPT
10044	113	41810	99	OPT
10045	113	41822	99	OPT
10046	113	44129	99	OPT
10047	113	44103	99	OPT
10048	113	42524	99	OPT
10049	113	44117	99	OPT
10050	113	44080	99	OPT
10051	113	44086	99	OPT
10052	113	44106	99	OPT
10053	113	44110	99	OPT
10054	113	44130	99	OPT
10055	113	44081	99	OPT
10056	113	44133	99	OPT
10057	113	44137	99	OPT
10058	113	44097	99	OPT
10059	113	44099	99	OPT
10060	113	44093	99	OPT
10061	113	44122	99	OPT
10062	113	44126	99	OPT
10063	113	44087	99	OPT
10064	113	44010	99	OPT
10065	113	44134	99	OPT
10066	113	44135	99	OPT
10067	113	43989	99	OPT
10068	114	44082	1	OBR
10069	114	44089	1	OBR
10070	114	44078	1	OBR
10071	114	44075	1	OBR
10072	114	44124	1	OBR
10073	114	44104	1	OBR
10074	114	44073	1	OBR
10075	114	44111	2	OBR
10076	114	44121	2	OBR
10077	114	44098	2	OBR
10078	114	44076	2	OBR
10079	114	44084	2	OBR
10080	114	44125	2	OBR
10081	114	44085	2	OBR
10082	114	41797	3	OBR
10083	114	44083	3	OBR
10084	114	44079	3	OBR
10085	114	44090	3	OBR
10086	114	44091	3	OBR
10087	114	41803	3	OBR
10088	114	44113	4	OBR
10089	114	41804	4	OBR
10090	114	44074	4	OBR
10091	114	44129	4	OBR
10092	114	44092	4	OBR
10093	114	44107	4	OBR
10094	114	41757	4	OBR
10095	114	44105	5	OBR
10096	114	44102	5	OBR
10097	114	44118	5	OBR
10098	114	44094	5	OBR
10099	114	44109	5	OBR
10100	114	44120	6	OBR
10101	114	44114	6	OBR
10102	114	44119	6	OBR
10103	114	42524	6	OBR
10104	114	44127	7	OBR
10105	114	44128	8	OBR
10106	114	44123	99	OPT
10107	114	44096	99	OPT
10108	114	44116	99	OPT
10109	114	41810	99	OPT
10110	114	41822	99	OPT
10111	114	43181	99	OPT
10112	114	44103	99	OPT
10113	114	41756	99	OPT
10114	114	44117	99	OPT
10115	114	44100	99	OPT
10116	114	44077	99	OPT
10117	114	44080	99	OPT
10118	114	44086	99	OPT
10119	114	44106	99	OPT
10120	114	44110	99	OPT
10121	114	44130	99	OPT
10122	114	44081	99	OPT
10123	114	44088	99	OPT
10124	114	44112	99	OPT
10125	114	44097	99	OPT
10126	114	44099	99	OPT
10127	114	44093	99	OPT
10128	114	44122	99	OPT
10129	114	44126	99	OPT
10130	114	44087	99	OPT
10131	114	44101	99	OPT
10132	114	44115	99	OPT
10133	114	44095	99	OPT
10134	114	44108	99	OPT
10135	115	44384	1	OBR
10136	115	44428	1	OBR
10137	115	44429	1	OBR
10138	115	44427	1	OBR
10139	115	44398	1	OBR
10140	115	44381	1	OBR
10141	115	44396	1	OBR
10142	115	44372	1	OBR
10143	115	44425	2	OBR
10144	115	41761	2	OBR
10145	115	44431	2	OBR
10146	115	44352	2	OBR
10147	115	44343	2	OBR
10148	115	44377	2	OBR
10149	115	44424	3	OBR
10150	115	44367	3	OBR
10151	115	44379	3	OBR
10152	115	44393	3	OBR
10153	115	44370	3	OBR
10154	115	44434	3	OBR
10155	115	44416	3	OBR
10156	115	44426	4	OBR
10157	115	44350	4	OBR
10158	115	44411	4	OBR
10159	115	44394	4	OBR
10160	115	44436	4	OBR
10161	115	41758	4	OBR
10162	115	44412	5	OBR
10163	115	44420	5	OBR
10164	115	44407	5	OBR
10165	115	44347	5	OBR
10166	115	44357	5	OBR
10167	115	41759	5	OBR
10168	115	44408	6	OBR
10169	115	44355	6	OBR
10170	115	44400	6	OBR
10171	115	44354	6	OBR
10172	115	44374	6	OBR
10173	115	44382	6	OBR
10174	115	44432	6	OBR
10175	115	44435	7	OBR
10176	115	44376	7	OBR
10177	115	44423	7	OBR
10178	115	41756	7	OBR
10179	115	44344	7	OBR
10180	115	44348	7	OBR
10181	115	44406	8	OBR
10182	115	43181	8	OBR
10183	115	41755	8	OBR
10184	115	44378	8	OBR
10185	115	44414	8	OBR
10186	115	44401	8	OBR
10187	115	44422	99	OPT
10188	115	45699	99	OPT
10189	115	45729	99	OPT
10190	115	45617	99	OPT
10191	115	44438	99	OPT
10192	115	44380	99	OPT
10193	115	44385	99	OPT
10194	115	44375	99	OPT
10195	115	42763	99	OPT
10196	115	42764	99	OPT
10197	115	42765	99	OPT
10198	115	42766	99	OPT
10199	115	42767	99	OPT
10200	115	42768	99	OPT
10201	115	42769	99	OPT
10202	115	42770	99	OPT
10203	115	45641	99	OPT
10204	115	45723	99	OPT
10205	115	45724	99	OPT
10206	115	45642	99	OPT
10207	115	45606	99	OPT
10208	115	44421	99	OPT
10209	115	45658	99	OPT
10210	115	44365	99	OPT
10211	115	44361	99	OPT
10212	115	44356	99	OPT
10213	115	44359	99	OPT
10214	115	44366	99	OPT
10215	115	44433	99	OPT
10216	115	44388	99	OPT
10217	115	44383	99	OPT
10218	115	45643	99	OPT
10219	115	45607	99	OPT
10220	115	45608	99	OPT
10221	115	45609	99	OPT
10222	115	44413	99	OPT
10223	115	44402	99	OPT
10224	115	45587	99	OPT
10225	115	45725	99	OPT
10226	115	45714	99	OPT
10227	115	45735	99	OPT
10228	115	45625	99	OPT
10229	115	42972	99	OPT
10230	115	42973	99	OPT
10231	115	45652	99	OPT
10232	115	45653	99	OPT
10233	115	45619	99	OPT
10234	115	45601	99	OPT
10235	115	45647	99	OPT
10236	115	45662	99	OPT
10237	115	45596	99	OPT
10238	115	45595	99	OPT
10239	115	45598	99	OPT
10240	115	45597	99	OPT
10241	115	44346	99	OPT
10242	115	44415	99	OPT
10243	115	45624	99	OPT
10244	115	45620	99	OPT
10245	115	45646	99	OPT
10246	115	45621	99	OPT
10247	115	45622	99	OPT
10248	115	45623	99	OPT
10249	115	44371	99	OPT
10250	115	45639	99	OPT
10251	115	45657	99	OPT
10252	115	45659	99	OPT
10253	115	45736	99	OPT
10254	115	45665	99	OPT
10255	115	45612	99	OPT
10256	115	45668	99	OPT
10257	115	45670	99	OPT
10258	115	43184	99	OPT
10259	115	45717	99	OPT
10260	115	45718	99	OPT
10261	115	45719	99	OPT
10262	115	45613	99	OPT
10263	115	44360	99	OPT
10264	115	45691	99	OPT
10265	115	45726	99	OPT
10266	115	45694	99	OPT
10267	115	45740	99	OPT
10268	115	45610	99	OPT
10269	115	45721	99	OPT
10270	115	45722	99	OPT
10271	115	45667	99	OPT
10272	115	45715	99	OPT
10273	115	45716	99	OPT
10274	115	45627	99	OPT
10275	115	45611	99	OPT
10276	115	43183	99	OPT
10277	115	45651	99	OPT
10278	115	44419	99	OPT
10279	115	45648	99	OPT
10280	115	44392	99	OPT
10281	115	44358	99	OPT
10282	115	45628	99	OPT
10283	115	45626	99	OPT
10284	115	44369	99	OPT
10285	115	45631	99	OPT
10286	115	45678	99	OPT
10287	115	45679	99	OPT
10288	115	45618	99	OPT
10289	115	45708	99	OPT
10290	115	45711	99	OPT
10291	115	45712	99	OPT
10292	115	45731	99	OPT
10293	115	45732	99	OPT
10294	115	45734	99	OPT
10295	115	45713	99	OPT
10296	115	44345	99	OPT
10297	115	45634	99	OPT
10298	115	45637	99	OPT
10299	115	45654	99	OPT
10300	115	44395	99	OPT
10301	115	44364	99	OPT
10302	115	45728	99	OPT
10303	115	45655	99	OPT
10304	115	44437	99	OPT
10305	115	45703	99	OPT
10306	115	45644	99	OPT
10307	115	45701	99	OPT
10308	115	44391	99	OPT
10309	115	45605	99	OPT
10310	115	45638	99	OPT
10311	115	45640	99	OPT
10312	115	44390	99	OPT
10313	115	45661	99	OPT
10314	115	45666	99	OPT
10315	115	45602	99	OPT
10316	115	44368	99	OPT
10317	115	45645	99	OPT
10318	115	45669	99	OPT
10319	115	45593	99	OPT
10320	115	45709	99	OPT
10321	115	45733	99	OPT
10322	115	45590	99	OPT
10323	115	45663	99	OPT
10324	115	44389	99	OPT
10325	115	45671	99	OPT
10326	115	45672	99	OPT
10327	115	45720	99	OPT
10328	115	44373	99	OPT
10329	115	45673	99	OPT
10330	115	45674	99	OPT
10331	115	44418	99	OPT
10332	115	45737	99	OPT
10333	115	45675	99	OPT
10334	115	45660	99	OPT
10335	115	44410	99	OPT
10336	115	45588	99	OPT
10337	115	45706	99	OPT
10338	115	45707	99	OPT
10339	115	44351	99	OPT
10340	115	45676	99	OPT
10341	115	45592	99	OPT
10342	115	45677	99	OPT
10343	115	45615	99	OPT
10344	115	45656	99	OPT
10345	115	45630	99	OPT
10346	115	45600	99	OPT
10347	115	45636	99	OPT
10348	115	45635	99	OPT
10349	115	45633	99	OPT
10350	115	45632	99	OPT
10351	115	44362	99	OPT
10352	115	45589	99	OPT
10353	115	45680	99	OPT
10354	115	45681	99	OPT
10355	115	45682	99	OPT
10356	115	45738	99	OPT
10357	115	45683	99	OPT
10358	115	45594	99	OPT
10359	115	44363	99	OPT
10360	115	45685	99	OPT
10361	115	45686	99	OPT
10362	115	45599	99	OPT
10363	115	45698	99	OPT
10364	115	45700	99	OPT
10365	115	45710	99	OPT
10366	115	45705	99	OPT
10367	115	44417	99	OPT
10368	115	45687	99	OPT
10369	115	45688	99	OPT
10370	115	45690	99	OPT
10371	115	44430	99	OPT
10372	115	45616	99	OPT
10373	115	44397	99	OPT
10374	115	45692	99	OPT
10375	115	44386	99	OPT
10376	115	45695	99	OPT
10377	115	45649	99	OPT
10378	115	45741	99	OPT
10379	115	44399	99	OPT
10380	115	45696	99	OPT
10381	115	45697	99	OPT
10382	115	45629	99	OPT
10383	115	44387	99	OPT
10384	115	45730	99	OPT
10385	115	45727	99	OPT
10386	115	45650	99	OPT
10387	115	44409	99	OPT
10388	115	44349	99	OPT
10389	115	45704	99	OPT
10390	115	45684	99	OPT
10391	115	45614	99	OPT
10392	115	45664	99	OPT
10393	115	45591	99	OPT
10394	115	45603	99	OPT
10395	115	45604	99	OPT
10396	115	45689	99	OPT
10397	115	45702	99	OPT
10398	115	45693	99	OPT
10399	115	45739	99	OPT
10400	116	41851	1	OBR
10401	116	48983	1	OBR
10402	116	48986	1	OBR
10403	116	48988	1	OBR
10404	116	48989	1	OBR
10405	116	41859	2	OBR
10406	116	48998	2	OBR
10407	116	49000	2	OBR
10408	116	49001	2	OBR
10409	116	48990	2	OBR
10410	116	41842	2	OBR
10411	116	49006	3	OBR
10412	116	41843	3	OBR
10413	116	48992	3	OBR
10414	116	48974	3	OBR
10415	116	49002	3	OBR
10416	116	48976	4	OBR
10417	116	49007	4	OBR
10418	116	41845	4	OBR
10419	116	41833	4	OBR
10420	116	49003	4	OBR
10421	116	41871	5	OBR
10422	116	48984	5	OBR
10423	116	49004	5	OBR
10424	116	48985	5	OBR
10425	116	41844	5	OBR
10426	116	41872	6	OBR
10427	116	42071	6	OBR
10428	116	42096	6	OBR
10429	116	48991	6	OBR
10430	116	48993	6	OBR
10431	116	41846	7	OBR
10432	116	42101	7	OBR
10433	116	49005	7	OBR
10434	116	46847	7	OBR
10435	116	41882	8	OBR
10436	116	41880	8	OBR
10437	116	49008	99	OPT
10438	116	48999	99	OPT
10439	116	41834	99	OPT
10440	116	41886	99	OPT
10441	116	41885	99	OPT
10442	116	41760	99	OPT
10443	116	41887	99	OPT
10444	116	41756	99	OPT
10445	116	41889	99	OPT
10446	116	41901	99	OPT
10447	116	41890	99	OPT
10448	116	48977	99	OPT
10449	116	48995	99	OPT
10450	116	41847	99	OPT
10451	116	41848	99	OPT
10452	116	41835	99	OPT
10453	116	48981	99	OPT
10454	116	48975	99	OPT
10455	116	41891	99	OPT
10456	116	48994	99	OPT
10457	116	48997	99	OPT
10458	116	48996	99	OPT
10459	116	48982	99	OPT
10460	116	41849	99	OPT
10461	116	48980	99	OPT
10462	116	48979	99	OPT
10463	116	41893	99	OPT
10464	116	48978	99	OPT
10465	116	41895	99	OPT
10466	116	41836	99	OPT
10467	116	41897	99	OPT
10468	116	48987	99	OPT
10469	116	49009	99	OPT
10470	116	49011	99	OPT
10471	116	49010	99	OPT
10472	116	41898	99	OPT
10473	116	41838	99	OPT
10474	116	41839	99	OPT
10475	117	44722	1	OBR
10476	117	51042	1	OBR
10477	117	44684	1	OBR
10478	117	44727	1	OBR
10479	117	44661	1	OBR
10480	117	51038	1	OBR
10481	117	41759	1	OBR
10482	117	41755	2	OBR
10483	117	44706	2	OBR
10484	117	51041	2	OBR
10485	117	44660	2	OBR
10486	117	51054	2	OBR
10487	117	44689	2	OBR
10488	117	51033	2	OBR
10489	117	44695	3	OBR
10490	117	51046	3	OBR
10491	117	41761	3	OBR
10492	117	44717	3	OBR
10493	117	51056	3	OBR
10494	117	44676	3	OBR
10495	117	51043	3	OBR
10496	117	51037	3	OBR
10497	117	43181	4	OBR
10498	117	44700	4	OBR
10499	117	51049	4	OBR
10500	117	51057	4	OBR
10501	117	44713	4	OBR
10502	117	41758	4	OBR
10503	117	51035	4	OBR
10504	117	51039	4	OBR
10505	117	51060	5	OBR
10506	117	51034	5	OBR
10507	117	41756	5	OBR
10508	117	51045	5	OBR
10509	117	51058	5	OBR
10510	117	44721	5	OBR
10511	117	44662	5	OBR
10512	117	51055	5	OBR
10513	117	51031	5	OBR
10514	117	51032	6	OBR
10515	117	51036	6	OBR
10516	117	51048	6	OBR
10517	117	51059	6	OBR
10518	117	44698	6	OBR
10519	117	51052	6	OBR
10520	117	51044	6	OBR
10521	117	44664	6	OBR
10522	117	51061	7	OBR
10523	117	51040	7	OBR
10524	117	44668	7	OBR
10525	117	51909	7	OBR
10526	117	51062	7	OBR
10527	117	42123	7	OBR
10528	117	44703	7	OBR
10529	117	51047	7	OBR
10530	117	51051	7	OBR
10531	117	44663	7	OBR
10532	117	51029	8	OBR
10533	117	51030	8	OBR
10534	117	44673	8	OBR
10535	117	44702	8	OBR
10536	117	51910	8	OBR
10537	117	42124	8	OBR
10538	117	44694	8	OBR
10539	117	51053	8	OBR
10540	117	51050	8	OBR
10541	117	45809	99	OPT
10542	117	45801	99	OPT
10543	117	44701	99	OPT
10544	117	44690	99	OPT
10545	117	44691	99	OPT
10546	117	44704	99	OPT
10547	117	42168	99	OPT
10548	117	42169	99	OPT
10549	117	44728	99	OPT
10550	117	44682	99	OPT
10551	117	44730	99	OPT
10552	117	44687	99	OPT
10553	117	44729	99	OPT
10554	117	42970	99	OPT
10555	117	42971	99	OPT
10556	117	42157	99	OPT
10557	117	44677	99	OPT
10558	117	45800	99	OPT
10559	117	44678	99	OPT
10560	117	44709	99	OPT
10561	117	44712	99	OPT
10562	117	44716	99	OPT
10563	117	45808	99	OPT
10564	117	43184	99	OPT
10565	117	45810	99	OPT
10566	117	43183	99	OPT
10567	117	44718	99	OPT
10568	117	42194	99	OPT
10569	117	42195	99	OPT
10570	117	45802	99	OPT
10571	117	42173	99	OPT
10572	117	42174	99	OPT
10573	117	45804	99	OPT
10574	117	42197	99	OPT
10575	117	42198	99	OPT
10576	117	45806	99	OPT
10577	117	45805	99	OPT
10578	118	44722	1	OBR
10579	118	51042	1	OBR
10580	118	44684	1	OBR
10581	118	44727	1	OBR
10582	118	44746	1	OBR
10583	118	51097	1	OBR
10584	118	41759	1	OBR
10585	118	41755	2	OBR
10586	118	44752	2	OBR
10587	118	51041	2	OBR
10588	118	44660	2	OBR
10589	118	51098	2	OBR
10590	118	44689	2	OBR
10591	118	51033	2	OBR
10592	118	44745	3	OBR
10593	118	51046	3	OBR
10594	118	41761	3	OBR
10595	118	44717	3	OBR
10596	118	51099	3	OBR
10597	118	44676	3	OBR
10598	118	51043	3	OBR
10599	118	51037	3	OBR
10600	118	43181	4	OBR
10601	118	44751	4	OBR
10602	118	51049	4	OBR
10603	118	44713	4	OBR
10604	118	51100	4	OBR
10605	118	41758	4	OBR
10606	118	51035	4	OBR
10607	118	51039	4	OBR
10608	118	51103	5	OBR
10609	118	51034	5	OBR
10610	118	41756	5	OBR
10611	118	51045	5	OBR
10612	118	51101	5	OBR
10613	118	44742	5	OBR
10614	118	44662	5	OBR
10615	118	51055	5	OBR
10616	118	51031	5	OBR
10617	118	51104	6	OBR
10618	118	51036	6	OBR
10619	118	51048	6	OBR
10620	118	51102	6	OBR
10621	118	44743	6	OBR
10622	118	51052	6	OBR
10623	118	51044	6	OBR
10624	118	44664	6	OBR
10625	118	51105	7	OBR
10626	118	51040	7	OBR
10627	118	44668	7	OBR
10628	118	51964	7	OBR
10629	118	51062	7	OBR
10630	118	42123	7	OBR
10631	118	44734	7	OBR
10632	118	51047	7	OBR
10633	118	51051	7	OBR
10634	118	44663	7	OBR
10635	118	51106	8	OBR
10636	118	51030	8	OBR
10637	118	44673	8	OBR
10638	118	44702	8	OBR
10639	118	51965	8	OBR
10640	118	42124	8	OBR
10641	118	44741	8	OBR
10642	118	51053	8	OBR
10643	118	51050	8	OBR
10644	118	45819	99	OPT
10645	118	45811	99	OPT
10646	118	44748	99	OPT
10647	118	44728	99	OPT
10648	118	44682	99	OPT
10649	118	44730	99	OPT
10650	118	44744	99	OPT
10651	118	44687	99	OPT
10652	118	44729	99	OPT
10653	118	42211	99	OPT
10654	118	42207	99	OPT
10655	118	44750	99	OPT
10656	118	42157	99	OPT
10657	118	44677	99	OPT
10658	118	45815	99	OPT
10659	118	44678	99	OPT
10660	118	44709	99	OPT
10661	118	44712	99	OPT
10662	118	44716	99	OPT
10663	118	45821	99	OPT
10664	118	43184	99	OPT
10665	118	44755	99	OPT
10666	118	45812	99	OPT
10667	118	43183	99	OPT
10668	118	44718	99	OPT
10669	118	42194	99	OPT
10670	118	42195	99	OPT
10671	118	45818	99	OPT
10672	118	45820	99	OPT
10673	118	42197	99	OPT
10674	118	42198	99	OPT
10675	118	45813	99	OPT
10676	118	45814	99	OPT
10677	119	45181	1	OBR
10678	119	45182	1	OBR
10679	119	46838	1	OBR
10680	119	46841	1	OBR
10681	119	41841	1	OBR
10682	119	45175	2	OBR
10683	119	45179	2	OBR
10684	119	41854	2	OBR
10685	119	46847	2	OBR
10686	119	45185	2	OBR
10687	119	46856	3	OBR
10688	119	45176	3	OBR
10689	119	46842	3	OBR
10690	119	46840	3	OBR
10691	119	45174	3	OBR
10692	119	45180	4	OBR
10693	119	45177	4	OBR
10694	119	41871	4	OBR
10695	119	41843	4	OBR
10696	119	46850	4	OBR
10697	119	45191	5	OBR
10698	119	46857	5	OBR
10699	119	45170	5	OBR
10700	119	45188	5	OBR
10701	119	45172	5	OBR
10702	119	46851	6	OBR
10703	119	46848	6	OBR
10704	119	46839	6	OBR
10705	119	41833	6	OBR
10706	119	41850	6	OBR
10707	119	46843	7	OBR
10708	119	46852	7	OBR
10709	119	46853	7	OBR
10710	119	46846	8	OBR
10711	119	46844	8	OBR
10712	119	46845	8	OBR
10713	119	41797	99	OPT
10714	119	41804	99	OPT
10715	119	45822	99	OPT
10716	119	45825	99	OPT
10717	119	47867	99	OPT
10718	119	46854	99	OPT
10719	119	41884	99	OPT
10720	119	45826	99	OPT
10721	119	45186	99	OPT
10722	119	41887	99	OPT
10723	119	44118	99	OPT
10724	119	44119	99	OPT
10725	119	44548	99	OPT
10726	119	41889	99	OPT
10727	119	44668	99	OPT
10728	119	41901	99	OPT
10729	119	41890	99	OPT
10730	119	44660	99	OPT
10731	119	41851	99	OPT
10732	119	44393	99	OPT
10733	119	44394	99	OPT
10734	119	44407	99	OPT
10735	119	44352	99	OPT
10736	119	44723	99	OPT
10737	119	41894	99	OPT
10738	119	45189	99	OPT
10739	119	47865	99	OPT
10740	119	45823	99	OPT
10741	119	45824	99	OPT
10742	119	46855	99	OPT
10743	119	44396	99	OPT
10744	119	46849	99	OPT
10745	119	45178	99	OPT
10746	119	41897	99	OPT
10747	119	41844	99	OPT
10748	119	44718	99	OPT
10749	119	42976	99	OPT
10750	119	45190	99	OPT
10751	119	44108	99	OPT
10752	119	44664	99	OPT
10753	119	45831	99	OPT
10754	119	45700	99	OPT
10755	119	45710	99	OPT
10756	119	45705	99	OPT
10757	119	45689	99	OPT
10758	119	45702	99	OPT
10759	119	45693	99	OPT
10760	119	45169	99	OPT
10761	119	45193	99	OPT
10762	119	45827	99	OPT
10763	119	45828	99	OPT
10764	119	47869	99	OPT
10765	119	45829	99	OPT
10766	119	45830	99	OPT
10767	119	47866	99	OPT
10768	119	47868	99	OPT
10769	119	47870	99	OPT
10770	119	47871	99	OPT
10771	119	47872	99	OPT
10772	119	47873	99	OPT
10773	120	44722	1	OBR
10774	120	51042	1	OBR
10775	120	44684	1	OBR
10776	120	44727	1	OBR
10777	120	44661	1	OBR
10778	120	51038	1	OBR
10779	120	41759	1	OBR
10780	120	41755	2	OBR
10781	120	44706	2	OBR
10782	120	51041	2	OBR
10783	120	44660	2	OBR
10784	120	51054	2	OBR
10785	120	44689	2	OBR
10786	120	51033	2	OBR
10787	120	44695	3	OBR
10788	120	51046	3	OBR
10789	120	41761	3	OBR
10790	120	44717	3	OBR
10791	120	51056	3	OBR
10792	120	44676	3	OBR
10793	120	51043	3	OBR
10794	120	51037	3	OBR
10795	120	43181	4	OBR
10796	120	44700	4	OBR
10797	120	51049	4	OBR
10798	120	51057	4	OBR
10799	120	44713	4	OBR
10800	120	41758	4	OBR
10801	120	51035	4	OBR
10802	120	51039	4	OBR
10803	120	51060	5	OBR
10804	120	51034	5	OBR
10805	120	41756	5	OBR
10806	120	51045	5	OBR
10807	120	51058	5	OBR
10808	120	44721	5	OBR
10809	120	44662	5	OBR
10810	120	51055	5	OBR
10811	120	51031	5	OBR
10812	120	51032	6	OBR
10813	120	51036	6	OBR
10814	120	51048	6	OBR
10815	120	51059	6	OBR
10816	120	44698	6	OBR
10817	120	51052	6	OBR
10818	120	51044	6	OBR
10819	120	44664	6	OBR
10820	120	51061	7	OBR
10821	120	51040	7	OBR
10822	120	44668	7	OBR
10823	120	51909	7	OBR
10824	120	51062	7	OBR
10825	120	42123	7	OBR
10826	120	44703	7	OBR
10827	120	51047	7	OBR
10828	120	51051	7	OBR
10829	120	44663	7	OBR
10830	120	51029	8	OBR
10831	120	51030	8	OBR
10832	120	44673	8	OBR
10833	120	44702	8	OBR
10834	120	51910	8	OBR
10835	120	42124	8	OBR
10836	120	44694	8	OBR
10837	120	51053	8	OBR
10838	120	51050	8	OBR
10839	120	45809	99	OPT
10840	120	45801	99	OPT
10841	120	44701	99	OPT
10842	120	44690	99	OPT
10843	120	44691	99	OPT
10844	120	44704	99	OPT
10845	120	42168	99	OPT
10846	120	42169	99	OPT
10847	120	44728	99	OPT
10848	120	44682	99	OPT
10849	120	44730	99	OPT
10850	120	44687	99	OPT
10851	120	44729	99	OPT
10852	120	42970	99	OPT
10853	120	42971	99	OPT
10854	120	42157	99	OPT
10855	120	44677	99	OPT
10856	120	45800	99	OPT
10857	120	44678	99	OPT
10858	120	44709	99	OPT
10859	120	44712	99	OPT
10860	120	44716	99	OPT
10861	120	45808	99	OPT
10862	120	43184	99	OPT
10863	120	45810	99	OPT
10864	120	43183	99	OPT
10865	120	44718	99	OPT
10866	120	42194	99	OPT
10867	120	42195	99	OPT
10868	120	45802	99	OPT
10869	120	42173	99	OPT
10870	120	42174	99	OPT
10871	120	45804	99	OPT
10872	120	42197	99	OPT
10873	120	42198	99	OPT
10874	120	45806	99	OPT
10875	120	45805	99	OPT
10876	121	44722	1	OBR
10877	121	51042	1	OBR
10878	121	44684	1	OBR
10879	121	44727	1	OBR
10880	121	44746	1	OBR
10881	121	51097	1	OBR
10882	121	41759	1	OBR
10883	121	41755	2	OBR
10884	121	44752	2	OBR
10885	121	51041	2	OBR
10886	121	44660	2	OBR
10887	121	51098	2	OBR
10888	121	44689	2	OBR
10889	121	51033	2	OBR
10890	121	44745	3	OBR
10891	121	51046	3	OBR
10892	121	41761	3	OBR
10893	121	44717	3	OBR
10894	121	51099	3	OBR
10895	121	44676	3	OBR
10896	121	51043	3	OBR
10897	121	51037	3	OBR
10898	121	43181	4	OBR
10899	121	44751	4	OBR
10900	121	51049	4	OBR
10901	121	44713	4	OBR
10902	121	51100	4	OBR
10903	121	41758	4	OBR
10904	121	51035	4	OBR
10905	121	51039	4	OBR
10906	121	51103	5	OBR
10907	121	51034	5	OBR
10908	121	41756	5	OBR
10909	121	51045	5	OBR
10910	121	51101	5	OBR
10911	121	44742	5	OBR
10912	121	44662	5	OBR
10913	121	51055	5	OBR
10914	121	51031	5	OBR
10915	121	51104	6	OBR
10916	121	51036	6	OBR
10917	121	51048	6	OBR
10918	121	51102	6	OBR
10919	121	44743	6	OBR
10920	121	51052	6	OBR
10921	121	51044	6	OBR
10922	121	44664	6	OBR
10923	121	51105	7	OBR
10924	121	51040	7	OBR
10925	121	44668	7	OBR
10926	121	51964	7	OBR
10927	121	51062	7	OBR
10928	121	42123	7	OBR
10929	121	44734	7	OBR
10930	121	51047	7	OBR
10931	121	51051	7	OBR
10932	121	44663	7	OBR
10933	121	51106	8	OBR
10934	121	51030	8	OBR
10935	121	44673	8	OBR
10936	121	44702	8	OBR
10937	121	51965	8	OBR
10938	121	42124	8	OBR
10939	121	44741	8	OBR
10940	121	51053	8	OBR
10941	121	51050	8	OBR
10942	121	45819	99	OPT
10943	121	45811	99	OPT
10944	121	44748	99	OPT
10945	121	44728	99	OPT
10946	121	44682	99	OPT
10947	121	44730	99	OPT
10948	121	44744	99	OPT
10949	121	44687	99	OPT
10950	121	44729	99	OPT
10951	121	42211	99	OPT
10952	121	42207	99	OPT
10953	121	44750	99	OPT
10954	121	42157	99	OPT
10955	121	44677	99	OPT
10956	121	45815	99	OPT
10957	121	44678	99	OPT
10958	121	44709	99	OPT
10959	121	44712	99	OPT
10960	121	44716	99	OPT
10961	121	45821	99	OPT
10962	121	43184	99	OPT
10963	121	44755	99	OPT
10964	121	45812	99	OPT
10965	121	43183	99	OPT
10966	121	44718	99	OPT
10967	121	42194	99	OPT
10968	121	42195	99	OPT
10969	121	45818	99	OPT
10970	121	45820	99	OPT
10971	121	42197	99	OPT
10972	121	42198	99	OPT
10973	121	45813	99	OPT
10974	121	45814	99	OPT
10975	122	44598	1	OBR
10976	122	48831	1	OBR
10977	122	48824	1	OBR
10978	122	44583	1	OBR
10979	122	48838	1	OBR
10980	122	48833	2	OBR
10981	122	48829	2	OBR
10982	122	48827	2	OBR
10983	122	48825	2	OBR
10984	122	48839	2	OBR
10985	122	48836	3	OBR
10986	122	41761	3	OBR
10987	122	44600	3	OBR
10988	122	48835	3	OBR
10989	122	48826	3	OBR
10990	122	48832	4	OBR
10991	122	44562	4	OBR
10992	122	42370	4	OBR
10993	122	42365	4	OBR
10994	122	44611	4	OBR
10995	122	48846	4	OBR
10996	122	48830	5	OBR
10997	122	42330	5	OBR
10998	122	44587	5	OBR
10999	122	48840	5	OBR
11000	122	48847	5	OBR
11001	122	44595	5	OBR
11002	122	48845	6	OBR
11003	122	44593	6	OBR
11004	122	48841	6	OBR
11005	122	48837	6	OBR
11006	122	48842	6	OBR
11007	122	41758	6	OBR
11008	122	48834	7	OBR
11009	122	41756	7	OBR
11010	122	48843	7	OBR
11011	122	44575	7	OBR
11012	122	41759	7	OBR
11013	122	48828	7	OBR
11014	122	43181	8	OBR
11015	122	41755	8	OBR
11016	122	48844	8	OBR
11017	122	44603	99	OPT
11018	122	42325	99	OPT
11019	122	44602	99	OPT
11020	122	42327	99	OPT
11021	122	44601	99	OPT
11022	122	44612	99	OPT
11023	122	42329	99	OPT
11024	122	42332	99	OPT
11025	122	44586	99	OPT
11026	122	44614	99	OPT
11027	122	42337	99	OPT
11028	122	42339	99	OPT
11029	122	42341	99	OPT
11030	122	44534	99	OPT
11031	122	44563	99	OPT
11032	122	44613	99	OPT
11033	122	42344	99	OPT
11034	122	42345	99	OPT
11035	122	42346	99	OPT
11036	122	42347	99	OPT
11037	122	42348	99	OPT
11038	122	42349	99	OPT
11039	122	42350	99	OPT
11040	123	50400	1	OBR
11041	123	50482	1	OBR
11042	123	50466	1	OBR
11043	123	48601	1	OBR
11044	123	50474	1	OBR
11045	123	50467	1	OBR
11046	123	50408	2	OBR
11047	123	50413	2	OBR
11048	123	50404	2	OBR
11049	123	50402	2	OBR
11050	123	50412	2	OBR
11051	123	50442	2	OBR
11052	123	50437	3	OBR
11053	123	50471	3	OBR
11054	123	50405	3	OBR
11055	123	50468	3	OBR
11056	123	50449	3	OBR
11057	123	50440	3	OBR
11058	123	50470	4	OBR
11059	123	50403	4	OBR
11060	123	50406	4	OBR
11061	123	50438	4	OBR
11062	123	50409	4	OBR
11063	123	50478	4	OBR
11064	123	50420	5	OBR
11065	123	42594	5	OBR
11066	123	50411	5	OBR
11067	123	50423	5	OBR
11068	123	50447	5	OBR
11069	123	50448	5	OBR
11070	123	50472	6	OBR
11071	123	42605	6	OBR
11072	123	50428	6	OBR
11073	123	50419	6	OBR
11074	123	50414	6	OBR
11075	123	50443	6	OBR
11076	123	50450	7	OBR
11077	123	50435	7	OBR
11078	123	50469	7	OBR
11079	123	50441	7	OBR
11080	123	50434	7	OBR
11081	123	50422	8	OBR
11082	123	50475	8	OBR
11083	123	50476	8	OBR
11084	123	50418	8	OBR
11085	123	50417	8	OBR
11086	123	50407	9	OBR
11087	123	50459	99	OPT
11088	123	50458	99	OPT
11089	123	50457	99	OPT
11090	123	50455	99	OPT
11091	123	50415	99	NAP
11092	123	50416	99	NAP
11093	123	50446	99	NAP
11094	123	50479	99	NAP
11095	123	50480	99	NAP
11096	123	50465	99	NAP
11097	123	50421	99	NAP
11098	123	50429	99	NAP
11099	123	50481	99	OPT
11100	123	50460	99	OPT
11101	123	50453	99	OPT
11102	123	50432	99	OPT
11103	123	50456	99	OPT
11104	123	50444	99	OPT
11105	123	50410	99	OPT
11106	123	50401	99	OPT
11107	123	50477	99	OPT
11108	123	50454	99	OPT
11109	123	50436	99	OPT
11110	123	50463	99	OPT
11111	123	50424	99	OPT
11112	123	50462	99	OPT
11113	123	50464	99	OPT
11114	123	50425	99	OPT
11115	123	50426	99	OPT
11116	123	50452	99	OPT
11117	123	50427	99	OPT
11118	123	50473	99	OPT
11119	123	50461	99	OPT
11120	123	50431	99	OPT
11121	123	50430	99	OPT
11122	123	50433	99	OPT
11123	123	50439	99	OPT
11124	123	50451	99	OPT
11125	123	50445	99	OPT
11126	124	43848	1	OBR
11127	124	43847	1	OBR
11128	124	43909	1	OBR
11129	124	43894	1	OBR
11130	124	43845	1	OBR
11131	124	41761	2	OBR
11132	124	43878	2	OBR
11133	124	43923	2	OBR
11134	124	43892	2	OBR
11135	124	43851	2	OBR
11136	124	43877	3	OBR
11137	124	43856	3	OBR
11138	124	41759	3	OBR
11139	124	43870	3	OBR
11140	124	41758	3	OBR
11141	124	43882	4	OBR
11142	124	43865	4	OBR
11143	124	43869	4	OBR
11144	124	43891	4	OBR
11145	124	43889	4	OBR
11146	124	43862	5	OBR
11147	124	43896	5	OBR
11148	124	43863	5	OBR
11149	124	43876	5	OBR
11150	124	42883	5	OBR
11151	124	43864	6	OBR
11152	124	43937	6	OBR
11153	124	43938	6	OBR
11154	124	42888	6	OBR
11155	124	41755	7	OBR
11156	124	43879	7	OBR
11157	124	43867	7	OBR
11158	124	43895	8	OBR
11159	124	41756	8	OBR
11160	124	43947	99	OPT
11161	124	43888	99	OPT
11162	124	43841	99	OPT
11163	124	43900	99	OPT
11164	124	43843	99	OPT
11165	124	43181	99	OPT
11166	124	43920	99	OPT
11167	124	43921	99	OPT
11168	124	47199	99	OPT
11169	124	43860	99	OPT
11170	124	43844	99	OPT
11171	124	43903	99	OPT
11172	124	43839	99	OPT
11173	124	43852	99	OPT
11174	124	43922	99	OPT
11175	124	43880	99	OPT
11176	124	43854	99	OPT
11177	124	43929	99	OPT
11178	124	43904	99	OPT
11179	124	43905	99	OPT
11180	124	47198	99	OPT
11181	124	43866	99	OPT
11182	124	43875	99	OPT
11183	124	43868	99	OPT
11184	124	43908	99	OPT
11185	124	43850	99	OPT
11186	124	43918	99	OPT
11187	124	43846	99	OPT
11188	124	43914	99	OPT
11189	124	43853	99	OPT
11190	124	43906	99	OPT
11191	124	43886	99	OPT
11192	124	43907	99	OPT
11193	124	43859	99	OPT
11194	124	43911	99	OPT
11195	124	43939	99	OPT
11196	124	43940	99	OPT
11197	124	43945	99	OPT
11198	124	43946	99	OPT
11199	124	43926	99	OPT
11200	124	43890	99	OPT
11201	124	43950	99	OPT
11202	124	43919	99	OPT
11203	124	43899	99	OPT
11204	124	43901	99	OPT
11205	124	43902	99	OPT
11206	124	43925	99	OPT
11207	124	43951	99	OPT
11208	124	43910	99	OPT
11209	124	43930	99	OPT
11210	124	43838	99	OPT
11211	124	43932	99	OPT
11212	124	43912	99	OPT
11213	124	43915	99	OPT
11214	124	43949	99	OPT
11215	124	43873	99	OPT
11216	124	43897	99	OPT
11217	124	43927	99	OPT
11218	124	43872	99	OPT
11219	124	43840	99	OPT
11220	124	43924	99	OPT
11221	124	43931	99	OPT
11222	124	43933	99	OPT
11223	124	43871	99	OPT
11224	124	43916	99	OPT
11225	124	43917	99	OPT
11226	124	43842	99	OPT
11227	124	43857	99	OPT
11228	124	43934	99	OPT
11229	124	43935	99	OPT
11230	124	43936	99	OPT
11231	124	43874	99	OPT
11232	124	43884	99	OPT
11233	124	43881	99	OPT
11234	124	43883	99	OPT
11235	124	43948	99	OPT
11236	124	43898	99	OPT
11237	124	43887	99	OPT
11238	124	43928	99	OPT
11239	124	43885	99	OPT
11240	124	43941	99	OPT
11241	124	43942	99	OPT
11242	124	43943	99	OPT
11243	124	43944	99	OPT
11244	125	42624	1	OBR
11245	125	45562	1	OBR
11246	125	42626	1	OBR
11247	125	42627	1	OBR
11248	125	42628	1	OBR
11249	125	45568	2	OBR
11250	125	42629	2	OBR
11251	125	42631	2	OBR
11252	125	42632	2	OBR
11253	125	42641	2	OBR
11254	125	42634	3	OBR
11255	125	42633	3	OBR
11256	125	42635	3	OBR
11257	125	42636	3	OBR
11258	125	42638	4	OBR
11259	125	42639	4	OBR
11260	125	42640	4	OBR
11261	125	42642	4	OBR
11262	125	45566	5	OBR
11263	125	42637	5	OBR
11264	125	51966	5	OBR
11265	125	51967	6	OBR
11266	125	45573	6	OBR
11267	125	45541	7	OBR
11268	125	42649	7	OBR
11269	125	42644	8	OBR
11270	125	42646	8	OBR
11271	125	42655	99	OPT
11272	125	45548	99	OPT
11273	125	45555	99	OPT
11274	125	42656	99	OPT
11275	125	42657	99	OPT
11276	125	45542	99	OPT
11277	125	46972	99	OPT
11278	125	45563	99	OPT
11279	125	46974	99	OPT
11280	125	42658	99	OPT
11281	125	42659	99	OPT
11282	125	42660	99	OPT
11283	125	42661	99	OPT
11284	125	42662	99	OPT
11285	125	42664	99	OPT
11286	125	42665	99	OPT
11287	125	42666	99	OPT
11288	125	42667	99	OPT
11289	125	42622	99	OPT
11290	125	45557	99	OPT
11291	125	45564	99	OPT
11292	125	42668	99	OPT
11293	125	45565	99	OPT
11294	125	42300	99	OPT
11295	125	42669	99	OPT
11296	125	45567	99	OPT
11297	125	42670	99	OPT
11298	125	45569	99	OPT
11299	125	42671	99	OPT
11300	125	42672	99	OPT
11301	125	45559	99	OPT
11302	125	45558	99	OPT
11303	125	45570	99	OPT
11304	125	45556	99	OPT
11305	125	45571	99	OPT
11306	125	42673	99	OPT
11307	125	45572	99	OPT
11308	125	42674	99	OPT
11309	125	42675	99	OPT
11310	125	42676	99	OPT
11311	125	45560	99	OPT
11312	125	42678	99	OPT
11313	125	52285	99	OPT
11314	125	52286	99	OPT
11315	125	42680	99	OPT
11316	125	42679	99	OPT
11317	125	42681	99	OPT
11318	125	52287	99	OPT
11319	125	42682	99	OPT
11320	125	42683	99	OPT
11321	125	45561	99	OPT
11322	125	41850	99	OPT
11323	125	42684	99	OPT
11324	125	42685	99	OPT
11325	125	42686	99	OPT
11326	125	42687	99	OPT
11327	125	42688	99	OPT
11328	125	42689	99	OPT
11329	125	42690	99	OPT
11330	125	45574	99	OPT
11331	125	42691	99	OPT
11332	125	45534	99	OPT
11333	125	45535	99	OPT
11334	125	45536	99	OPT
11335	125	45537	99	OPT
11336	125	45538	99	OPT
11337	125	45539	99	OPT
11338	125	42693	99	OPT
11339	125	45540	99	OPT
11340	125	45543	99	OPT
11341	125	45544	99	OPT
11342	125	45545	99	OPT
11343	125	45547	99	OPT
11344	125	42694	99	OPT
11345	125	42696	99	OPT
11346	125	42695	99	OPT
11347	125	45549	99	OPT
11348	125	45550	99	OPT
11349	125	45551	99	OPT
11350	125	45554	99	OPT
11351	125	45552	99	OPT
11352	125	45553	99	OPT
11353	125	46973	99	OPT
11354	126	44598	1	OBR
11355	126	44564	1	OBR
11356	126	44600	1	OBR
11357	126	42365	1	OBR
11358	126	44560	1	OBR
11359	126	44588	1	OBR
11360	126	44574	2	OBR
11361	126	42330	2	OBR
11362	126	44587	2	OBR
11363	126	47208	2	OBR
11364	126	42363	2	OBR
11365	126	47207	3	OBR
11366	126	42370	3	OBR
11367	126	44599	3	OBR
11368	126	42368	3	OBR
11369	126	44595	3	OBR
11370	126	47221	4	OBR
11371	126	44593	4	OBR
11372	126	44607	4	OBR
11373	126	44575	4	OBR
11374	126	44576	4	OBR
11375	126	47220	5	OBR
11376	126	44596	5	OBR
11377	126	42337	5	OBR
11378	126	47214	5	OBR
11379	126	44606	5	OBR
11380	126	44585	6	OBR
11381	126	44611	6	OBR
11382	126	44603	99	OPT
11383	126	42325	99	OPT
11384	126	41756	99	OPT
11385	126	44602	99	OPT
11386	126	42327	99	OPT
11387	126	44614	99	OPT
11388	126	42339	99	OPT
11389	126	44615	99	OPT
11390	126	44563	99	OPT
11391	126	44613	99	OPT
11392	126	47213	99	OPT
11393	126	47222	99	OPT
11394	126	47223	99	OPT
11395	126	47227	99	OPT
11396	126	47206	99	OPT
11397	126	47209	99	OPT
11398	126	47224	99	OPT
11399	126	47225	99	OPT
11400	126	47226	99	OPT
11401	126	47219	99	OPT
11402	126	47229	99	OPT
11403	126	47228	99	OPT
11404	126	42344	99	OPT
11405	126	42345	99	OPT
11406	126	42346	99	OPT
11407	126	47215	99	OPT
11408	126	47236	99	OPT
11409	126	47237	99	OPT
11410	126	42347	99	OPT
11411	126	47238	99	OPT
11412	126	47239	99	OPT
11413	126	47240	99	OPT
11414	126	47233	99	OPT
11415	126	47234	99	OPT
11416	126	47235	99	OPT
11417	126	42348	99	OPT
11418	126	42349	99	OPT
11419	126	42350	99	OPT
11420	126	47216	99	OPT
11421	126	47231	99	OPT
11422	126	47232	99	OPT
11423	126	47217	99	OPT
11424	126	47230	99	OPT
11425	126	47218	99	OPT
11426	126	47211	99	OPT
11427	126	47210	99	OPT
11428	126	47212	99	OPT
11429	127	48442	1	OBR
11430	127	48443	1	OBR
11431	127	48466	1	OBR
11432	127	48414	1	OBR
11433	127	48450	1	OBR
11434	127	48448	2	OBR
11435	127	48451	2	OBR
11436	127	48452	2	OBR
11437	127	48444	2	OBR
11438	127	48454	2	OBR
11439	127	48438	3	OBR
11440	127	48453	3	OBR
11441	127	48455	3	OBR
11442	127	48421	3	OBR
11443	127	48445	3	OBR
11444	127	48439	4	OBR
11445	127	44244	4	OBR
11446	127	48436	4	OBR
11447	127	48437	4	OBR
11448	127	44238	4	OBR
11449	127	48428	5	OBR
11450	127	48446	5	OBR
11451	127	41691	5	OBR
11452	127	48458	5	OBR
11453	127	48447	5	OBR
11454	127	48422	5	OBR
11455	127	51815	6	OBR
11456	127	48459	6	OBR
11457	127	48456	6	OBR
11458	127	41680	6	OBR
11459	127	48423	6	OBR
11460	127	48457	7	OBR
11461	127	41665	7	OBR
11462	127	48460	7	OBR
11463	127	48435	7	OBR
11464	127	48424	7	OBR
11465	127	48461	8	OBR
11466	127	44260	8	OBR
11467	127	48441	8	OBR
11468	127	48434	8	OBR
11469	127	51816	99	NAP
11470	127	42293	99	OPT
11471	127	48425	99	OPT
11472	127	48426	99	OPT
11473	127	48427	99	OPT
11474	127	42303	99	OPT
11475	127	42302	99	OPT
11476	127	44234	99	OPT
11477	127	42316	99	OPT
11478	127	42312	99	OPT
11479	127	42292	99	OPT
11480	127	42294	99	OPT
11481	127	42304	99	OPT
11482	127	42308	99	OPT
11483	127	42295	99	OPT
11484	127	41686	99	NAP
11485	127	48467	99	OPT
11486	127	44266	99	OPT
11487	127	42317	99	OPT
11488	127	42313	99	OPT
11489	127	44237	99	OPT
11490	127	42309	99	OPT
11491	127	42310	99	OPT
11492	127	42318	99	OPT
11493	127	42305	99	OPT
11494	127	42311	99	OPT
11495	127	42306	99	OPT
11496	127	41719	99	NAP
11497	127	48432	99	NAP
11498	127	48462	99	OPT
11499	127	48463	99	OPT
11500	127	42297	99	OPT
11501	127	42298	99	OPT
11502	127	45381	99	OPT
11503	127	41684	99	NAP
11504	127	41661	99	NAP
11505	127	41713	99	NAP
11506	127	44233	99	OPT
11507	127	41666	99	OPT
11508	127	42307	99	OPT
11509	127	42291	99	OPT
11510	127	48416	99	OPT
11511	127	48433	99	OPT
11512	127	45380	99	OPT
11513	127	45382	99	OPT
11514	127	44267	99	OPT
11515	127	44250	99	OPT
11516	127	42321	99	OPT
11517	127	48440	99	OPT
11518	127	44268	99	OPT
11519	127	48417	99	OPT
11520	127	48429	99	NAP
11521	127	41718	99	NAP
11522	127	42287	99	OPT
11523	127	42288	99	OPT
11524	127	48464	99	OPT
11525	127	48465	99	OPT
11526	127	48431	99	NAP
11527	127	48420	99	NAP
11528	127	48419	99	NAP
11529	127	48418	99	NAP
11530	127	48415	99	NAP
11531	127	42322	99	OPT
11532	127	42323	99	OPT
11533	127	41688	99	NAP
11534	127	42290	99	OPT
11535	127	42320	99	OPT
11536	128	41571	1	OBR
11537	128	41991	1	OBR
11538	128	51261	1	OBR
11539	128	43167	1	OBR
11540	128	51264	1	OBR
11541	128	43541	1	OBR
11542	128	51242	2	OBR
11543	128	43165	2	OBR
11544	128	51243	2	OBR
11545	128	51262	2	OBR
11546	128	41761	2	OBR
11547	128	51274	2	OBR
11548	128	51268	2	OBR
11549	128	51245	3	OBR
11550	128	42002	3	OBR
11551	128	43157	3	OBR
11552	128	51244	3	OBR
11553	128	51269	3	OBR
11554	128	41759	3	OBR
11555	128	43536	4	OBR
11556	128	51376	4	OBR
11557	128	43155	4	OBR
11558	128	51266	4	OBR
11559	128	51256	4	OBR
11560	128	41758	4	OBR
11561	128	43163	5	OBR
11562	128	43181	5	OBR
11563	128	51372	5	OBR
11564	128	51380	5	OBR
11565	128	51263	5	OBR
11566	128	51267	5	OBR
11567	128	41755	6	OBR
11568	128	51377	6	OBR
11569	128	51373	6	OBR
11570	128	51378	6	OBR
11571	128	51259	6	OBR
11572	128	51270	6	OBR
11573	128	43540	7	OBR
11574	128	51381	7	OBR
11575	128	51374	7	OBR
11576	128	51379	7	OBR
11577	128	51265	7	OBR
11578	128	51280	7	OBR
11579	128	51375	8	OBR
11580	128	41756	8	OBR
11581	128	51281	8	OBR
11582	128	51248	8	OBR
11583	128	41964	99	OPT
11584	128	41965	99	OPT
11585	128	41966	99	OPT
11586	128	41967	99	OPT
11587	128	41968	99	OPT
11588	128	41969	99	OPT
11589	128	41970	99	OPT
11590	128	41971	99	OPT
11591	128	41972	99	OPT
11592	128	41973	99	OPT
11593	128	41974	99	OPT
11594	128	41975	99	OPT
11595	128	41976	99	OPT
11596	128	41978	99	OPT
11597	128	41979	99	OPT
11598	128	41982	99	OPT
11599	128	43537	99	OPT
11600	128	51273	99	OPT
11601	128	51252	99	OPT
11602	128	51260	99	OPT
11603	128	51275	99	OPT
11604	128	51276	99	OPT
11605	128	51277	99	OPT
11606	128	51278	99	OPT
11607	128	51279	99	OPT
11608	128	41981	99	OPT
11609	128	51257	99	OPT
11610	128	41984	99	OPT
11611	128	43543	99	OPT
11612	128	43150	99	OPT
11613	128	43158	99	OPT
11614	128	41713	99	OPT
11615	128	41681	99	OPT
11616	128	43145	99	OPT
11617	128	43156	99	OPT
11618	128	43184	99	OPT
11619	128	43183	99	OPT
11620	128	41988	99	OPT
11621	128	42040	99	OPT
11622	128	51246	99	OPT
11623	129	48442	1	OBR
11624	129	48443	1	OBR
11625	129	48466	1	OBR
11626	129	48414	1	OBR
11627	129	48450	1	OBR
11628	129	48448	2	OBR
11629	129	48451	2	OBR
11630	129	48452	2	OBR
11631	129	48444	2	OBR
11632	129	48454	2	OBR
11633	129	48438	3	OBR
11634	129	48453	3	OBR
11635	129	48455	3	OBR
11636	129	48421	3	OBR
11637	129	48445	3	OBR
11638	129	48439	4	OBR
11639	129	44244	4	OBR
11640	129	48436	4	OBR
11641	129	48437	4	OBR
11642	129	44238	4	OBR
11643	129	48428	5	OBR
11644	129	48446	5	OBR
11645	129	41691	5	OBR
11646	129	48458	5	OBR
11647	129	48447	5	OBR
11648	129	48422	5	OBR
11649	129	51815	6	OBR
11650	129	48459	6	OBR
11651	129	48456	6	OBR
11652	129	41680	6	OBR
11653	129	48423	6	OBR
11654	129	48457	7	OBR
11655	129	41665	7	OBR
11656	129	48460	7	OBR
11657	129	48435	7	OBR
11658	129	48424	7	OBR
11659	129	48461	8	OBR
11660	129	44260	8	OBR
11661	129	48441	8	OBR
11662	129	48434	8	OBR
11663	129	51816	99	NAP
11664	129	42293	99	OPT
11665	129	48425	99	OPT
11666	129	48426	99	OPT
11667	129	48427	99	OPT
11668	129	42303	99	OPT
11669	129	42302	99	OPT
11670	129	44234	99	OPT
11671	129	42316	99	OPT
11672	129	42312	99	OPT
11673	129	42292	99	OPT
11674	129	42294	99	OPT
11675	129	42304	99	OPT
11676	129	42308	99	OPT
11677	129	42295	99	OPT
11678	129	41686	99	NAP
11679	129	48467	99	OPT
11680	129	44266	99	OPT
11681	129	42317	99	OPT
11682	129	42313	99	OPT
11683	129	44237	99	OPT
11684	129	42309	99	OPT
11685	129	42310	99	OPT
11686	129	42318	99	OPT
11687	129	42305	99	OPT
11688	129	42311	99	OPT
11689	129	42306	99	OPT
11690	129	41719	99	NAP
11691	129	48432	99	NAP
11692	129	48462	99	OPT
11693	129	48463	99	OPT
11694	129	42297	99	OPT
11695	129	42298	99	OPT
11696	129	45381	99	OPT
11697	129	41684	99	NAP
11698	129	41661	99	NAP
11699	129	41713	99	NAP
11700	129	44233	99	OPT
11701	129	41666	99	OPT
11702	129	42307	99	OPT
11703	129	42291	99	OPT
11704	129	48416	99	OPT
11705	129	48433	99	OPT
11706	129	45380	99	OPT
11707	129	45382	99	OPT
11708	129	44267	99	OPT
11709	129	44250	99	OPT
11710	129	42321	99	OPT
11711	129	48440	99	OPT
11712	129	44268	99	OPT
11713	129	48417	99	OPT
11714	129	48429	99	NAP
11715	129	41718	99	NAP
11716	129	42287	99	OPT
11717	129	42288	99	OPT
11718	129	48464	99	OPT
11719	129	48465	99	OPT
11720	129	48431	99	NAP
11721	129	48420	99	NAP
11722	129	48419	99	NAP
11723	129	48418	99	NAP
11724	129	48415	99	NAP
11725	129	42322	99	OPT
11726	129	42323	99	OPT
11727	129	41688	99	NAP
11728	129	42290	99	OPT
11729	129	42320	99	OPT
11730	130	41571	1	OBR
11731	130	51242	1	OBR
11732	130	41991	1	OBR
11733	130	51261	1	OBR
11734	130	51264	1	OBR
11735	130	43177	1	OBR
11736	130	43165	2	OBR
11737	130	51243	2	OBR
11738	130	51257	2	OBR
11739	130	51274	2	OBR
11740	130	51268	2	OBR
11741	130	43156	2	OBR
11742	130	43142	2	OBR
11743	130	51245	3	OBR
11744	130	43178	3	OBR
11745	130	43157	3	OBR
11746	130	43158	3	OBR
11747	130	51262	3	OBR
11748	130	51244	3	OBR
11749	130	51269	3	OBR
11750	130	43155	4	OBR
11751	130	43154	4	OBR
11752	130	51263	4	OBR
11753	130	51266	4	OBR
11754	130	51259	4	OBR
11755	130	51270	4	OBR
11756	130	43163	5	OBR
11757	130	43144	5	OBR
11758	130	43150	5	OBR
11759	130	51253	5	OBR
11760	130	51265	5	OBR
11761	130	51267	5	OBR
11762	130	51246	5	OBR
11763	130	51247	6	OBR
11764	130	43143	6	OBR
11765	130	51249	6	OBR
11766	130	51258	6	OBR
11767	130	51256	6	OBR
11768	130	51255	6	OBR
11769	130	43170	6	OBR
11770	130	43166	7	OBR
11771	130	51250	7	OBR
11772	130	51280	7	OBR
11773	130	51254	7	OBR
11774	130	51248	7	OBR
11775	130	43171	7	OBR
11776	130	51251	8	OBR
11777	130	51271	8	OBR
11778	130	51281	8	OBR
11779	130	41964	99	OPT
11780	130	41965	99	OPT
11781	130	41966	99	OPT
11782	130	41967	99	OPT
11783	130	41968	99	OPT
11784	130	41969	99	OPT
11785	130	41970	99	OPT
11786	130	41971	99	OPT
11787	130	41972	99	OPT
11788	130	41973	99	OPT
11789	130	41974	99	OPT
11790	130	41975	99	OPT
11791	130	43172	99	OPT
11792	130	41979	99	OPT
11793	130	43181	99	OPT
11794	130	41755	99	OPT
11795	130	41982	99	OPT
11796	130	51273	99	OPT
11797	130	51252	99	OPT
11798	130	51260	99	OPT
11799	130	51275	99	OPT
11800	130	51276	99	OPT
11801	130	51277	99	OPT
11802	130	51278	99	OPT
11803	130	51279	99	OPT
11804	130	41981	99	OPT
11805	130	42018	99	OPT
11806	130	43147	99	OPT
11807	130	41984	99	OPT
11808	130	43148	99	OPT
11809	130	51272	99	OPT
11810	130	41756	99	OPT
11811	130	43145	99	OPT
11812	130	43167	99	OPT
11813	130	41988	99	OPT
11814	131	46970	1	OBR
11815	131	46971	1	OBR
11816	131	44776	1	OBR
11817	131	46949	1	OBR
11818	131	46950	1	OBR
11819	131	46966	1	NAP
11820	131	44772	1	OBR
11821	131	44805	1	OBR
11822	131	46956	2	OBR
11823	131	46960	2	OBR
11824	131	46953	2	OBR
11825	131	46968	2	NAP
11826	131	44785	2	OBR
11827	131	46964	2	OBR
11828	131	44818	2	OBR
11829	131	43181	3	OBR
11830	131	41756	3	OBR
11831	131	44820	3	NAP
11832	131	41761	3	OBR
11833	131	44796	3	NAP
11834	131	44781	3	OBR
11835	131	41759	3	OBR
11836	131	44816	4	OBR
11837	131	41755	4	OBR
11838	131	46948	4	NAP
11839	131	46942	4	NAP
11840	131	44779	4	NAP
11841	131	44787	4	NAP
11842	131	44783	4	NAP
11843	131	46937	4	OBR
11844	131	44766	5	OBR
11845	131	46943	5	OBR
11846	131	44797	5	NAP
11847	131	44811	5	NAP
11848	131	44808	5	NAP
11849	131	46967	5	NAP
11850	131	44792	5	OBR
11851	131	46951	5	NAP
11852	131	46965	6	OBR
11853	131	44804	6	OBR
11854	131	44810	6	NAP
11855	131	46945	6	OBR
11856	131	44788	6	NAP
11857	131	44765	6	NAP
11858	131	46939	6	OBR
11859	131	46936	6	NAP
11860	131	46952	7	OBR
11861	131	46940	7	NAP
11862	131	46946	7	OBR
11863	131	46944	7	NAP
11864	131	44803	7	NAP
11865	131	44778	7	NAP
11866	131	46934	7	NAP
11867	131	44782	7	NAP
11868	131	44763	7	NAP
11869	131	44761	7	NAP
11870	131	44762	8	NAP
11871	131	44802	8	NAP
11872	131	46947	8	OBR
11873	131	44815	8	NAP
11874	131	46938	8	NAP
11875	131	44771	8	NAP
11876	131	46958	8	NAP
11877	131	44790	99	OPT
11878	131	44793	99	OPT
11879	131	44757	99	OPT
11880	131	46941	99	OPT
11881	131	44809	99	OPT
11882	131	44777	99	OPT
11883	131	46962	99	OPT
11884	131	46957	99	OPT
11885	131	44819	99	OPT
11886	131	44824	99	OPT
11887	131	44774	99	OPT
11888	131	46963	99	OPT
11889	131	46954	99	OPT
11890	131	46955	99	OPT
11891	131	44760	99	OPT
11892	131	44794	99	OPT
11893	131	44812	99	OPT
11894	131	44758	99	OPT
11895	131	46969	99	OPT
11896	131	44795	99	OPT
11897	131	44825	99	OPT
11898	131	43184	99	OPT
11899	131	44807	99	OPT
11900	131	43183	99	OPT
11901	131	44798	99	OPT
11902	131	46935	99	OPT
11903	131	44799	99	OPT
11904	131	46961	99	OPT
11905	131	44800	99	OPT
11906	131	44791	99	OPT
11907	131	44759	99	OPT
11908	131	46959	99	OPT
11909	132	52221	1	OBR
11910	132	48442	1	OBR
11911	132	52244	1	OBR
11912	132	52240	1	OBR
11913	132	52241	1	OBR
11914	132	48466	1	OBR
11915	132	48448	2	OBR
11916	132	52236	2	OBR
11917	132	52234	2	OBR
11918	132	52242	2	OBR
11919	132	48445	2	OBR
11920	132	48414	2	OBR
11921	132	52248	3	OBR
11922	132	52258	3	OBR
11923	132	52256	3	OBR
11924	132	52245	3	OBR
11925	132	52260	3	OBR
11926	132	52247	3	OBR
11927	132	52227	4	OBR
11928	132	52223	4	OBR
11929	132	52253	4	OBR
11930	132	48447	4	OBR
11931	132	52254	4	OBR
11932	132	52224	4	OBR
11933	132	48446	5	OBR
11934	132	52226	5	OBR
11935	132	52255	5	OBR
11936	132	52251	5	OBR
11937	132	52252	5	OBR
11938	132	52229	5	OBR
11939	132	52235	6	OBR
11940	132	52261	6	OBR
11941	132	52239	6	OBR
11942	132	52231	6	OBR
11943	132	52232	6	OBR
11944	132	52238	6	OBR
11945	132	52262	7	OBR
11946	132	52257	7	OBR
11947	132	52263	7	OBR
11948	132	52225	7	OBR
11949	132	52228	7	OBR
11950	132	52264	8	OBR
11951	132	52233	8	OBR
11952	132	52249	8	OBR
11953	132	52250	8	OBR
11954	132	52243	8	OBR
11955	132	52222	8	OBR
11956	132	42302	99	OPT
11957	132	42295	99	OPT
11958	132	42317	99	OPT
11959	132	42311	99	OPT
11960	132	43686	99	OPT
11961	132	52246	99	OPT
11962	132	41661	99	OPT
11963	132	48440	99	OPT
11964	132	52230	99	OPT
11965	132	52237	99	OPT
11966	132	52259	99	OPT
11967	133	46201	1	OBR
11968	133	46220	1	OBR
11969	133	46219	1	OBR
11970	133	46217	1	OBR
11971	133	44805	1	OBR
11972	133	46202	1	OBR
11973	133	46204	1	OBR
11974	133	46187	2	OBR
11975	133	46215	2	OBR
11976	133	46190	2	OBR
11977	133	43988	2	OBR
11978	133	46193	2	OBR
11979	133	46211	2	OBR
11980	133	46194	2	OBR
11981	133	46207	3	OBR
11982	133	46203	3	OBR
11983	133	46208	3	OBR
11984	133	46188	3	OBR
11985	133	46210	3	OBR
11986	133	44001	3	OBR
11987	133	46198	3	OBR
11988	133	46189	4	OBR
11989	133	46206	4	OBR
11990	133	46195	4	OBR
11991	133	46209	4	OBR
11992	133	46213	4	OBR
11993	133	46191	4	OBR
11994	133	46221	4	OBR
11995	133	46216	5	OBR
11996	133	46212	5	OBR
11997	133	46214	5	OBR
11998	133	46196	5	OBR
11999	133	46205	5	OBR
12000	133	46199	5	OBR
12001	133	46192	5	OBR
12002	133	43181	6	OBR
12003	133	46218	6	OBR
12004	133	46200	6	OBR
12005	133	41735	99	OPT
12006	133	41739	99	OPT
12007	133	41681	99	OPT
12008	133	41667	99	OPT
12009	133	41748	99	OPT
12010	134	47596	1	OBR
12011	134	47597	1	OBR
12012	134	47579	1	OBR
12013	134	47587	1	OBR
12014	134	47578	1	OBR
12015	134	47595	2	OBR
12016	134	47599	2	OBR
12017	134	47609	2	OBR
12018	134	47580	2	OBR
12019	134	47601	2	OBR
12020	134	47607	2	OBR
12021	134	47614	3	OBR
12022	134	47617	3	OBR
12023	134	47582	3	OBR
12024	134	47588	3	OBR
12025	134	47581	3	OBR
12026	134	47640	3	OBR
12027	134	47605	4	OBR
12028	134	47608	4	OBR
12029	134	47618	4	OBR
12030	134	47619	4	OBR
12031	134	47643	4	OBR
12032	134	47628	4	OBR
12033	134	47630	5	OBR
12034	134	47616	5	OBR
12035	134	47583	5	OBR
12036	134	47615	5	OBR
12037	134	47623	5	OBR
12038	134	47606	5	OBR
12039	134	47626	6	OBR
12040	134	47629	6	OBR
12041	134	47642	6	OBR
12042	134	47627	6	OBR
12043	134	47634	6	OBR
12044	134	47586	6	OBR
12045	134	47635	7	OBR
12046	134	47621	7	OBR
12047	134	47638	7	OBR
12048	134	47625	7	OBR
12049	134	47584	7	OBR
12050	134	47610	7	OBR
12051	134	47641	7	OBR
12052	134	47620	8	OBR
12053	134	47631	8	OBR
12054	134	47624	8	OBR
12055	134	47585	8	OBR
12056	134	47637	8	OBR
12057	134	47622	8	OBR
12058	134	47565	99	OPT
12059	134	47639	99	OPT
12060	134	47632	99	OPT
12061	134	47633	99	OPT
12062	134	47636	99	OPT
12063	134	52075	99	OPT
12064	134	52076	99	OPT
12065	134	52074	99	OPT
12066	135	47582	1	OBR
12067	135	47579	1	OBR
12068	135	47580	1	OBR
12069	135	47587	1	OBR
12070	135	47578	1	OBR
12071	135	47595	2	OBR
12072	135	47596	2	OBR
12073	135	47599	2	OBR
12074	135	47609	2	OBR
12075	135	47601	2	OBR
12076	135	47607	2	OBR
12077	135	47568	3	OBR
12078	135	47588	3	OBR
12079	135	47590	3	OBR
12080	135	47581	3	OBR
12081	135	47606	3	OBR
12082	135	47561	3	OBR
12083	135	47559	3	OBR
12084	135	47594	4	OBR
12085	135	47583	4	OBR
12086	135	47571	4	OBR
12087	135	47592	4	OBR
12088	135	47610	4	OBR
12089	135	47569	4	OBR
12090	135	47558	4	OBR
12091	135	47597	5	OBR
12092	135	47593	5	OBR
12093	135	47602	5	OBR
12094	135	47563	5	OBR
12095	135	47560	5	OBR
12096	135	47591	5	OBR
12097	135	47576	5	OBR
12098	135	47612	6	OBR
12099	135	47564	6	OBR
12100	135	47567	6	OBR
12101	135	47566	6	OBR
12102	135	47562	6	OBR
12103	135	47600	6	OBR
12104	135	47565	7	OBR
12105	135	47598	7	OBR
12106	135	47572	7	OBR
12107	135	47573	7	OBR
12108	135	47584	7	OBR
12109	135	47586	7	OBR
12110	135	47589	7	OBR
12111	135	47575	8	OBR
12112	135	51241	8	OBR
12113	135	47570	8	OBR
12114	135	47574	8	OBR
12115	135	47585	8	OBR
12116	135	47577	8	OBR
12117	135	47557	8	OBR
12118	135	47605	99	OPT
12119	135	47608	99	OPT
12120	135	47611	99	OPT
12121	135	47604	99	OPT
12122	135	47613	99	OPT
12123	136	47596	1	OBR
12124	136	47597	1	OBR
12125	136	47579	1	OBR
12126	136	47587	1	OBR
12127	136	47578	1	OBR
12128	136	47595	2	OBR
12129	136	47599	2	OBR
12130	136	47609	2	OBR
12131	136	47580	2	OBR
12132	136	47601	2	OBR
12133	136	47607	2	OBR
12134	136	47582	3	OBR
12135	136	47588	3	OBR
12136	136	47660	3	OBR
12137	136	47581	3	OBR
12138	136	47606	3	OBR
12139	136	47665	3	OBR
12140	136	47648	3	OBR
12141	136	47669	4	OBR
12142	136	47644	4	OBR
12143	136	47659	4	OBR
12144	136	47650	4	OBR
12145	136	47610	4	OBR
12146	136	47647	4	OBR
12147	136	47652	4	OBR
12148	136	47668	5	OBR
12149	136	47583	5	OBR
12150	136	47645	5	OBR
12151	136	47653	5	OBR
12152	136	47667	5	OBR
12153	136	47666	5	OBR
12154	136	47646	6	OBR
12155	136	47670	6	OBR
12156	136	47654	6	OBR
12157	136	47649	6	OBR
12158	136	51371	6	OBR
12159	136	47662	6	OBR
12160	136	47671	7	OBR
12161	136	47657	7	OBR
12162	136	47661	7	OBR
12163	136	47584	7	OBR
12164	136	47586	7	OBR
12165	136	47664	7	OBR
12166	136	47656	8	OBR
12167	136	47655	8	OBR
12168	136	51370	8	OBR
12169	136	47585	8	OBR
12170	136	47663	8	OBR
12171	136	47658	8	OBR
12172	136	47605	99	OPT
12173	136	47608	99	OPT
12174	136	47611	99	OPT
12175	136	47673	99	OPT
12176	136	47672	99	OPT
12177	137	47596	1	OBR
12178	137	47597	1	OBR
12179	137	47579	1	OBR
12180	137	47587	1	OBR
12181	137	47578	1	OBR
12182	137	47595	2	OBR
12183	137	47599	2	OBR
12184	137	47609	2	OBR
12185	137	47580	2	OBR
12186	137	47601	2	OBR
12187	137	47607	2	OBR
12188	137	47582	3	OBR
12189	137	47687	3	OBR
12190	137	47588	3	OBR
12191	137	47679	3	OBR
12192	137	47675	3	OBR
12193	137	47581	3	OBR
12194	137	47606	3	OBR
12195	137	47610	4	OBR
12196	137	47694	4	OBR
12197	137	47676	4	OBR
12198	137	47690	4	OBR
12199	137	47695	4	OBR
12200	137	47678	4	OBR
12201	137	47693	4	OBR
12202	137	47583	5	OBR
12203	137	47681	5	OBR
12204	137	47688	5	OBR
12205	137	47699	5	OBR
12206	137	47701	5	OBR
12207	137	47700	5	OBR
12208	137	47684	6	OBR
12209	137	47674	6	OBR
12210	137	47682	6	OBR
12211	137	47586	6	OBR
12212	137	47683	6	OBR
12213	137	47692	6	OBR
12214	137	47686	7	OBR
12215	137	47696	7	OBR
12216	137	47680	7	OBR
12217	137	47584	7	OBR
12218	137	47685	7	OBR
12219	137	47677	7	OBR
12220	137	47603	8	OBR
12221	137	47698	8	OBR
12222	137	47585	8	OBR
12223	137	47697	8	OBR
12224	137	47689	8	OBR
12225	137	47691	8	OBR
12226	137	47605	99	OPT
12227	137	47608	99	OPT
12228	137	47611	99	OPT
12229	137	47702	99	OPT
12230	137	47703	99	OPT
12231	138	51619	1	OBR
12232	138	51616	1	OBR
12233	138	51638	1	OBR
12234	138	52132	1	OBR
12235	138	51641	1	OBR
12236	138	51640	1	OBR
12237	138	51636	2	OBR
12238	138	52136	2	OBR
12239	138	47579	2	OBR
12240	138	52181	2	OBR
12241	138	52180	2	OBR
12242	138	51642	2	OBR
12243	138	51626	3	OBR
12244	138	52183	3	OBR
12245	138	47724	3	OBR
12246	138	52179	3	OBR
12247	138	52182	3	OBR
12248	138	47621	4	OBR
12249	138	47631	4	OBR
12250	138	52185	4	OBR
12251	138	52187	4	OBR
12252	138	52186	4	OBR
12253	138	47596	5	OBR
12254	138	52178	5	OBR
12255	138	51628	5	OBR
12256	138	52188	5	OBR
12257	138	51631	6	OBR
12258	138	47638	6	OBR
12259	138	52177	6	OBR
12260	138	51637	6	OBR
12261	138	52184	6	OBR
12262	138	51625	99	OPT
12263	138	51594	99	OPT
12264	138	47605	99	OPT
12265	138	51583	99	OPT
12266	138	52166	99	OPT
12267	138	47641	99	OPT
12268	138	52075	99	OPT
12269	138	52076	99	OPT
12270	138	52074	99	OPT
12271	139	51619	1	OBR
12272	139	51616	1	OBR
12273	139	51638	1	OBR
12274	139	52132	1	OBR
12275	139	51641	1	OBR
12276	139	51640	1	OBR
12277	139	52169	2	OBR
12278	139	51636	2	OBR
12279	139	52136	2	OBR
12280	139	47579	2	OBR
12281	139	52167	2	OBR
12282	139	51642	2	OBR
12283	139	52172	3	OBR
12284	139	47724	3	OBR
12285	139	52174	3	OBR
12286	139	52171	3	OBR
12287	139	52170	3	OBR
12288	139	47621	4	OBR
12289	139	51626	4	OBR
12290	139	52164	4	OBR
12291	139	52175	4	OBR
12292	139	52168	4	OBR
12293	139	52176	5	OBR
12294	139	47638	5	OBR
12295	139	52173	5	OBR
12296	139	52163	5	OBR
12297	139	51631	6	OBR
12298	139	47631	6	OBR
12299	139	52165	6	OBR
12300	139	51637	6	OBR
12301	139	51628	6	OBR
12302	139	51625	99	OPT
12303	139	51594	99	OPT
12304	139	47596	99	OPT
12305	139	47605	99	OPT
12306	139	51583	99	OPT
12307	139	52166	99	OPT
12308	139	47641	99	OPT
12309	139	52075	99	OPT
12310	139	52076	99	OPT
12311	139	52074	99	OPT
12312	140	52135	1	OBR
12313	140	52136	1	OBR
12314	140	47710	1	OBR
12315	140	52132	1	OBR
12316	140	47724	1	OBR
12317	140	47741	1	OBR
12318	140	47736	2	OBR
12319	140	47746	2	OBR
12320	140	47731	2	OBR
12321	140	47745	2	OBR
12322	140	47755	2	OBR
12323	140	47737	2	OBR
12324	140	52134	3	OBR
12325	140	52133	3	OBR
12326	140	52130	3	OBR
12327	140	47738	3	OBR
12328	140	52131	3	OBR
12329	140	47740	3	OBR
12330	140	47739	4	OBR
12331	140	52189	4	OBR
12332	140	47744	4	OBR
12333	140	52190	4	OBR
12334	140	47733	4	OBR
12335	140	47734	5	OBR
12336	140	52191	5	OBR
12337	140	47752	5	OBR
12338	140	47730	5	OBR
12339	140	47749	6	OBR
12340	140	47753	6	OBR
12341	140	52192	6	OBR
12342	140	47748	6	OBR
12343	140	47754	99	OPT
12344	140	52139	99	OPT
12345	140	47750	99	OPT
12346	140	44548	99	OPT
12347	140	47706	99	OPT
12348	140	47751	99	OPT
12349	140	52075	99	OPT
12350	140	52076	99	OPT
12351	140	52074	99	OPT
12352	140	47758	99	OPT
12353	141	52135	1	OBR
12354	141	52136	1	OBR
12355	141	47722	1	OBR
12356	141	47710	1	OBR
12357	141	52132	1	OBR
12358	141	47724	1	OBR
12359	141	47726	2	OBR
12360	141	47705	2	OBR
12361	141	47707	2	OBR
12362	141	47708	2	OBR
12363	141	47723	2	OBR
12364	141	52205	2	OBR
12365	141	47711	3	OBR
12366	141	47709	3	OBR
12367	141	47713	3	OBR
12368	141	47721	3	OBR
12369	141	52206	3	OBR
12370	141	47720	4	OBR
12371	141	47718	4	OBR
12372	141	47719	4	OBR
12373	141	47717	4	OBR
12374	141	52204	4	OBR
12375	141	52200	99	OPT
12376	141	44548	99	OPT
12377	141	47716	99	OPT
12378	141	52131	99	OPT
12379	141	51597	99	OPT
12380	141	52166	99	OPT
12381	141	51596	99	OPT
12382	141	51726	99	OPT
12383	141	47744	99	OPT
12384	141	52194	99	OPT
12385	141	47706	99	OPT
12386	141	47725	99	OPT
12387	141	51732	99	OPT
12388	141	51733	99	OPT
12389	141	52075	99	OPT
12390	141	52076	99	OPT
12391	141	52074	99	OPT
12392	141	51590	99	OPT
12393	142	52135	1	OBR
12394	142	52136	1	OBR
12395	142	47710	1	OBR
12396	142	52132	1	OBR
12397	142	47724	1	OBR
12398	142	47741	1	OBR
12399	142	47736	2	OBR
12400	142	47746	2	OBR
12401	142	47731	2	OBR
12402	142	47745	2	OBR
12403	142	47755	2	OBR
12404	142	47737	2	OBR
12405	142	52134	3	OBR
12406	142	52133	3	OBR
12407	142	52130	3	OBR
12408	142	52131	3	OBR
12409	142	47740	3	OBR
12410	142	47733	3	OBR
12411	142	47767	4	OBR
12412	142	47773	4	OBR
12413	142	47765	4	OBR
12414	142	47772	4	OBR
12415	142	47762	4	OBR
12416	142	47759	4	OBR
12417	142	47774	5	OBR
12418	142	47760	5	OBR
12419	142	47770	5	OBR
12420	142	47771	5	OBR
12421	142	52137	5	OBR
12422	142	47748	5	OBR
12423	142	52138	6	OBR
12424	142	52140	6	OBR
12425	142	47761	6	OBR
12426	142	47720	99	OPT
12427	142	52139	99	OPT
12428	142	47718	99	OPT
12429	142	44548	99	OPT
12430	142	47769	99	OPT
12431	142	47768	99	OPT
12432	142	52075	99	OPT
12433	142	52076	99	OPT
12434	142	52074	99	OPT
12435	143	51581	1	OBR
12436	143	52135	1	OBR
12437	143	52200	1	OBR
12438	143	52136	1	OBR
12439	143	47722	1	OBR
12440	143	47724	1	OBR
12441	143	52194	1	OBR
12442	143	52198	2	OBR
12443	143	52199	2	OBR
12444	143	51579	2	OBR
12445	143	47708	2	OBR
12446	143	47706	2	OBR
12447	143	52195	3	OBR
12448	143	47745	3	OBR
12449	143	47705	3	OBR
12450	143	47713	3	OBR
12451	143	51585	3	OBR
12452	143	47726	4	OBR
12453	143	51589	4	OBR
12454	143	52196	4	OBR
12455	143	51588	4	OBR
12456	143	47725	4	OBR
12457	143	52197	4	OBR
12458	143	51600	99	OPT
12459	143	47718	99	OPT
12460	143	51594	99	OPT
12461	143	51599	99	OPT
12462	143	51592	99	OPT
12463	143	51593	99	OPT
12464	143	47727	99	OPT
12465	143	51597	99	OPT
12466	143	52166	99	OPT
12467	143	47710	99	OPT
12468	143	51596	99	OPT
12469	143	47712	99	OPT
12470	143	52193	99	OPT
12471	143	47741	99	OPT
12472	143	51598	99	OPT
12473	143	51595	99	OPT
12474	143	52075	99	OPT
12475	143	52076	99	OPT
12476	143	52074	99	OPT
12477	143	51590	99	OPT
12478	144	52135	1	OBR
12479	144	52136	1	OBR
12480	144	47722	1	OBR
12481	144	47705	1	OBR
12482	144	47724	1	OBR
12483	144	51734	1	OBR
12484	144	47718	2	OBR
12485	144	52200	2	OBR
12486	144	51727	2	OBR
12487	144	51606	2	OBR
12488	144	51726	2	OBR
12489	144	51732	2	OBR
12490	144	52207	3	OBR
12491	144	47708	3	OBR
12492	144	51731	3	OBR
12493	144	51725	3	OBR
12494	144	51733	3	OBR
12495	144	51728	3	OBR
12496	144	52203	4	OBR
12497	144	47709	4	OBR
12498	144	51729	4	OBR
12499	144	47707	4	OBR
12500	144	52194	4	OBR
12501	144	51600	99	OPT
12502	144	52195	99	OPT
12503	144	51594	99	OPT
12504	144	51592	99	OPT
12505	144	51593	99	OPT
12506	144	52198	99	OPT
12507	144	51604	99	OPT
12508	144	52131	99	OPT
12509	144	52201	99	OPT
12510	144	52166	99	OPT
12511	144	47710	99	OPT
12512	144	51596	99	OPT
12513	144	47712	99	OPT
12514	144	52193	99	OPT
12515	144	47741	99	OPT
12516	144	51595	99	OPT
12517	144	52075	99	OPT
12518	144	52076	99	OPT
12519	144	52074	99	OPT
12520	144	51590	99	OPT
12521	145	52135	1	OBR
12522	145	52200	1	OBR
12523	145	47722	1	OBR
12524	145	51601	1	OBR
12525	145	51597	1	OBR
12526	145	51596	1	OBR
12527	145	51590	1	OBR
12528	145	52195	2	OBR
12529	145	51599	2	OBR
12530	145	52198	2	OBR
12531	145	47705	2	OBR
12532	145	51598	2	OBR
12533	145	52197	2	OBR
12534	145	51581	3	OBR
12535	145	51607	3	OBR
12536	145	51602	3	OBR
12537	145	52136	3	OBR
12538	145	51604	3	OBR
12539	145	52201	3	OBR
12540	145	52194	3	OBR
12541	145	47709	4	OBR
12542	145	51605	4	OBR
12543	145	47707	4	OBR
12544	145	52193	4	OBR
12545	145	47741	4	OBR
12546	145	52202	99	OPT
12547	145	47718	99	OPT
12548	145	51594	99	OPT
12549	145	51586	99	OPT
12550	145	52203	99	OPT
12551	145	51592	99	OPT
12552	145	51593	99	OPT
12553	145	52131	99	OPT
12554	145	51606	99	OPT
12555	145	52166	99	OPT
12556	145	47710	99	OPT
12557	145	52132	99	OPT
12558	145	47724	99	OPT
12559	145	47708	99	OPT
12560	145	47725	99	OPT
12561	145	52075	99	OPT
12562	145	52076	99	OPT
12563	145	52074	99	OPT
12564	146	52213	1	OBR
12565	146	52135	1	OBR
12566	146	52200	1	OBR
12567	146	52136	1	OBR
12568	146	47722	1	OBR
12569	146	47707	1	OBR
12570	146	52215	2	OBR
12571	146	52219	2	OBR
12572	146	51606	2	OBR
12573	146	47724	2	OBR
12574	146	51742	2	OBR
12575	146	52214	2	OBR
12576	146	52210	3	OBR
12577	146	51746	3	OBR
12578	146	51748	3	OBR
12579	146	47721	3	OBR
12580	146	51747	3	OBR
12581	146	52217	4	OBR
12582	146	52211	4	OBR
12583	146	52208	4	OBR
12584	146	51741	4	OBR
12585	146	51745	4	OBR
12586	146	52216	99	OPT
12587	146	47718	99	OPT
12588	146	51594	99	OPT
12589	146	52212	99	OPT
12590	146	52209	99	OPT
12591	146	51592	99	OPT
12592	146	51593	99	OPT
12593	146	47727	99	OPT
12594	146	52166	99	OPT
12595	146	47710	99	OPT
12596	146	47712	99	OPT
12597	146	51749	99	OPT
12598	146	47741	99	OPT
12599	146	47717	99	OPT
12600	146	52218	99	OPT
12601	146	47725	99	OPT
12602	146	52075	99	OPT
12603	146	52076	99	OPT
12604	146	52074	99	OPT
12605	147	51616	1	OBR
12606	147	51626	1	OBR
12607	147	51636	1	OBR
12608	147	51641	1	OBR
12609	147	51642	1	OBR
12610	147	51640	1	OBR
12611	147	51631	2	OBR
12612	147	51637	2	OBR
12613	147	47579	2	OBR
12614	147	51682	2	OBR
12615	147	47580	2	OBR
12616	147	51689	2	OBR
12617	147	51619	3	OBR
12618	147	51690	3	OBR
12619	147	51691	3	OBR
12620	147	51721	3	OBR
12621	147	47606	3	OBR
12622	147	51703	3	OBR
12623	147	51716	4	OBR
12624	147	51709	4	OBR
12625	147	51693	4	OBR
12626	147	47610	4	OBR
12627	147	51712	4	OBR
12628	147	51704	4	OBR
12629	147	51694	5	OBR
12630	147	52129	5	OBR
12631	147	51638	5	OBR
12632	147	51695	5	OBR
12633	147	51696	5	OBR
12634	147	51697	5	OBR
12635	147	52127	6	OBR
12636	147	51714	6	OBR
12637	147	51710	6	OBR
12638	147	51698	6	OBR
12639	147	51692	6	OBR
12640	147	52128	7	OBR
12641	147	51699	7	OBR
12642	147	51707	7	OBR
12643	147	51700	7	OBR
12644	147	51702	7	OBR
12645	147	51718	8	OBR
12646	147	52126	8	OBR
12647	147	51717	8	OBR
12648	147	51724	8	OBR
12649	147	51705	8	OBR
12650	147	51713	8	OBR
12651	147	51594	99	OPT
12652	147	47595	99	OPT
12653	147	47605	99	OPT
12654	147	51583	99	OPT
12655	147	51719	99	OPT
12656	147	51708	99	OPT
12657	147	51715	99	OPT
12658	147	51723	99	OPT
12659	147	51711	99	OPT
12660	147	52124	99	OPT
12661	147	52125	99	OPT
12662	147	52075	99	OPT
12663	147	52076	99	OPT
12664	147	52074	99	OPT
12665	148	51616	1	OBR
12666	148	51636	1	OBR
12667	148	51629	1	OBR
12668	148	51641	1	OBR
12669	148	51642	1	OBR
12670	148	51618	1	OBR
12671	148	51619	2	OBR
12672	148	51620	2	OBR
12673	148	51638	2	OBR
12674	148	51630	2	OBR
12675	148	51609	2	OBR
12676	148	51640	2	OBR
12677	148	51625	3	OBR
12678	148	51622	3	OBR
12679	148	47629	3	OBR
12680	148	51633	3	OBR
12681	148	51628	3	OBR
12682	148	47607	3	OBR
12683	148	51626	4	OBR
12684	148	51632	4	OBR
12685	148	51637	4	OBR
12686	148	51614	4	OBR
12687	148	51617	4	OBR
12688	148	47580	4	OBR
12689	148	47630	5	OBR
12690	148	51610	5	OBR
12691	148	47619	5	OBR
12692	148	47615	5	OBR
12693	148	51611	5	OBR
12694	148	51631	6	OBR
12695	148	51621	6	OBR
12696	148	51615	6	OBR
12697	148	47627	6	OBR
12698	148	47634	6	OBR
12699	148	47643	6	OBR
12700	148	47638	7	OBR
12701	148	51623	7	OBR
12702	148	47610	7	OBR
12703	148	47622	7	OBR
12704	148	51612	7	OBR
12705	148	47606	7	OBR
12706	148	47621	8	OBR
12707	148	51624	8	OBR
12708	148	51627	8	OBR
12709	148	51639	8	OBR
12710	148	51613	8	OBR
12711	148	47635	99	OPT
12712	148	47626	99	OPT
12713	148	51594	99	OPT
12714	148	47595	99	OPT
12715	148	47596	99	OPT
12716	148	47631	99	OPT
12717	148	47605	99	OPT
12718	148	51583	99	OPT
12719	148	47637	99	OPT
12720	148	52124	99	OPT
12721	148	52125	99	OPT
12722	148	47641	99	OPT
12723	148	52075	99	OPT
12724	148	52076	99	OPT
12725	148	52074	99	OPT
12726	149	51616	1	OBR
12727	149	51626	1	OBR
12728	149	51636	1	OBR
12729	149	51670	1	OBR
12730	149	51686	1	OBR
12731	149	51641	1	OBR
12732	149	51642	1	OBR
12733	149	51631	2	OBR
12734	149	51648	2	OBR
12735	149	51682	2	OBR
12736	149	51678	2	OBR
12737	149	51683	2	OBR
12738	149	51654	2	OBR
12739	149	51685	3	OBR
12740	149	51687	3	OBR
12741	149	51688	3	OBR
12742	149	51639	3	OBR
12743	149	47681	3	OBR
12744	149	51649	3	OBR
12745	149	51684	3	OBR
12746	149	51651	4	OBR
12747	149	51656	4	OBR
12748	149	47683	4	OBR
12749	149	51661	4	OBR
12750	149	51645	4	OBR
12751	149	51663	4	OBR
12752	149	51667	4	OBR
12753	149	52121	5	OBR
12754	149	51676	5	OBR
12755	149	51679	5	OBR
12756	149	51644	5	OBR
12757	149	51653	5	OBR
12758	149	51646	5	OBR
12759	149	52122	6	OBR
12760	149	51665	6	OBR
12761	149	51671	6	OBR
12762	149	51672	6	OBR
12763	149	47606	6	OBR
12764	149	51677	6	OBR
12765	149	51680	6	OBR
12766	149	52120	7	OBR
12767	149	51637	7	OBR
12768	149	51657	7	OBR
12769	149	51652	7	OBR
12770	149	51655	7	OBR
12771	149	52123	8	OBR
12772	149	47610	8	OBR
12773	149	51669	8	OBR
12774	149	51674	8	OBR
12775	149	51675	8	OBR
12776	149	51664	8	OBR
12777	149	51666	8	OBR
12778	149	51594	99	OPT
12779	149	47595	99	OPT
12780	149	47605	99	OPT
12781	149	51583	99	OPT
12782	149	51638	99	OPT
12783	149	51647	99	OPT
12784	149	51681	99	OPT
12785	149	47689	99	OPT
12786	149	47580	99	OPT
12787	149	52124	99	OPT
12788	149	52125	99	OPT
12789	149	52075	99	OPT
12790	149	52076	99	OPT
12791	149	52074	99	OPT
12792	149	51640	99	OPT
\.


--
-- Data for Name: myentity; Type: TABLE DATA; Schema: public; Owner: winfor
--

COPY public.myentity (id, field) FROM stdin;
\.


--
-- Name: alunoentity_seq; Type: SEQUENCE SET; Schema: public; Owner: winfor
--

SELECT pg_catalog.setval('public.alunoentity_seq', 1, false);


--
-- Name: cursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winfor
--

SELECT pg_catalog.setval('public.cursos_id_seq', 149, true);


--
-- Name: matrizes_curriculares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winfor
--

SELECT pg_catalog.setval('public.matrizes_curriculares_id_seq', 149, true);


--
-- Name: matrizes_disciplinas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: winfor
--

SELECT pg_catalog.setval('public.matrizes_disciplinas_id_seq', 12792, true);


--
-- Name: myentity_seq; Type: SEQUENCE SET; Schema: public; Owner: winfor
--

SELECT pg_catalog.setval('public.myentity_seq', 1, false);


--
-- Name: cursos cursos_pkey; Type: CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.cursos
    ADD CONSTRAINT cursos_pkey PRIMARY KEY (id);


--
-- Name: disciplinas disciplinas_pkey; Type: CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.disciplinas
    ADD CONSTRAINT disciplinas_pkey PRIMARY KEY (id);


--
-- Name: matrizes_curriculares matrizes_curriculares_pkey; Type: CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_curriculares
    ADD CONSTRAINT matrizes_curriculares_pkey PRIMARY KEY (id);


--
-- Name: matrizes_disciplinas matrizes_disciplinas_pkey; Type: CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_disciplinas
    ADD CONSTRAINT matrizes_disciplinas_pkey PRIMARY KEY (id);


--
-- Name: myentity myentity_pkey; Type: CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.myentity
    ADD CONSTRAINT myentity_pkey PRIMARY KEY (id);


--
-- Name: cursos_cod_curso_ux; Type: INDEX; Schema: public; Owner: winfor
--

CREATE UNIQUE INDEX cursos_cod_curso_ux ON public.cursos USING btree (cod_curso);


--
-- Name: disciplinas_codigo_ux; Type: INDEX; Schema: public; Owner: winfor
--

CREATE UNIQUE INDEX disciplinas_codigo_ux ON public.disciplinas USING btree (codigo);


--
-- Name: disciplinas_prequisitos_ux; Type: INDEX; Schema: public; Owner: winfor
--

CREATE UNIQUE INDEX disciplinas_prequisitos_ux ON public.disciplinas_prequisitos USING btree (disciplina_id, prequisito_id);


--
-- Name: matrizes_disciplinas_mat_disc_semestre; Type: INDEX; Schema: public; Owner: winfor
--

CREATE UNIQUE INDEX matrizes_disciplinas_mat_disc_semestre ON public.matrizes_disciplinas USING btree (matriz_curricular_id, disciplina_id, semestre);


--
-- Name: disciplinas_prequisitos disciplinas_prequisitos_disciplina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.disciplinas_prequisitos
    ADD CONSTRAINT disciplinas_prequisitos_disciplina_id_fkey FOREIGN KEY (disciplina_id) REFERENCES public.disciplinas(id);


--
-- Name: disciplinas_prequisitos disciplinas_prequisitos_prequisito_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.disciplinas_prequisitos
    ADD CONSTRAINT disciplinas_prequisitos_prequisito_id_fkey FOREIGN KEY (prequisito_id) REFERENCES public.disciplinas(id);


--
-- Name: matrizes_curriculares matrizes_curriculares_curso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_curriculares
    ADD CONSTRAINT matrizes_curriculares_curso_id_fkey FOREIGN KEY (curso_id) REFERENCES public.cursos(id);


--
-- Name: matrizes_disciplinas matrizes_disciplinas_disciplina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_disciplinas
    ADD CONSTRAINT matrizes_disciplinas_disciplina_id_fkey FOREIGN KEY (disciplina_id) REFERENCES public.disciplinas(id);


--
-- Name: matrizes_disciplinas matrizes_disciplinas_matriz_curricular_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: winfor
--

ALTER TABLE ONLY public.matrizes_disciplinas
    ADD CONSTRAINT matrizes_disciplinas_matriz_curricular_id_fkey FOREIGN KEY (matriz_curricular_id) REFERENCES public.matrizes_curriculares(id);


--
-- PostgreSQL database dump complete
--

